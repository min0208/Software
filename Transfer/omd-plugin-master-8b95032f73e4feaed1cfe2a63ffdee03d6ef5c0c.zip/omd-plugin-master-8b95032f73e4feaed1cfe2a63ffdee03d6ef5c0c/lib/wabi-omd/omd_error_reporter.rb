# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd error reporter

# OMDErrorReporter is a class to report error from OMD
class OMDErrorReporter
  attr_accessor :index, :subject, :error_msg
  ERR = {
    no_connect: 'OMD Proxy is not connected with IP:%data% PORT:%data%',
    invalid_msg_field: 'Field: %data% is invalid for message %data%(%data%)',
    no_msgtype: 'Field MsgType is not included in your sent out table',
    invalid_rg: 'Group name: %data% is not one of the valid repeating group names: %data% ',
    invalid_rg_field: 'Field name: %data% is not one of the valid fields in group %data% : %data% ',
    invalid_subject: 'Subject: %data% is not one of the valid subjects: %data%',
    invalid_timestamp: 'Timestamp: %data% is not existing',
    no_wabi: 'WABI is not invoked in your env.rb',
    wrong_option: 'Option: %data% is wrong. It should be: from <TS1> to <TS2> in sequence',
    no_response_message_exact: 'No match reponse for exactaly matched repeating group',
    multiple_match_exact: 'There are mutiple messages match for repeating group (exactly matching)',
    missing_package: 'Missing package: %data%',
    invalid_template: 'Invalid template name: %data%',
    missing_field: 'Missing field: %data%',
  }.freeze
  def initialize
  end

  # trigger the execption
  def trigger
    @error_msg = "Line Number: #{@index}\n" + @error_msg  if @index
    @error_msg = "Product: #{@subject}\n" + @error_msg if @subject
    raise @error_msg
  end

  # @param id [Symbol] error message ID
  # @param param [Array<String>] input parameters
  def report(id, param = nil)
    if ERR[id]
      msg = ERR[id].clone
      # replace the place holder
      if param
        param.each do |p|
          msg['%data%'] = p.to_s if msg['%data%']
        end
      end
      raise msg
    end
  end

  # clean the index and subject info
  def clean
    @index = nil
    @subject = nil
  end
end
