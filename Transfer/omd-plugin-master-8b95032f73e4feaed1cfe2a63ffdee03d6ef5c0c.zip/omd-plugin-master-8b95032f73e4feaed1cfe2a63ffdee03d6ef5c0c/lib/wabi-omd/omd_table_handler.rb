# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd table handler

# OMDTableHandler is class for handling OMD table
class OMDTableHandler
  #      rg_handler: repeat group handler
  # refresh_handler: refresh handler
  #  scenario_stime: scenario start time
  attr_accessor :rg_handler, :refresh_handler, :scenario_stime

  # constructor
  def initialize(proxy, cmp)
    @proxy            = proxy
    @cmp              = cmp == 'Y' ? true : false
    @ins              = false
    @rg_handler       = nil
    @refresh_handler  = nil
    @scenario_stime   = nil
    @subjects         = {}
  end

  #def set_refresh_handler(refresh_handler)
  #  @refresh_handler = refresh_handler
  #end

  # @param sub [String] subjec tin the table
  # add subjects
  def set_subject(sub)
    subjects = sub.strip.split ','
    subjects.each do |sub|
      sub = sub.strip
      valid_subs = $product_config.get_valid_subjects
      if valid_subs.include? sub
        @subjects[sub] = $product_config.get_product sub
      else
        # invalid subject name
        $error_handler.report(:invalid_subject, [sub, valid_subs.join(',')])
      end
    end
  end

  # @param options [String] empty| from A to B | from A
  # set time range
  def set_timerange(options)
    options = options.strip
    # handle in sequence
    if options.include? 'in sequence'
      @ins = true
      # remove in sequence
      options['in sequence'] = ''
      options = options.strip
    end
    # handle exactly
    if options.include? 'exactly'
      @proxy.exact = true
      options['exactly'] = ''
      options = options.strip
    else
      @proxy.exact = false
    end
    # handle afterwards
    if options.include? 'afterwards'
      # set the last match as the start time
      if $omd_latest_match
        @proxy.stime = $omd_latest_match if $omd_latest_match
      end
      # remove afterwards
      options['afterwards'] = ''
      options = options.strip
    end
    ## handle from and to
    $error_handler.report(:no_wabi, []) unless $timestamps
    arr = options.split(' ')
    from_ts = nil
    to_ts = nil
    # get from TS
    index_of_from = (arr.index 'from') || (arr.index 'after')
    if index_of_from
      if arr[index_of_from + 1]
        from_ts = arr[index_of_from + 1]
        if $timestamps[from_ts]
          from_ts = $timestamps[from_ts]
        else
          # error handling
          $error_handler.report(:invalid_timestamp, [from_ts])
        end
      else
        # error handling
        $error_handler.report(:wrong_option, [options])
      end
    end
    # get to TS
    if arr.index 'to'
      if arr[arr.index('to') + 1]
        to_ts = arr[arr.index('to') + 1]
        if $timestamps[to_ts]
          to_ts = $timestamps[to_ts]
        else
          # error handling
          $error_handler.report(:invalid_timestamp, [to_ts])
        end
      else
        # error handling
        $error_handler.report(:wrong_option, [options])
      end
    end
    # overwrite the default proxy start and
    # end time
    # default start time
    @dstime = @proxy.stime = OMDUtil.get_time(from_ts) if from_ts
    # default end time
    @detime = @proxy.etime = OMDUtil.get_time(to_ts) if to_ts
  end

  # @response_hash [Hash]
  # get the proxy reponse
  def get_response(response_hash = nil)
    @subjects.each do |sub, product|
      # set the default start time
      if response_hash
        @proxy.stime = response_hash[sub]
        # update the time iterator of the product
        response_hash[sub] = OMDUtil.get_time(Time.now)
      end
      # set the proxy product
      @proxy.product = product
      @proxy.send_get_response
    end
  end

  # check if current is a refresh product
  # return true if it is a refresh product
  #  otherwise return false
  def is_refresh_product(sub)
    if !@refresh_handler.nil? and @refresh_handler.is_refresh_product(sub)
      return true
    end
    return false
  end


  def bind_refresh_cycle_to_ref(ref)
    # record refresh time range to ref
    if ref
      ref = ref.strip if ref.to_s.size > 0
      $timestamps["#{ref}.RefreshStartTime"] = Time.parse @proxy.stime
      $timestamps["#{ref}.RefreshEndTime"]   = Time.parse @proxy.etime
    end
  end


  # @param row, test case row
  # @param 
  # process refresh start and end time,
  # 
  def handle_refresh(sub, row)

    # first check from table, if not, then query proxy / search back
    # gain corresponding refresh channel id from realtime channel id, based on the csv config
    # like realtime ch10 => refresh ch510
    @refresh_handler.process_refresh_channel_id(sub, row)

    if handle_from_timestamp(row) && handle_to_timestamp(row)
      $world.puts "Refresh search time range set by From / To column:" \
        "start_time=#{@proxy.stime}," \
        "end_time=#{@proxy.etime}," \
        "channelID=#{row['ChannelID']}" if $world
    else
      if !@refresh_handler.nil?

        refresh_complete = @refresh_handler.get_channel_refresh_complete(row['ChannelID'])
        if !refresh_complete.nil?
          @proxy.stime = OMDUtil.get_time refresh_complete['PREV_COMP_TIME']
          @proxy.etime = OMDUtil.get_time refresh_complete['LAST_COMP_TIME']
        # else
        #   pass
        #   # some logging complain about uncompleted refresh ?
        end
      # else
      #   pass
      #   # some logging complain about nil handler ?
      end
      $world.puts "Refresh search time range set by query proxy:" \
        "start_time=#{@proxy.stime}," \
        "end_time=#{@proxy.etime}," \
        "channelID=#{row['ChannelID']}" if $world
    end    

    if ! @proxy.stime or ! @proxy.etime
      raise "faile to check refresh cycle"
    end
    
    bind_refresh_cycle_to_ref(row["ResponseRef"])

  end

  # @param row, test case row
  # 
  # process test row start time
  #  based on the given From input
  def handle_from_timestamp(row)
    # handle from and to column in row
    tag = 'From'
    ts  = row[tag]
    if ts
      unless ts.empty?
        # invalid timestamp
        $error_handler.report(:invalid_timestamp, [ts]) unless $timestamps[ts]
        @proxy.stime = OMDUtil.get_time $timestamps[ts]
        row.delete tag
        return true
      end
    end

    return false
  end

  # @param row, test case row
  # 
  # process test row end time
  #  based on the given To input
  def handle_to_timestamp(row)
    # check to timestamp
    tag = 'To'
    ts = row[tag]
    if ts
      unless ts.empty?
        # invalid timestamp
        $error_handler.report(:invalid_timestamp, [ts]) unless $timestamps[ts]
        @proxy.etime = OMDUtil.get_time $timestamps[ts]
        row.delete tag
        return true
      end
    end

    return false
  end

  # @param row, test case row
  # 
  # process test row start and end time
  #  based on the given From/To input
  def handle_realtime(row)
    # handle from and to column in row
    handle_from_timestamp(row)
    handle_to_timestamp(row)
  end

  # param row, test case hash
  #
  # 1. process alias for the test row
  # 2. process template for the test row
  # 3. validate the test row
  # 4. process repeating groups for the test row
  def pre_process_test_row(row)
    # handle alias
    # OMDUtil::Logger.info 'handle alias'
    row = $omd_alias_handler.handle(row) if $omd_alias_handler
    # handle template
    # OMDUtil::Logger.info 'handle template'
    row = $omd_template_handler.handle(row) if $omd_template_handler
    # handle validation
    # OMDUtil::Logger.info 'handle validation'
    row = $omd_validator.validate(row) if $omd_validator
    # handle repeating group
    # OMDUtil::Logger.info 'handle repeating group'
    row = @rg_handler.handle(row) if @rg_handler.has_group?

    return row
  end

  # @param tablehash [Array<hash>] hash of the AST::DATATABLE
  # @param 
  # submit the table
  def submit(tablehash)
    ref_hash = {}
    @subjects.each do |sub, product|
      @proxy.product         = product
      @proxy.stime           = @scenario_stime
      @proxy.stime           = @dstime if @dstime
      @proxy.etime           = @detime if @detime
      $error_handler.subject = sub
      index = 1
      tablehash.each do |row|
        $error_handler.index = index
        # assign the default start time and end time
        @proxy.stime = @dstime if @dstime && (@ins == false)
        @proxy.etime = @detime if @detime
        # pre process test case row
        row      = row.clone
        template = row['Template']
        row      = pre_process_test_row(row)
        # handle real-time & refresh
        if is_refresh_product(sub)
          handle_refresh(sub, row)
        else
          handle_realtime(row)
        end
        # check missing package
        @proxy.check_missing_package if @cmp
        # send row & store the ref result
        ref_result = @proxy.send_out(row, template, @ins)
        ref_hash   = ref_hash.merge ref_result if ref_result
        index += 1
      end
    end
    ref_hash
  end
end
