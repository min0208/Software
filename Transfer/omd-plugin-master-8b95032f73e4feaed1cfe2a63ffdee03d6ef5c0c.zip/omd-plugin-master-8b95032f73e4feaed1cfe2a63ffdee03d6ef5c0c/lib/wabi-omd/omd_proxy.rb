# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd proxy

require 'socket'
require 'json'
require 'time'
# OMDProxy class function for omdProxy 
class OMDProxy
  # stime: start time
  # etime: end time
  # product: product time
  # timeout: timeout
  # exact?: if check the repeating group sequence
  attr_accessor :stime, :etime, :product, :timeout, :exact
  # @param ip [String] omd proxy ip
  # @param port [Int] omd port number
  def initialize(ip, port)
    @ip = ip
    @port = port
    # default timeout is 30 seconds
    @timeout = 30
  end

  # @param hash [Hash] data row hash after alias, template and validate
  # @return [Hash] result hash return from omd-proxy
  def send_out(row, template = nil, ins = false)
    $error_handler.error_msg = "Start Time: #{@stime}\nEnd Time: #{@etime}\nMatch Pattern: #{row}\n" if $error_handler
    result = nil
    if row.keys.include? 'Count'
      num = send_count(row)
      expcted_count = row['Count']

      if expcted_count.strip == 'any' or expcted_count.strip == '*'
        $world.puts  "Count only: #{template} count = #{num}"
      elsif num.strip != expcted_count.strip && $error_handler
        $error_handler.error_msg += "Expected #{template} count:#{expcted_count}; Actual count:#{num} "
        $error_handler.trigger
      else
        $world.puts  "Count success: #{template} count = #{num}"
      end
    elsif @exact
      # match repeating group
      result = send_match_exact(row, ins)
    else
      # check the first met entry
      if row['FirstEntry']
        first_entry = row['FirstEntry']
        row.delete 'FirstEntry'
        return send_first_match(row) if first_entry.downcase == 'true'
      end
      result = send_match(row, ins)
    end
    return result
  end

  # @param ref_row [Hash] table row
  def send_first_match(ref_row)
    row = ref_row.clone
    message = { 'product' => @product, 'action' => 'count', 'start_time' => @stime, 'message' => {}, 'timeout' => @timeout.to_s }
    message['end_time'] = @etime if @etime
    message['channel'] = row['ChannelID'] if row['ChannelID']
    message['message']['fields'] = OMDUtil.get_checking_fields row
    res = send_raw(message.to_json)
    res = JSON.parse res
    #find the match
    if res['status'] == 'success' and res['count'] != '0'
      seqs = res['messages'].scan(/;SeqNum=\d*;/)
      # get rid of "SeqNum"
      seqs.collect! {|x| x[8..-2]}
      seq_num = seqs.min
      row['SeqNum'] = seq_num
      # get message time
      times = res['messages'].scan(/MsgTime=\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d.\d\d\d\d\d\d;/)
      times.collect! {|x| x[8..-1]}
      end_time = times.min
      if row['MsgType'] == '100'
        # sequence reset
        return send_match(row, false,nil,end_time)
      else
        # not sequence reset 
        return send_match(row, false)
      end
    else
    # not found
      return send_match(row, false)
    end
  end

  # @param ref_row [Hash] table row
  # @return [String] count number
  def send_count(ref_row)
    row = ref_row.clone
    row.delete 'Count' if row['Count']
    message = { 'product'    => @product,
                'action'     => 'count',
                'start_time' => @stime, 
                'message'    => {},
                'timeout'    => @timeout.to_s }
    message['end_time'] = @etime if @etime
    message['channel']  = row['ChannelID'] if row['ChannelID']
    message['message']['fields'] = OMDUtil.get_checking_fields row
    res = send_raw(message.to_json)
    res = JSON.parse res
    return res['count'] if res['status'] == 'success'
  end

  # print the response messages regarding products
  # and in a time range
  def send_get_response
    message = { 'product'    => @product,
                'action'     => 'count',
                'start_time' => @stime, 
                'message'    => { 'fields' => [{ 'MsgType' => '(.*)' }] },
                'timeout'    => @timeout.to_s }
    # set the end time
    message['end_time'] = @etime if @etime
    # parse the result
    res = send_raw(message.to_json)
    res = JSON.parse res
    # if responde exist,
    if res['messages']
      # output product name
      $world.puts @product.to_s + ' retrieve following messages:' if $world
      # output pdf
      sub    = $product_config.get_subject @product
      tables = []
      res['messages'].split("\n").each do |msg|
        msg = Utils.convert_omd_msg msg
        msg = Utils.handle_mmdh_msg msg 
        tables << { 'Title'       => "Received #{sub} message fields",
                    'NumOfColumn' => 4,
                    'Template'    => '',
                    'TextMsg'     => msg,
                    'BinMsg'      => ''}
      end
      OMDUtil.print_pdf_table(tables)
    end
  end

  # @param stime [String] start time
  # @param etime [String] end time
  # @return [JSON] return message
  # check if there is missing_package
  def check_missing_package
    message = { 'product' => @product, 'action' => 'retrieve', 'start_time' => @stime, 'message' => {} }
    message['end_time'] = @etime if @etime
    message['message']['fields'] = [{ 'GapDetected' => 'Y' }]
    res = JSON.parse send_raw(message.to_json)
    if (res['status'] == 'failed')
      return
    else
      $error_handler.report(:missing_package, [res.to_s])
    end
  end

  # @param row [Hash] table row
  # @return [JSON] return message
  # send out a row message for message retrieve
  def send_retrieve(row)
    message = { 'product' => @product, 'action' => 'retrieve', 'start_time' => @stime, 
      'message' => {}, 'timeout' => @timeout.to_s }
    message['end_time'] = @etime if @etime
    message['channel'] = row['ChannelID'] if row['ChannelID']
    message['message']['fields'] = OMDUtil.get_checking_fields row
    JSON.parse send_raw(message.to_json)
  end

  # @param row [Hash] table row
  # @param ins [Boolean] if in sequence check
  # @param result [Hash] stored received result
  # send out a row message for match checking
  def send_match(row, ins = false, start_time=nil,end_time=nil)
    # result hash for REsponseRef
    result = {}
    if row['ResponseRef']
      ref = row['ResponseRef'].strip if row['ResponseRef'].to_s.size > 0
      row.delete 'ResponseRef'
    end
    message = { 'product' => @product, 'action' => 'match', 'start_time' => @stime, 
      'message' => {}, 'timeout' => @timeout.to_s }
    message['end_time'] = @etime if @etime
    message['start_time'] = start_time if start_time
    message['end_time'] = end_time if end_time
    message['channel'] = row['ChannelID'] if row['ChannelID']
    message['message']['fields'] = OMDUtil.get_checking_fields row
    
    res = send_raw(message.to_json)
    res = JSON.parse res
    if res['status'] == 'success'
      channel  = res['message']['channel']
      msg_time = res['message']['time']
      m_fields = res['message']['fields']
      # change the latest match time
      $omd_latest_match = msg_time
      # sequence checking
      @stime = msg_time if ins
      # parse message
      msg              = OMDUtil.parse_message(channel, msg_time, m_fields, ref, result)
      highlighted_keys = OMDUtil.get_highlighted_keys row
      omd_msg          = OMDUtil.convert_omd_msg(msg, highlighted_keys)
      omd_msg          = OMDUtil.handle_mmdh_msg(omd_msg, @product)
      # output pdf
      sub    = $product_config.get_subject @product
      tables = [ { 'Title'       => "Received #{sub} message fields",
                   'NumOfColumn' => 4,
                   'Template'    => highlighted_keys.join(','),
                   'TextMsg'     => omd_msg,
                   'BinMsg'      => res['message']['binary'] } ]
      OMDUtil.print_pdf_table(tables)
    else
      # handle identical multicple match messages
      if OMDUtil.identical_multimatch? res and $world
        highlighted_keys = OMDUtil.get_highlighted_keys row
        omd_msg          = OMDUtil.get_identical_msg res['error_msg']
        omd_msg          = OMDUtil.handle_mmdh_msg(omd_msg, @product)
        # output pdf
        sub = $product_config.get_subject @product
        tables = [ { 'Title'       => "Received #{sub} message fields",
                     'NumOfColumn' => 4,
                     'Template'    => highlighted_keys.join(','),
                     'TextMsg'     => omd_msg,
                     'BinMsg'      => '' } ]
        OMDUtil.print_pdf_table(tables)
      else
        # not found
        $error_handler.error_msg += ('error msg:' + res['error_msg'])
        # raise the error
        $error_handler.trigger
      end
    end
    result
  end

  # @param row [Hash] table row
  # @param ins [Boolean] if in sequence check
  # @param return_result [Hash] return hash for response ref
  # send out a row message for match checking
  def send_match_exact(row, ins = false)
    result = get_exact_result(row, @stime)
    return_result = []
    if result.nil?
      $error_handler.error_msg += "error msg: no matched message found in exactly match. "\
        "search pattern: start_time: #{@stime} end_time: #{@etime} row: #{row}"
      $error_handler.trigger
    elsif result.size == 1
      row['SeqNum'] = result.first['message']['fields'].first['SeqNum']
      return_result = send_match(row, ins)
    else
      $error_handler.error_msg += "error msg: multiple matched messages found in exactly match."\
        "search pattern: start_time: #{@stime} end_time: #{@etime} row: #{row}"
      $error_handler.trigger
    end
    return return_result
  end

  # @param row [Hash] message table row
  # @stime [TS] start timestamp
  # @return [Array] the set of the found messages
  # get the exactly match result array
  def get_exact_result(row, stime)
    result = []
    message = { 'product' => @product, 'action' => 'retrieve', 'start_time' => stime, 
      'message' => {}, 'timeout' => @timeout.to_s }
    message['end_time'] = @etime if @etime
    message['channel'] = row['ChannelID'] if row['ChannelID']
    message['message']['fields'] = OMDUtil.get_checking_fields row
    res_raw = send_raw(message.to_json)
    res = JSON.parse res_raw
    if (res['status'] == 'success')
      result << res if exact_match?(res_raw, row)
      temp = get_exact_result(row, OMDUtil.get_next_time(res['message']['time']))
      result += temp if temp
    else
      return nil
    end
    result
  end

  # @param msg [String] raw return message from proxy
  # @row [Hash] message table row
  # @return [boolean] is the message exactly match the row
  # check if the message exactly match the row especially for repeating group
  def exact_match?(msg, row)
    # clone the message
    msg = msg.clone
    checked_groups = []
    row.each do |_k, v|
      checked_groups << v if v.class == Array
    end

    checked_groups.each do |group|
      group_index = 0
      group.each do |hash|
        hash_index = []
        hash.each do |k, v|
          check_str = "\"#{k}\": \"#{v}\""
          if msg.index check_str
            temp_index = msg.index check_str
            # remove the found pattern
            msg[check_str] = ''
            # save the hash index
            hash_index << temp_index
          else
            return false
          end
        end
        # update the group_index
        hash_index.sort!
        return false if hash_index.first < group_index
        group_index = hash_index.last
      end
    end
    true
  end

  # @param message [String] raw message
  # @return [String] json message back
  # send raw message in string format
  def send_raw(message)
    $logger.debug "sent: " + JSON.pretty_generate(JSON.parse message)
    $proxy_spent_time ||= 0
    proxy_start = Time.now

    begin
      proxy = TCPSocket.new(@ip, @port)
    rescue
      $error_handler.report(:no_connect, [@ip, @port])
    end

    # socket conversation
    proxy.puts message
    res = ''
    while line = proxy.gets
      res += line
    end
    proxy.close

    spent_time = Time.now - proxy_start
    $logger.debug "receive: " + res
    $proxy_spent_time += spent_time
    res
  end

  # @param id [String] test case id
  # @param name [String] test case name
  # @return [String] proxy confirmed message
  def send_sce_start(id, name)
    message = { 'action' => 'log' }
    message['message'] = { 'fields' => [{'info' => "Test Started: Case=#{id};Title=#{name};"}] }

   # msg = "{\"action\" : \"log\" , \"message\" : { \"fields\" :[ {\"info\" : \"Test Started: Case=#{id};Title=#{name};\"}]}}"
    begin
      # if the prxy is available
      res = send_raw message.to_json
      return res
    rescue
      # if the proxy is not connected, in env, just let it go
      return nil
    end
  end

  # @param id [String] test case id
  # @param name [String] test case name
  # @return [String] proxy confirmed message
  def send_sce_end(id, name)
    message = { 'action' => 'log' }
    message['message'] = { 'fields' => [{'info' => "Test Finished: Case=#{id};Title=#{name};"}] }
    #msg = "{\"action\" : \"log\" , \"message\" : { \"fields\" :[ {\"info\" : \"Test Finished: Case=#{id};Title=#{name};\"}]}}"
    begin
      # if the prxy is available
      res = send_raw message.to_json
      return res
    rescue
      # if the proxy is not connected, in env, just let it go
      return nil
    end
  end

  def send_refresh_complete(channel)
    message = { 'action' => 'refresh', 'channel' => channel, 'timeout' => @timeout.to_s }
    res_raw = send_raw(message.to_json)
    res     = JSON.parse res_raw
    return res if (res['status'] == 'success')
    if (res['status'] == 'success')
      return res
    end

    return nil
  end
end
