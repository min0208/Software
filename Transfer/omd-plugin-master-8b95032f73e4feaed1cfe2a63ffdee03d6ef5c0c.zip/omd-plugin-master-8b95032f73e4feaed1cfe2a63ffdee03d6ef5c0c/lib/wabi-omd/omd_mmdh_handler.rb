# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd mmdh support handler

require 'json'

# OMD-MMDH handler class
class OMDMMDHHandler
  # timeout: process timed out
  # type: process type
  # duration: time range for searching message
  # logon_until_success_ind: logon until success indicator
  attr_accessor :timeout, :type, :duration, :logon_until_success_ind, :case_id

  def initialize(project, proxy)
    @proxy                    = proxy
    @timeout                  = 30
    @duration                 = 1
    @logon_until_success_ind  = true
    @subjects                 = {}
    url = "#{File.dirname(__FILE__)}/../../config/#{project}/product_message_map.csv"
    @product_msg_map       = load_product_msg_map(url)
    @session_logon_success = ['0','1','2','101']
    @session_status = { '0' => 'Session active',
                        '1' => 'Session password changed',
                        '2' => 'Session password due to expire',
                        '3' => 'New session password does not comply with policy',
                        '5' => 'Invalid username or password',
                        '6' => 'Account locked',
                        '8' => 'Password expired',
                        '100' => 'Password not changed (changed within 24 hrs)',
                        '101' => 'Session Active - refresh required',
                        '104' => 'Already Connected',
                        '105' => 'Client Public Key Generation Issue' }
    @refresh_status = { '0' => 'Request fully processed' }
  end

  # handle subjects
  def set_subject(sub)
    subjects = sub.strip.split ','
    subjects.each do |sub|
      sub = sub.strip
      valid_subs = $product_config.get_valid_subjects
      if valid_subs.include? sub
        @subjects[sub] = $product_config.get_product sub
      else
        # invalid subject name
        $error_handler.report(:invalid_subject, [sub, valid_subs.join(',')])
      end
    end
  end

  # load product and message type map from csv
  def load_product_msg_map(csv)
    hash = {}
    CSV.foreach(csv) do |row|
      next if !row[0].nil? && row[0].match(/^ *#/)
      hash[row[0]] = row[1..-1]
    end
    hash
  end

  # get field/value column in row
  def get_fields(row)
    fields = []
    row.each do |k, v|
      if v.class == Array
        v.each do |e|
          e = e.map { |k, v| "#{k}=#{v}" }.join ','
          fields << { k => e }
        end
      else
        fields << { k => v }
      end
    end
    fields
  end

  def get_msg_fields_hash(msg)
    fields = []
    pairs = msg.strip.split(';')
    pairs.each do |p|
      key = p.split('=').first
      val = p.split('=').last
      next unless key
      fields << { key => "#{val}" }
    end
    fields
  end

  # get action
  def get_action(row_ref)
    res = nil
    tag = 'Action'
    if row_ref.include? tag
      res = row_ref[tag]
      row_ref.delete tag
    end
    res
  end

  # handle tags for type send admin
  # - LogonUntilSuccessInd
  def handle_send_admin_tags(row)
    tag = 'LogonUntilSuccessInd'
    val = row[tag]
    if val 
      @logon_until_success_ind = false if val == 'N'
      row.delete tag
    end
    row
  end

  # handle tags for type verify
  # - Product
  def handle_verify_tags(row)
    tag = 'Product'
    sub = row[tag]
    if sub
      sub = sub.strip
      valid_subs = $product_config.get_valid_subjects
      if valid_subs.include? sub
        row['OMDCProduct'] = $product_config.get_product sub
      else
        $error_handler.report(:invalid_subject, [sub, valid_subs.join(',')])
      end
      row.delete tag
    else
      $error_handler.report(:missing_field, [tag])
    end

    tag = 'KeepMessageLog'
    sub = row[tag]
    if sub.nil? or sub.strip == ''
      case_id  = @case_id ? @case_id : 'CASEID'
      row[tag] = "#{case_id}_#{Time.now.strftime('%Y%m%d%H%M%S%6N')}"
    end
    $world.puts "Message log will be kept: #{row[tag]}.log" if $world

    row
  end

  # handle common tags
  # - ReferenceVar
  # - Duration
  def handle_common_tags(row)
    tag = 'ReferenceVar'
    val = row[tag]
    if val
      @ref_var = val
      row.delete tag
    end
    
    tag = 'Duration'
    val = row[tag]
    if val
      @duration = val
      row.delete tag
    end
    row
  end

  # handle special tags
  def handle_special_tags(row)
    if @type == 'send'
      # handle field MMDHProduct
      row['MMDHProduct'] = @proxy.product
      handle_send_admin_tags row
    elsif @type == 'verify'
      # handle field MMDHProduct
      row['MMDHProduct'] = @proxy.product
      # handle tags for type verify
      row = handle_verify_tags row
      row = handle_verify_time_range row
    elsif @type == 'check'
      # handle tags for type check
      row = handle_common_tags row
    elsif @type == 'lookup'
      # handle tags for lookup
      row = handle_common_tags row
    end
    row
  end

  # handle From/To timestamp
  def handle_from_to(row)
    tag = 'From'
    ts  = row[tag]
    if ts
      unless ts.empty?
        $error_handler.report(:invalid_timestamp, [ts]) unless $timestamps[ts]
        @proxy.stime = OMDUtil.get_time $timestamps[ts]
      end
      row.delete tag
    end

    tag = 'To'
    ts = row[tag]
    if ts
      unless ts.empty?
        $error_handler.report(:invalid_timestamp, [ts]) unless $timestamps[ts]
        @proxy.etime = OMDUtil.get_time $timestamps[ts]
      end
      row.delete tag
    end
    row
  end

  # handle time range for verify function
  def handle_verify_time_range(row)
    tag = 'OMDCStartTime'
    ts  = row[tag]
    if ts and $timestamps[ts]
      row[tag] = OMDUtil.get_time $timestamps[ts]
    end
    tag = 'OMDCEndTime'
    ts  = row[tag]
    if ts and $timestamps[ts]
      row[tag] = OMDUtil.get_time $timestamps[ts]
    end
    tag = 'MMDHStartTime'
    ts  = row[tag]
    if ts and $timestamps[ts]
      row[tag] = OMDUtil.get_time $timestamps[ts]
    end
    tag = 'MMDHEndTime'
    ts  = row[tag]
    if ts and $timestamps[ts]
      row[tag] = OMDUtil.get_time $timestamps[ts]
    end
    row
  end

  # handle message type
  def handle_msg_type(row)
    msg_type_list = []
    tag = 'MsgType'
    msg_type = row[tag]
    if msg_type.nil? or msg_type.empty?
      product = row['OMDCProduct']
      msg_type_list = @product_msg_map[product]
    else
      msg_type_list.replace(msg_type.split(','))
    end
    row.delete tag
    msg_type_list
  end

  # print format output in pdf report
  def print_format_output(res_array)
    return unless $world
    res_array.each do |res|
      $world.puts "MsgType: #{res['MsgType']}, #{res['InfoMsg']}" if $world
    end
  end
  
  # verify result for all message type
  def verify_result(res_array)
    res = res_array.select { |res| res['Status'] == 'FAILED' }
    if !res.empty?
      error = 'error msg: failed to varify.'
      res_array.each do |res|
        error += " reason=MsgType:#{res['MsgType']},#{res['InfoMsg']}." if res['Status'] == 'FAILED'
      end
      $error_handler.error_msg = error
      $error_handler.trigger
    end
  end

  # handle field value
  def handle_field_value(row)
    row.default = nil
    row = Marshal.load(Marshal.dump(row))
    row = $omd_validator.handle_null(row)
    row = $omd_validator.handle_variable(row)
    row = $omd_validator.handle_value_normalization(row)
    row
  end

  # pre-process row
  def pre_process_row(row)
    # handle template
    if row.has_key? 'Template'
      row = $omd_template_handler.handle(row) if $omd_template_handler
    end
    row = handle_field_value(row)
    row = handle_from_to(row)
    row
  end

  # send logon
  def send_logon(row)
    # 1.send logon request
    message = { 'product'    => '',
                'channel'    => '',
                'action'     => 'mmdh_logon',
                'start_time' => '',
                'end_time'   => '',
                'message'    => {},
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = get_fields(row)

    # 2.parse the result
    res = JSON.parse @proxy.send_raw(message.to_json)
    if res['status'] == 'failed'
      $error_handler.error_msg = ('error msg:' + res['error_msg'])
      $error_handler.trigger
    end
  end

  # send logout
  def send_logout(row)
    # 1.send logout request
    message = { 'product'    => '',
                'channel'    => '',
                'action'     => 'mmdh_logout',
                'start_time' => '',
                'end_time'   => '',
                'message'    => {},
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = get_fields(row)

    # 2.parse the result
    res = JSON.parse @proxy.send_raw(message.to_json)
    if res['status'] == 'failed'
      $error_handler.error_msg = ('error msg:' + res['error_msg'])
      $error_handler.trigger
    end
    $world.puts "#{row['UserName']} Disconnected" if $world
  end

  # get message time of logon success response
  def get_session_logon_time(row_ref)
    msg_type = '1102'
    message = { 'product'    => @proxy.product,
                'channel'    => '',
                'action'     => 'count',
                'message'    => {},
                'start_time' => @proxy.stime,
                'end_time'   => '',
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = [{ 'MsgType' => msg_type }]
    res = JSON.parse @proxy.send_raw(message.to_json)
    msg_time = nil
    unless res['count'].to_i == 0
      messages = res['messages'].split("\n")
      regex_ts = /^MsgTime=(\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d)\.\d\d\d\d\d\d;.*$/
      msg_time = $1 if messages[0] =~ regex_ts
    end
    msg_time
  end

  # check session status
  def check_session_success(row)
    # 1.send count request
    msg_type = '1102'
    message = { 'product'    => @proxy.product,
                'channel'    => '',
                'action'     => 'count',
                'message'    => {},
                'start_time' => @proxy.stime,
                'end_time'   => '',
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = [{ 'MsgType' => msg_type }]

    # 2.parse the result
    res = JSON.parse @proxy.send_raw(message.to_json)
    count = res['count'].to_i
    unless count == 0
      messages = res['messages'].split("\n")
      status = $1 if messages[0] =~ /^.*;SessionStatus=(\d+);.*$/
      @logon_status['result'] = 'success' if @session_logon_success.include? status
      @logon_status['status'] = "#{status} (#{@session_status[status]})"
    end
    count
  end

  # retreive admin message
  # - Logon (1101)
  # - Logon Response (1102)
  # - Refresh Request (1201)
  # - Refresh Response (1202)
  def retrieve_admin_message(row)
    result = []
    message = { 'product'    => @proxy.product,
                'channel'    => '',
                'action'     => 'retrieve_log',
                'message'    => {},
                'start_time' => @proxy.stime,
                'end_time'   => '',
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = [{ 'MsgType' => '1101'}]
    res = JSON.parse  @proxy.send_raw(message.to_json)
    unless res['count'].to_i == 0
      res['messages'].split('\n').each do |message|
        if message =~ /^\[(\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d.\d\d\d\d\d\d) \d+\] (Sent|Received): (.*)$/
          title = "#{$2} #{@proxy.product} message fields"
          new_msg = "SendTime=#{$1};#{$3}" if message =~ /^\[(\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d.\d\d\d\d\d\d) \d+\] (Sent|Received): (.*)$/
          result << {'Title' => title, 'Message' => new_msg }
        end
      end
    end
    message = { 'product'    => @proxy.product,
                'channel'    => '',
                'action'     => 'retrieve_log',
                'message'    => {},
                'start_time' => @proxy.stime,
                'end_time'   => '',
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = [{ 'MsgType' => '1102'}]
    res = JSON.parse  @proxy.send_raw(message.to_json)
    unless res['count'].to_i == 0
      res['messages'].split('\n').each do |message|
        if message =~ /^\[(\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d.\d\d\d\d\d\d) \d+\] (Sent|Received): (.*)$/
          title = "#{$2} #{@proxy.product} message fields"
          new_msg = "SendTime=#{$1};#{$3}" if message =~ /^\[(\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d.\d\d\d\d\d\d) \d+\] (Sent|Received): (.*)$/
          result << {'Title' => title, 'Message' => new_msg }
        end
      end
    end
    message = { 'product'    => @proxy.product,
                'channel'    => '',
                'action'     => 'retrieve_log',
                'message'    => {},
                'start_time' => @proxy.stime,
                'end_time'   => '',
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = [{ 'MsgType' => '1201'}]
    res = JSON.parse  @proxy.send_raw(message.to_json)
    unless res['count'].to_i == 0
      res['messages'].split('\n').each do |message|
        if message =~ /^\[(\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d.\d\d\d\d\d\d) \d+\] (Sent|Received): (.*)$/
          title = "#{$2} #{@proxy.product} message fields"
          new_msg = "SendTime=#{$1};#{$3}" if message =~ /^\[(\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d.\d\d\d\d\d\d) \d+\] (Sent|Received): (.*)$/
          result << {'Title' => title, 'Message' => new_msg }
        end
      end
      $world.puts "Send Refresh Request message (1201) to MMDH successfully" if $world
    end
    message = { 'product'    => @proxy.product,
                'channel'    => '',
                'action'     => 'retrieve_log',
                'message'    => {},
                'start_time' => @proxy.stime,
                'end_time'   => '',
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = [{ 'MsgType' => '1202'}]
    res = JSON.parse  @proxy.send_raw(message.to_json)
    unless res['count'].to_i == 0
      res['messages'].split('\n').each do |message|
        if message =~ /^\[(\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d.\d\d\d\d\d\d) \d+\] (Sent|Received): (.*)$/
          title = "#{$2} #{@proxy.product} message fields"
          new_msg = "SendTime=#{$1};#{$3}" if message =~ /^\[(\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d.\d\d\d\d\d\d) \d+\] (Sent|Received): (.*)$/
          result << {'Title' => title, 'Message' => new_msg }
        end
      end
      $world.puts "MMDH responds to the refresh request through Refresh Response message(1202)" if $world
    end
    # pdf output
    tables = []
    result.each do |res|
      tables << { 'Title'       => res['Title'],
                  'NumOfColumn' => 4,
                  'Template'    => '',
                  'TextMsg'     => res['Message'],
                  'BinMsg'      => ''}
    end
    OMDUtil.print_pdf_table(tables)
  end

  # match message
  def send_match(row)
    result  = { 'MsgType' => "#{row['MsgType']}" }
    message = { 'product'    => '',
                'channel'    => '',
                'action'     => 'mmdh_match',
                'start_time' => @proxy.stime,
                'end_time'   => @proxy.etime,
                'message'    => {},
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = get_fields(row)
    res = JSON.parse @proxy.send_raw(message.to_json)
    if res['status'] == 'failed'
      result['Status']  = 'FAILED'
      result['InfoMsg'] = res['error_msg']
    else
      result['Status']  = 'SUCCESS'
      result['InfoMsg'] = res['info_msg']
    end
    result
  end

  # range request
  #
  def send_lookup(row)
    message = { 'product'    => @proxy.product,
                'channel'    => '',
                'action'     => 'rt_count',
                'message'    => {},
                'start_time' => @proxy.stime,
                'end_time'   => @proxy.etime,
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = get_fields(row)

    # 2.parse the result
    res = JSON.parse @proxy.send_raw(message.to_json)
    count = res['count'].to_i
    unless count == 0
      @last_msg = res['messages'].split("\n")[-1]
    end
    count
  end

  # single logon
  def single_logon(row_ref)
    timeout       = 30
    start_time    = Time.now
    @proxy.stime  = OMDUtil.get_time start_time
    send_logon(row_ref)
    begin
      sleep(1)
      count = check_session_success(row_ref)
      break if Time.now - start_time >= timeout
    end while (count == 0)
  end

  # process logon
  def process_logon(row_ref)
    @logon_status = { 'result' => 'failed', 'status' => 'Unknown' }
    # repeat logon until success
    if @logon_until_success_ind
      stime = Time.now
      begin
        single_logon(row_ref)
        break if Time.now - stime >= @timeout
      end while (@logon_status['result'] == 'failed')
    # logon once
    else
      single_logon(row_ref)
    end

    # check logon status
    if @logon_status['result'] == 'failed'
      error = 'Failed to logon, reason=unknown'
      if @logon_status['status'] != 'Unknown'
        error = "Failed to logon, MMDH returns SessionStatus=#{@logon_status['status']} through the Logon Response message (1102)"
      end
      retrieve_admin_message(row_ref)
      $error_handler.error_msg = error
      $error_handler.trigger
    else
      $world.puts "Logon successfully, MMDH returns SessionStatus=#{@logon_status['status']} through the Logon Response message (1102)" if $world
      retrieve_admin_message(row_ref)
    end
  end

  # process logout
  def process_logout(row_ref)
    send_logout(row_ref)
  end

  # process row
  def send_admin(row_ref)
    action = get_action(row_ref)
    if "Logon" == action
      process_logon(row_ref)
    elsif "Logout" == action
      process_logout(row_ref)
    else
      $error_handler.error_msg = ("error msg: invalid action [#{action}]")
      $error_handler.trigger
    end
  end

  # veriry message
  def verify_row(row_ref)
    msg_type_list = handle_msg_type(row_ref)
    $world.puts "verify message between product #{row_ref['OMDCProduct']}" \
      " and #{row_ref['MMDHProduct']}, MsgType: #{msg_type_list.join(',')}" if $world
    # verify
    res_array = []
    msg_type_list.each do |msg_type|
      row = row_ref.clone
      row['MsgType'] = msg_type
      res = send_match(row)
      res_array << res
    end
    # pdf output
    print_format_output(res_array)
    # case result
    verify_result(res_array)
  end

  # get retransmit complete time
  def check_retransmit_complete(row_ref)
    result = {}
    # retrieve timestamp of logon success response
    lg_time = get_session_logon_time(row_ref)
    unless lg_time
      $error_handler.error_msg = "session is not logon"
      $error_handler.trigger
    end
    # check retransmit status
    # it's completed if count message with one interval time
    stime    = Time.parse lg_time
    cur_time = Time.now
    begin
      sleep(1)
      @proxy.stime = OMDUtil.get_time(stime)
      @proxy.etime = OMDUtil.get_time(stime + @duration)
      count = @proxy.send_count(row_ref)
      stime = stime + @duration
      break if Time.now - cur_time > @timeout
    end until (count.to_i == 0)

    if count.to_i == 0
      $timestamps["#{@ref_var}"] = stime - @duration if $timestamps
      $world.puts "retransmit completed at #{OMDUtil.get_time($timestamps["#{@ref_var}"])}" if $world
    else
      $error_handler.error_msg = "process timed out"
      $error_handler.trigger
    end
    result
  end

  def lookup_last_message(row_ref)
    result = {}
    etime = cur_time = Time.now
    @last_msg = nil
    begin
      @proxy.stime = OMDUtil.get_time(etime - @duration)
      @proxy.etime = OMDUtil.get_time(etime)
      count = send_lookup(row_ref)
      etime = etime - @duration
      break if Time.now - cur_time > @timeout
    end until (count > 0)

    if  @last_msg
      channel  = nil
      msg_time = $1 if @last_msg =~ /^MsgTime=(\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d.\d\d\d\d\d\d);.*$/
      m_fields = get_msg_fields_hash @last_msg
      ref      = @ref_var
      res      = {}
      msg = OMDUtil.parse_message(channel, msg_time, m_fields, ref, res)
      result = result.merge res
      $world.puts "  Current Time: #{OMDUtil.get_time(cur_time)}"                        if $world
      $world.puts "  Message Time: #{OMDUtil.get_time($timestamps["#{ref}.Timestamp"])}" if $world
      $world.puts "InternalSeqNum: #{result["#{ref}.InternalSeqNum"]}"                   if $world
    else
      $error_handler.error_msg = "process timed out"
      $error_handler.trigger
    end
    result
  end

  # submit table
  def submit(table_hash)
    OMDUtil::Logger.debug '@subjects:' + @subjects.to_s
    ref_hash = {}
    @subjects.each do |sub, product|
      $error_handler.subject = sub
      @proxy.product         = product
      index                  = 1
      table_hash.each do |row|
        ref_result = nil
        $error_handler.index = index
        row = row.clone
        row = pre_process_row(row)
        row = handle_special_tags(row)
        if @type == 'send'
          send_admin(row)
        elsif @type == 'verify'
          verify_row(row)
        elsif @type == 'check'
          ref_result = check_retransmit_complete(row)
        elsif @type == 'lookup'
          ref_result = lookup_last_message(row)
        end
        ref_hash = ref_hash.merge ref_result if ref_result
        index += 1
      end
    end
    ref_hash
  end

end
