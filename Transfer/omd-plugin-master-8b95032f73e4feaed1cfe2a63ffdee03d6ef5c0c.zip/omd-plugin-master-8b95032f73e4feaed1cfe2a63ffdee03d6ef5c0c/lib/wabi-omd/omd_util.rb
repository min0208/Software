# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd utility

# module OMDUtil for omd utilities 

require 'logger'

module OMDUtil
  Logger = Logger.new(STDOUT)

  def self.wabi_fields()
    return ["Count", "ChannelID", "FirstEntry", "ResponseRef", "RealtimeChannelID", "From", "To", "At"]
  end

  # @param row [Hash] a row of data table
  # return [Hash] hash in sent out fields item
  def self.get_checking_fields(row)
    # clone row
    res = []
    row = row.clone
    # remove invalid field
    wabi_fields.each do | field |
      row.delete field
    end
    # concat field/value
    row.each do |k, v|
      if v.class == Array
        v.each do |e|
           e = e.map { |k, v| "#{k}=#{v}" }.join '`'
           res << { k => e }
        end
      else
        res << { k => v }
      end
    end
    res
  end

  # @return [TimeStamp] a very early time stamp
  # get very early time
  def self.begin_time
    Time.new(1900, 01, 01).strftime('%Y-%m-%d %H:%M:%S.%6N')
  end

  # get current time
  # @return [Timestamp]time stamp of now
  def self.now_time
    Time.now.strftime('%Y-%m-%d %H:%M:%S.%6N')
  end

  # @param ts [Timestamp|nil] input timestamp
  # @return [String] omd timestamp string format
  # get time from a timestamp
  def self.get_time(ts)
    if ts
      return ts.strftime('%Y-%m-%d %H:%M:%S.%6N')
    else
      # if input is nil,out put nil
      return nil
    end
  end

  # @param ts [OMD Time Format]
  # @return [OMD Time Format]
  # get the next OMD time (add 1 ms)
  def self.get_next_time(ts)
    times = ts.split '.'
    mt = (times.last.to_i + 1).to_s
    mt = '0' + mt while mt.size < 6
    times.first + '.' + mt
  end

  # @param msg [Hash]
  # @return [boolean]
  # check if the return is mulitmach but identical messages
  def self.identical_multimatch?(msg)
    if msg['status'] == 'failed'
      error = msg['error_msg']
      if error.include? "multiple responses matched"
        number = error.scan(/MsgTime/).size
        msgtimes = error.scan(/MsgTime=\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d.\d\d\d\d\d\d;/)
        seqs = error.scan(/SeqNum=\d*;/)
        OMDUtil::Logger.debug msgtimes
        OMDUtil::Logger.debug seqs
        # sort the time and seq numbers
        msgtimes.sort!
        seqs.sort!
        if msgtimes.size == number and seqs.size == number
            return true if msgtimes.first == msgtimes.last and seqs.first == seqs.last
        end
      end
    end
    return false
  end
  
  # @param [String] error msg content
  # @return [String]
  def self.get_identical_msg(msg)
    message = (msg.split('MsgTime=')).last
    return ( 'MsgTime=' + message).strip!
  end

  # @param [String] text
  # remove quotation marks for a string
  def self.remove_quotation_marks(text)
    return text.gsub!(/^"(.*)"$/, '\1') if !text.nil?
    return text
  end

  #@param [String] text
  # fill with space for a string
  def self.fill_with_space(text)
    return text.replace("#{$1}#{" " * $2.to_i}") if text =~ /(.*)<space>{(\d+)}$/
    return text
  end

  def self.parse_message(channel, msg_time, msg_hash, ref, result_hash)
    msg = ''
    # message time
    if msg_time
      msg += "MsgTime=#{msg_time};"
      $timestamps["#{ref}.Timestamp"] = Time.parse(msg_time) if ref
    end
    # channel
    if channel
      msg += "ChannelID=#{channel};"
      result_hash["#{ref}.ChannelID"] = channel if ref
    end
    # message fields
    msg_hash.each do |ele|
      ele.each do |k, v|
        msg += "#{k}=#{v};"
        # store the key/value
        result_hash["#{ref}.#{k}"] = v if ref
      end
    end
    msg
  end

  # print pdf table
  # - hash of table (array)
  # - table title
  # - num of column
  # - field template
  # - text message
  # - binary message
  def self.print_pdf_table(tables, print_key = 'Y')
    return unless $world
    tables.each do |table|
      pdf_table_title_t = 'Template Tags: '
      pdf_table_title_s = "#{table['Title']}(format=table, column=#{table['NumOfColumn']}, print_key=#{print_key}): "
      pdf_table_title_b = 'Received BinMsg: '
      $world.puts "#{pdf_table_title_t} #{table['Template']}"
      $world.puts "#{pdf_table_title_s} #{table['TextMsg']}"
      $world.puts "#{pdf_table_title_b} #{table['BinMsg']}"
    end
  end

  # print prerun error
  # add message header - Error Message
  # format refrence message as table output
  #
  def self.print_prerun_error(err)
    $world.puts "Error Message: "
    if err =~ /^([\S\s]+)error msg:([\S\s]+)RefMsg:([\S\s]+)$/ and $3.strip.chomp != ''
      err_msg = $1
      err_arr = $2.split("\n")
      ref_arr = $3.strip.split('; ')
      tables = []
      index  = 0
      ref_arr.size.times do
        tables << { 'Title'       => "#{err_arr[index]}",
                    'NumOfColumn' => 4,
                    'Template'    => '',
                    'TextMsg'     => "#{ref_arr[index]}",
                    'BinMsg'      => ''}
        index += 1
      end
      $world.puts err_msg if $world
      OMDUtil.print_pdf_table(tables)
    else
      $world.puts err if $world
    end
  end

  def self.get_msg_fields_hash(msg)
    fields = []
    pairs = msg.strip.split(';')
    pairs.each do |p|
      # key = p.split('=').first
      # val = p.split('=').last

      key = p.split('=')[0]
      if p.split('=')[1]
        val = p.split('=')[1] 
      else
        val = ""
      end

      next unless key
      fields << { key => "#{val}" }
    end
    fields
  end

  def self.get_fields(row)
    fields = []
    row.each do |k, v|
      if v.class == Array
        v.each do |e|
          e = e.map { |k, v| "#{k}=#{v}" }.join ','
          fields << { k => e }
        end
      else
        fields << { k => v }
      end
    end
    fields
  end

  # @param msg [String] OMD received message
  # @return [String] converted OMD received message
  # convert the omd proxy received msg into PDF friendly format, add repeating group surfix
  def self.convert_omd_msg(msg, hl_keys = nil)
    pairs = msg.strip.split ';'
    res = []
    record = {}
    pairs.each do |p|
      key = p.split('=').first
      next unless key
      if record[key]
        record[key] += 1
        # replace the string
        new_key = "#{key}(#{record[key]})"
        p[key] = new_key
        res << p
        if hl_keys
          # new highlighted key is needed
          hl_keys << new_key if hl_keys.include? key.strip
        end
      else
        record[key] = 1
        res << p
      end
    end
    # reorder the res
    result = []
    index  = 0
    real_index = 0
    while index < res.size
      result[index] = res[real_index]
      real_index += 1
      index += 2
    end
    index = 1
    while index < res.size
      result[index] = res[real_index]
      real_index += 1
      index += 2
    end
    result.join ';'
  end

  # @param row [Hash] row after validation
  # @return [Array]
  # get the tags should be highlighted
  def self.get_highlighted_keys(row)
    res = []
    row.each do |k, v|
      # repeating group
      if v.class == Array
        v.each do |pair|
          res << pair.keys
        end
      else
        # normal case
        res << k
      end
    end
    res.flatten.uniq
  end

  # @param msg
  # @return msg
  # get the msg processed MMDH
  def self.handle_mmdh_msg(msg, product)
    res = msg
    if $product_config.is_mmdh_product(product)
      res.gsub!(/ChannelID=\d+;/,'') if res
    end
    res
  end

end

