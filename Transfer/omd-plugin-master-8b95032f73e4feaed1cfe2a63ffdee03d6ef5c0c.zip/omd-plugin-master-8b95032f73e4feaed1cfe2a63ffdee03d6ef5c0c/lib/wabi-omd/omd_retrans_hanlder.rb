# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd retransmission hanlder

require 'json'

# OMDRetransHandler class function for omd
class OMDRetransHandler
  # timedout: retransmit timedout
  # interval: retransmit interval
  # latency : enlarge scope for searching delayed real-time message
  attr_accessor :timedout, :interval, :latency, :case_id

  def initialize(project, server_host, server_port, proxy)
    @server_host = server_host
    @server_port = server_port
    @proxy       = proxy
    @timedout    = 30
    @interval    = 1
    @latency     = 1
    @subjects    = {}
    url = "#{File.dirname(__FILE__)}/../../config/#{project}/retrans_channel_map.csv"
    @product_channel_map = get_product_channel_map(url)
    @error_info  = { '102' => { '5' => 'Invalid username or IP Address',
                                '100' => 'User already connected' },
                     '202' => { '1' => 'Unknown/Unauthorized channel ID',
                                '2' => 'Messages not available',
                                '100' => 'Exceeds maximum sequence range',
                                '101' => 'Exceeds maximum requests in a day' } }
  end

  # load product channel map
  def get_product_channel_map(csv)
    hash = {}
    CSV.foreach(csv) do |row|
      next if !row[0].nil? && row[0].match(/^ *#/)
      hash[row[0]] = row[1..-1]
    end
    hash
  end

  # handle subjects
  def set_subject(sub)
    subjects = sub.strip.split ','
    subjects.each do |sub|
      sub = sub.strip
      valid_subs = $product_config.get_valid_subjects
      if valid_subs.include? sub
        @subjects[sub] = $product_config.get_product sub
      else
        # invalid subject name
        $error_handler.report(:invalid_subject, [sub, valid_subs.join(',')])
      end
    end
  end

  # handle channel column in row
  def handle_channel(row)
    channel_list = []
    tag     = 'Channel'
    channel = row[tag]
    if channel.nil? or channel.empty?
      product = @proxy.product
      channel_list.replace(@product_channel_map[product])
    else
      channel_list.replace(channel.split(','))
    end
    row.delete tag
    channel_list
  end

  # handle from and to column in row
  def handle_from_to(row)
    tag = 'From'
    ts  = row[tag]
    if ts
      unless ts.empty?
        # invalid timestamp
        $error_handler.report(:invalid_timestamp, [ts]) unless $timestamps[ts]
        row['RealtimeStartTime'] = OMDUtil.get_time $timestamps[ts]
        @proxy.stime             = row['RealtimeStartTime']
      end
      row.delete tag
    end
  
    tag = 'To'
    ts = row[tag]
    if ts
      unless ts.empty?
        # invalid timestamp
        $error_handler.report(:invalid_timestamp, [ts]) unless $timestamps[ts]
        row['RealtimeEndTime'] = OMDUtil.get_time $timestamps[ts]
        @proxy.etime           = row['RealtimeEndTime']
      end
      row.delete tag
    end
  end

  # get field/value column in row
  def get_fields(row)
    fields = []
    row.each do |k, v|
      if v.class == Array
        v.each do |e|
          e = e.map { |k, v| "#{k}=#{v}" }.join ','
          fields << { k => e }
        end
      else
        fields << { k => v }
      end
    end
    fields
  end

  # format output
  def print_format_output(res_array)
    return unless $world
    res_array.each do |res|
      next if res['Status'] == 'SKIPPED'
      $world.puts "Channel #{res['Channel']}: " \
        "Begin SeqNum: #{res['BeginSeqNum']}, " \
        "End SeqNum: #{res['EndSeqNum']}, #{res['InfoMsg']}"
      $world.puts res['admin_msg'] if res['admin_msg'] 
    end
  end

  # valify result
  def varify_result(res_array)
    res = res_array.select { |res| res['Status'] == 'SUCCESS' }
    return unless res.empty?
    # raise error when no success case found
    error = 'error msg: retransmission check fail.'
    res_array.each do |res|
      error += " reason=#{res['InfoMsg']}." if res['Status'] == 'FAILED'
    end
    $error_handler.error_msg = error
    $error_handler.trigger
  end

  # retrieve seqnum from real-time messages log
  # assign real-time seqnum to retransmission if it's not given
  def retrieve_realtime_seqnum(row)
    # 1.send count request
    message = { 'product'    => row['RealtimeProduct'],
                'channel'    => row['ChannelID'],
                'action'     => 'rt_count',
                'start_time' => row['RealtimeStartTime'],
                'end_time'   => row['RealtimeEndTime'],
                'message'    => {},
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = [{ 'MsgType' => '(.*)' }]

    # 2.parse the result
    res = JSON.parse @proxy.send_raw(message.to_json)
    unless res['count'].to_i == 0
      messages = res['messages'].split("\n")
      unless row['BeginSeqNum']
        row['BeginSeqNum'] = $1 if messages[0]  =~ /^.*;SeqNum=(\d+);.*$/
      end
      unless row['EndSeqNum']
        row['EndSeqNum'] = $1 if messages[-1] =~ /^.*;SeqNum=(\d+);.*$/
      end
    end
  end

  # send retrans request
  def send_retrans_request(row)
    row['RetransStartTime'] = OMDUtil.get_time Time.now
    row['RetransEndTime']   = nil
    # 1.send count request
    message = { 'product'    => nil,
                'channel'    => nil,
                'action'     => 'rt_request',
                'start_time' => nil,
                'end_time'   => nil,
                'message'    => {},
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = get_fields(row)

    # 2.parse the result
    res = JSON.parse @proxy.send_raw(message.to_json)
    if res['status'] == 'failed'
      @channel_res['Status']  = 'FAILED'
      @channel_res['InfoMsg'] = res['error_msg']
      throw
    end
  end

  # check session status
  def check_session_status(row)
    # 1.send count request
    msg_type = '102'
    message = { 'product'    => row['RetransProduct'],
                'channel'    => '0',
                'action'     => 'count',
                'message'    => {},
                'start_time' => row['RetransStartTime'],
                'end_time'   => row['RetransEndTime'],
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = [{ 'MsgType' => msg_type,
                                      'SessionStatus' => '([1-9][0-9]*)'}]

    # 2.parse the result
    res = JSON.parse  @proxy.send_raw(message.to_json)
    unless res['count'].to_i == 0 
      messages = res['messages'].split("\n")
      status = $1 if messages[0] =~ /^.*;SessionStatus=(\d+);.*$/
      @channel_res['Status']  = 'FAILED'
      @channel_res['InfoMsg'] = @error_info[msg_type][status]
      throw
    end
  end

  # check retransmit status
  def check_retrans_status(row)
    # 1.send count request
    msg_type = '202'
    message = { 'product'    => row['RetransProduct'],
                'channel'    => '0',
                'action'     => 'count',
                'message'    => {},
                'start_time' => row['RetransStartTime'],
                'end_time'   => row['RetransEndTime'],
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = [{ 'MsgType' => msg_type,
                                      'RetransStatus' => '([1-9][0-9]*)'}]

    # 2.parse the result
    res = JSON.parse  @proxy.send_raw(message.to_json)
    unless res['count'].to_i == 0 
      messages = res['messages'].split("\n")
      status = $1 if messages[0] =~ /^.*;RetransStatus=(\d+);.*$/
      @channel_res['Status']  = 'FAILED'
      @channel_res['InfoMsg'] = @error_info[msg_type][status]
      throw
    end
  end

  # check retransmit complete
  def check_retrans_complete(row)
    # 1.send count request
    message = { 'product'    => row['RetransProduct'],
                'channel'    => row['ChannelID'],
                'action'     => 'count',
                'message'    => {},
                'start_time' => row['RetransStartTime'],
                'end_time'   => row['RetransEndTime'],
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = [{ 'SeqNum' => row['EndSeqNum']}]

    # 2.parse the result
    res = JSON.parse  @proxy.send_raw(message.to_json)
    unless res['count'].to_i == 0
      messages = res['messages'].split("\n")
      msg_time = /^MsgTime=(\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d.\d\d\d\d\d\d);.*$/
      row['RetransEndTime'] = $1 if messages[0] =~ msg_time
    end
    return res['count']
  end

  # handle begin & end seqnum
  def handle_seqnum_range(row)
    # 1.retrieve seqnum range from real-time if need
    unless row['BeginSeqNum'] and row['EndSeqNum']
      retrieve_realtime_seqnum(row)
    end

    # 2.skip process when no message found
    unless row['BeginSeqNum'] and row['EndSeqNum']
      @channel_res['Status'] = 'SKIPPED'
      throw
    end
    # 3.fail when invalid seqnum range
    unless (row['BeginSeqNum'].to_i >= 0 \
      and row['BeginSeqNum'].to_i <= row['EndSeqNum'].to_i)
      @channel_res['Status']  = 'FAILED'
      @channel_res['InfoMsg'] = "Invalid seqnum: " \
        "BeginSeqNum=#{row['BeginSeqNum']} EndSeqNum=#{row['EndSeqNum']}"
      throw
    end
    # 4.continue with valid seqnum range
    @channel_res['BeginSeqNum'] = row['BeginSeqNum']
    @channel_res['EndSeqNum']   = row['EndSeqNum']
  end

  def is_duplicated_logon(row)
    res = false
    tag = 'DuplicatedLogon'
    duplicated = row[tag]
    if duplicated
      res = true if duplicated == 'Y'
      row.delete tag
    end
    res
  end
 
  def retrieve_admin_message(row)
    return if row['RetransStartTime'].nil?
    # 1.send count request
    message = { 'product'    => row['RetransProduct'],
                'channel'    => '0',
                'action'     => 'retrieve_log',
                'message'    => {},
                'start_time' => row['RetransStartTime'],
                'end_time'   => row['RetransEndTime'],
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = [{ 'MsgType' => '(.*)'}]

    # 2.parse the result
    res = JSON.parse  @proxy.send_raw(message.to_json)
    unless res['count'].to_i == 0
      @channel_res['admin_msg'] = res['messages']
    end
  end

  # send retrans request
  def request_retransmit(row)
    start_time = Time.now
    # 1.send retrans request
    send_retrans_request(row)
    # negative test
    if is_duplicated_logon(row)
      send_retrans_request(row)
    end
    # 2.check retrans status
    begin
      sleep(1)
      check_session_status(row)
      check_retrans_status(row)
      count = check_retrans_complete(row)
      break if Time.now - start_time >= @timedout
    end while (count.to_i <= 0)
    # 3.check retrans complete
    unless row['RetransEndTime']
      @channel_res['Status']  = 'FAILED'
      @channel_res['InfoMsg'] = 'Failed to retransmit'
      throw
    end
  end

  # match retransmission with real-time
  def match_messages(row)
    # 1.send match request
    message = { 'product'    => @proxy.product,
                'channel'    => row['ChannelID'],
                'action'     => 'rt_match',
                'message'    => {},
                'start_time' => @proxy.stime,
                'end_time'   => @proxy.etime,
                'timeout'    => @proxy.timeout.to_s }
    message['message']['fields'] = get_fields(row)

    # 2.parse the result
    res = JSON.parse @proxy.send_raw(message.to_json)
    unless res['status'] == 'success'
      @channel_res['Status']  = 'FAILED'
      @channel_res['InfoMsg'] = res['error_msg']
      throw
    end
    # 3.match success
    @channel_res['Status']  = 'SUCCESS'
    @channel_res['InfoMsg'] = res['info_msg']
  end

  # pre-process row
  def pre_process_row(row)
    row = $omd_validator.handle_null(row)
    row = $omd_validator.handle_variable(row)
    row['Address']           = @server_host
    row['Port']              = @server_port
    row['RealtimeProduct']   = @proxy.product
    row['RealtimeLatency']   = @latency if @latency
    row['RealtimeStartTime'] = @proxy.stime
    row['RealtimeEndTime']   = @proxy.etime
    row['RetransProduct']    = "Retransmission-#{row['UserName']}"
    row['RetransStartTime']  = nil
    row['RetransEndTime']    = nil

    # keep message log
    tag = 'KeepMessageLog'
    sub = row[tag]
    if sub.nil? or sub.strip == ''
      case_id  = @case_id ? @case_id : 'CASEID'
      row[tag] = "#{case_id}_#{Time.now.strftime('%Y%m%d%H%M%S%6N')}"
    end
    $world.puts "Message log will be kept: #{row[tag]}.log" if $world

    handle_from_to(row)
  end

  # retransmit
  def retransmit(row_ref)
    # 1.pre-process row
    pre_process_row(row_ref)
    # 2.get channel list
    channel_list = handle_channel(row_ref)
    $world.puts "Retransmission check for product: " \
      "#{@proxy.product}, channel: #{channel_list.join(',')}" if $world
    res_array = []
    # 3.retransmit for channel
    channel_list.each do |channel|
      @channel_res = { 'Channel'     => channel,
                       'BeginSeqNum' => nil,
                       'EndSeqNum'   => nil,
                       'Status'      => nil,
                       'InfoMsg'     => nil }
      row = row_ref.clone
      row['ChannelID'] = channel
      begin
        # 3.1 get seq num range
        handle_seqnum_range(row)
        # 3.2 retrans request
        request_retransmit(row)
        # 3.3 match realtime messages with retransmission
        match_messages(row)
      rescue
      end
      # 4.retrieve retans admin message
      retrieve_admin_message(row)
      res_array << @channel_res

      # wait seconds
      sleep(@interval.to_i)
    end
    # 4.output
    print_format_output(res_array)
    # 5.verify result
    varify_result(res_array)
  end

  # submit table
  def submit(table_hash)
    OMDUtil::Logger.debug '@subjects:' + @subjects.to_s
    @subjects.each do |sub, product|
      $error_handler.subject = sub
      @proxy.product = product
      index = 1
      table_hash.each do |row|
        $error_handler.index = index
        # handle retransmission
        retransmit(row.clone)
        index += 1
      end
    end
  end

end
