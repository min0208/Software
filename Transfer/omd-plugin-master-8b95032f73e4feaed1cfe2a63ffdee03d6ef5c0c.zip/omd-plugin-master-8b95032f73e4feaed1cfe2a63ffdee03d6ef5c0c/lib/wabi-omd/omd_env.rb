#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: cucumber env

# set the default project & version
ENV['OMD_PROJECT'] ||= 'omdc'
ENV['OMD_VERSION'] ||= '2.0'
ENV['OMD_IP']      ||= '127.0.0.1'
ENV['OMD_PORT']    ||= '6666'
ENV['OMD_CMP']     ||= 'Y'

Before do |_scenario|
  # set the log level
  # if ENV['log_level']
  #   require 'logger'
  #   eval "OMDUtil::Logger.level = Logger::#{ENV['log_level']}"
  # end
  # set the default project & version

  omd_project = ENV['OMD_PROJECT']
  omd_version = ENV['OMD_VERSION']
  omd_ip      = ENV['OMD_IP']
  omd_port    = ENV['OMD_PORT']
  omd_cmp     = ENV['OMD_CMP']
  @omd_cmp    ||= omd_cmp

  # proxy is scneario instance
  @scenario_starttime ||= OMDUtil.get_time Time.now

  @omd_proxy = OMDProxy.new(omd_ip, "#{omd_port}".to_i)
  # set the default start time as the begin of scenario
  $product_config ||= OMDProductConfig.new(omd_project)
  # gloable alias handler
  $omd_alias_handler ||= OMDAliasHandler.new(omd_project, omd_version)
  # gloabal template handler
  $omd_template_handler ||= OMDTemplateHandler.new(omd_project, omd_version)
  # gloabal validator
  $omd_validator ||= OMDValidator.new(omd_project, omd_version)
  # gloabal error handler
  $error_handler ||= OMDErrorReporter.new
  # repeating group handler is scenario instance
  @omd_rg_handler ||= OMDRepeatGroupHandler.new(omd_project, omd_version)

  # reponse hash <product name>  => <default from time stamp>
  @omd_response_hash ||= {}
  # initialize response hash
  $product_config.get_valid_subjects.each { |s| @omd_response_hash[s] = @scenario_starttime }

  # send out start info into proxy, for scenario tracking / debug
  @omd_proxy.send_sce_start @case_id, @scenario_name if @case_id && @scenario_name

  # refresh complete
  @wait_full_refresh_cycle  ||= true
  @refresh_publish_duration ||= 30
  @refresh_verify_timeout   ||= 600

  # pre-run case mode
  @pre_run_case    = ENV['PRE_RUN_CASE']
  @scenario_status = 'Passed'

  require 'logger'
  $logger = Logger.new(STDOUT)
  $logger.level = Logger::DEBUG

end

After do |_scenario|
  # send end info into proxy, for scenario tracking / debug
  @omd_proxy.send_sce_end @case_id, @scenario_name if @case_id && @scenario_name
end
