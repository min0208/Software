# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd client tool hanlder

require 'json'

# OMDClientToolHandler class function for omd
class OMDClientToolHandler
  # bigmap: inherit bigmap from WABI-WEB
  attr_accessor :bigmap, :lastbbo_ind

  def initialize(project)
    @omd_ct_proxy       = nil
    @subjects           = {}
    @myref              = nil
    @lastbbo            = false
    @product_table_map  = load_product_table("#{File.dirname(__FILE__)}/../../config/#{project}/#{project}_ct_product_table.csv")
    @table_template_map = load_table_template("#{File.dirname(__FILE__)}/../../config/#{project}/#{project}_ct_table_template.csv")
    @product_proxy_map  = load_product_proxy("features/#{project}_ct_product_proxy.csv")
  end

  # load field name map
  def load_field_name(csv)
    res = {}
    if File.exist? csv
      CSV.foreach(csv) do |row|
        next if !row[0].nil? && row[0].match(/^ *#/)
        res["#{row[0]}"] = "#{row[1]}"
      end
    else
      $error_handler.error_msg = "#{csv} not found"
      $error_handler.trigger
    end
    res
  end

  # load product table map
  def load_product_table(csv)
    res = {}
    if File.exist? csv
      CSV.foreach(csv) do |row|
        next if !row[0].nil? && row[0].match(/^ *#/)
        res["#{row[0]}"] = "#{row[1..-1].join(',')}"
      end
    else
      $error_handler.error_msg = "#{csv} not found"
      $error_handler.trigger
    end
    res
  end

  # load table template map
  def load_table_template(csv)
    res = {}
    if File.exist? csv
      CSV.foreach(csv) do |row|
        next if !row[0].nil? && row[0].match(/^ *#/)
        res["#{row[0]}"] = { 'column'    => "#{row[1]}",
                             'print_ind' => "#{row[2]}",
                             'title'     => "#{row[3]}",
                             'fields'    => "#{row[4..-1].join(',')}" }
      end
    else
      $error_handler.error_msg = "#{csv} not found"
      $error_handler.trigger
    end
    res
  end

  # load product proxy map
  def load_product_proxy(csv)
    res = {}
    if File.exist? csv
      CSV.foreach(csv) do |row|
        next if !row[0].nil? && row[0].match(/^ *#/)
        res[row[0]] = row[1..-1]
      end
    else
      $error_handler.error_msg = "#{csv} not found"
      $error_handler.trigger
    end
    res
  end

  # print product table map
  def print_product_table
    return if $world.nil?
    @product_table_map.each do |key, val|
      $world.puts "#{$product_config.get_subject(key)}: #{val}"
    end
  end

  # @param sub [String] subjec tin the table
  # add subjects
  def set_subject(sub)
    subjects = sub.strip.split ','
    subjects.each do |sub|
      sub = sub.strip
      valid_subs = $product_config.get_valid_subjects
      if valid_subs.include? sub
        @subjects[sub] = $product_config.get_product sub
      else
        $error_handler.report(:invalid_subject, [sub, valid_subs.join(',')])
      end
    end
  end

  # get field/value column in row
  def get_fields(row)
    fields = []
    row.each do |k, v|
      if v.class == Array
        v.each do |e|
          e = e.map { |k, v| "#{k}=#{v}" }.join ','
          fields << { k => e }
        end
      else
        fields << { k => v }
      end
    end
    fields
  end

  # get field/vale map
  def get_result_hash(msg)
    return {} if @myref.nil? or msg.nil?
    result_hash = {}
    msg.split(';').each do |item|
      key  = "#{item.split('=')[0]}"
      val  = "#{item.split('=')[1]}"
      result_hash["#{@myref}.#{key}"] = "#{val}"
    end
    result_hash
  end

  # get highlight keys
  def get_highlight_keys(row)
    row = row.clone
    tag = 'MyRef'
    if row[tag]
      row.delete tag
    end
    tag = 'TableName'
    if row[tag]
      row.delete tag
    end

    fields = row.keys.join(',')
    fields
  end

  def print_table_news(bigmap, row)
    template = row['TableName']
    if @table_template_map.keys.include? template
      highlight_keys = get_highlight_keys row
      table_template = @table_template_map[template]
      print_key      = table_template['print_ind']
      table_title    = table_template['title']
      num_of_column  = table_template['column']
      table_fields   = table_template['fields']

      tables = []
      bigmap["#{@myref}.NumOfNews"].to_i.times do |i|
        table_fields_tmp = table_fields.gsub('00', (i+1).to_s.rjust(2, '0'))
        # process field
        fields = ''
        table_fields_tmp.split(',').each do |key|
          key = key.strip
          if key =~ /filler\((.*)\)$/
            key = val = $1
          else
            val = bigmap["#{@myref}.#{key}"]
            val = '<space>' if val.nil? or val.strip == ''
          end
          key = key.gsub('_', ' ')
          fields += "#{key}=#{val};"
        end
        # special handle field/value
        # -- replace <space> with '\n'
        # -- replace '_' with space
        fields         = fields.gsub('<space>',"\n")
        highlight_keys = highlight_keys.gsub('_', ' ')
        # print pdf
        tables << { 'Title'       => table_title,
                    'NumOfColumn' => num_of_column,
                    'Template'    => highlight_keys,
                    'TextMsg'     => fields,
                    'BinMsg'      => '' }
        
      end
      OMDUtil.print_pdf_table(tables, print_key)
    end
  end

  def print_table_index(bigmap, row)
    template = row['TableName']
    if @table_template_map.keys.include? template
      highlight_keys = get_highlight_keys row
      table_template = @table_template_map[template]
      print_key      = table_template['print_ind']
      table_title    = table_template['title']
      num_of_column  = table_template['column']
      table_fields   = table_template['fields']

      # process field
      fields = "Index Code=Index Code;Spot=Spot;Change(%)=Change(%);High=High;Low=Low;Open=Open;Close=Close;EAS=EAS;Turnover=Turnover;Volume=Volume;Previous Session Close=Previous Session Close;Index Status=Index Status;Index Time=Index Time;"
      field_template = ['IndexCode00','IndexSpot00','IndexChange00','IndexHigh00','IndexLow00','IndexOpen00','IndexClose00','IndexEAS00','IndexTurnover00','IndexVolume00','IndexPrevClose00','IndexStatus00','IndexTime00']
      bigmap["#{@myref}.NumOfIndex"].to_i.times do |i|
        field_template.each do |key|
          key = key.gsub('00', (i+1).to_s.rjust(2, '0'))
          val = bigmap["#{@myref}.#{key}"]
          val = '<space>' if val.nil? or val.strip == ''
          fields += "#{key}=#{val};"
        end
      end

      # special handle field/value
      # -- replace <space> with '\n'
      # -- replace '_' with space
      fields         = fields.gsub('<space>',"\n")
      highlight_keys = highlight_keys.gsub('_', ' ')
      tables = [ { 'Title'       => table_title,
                   'NumOfColumn' => num_of_column,
                   'Template'    => highlight_keys,
                   'TextMsg'     => fields,
                   'BinMsg'      => '' } ]
      OMDUtil.print_pdf_table(tables, print_key)
    end
  end

  def print_table_with_template(bigmap, row)
    template = row['TableName']

    #special handle table News
    return print_table_news(bigmap, row) if template == 'P1_News'
    #special handle table Index
    return print_table_index(bigmap, row) if template == 'P6_Index_Details'

    if @table_template_map.keys.include? template
      highlight_keys = get_highlight_keys row
      table_template = @table_template_map[template]
      print_key      = table_template['print_ind']
      table_title    = table_template['title']
      num_of_column  = table_template['column']
      table_fields   = table_template['fields']
      # process field
      fields = ''
      table_fields.split(',').each do |key|
        key = key.strip
        if key =~ /filler\((.*)\)$/
          key = val = $1
        else
          val = bigmap["#{@myref}.#{key}"]
          val = '<space>' if val.nil? or val.strip == ''
        end
        key = key.gsub('_', ' ')
        fields += "#{key}=#{val};"
      end
      # special handle field/value
      # -- replace <space> with '\n'
      # -- replace '_' with space
      fields         = fields.gsub('<space>',"\n")
      highlight_keys = highlight_keys.gsub('_', ' ')
      # print pdf
      tables = [ { 'Title'       => table_title,
                   'NumOfColumn' => num_of_column,
                   'Template'    => highlight_keys,
                   'TextMsg'     => fields,
                   'BinMsg'      => '' } ]
      OMDUtil.print_pdf_table(tables, print_key)
    end
  end

  # handle value of row field
  def handle_field_value(row)
    row.default = nil
    row = Marshal.load(Marshal.dump(row))
    row = $omd_validator.handle_null(row)
    row = $omd_validator.handle_variable(row)
    row
  end

  # pre-process row
  def pre_process_row(row)
    @myref = nil
    tag = 'MyRef'
    if row[tag]
      @myref = row[tag].strip if row[tag].to_s.strip.size > 0
      row.delete 'MyRef'
    end
    $error_handler.report(:missing_field, [tag]) if @myref.nil?
    row = $omd_alias_handler.handle(row) if $omd_alias_handler
    row = handle_field_value(row)
    row
  end

  # send request request
  def send_lastbbo(row)
    message = { 'action'  => 'lastbbo',
                'message' => {},
                'time'    => '' }
    message['message']['fields'] = get_fields(row)
    res = JSON.parse @omd_ct_proxy.send_raw(message.to_json)
    unless res['status'] == 'success'
      $error_handler.error_msg = ('error msg: failed to dump last bid and ask, reason=' + res['error_msg'])
      $error_handler.trigger
    end
    res
  end

  # send request request
  def send_request(row)
    message = { 'action'  => 'request',
                'message' => {},
                'time'    => '' }
    message['message']['fields'] = get_fields(row)
    res = JSON.parse @omd_ct_proxy.send_raw(message.to_json)
    unless res['status'] == 'success'
      $error_handler.error_msg = ('error msg: failed to dump client tool data, reason=' + res['error_msg'])
      $error_handler.trigger
    end
    res
  end

  # send close request
  def send_close(row)
    message = { 'action'  => 'quit',
                'message' => {},
                'time'    => '' }
    message['message']['fields'] = get_fields(row)
    res = JSON.parse @omd_ct_proxy.send_raw(message.to_json)
    unless res['status'] == 'success'
      $error_handler.error_msg = ('error msg:' + res['error_msg'])
      $error_handler.trigger
    end
    res
  end

  # dump snapshot of client tool
  def dump_snapshot(row)
    if @lastbbo_ind
      res     = send_lastbbo(row)
    else
      res     = send_request(row)
    end
    @bigmap = @bigmap.merge get_result_hash(res['info_msg'])
  end

  def close_proxy(row)
    send_close(row)
    send_close(row)
  end

  # check table template for product
  def check_table_template(product, template)
    if @product_table_map[product].include? template
      # pass checking
    else
      # report error
      error = "table [#{template}] is not one of the valid table for product [#{product}]: #{@product_table_map[product]}"
      $error_handler.error_msg = error
      $error_handler.trigger
    end
  end

  # verify table
  def verify_table(row)
    row = row.clone
    tag = 'MyRef'
    if row[tag]
      row.delete tag
    end
    tag = 'TableName'
    if row[tag]
      template       = row[tag]
      table_template = @table_template_map[template]
      table_fields   = []
      table_template['fields'].split(',').each {|x| table_fields << x.strip }
      row.delete tag
    end

    field_not_found = ''
    field_expect    = ''
    field_actual    = ''
    row.each do |key, val|
      key = key.strip
      if table_fields.include? key
        expect_val = val
        actual_val = @bigmap["#{@myref}.#{key}"]
        if expect_val =~ /^regex\((.*)\)$/
          expect_regex = "^#{expect_val[6..-2]}$"
          unless actual_val.match(expect_regex)
            field_expect += " #{key}=#{expect_val}"
            field_actual += " #{key}=#{actual_val}"
          end
        elsif expect_val[0] == '"' and expect_val[-1] == '"'
          unless "#{expect_val[1..-2]}" == "#{actual_val}"
            field_expect += " #{key}=#{expect_val[1..-2]}"
            field_actual += " #{key}=#{actual_val}"
          end
        else
          unless "#{expect_val}" == "#{actual_val}"
            field_expect += " #{key}=#{expect_val}"
            field_actual += " #{key}=#{actual_val}"
          end
        end
      else
        field_not_found += (" " + key)
      end
    end

    error = ''
    if field_not_found != ''
      error += "fields #{field_not_found} not found. "
    end
    if field_expect != ''
      error += "expect fields #{field_expect}, but actually received #{field_actual}. "
    end
    if error != ''
      $error_handler.error_msg = ('error msg:' + error)
      $error_handler.trigger
    end
  end

  # verify table
  def verify(table_hash)
    @subjects.each do |sub, product|
      $error_handler.subject = sub
      # process table
      index = 1
      table_hash.each do | row |
        $error_handler.index = index
        row = row.clone
        row = pre_process_row(row)
        check_table_template(product, row['TableName'])
        # print
        print_table_with_template(@bigmap, row)
        # verify
        verify_table(row)
        index += 1;
      end
    end
  end

  # submit table
  def submit(table_hash)
    $world.puts "Process Time: #{OMDUtil.now_time}" if $world
    @subjects.each do |sub, product|
      $error_handler.subject = sub
      # connect proxy
      server_info = @product_proxy_map[product]
      host = server_info[0]
      port = server_info[1]
      @omd_ct_proxy = OMDProxy.new(host, "#{port}".to_i)
      # process table
      index = 1
      table_hash.each do | row |
        $error_handler.index = index
        row = row.clone
        row = pre_process_row(row)
        dump_snapshot(row)
        index += 1;
      end
    end
  end

end
