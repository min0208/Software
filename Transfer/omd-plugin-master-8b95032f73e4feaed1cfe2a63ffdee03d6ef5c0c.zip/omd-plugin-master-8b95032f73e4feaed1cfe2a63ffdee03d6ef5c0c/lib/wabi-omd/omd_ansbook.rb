# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd ans book handler

# require 'rubyXL'
require 'json'

# refs OMDD Readiness Test Answer Book v2.2
def print_filtered_keys(expected_prefix)
  # TODO, slightly troublesome, no special handling for repeating group, so there are chance that things like LPBrokerNumber could not be fetched since column names are the same

  $logger.info "searching #{expected_prefix}"
  fetched = @bigmap.select{ |x| x.start_with?(expected_prefix)}
  if fetched
    $logger.info "found #{fetched.length} #{expected_prefix} records"
    $logger.info JSON.pretty_generate(fetched) 

    # fh = File.open("/home/bigmap.json", "a")
    # fh.write(JSON.dump(fetched))
    # fh.write(JSON.pretty_generate(fetched) )
  else
    $logger.warn "can't find #{expected_prefix} at bigmap"
  end
end

def search_on_client_tool(answerbook_search)

  watch_security = answerbook_search["SecurityCode"]
  watch_index    = answerbook_search["IndexCode"]

  begin
    for product in ["Securities Standard", "Securities Premium", "Securities FullTick" ]
      watch_security.each_with_index do | security, idx |
        steps %Q{
          * #{product} dump client tool data:
          | MyRef                              | SecurityCode   | ExcludedSecurity | ExcludedMarket | ExcludedNews | ExecludedCurrency |
          | ANSBOOK_CT_#{product}_#{security}_ | #{security}    | N                | N              | N            | N                 |
        }

      #  print_filtered_keys("ANSBOOK_CT_#{product}_#{security}")
      # query_answer_book_to_client_tool(product, to_search)
      end
    end 
#    print_filtered_keys("ANSBOOK_CT_#{product}_#{security}")

    for product in ["Index"]
      watch_index.each_with_index do | security, idx |
        steps %Q{
          * #{product} dump client tool data:
          | MyRef               | IndexCode      | ExcludedSecurity | ExcludedMarket | ExcludedNews | ExecludedCurrency |
          | ANSBOOK_CT_Index    | #{security}    | N                | N              | N            | N                 |
        }

      # query_answer_book_to_client_tool(product, to_search)
      end
    end 
 #  $logger.info "--------search_on_client_tool---59-------"
 #  $logger.info @bigmap  
 #  $logger.info "----------------------------------------"
  rescue
    $logger.warn "error set time range for answer book query"
  end
end

def search_on_proxy_message(answerbook_search)

  watch_security = answerbook_search["SecurityCode"]
  watch_index_code = answerbook_search["IndexCode"]

  @search_last_message_duration = 60 * 60 * 24
  # @search_last_message_timeout = 10
  @search_proxy_only_once = true

  begin
      # * Set 2019-04-22 07:00:00 as ANSBOOK_TS_START
      # * Set 2019-04-22 19:00:00 as ANSBOOK_TS_END
    steps %Q{
      * Set 07:00:00 as ANSBOOK_TS_START
      * Set 19:00:00 as ANSBOOK_TS_END
    }
  rescue
    $logger.warn "error set time range for answer book query"
  end

  $logger.info "ANSBOOK_TS_START is #{$timestamps["ANSBOOK_TS_START"]}"
  $logger.info "ANSBOOK_TS_END is #{$timestamps["ANSBOOK_TS_END"]}"

  # global, nothing related
  for msg_type in ["MarketDefinition"]
    begin
      steps %Q{
        * Securities Standard search last message from ANSBOOK_TS_START to ANSBOOK_TS_END:
        | Template    | ResponseRef                |
        | #{msg_type} | ANSBOOK_PROXY_#{msg_type}_ |
      }
    rescue
      $logger.warn "error search #{msg_type} from proxy log"
    end
    print_filtered_keys("ANSBOOK_PROXY_#{msg_type}_")
  end

  for msg_type in ["IndexDefinition", "IndexData"]                                                          
  # for msg_type in ["IndexDefinition"]
    for index_code in watch_index_code
      begin
        steps %Q{
          * Index search last message from ANSBOOK_TS_START to ANSBOOK_TS_END:
          | Template    | IndexCode     | ResponseRef                             |
          | #{msg_type} | #{index_code} | ANSBOOK_PROXY_#{msg_type}_#{index_code} |
        }
      rescue
        $logger.warn "error search #{msg_type} from proxy log"
      end
    end
    print_filtered_keys("ANSBOOK_PROXY_#{msg_type}_")
  end

  # market related
  market_list = ["MAIN", "GEM ", "NASD", "ETS "]
  currency_list = ["AUD", "CAD", "CNH", "CNY", "EUR", "GBP", "HKD", "JPY", "SGD", "USD", "KRW", "RUB", "   "]
  
  # 1_
  for market in market_list
    begin
      steps %Q{
        * Securities Standard search last message from ANSBOOK_TS_START to ANSBOOK_TS_END:
        | Template         | MarketCode   | ResponseRef                              |
        | MarketDefinition | "#{market}"  | ANSBOOK_PROXY_MarketDefinition_#{market} |
      }
    rescue
      $logger.warn "error search MarketDefinition for market #{market} from proxy log"
    end

    for currency in currency_list
      begin
        steps %Q{
          * Securities Standard search last message from ANSBOOK_TS_START to ANSBOOK_TS_END:
          | Template         | MarketCode  | CurrencyCode   | ResponseRef                                          |
          | MarketTurnover   | "#{market}" | "#{currency}"  | "ANSBOOK_PROXY_MarketTurnover_#{market}_#{currency}" |
        }
      rescue
        $logger.warn "error search MarketTurnover for market #{market} from proxy log"
      end
    end
  end

  print_filtered_keys("ANSBOOK_PROXY_Market_")
  print_filtered_keys("ANSBOOK_PROXY_MarketTurnover_")

  # currency related
  for currency in currency_list
    begin
      steps %Q{
        * Securities Standard search last message from ANSBOOK_TS_START to ANSBOOK_TS_END:
        | Template           | CurrencyCode   | ResponseRef                              |
        | CurrencyRate       | "#{currency}"  | "ANSBOOK_PROXY_CurrencyRate_#{currency}" |
      }
    rescue
      $logger.warn "error search CurrencyRate for currency #{currency} from proxy log"
    end
  end

  print_filtered_keys("ANSBOOK_PROXY_CurrencyRate")
=end
  # security related, on given product / msg_type / security code

  #SecuritiesPremium, SecuritiesStandard, SecuritiesFullTick
  product_and_msg_types = [
    ["Securities Premium",  "Trade"],
    ["Securities Standard", "TradeTicker"],
    ["Securities FullTick", "TradeCancel"],
    ["Securities Standard", "TradingSessionStatus"],
    ["Securities Standard", "News"],
    ["Securities Standard", "IndicativeEquilibriumPrice"],
    ["Securities FullTick", "IndicativeEquilibriumPrice"],
    ["Securities Premium",  "IndicativeEquilibriumPrice"],
    ["Securities Standard", "OrderImbalance"],
    ["Securities FullTick", "OrderImbalance"],
    # "Stock Connect Daily"
    ["Stock Connect Data",  "StockConnectDailyQuotaBalance"],
    ["Stock Connect Data",  "StockConnectMarketTurnover"],
    ["Securities Standard", "SecurityDefinition"],
    ["Securities Standard", "LiquidityProvider"],
    ["Securities Standard", "SecurityStatus"],
    ["Securities Premium",  "Statistics"],
    ["Securities Standard", "Yield"],
    ["Securities Premium",  "ClosingPrice"],
    ["Securities Standard", "NominalPrice"],
    ["Securities Standard", "ReferencePrice"],
    ["Securities Standard", "VCMTrigger"],
  ]

  for pair in product_and_msg_types
    product = pair[0]
    msg_type = pair[1]
    for security in watch_security
      begin
        if "Trade" == msg_type or "TradeCancel" == msg_type or "TradeTicker" == msg_type
          get_trade_list(product, msg_type, security)
        elsif  "IndicativeEquilibriumPrice" == msg_type
          steps %Q{
            * #{product} search all the message from ANSBOOK_TS_START to ANSBOOK_TS_END:
              | Template    | SecurityCode   | ResponseRef                                |
              | #{msg_type} | #{security}    | ANSBOOK_PROXY_IEP_#{product}_#{security}_  |
          }
        elsif  "OrderImbalance" == msg_type
          steps %Q{
            * #{product} search all the message from ANSBOOK_TS_START to ANSBOOK_TS_END:
              | Template    | SecurityCode   | ResponseRef                                       |
              | #{msg_type} | #{security}    | ANSBOOK_PROXY_OImbalance_#{product}_#{security}_  |
          }
        elsif  ["TradingSessionStatus", "News", "StockConnectDailyQuotaBalance", "StockConnectMarketTurnover"].include? msg_type
           steps %Q{
            * #{product} search all the message from ANSBOOK_TS_START to ANSBOOK_TS_END:
            | Template    | ResponseRef                |
            | #{msg_type} | ANSBOOK_PROXY_#{msg_type}_ |
          }
        else
          steps %Q{
          * #{product} search last message from ANSBOOK_TS_START to ANSBOOK_TS_END:
          | Template    | SecurityCode | ResponseRef                                      |
          | #{msg_type} | #{security}  | ANSBOOK_PROXY_#{msg_type}_#{security}_            | 
        }
        end
      rescue
        $logger.warn "!!!!!error search #{msg_type} for security #{security} from #{product} proxy log"
      end
    end

    # print_filtered_keys("ANSBOOK_PROXY_IEP_#{product}_#{security}")

  end
end

def get_trade_list(product, msg_type, security)
  begin
    steps %Q{
      * #{product} search all the message from ANSBOOK_TS_START to ANSBOOK_TS_END:
      | Template    | SecurityCode | ResponseRef                                  |
      | #{msg_type} | #{security}  | ANSBOOK_PROXY_#{msg_type}_#{security}_       | 
    }

  # @bigmap["ANSBOOK_PROXY_#{msg_type}_#{security}"] == 
  # {
  #    "ANSBOOK_PROXY_Trade_30014"=>
    #   [
    #     {"MsgTime"=>"2019-09-19 09:49:55.070000", "ChannelID"=>"21", "SeqNum"=>"9076", "MsgSize"=>"32", "MsgType"=>"50", 
    #       "SecurityCode"=>"30014", "TradeID"=>"1", "Price"=>"0.13", "Quantity"=>"10000", "TrdType"=>"0", 
    #       "TradeTime"=>"2019-09-19 01:49:55.000000"},
    #     {"MsgTime"=>"2019-09-19 09:49:57.846000", "ChannelID"=>"21", "SeqNum"=>"9083", "MsgSize"=>"32", "MsgType"=>"50", 
    #       "SecurityCode"=>"30014", "TradeID"=>"2", "Price"=>"0.12", "Quantity"=>"5000", "TrdType"=>"0",
    #       "TradeTime"=>"2019-09-19 01:49:57.000000"
    #      } 
    #   ],
    #  "ANSBOOK_PROXY_Trade_30042"=>
    #   [
    #     {"MsgTime"=>"2019-09-20 09:49:49.348000", "ChannelID"=>"20", "SeqNum"=>"9051", "MsgSize"=>"32", "MsgType"=>"50", 
    #       "SecurityCode"=>"30042", "TradeID"=>"1", "Price"=>"15", "Quantity"=>"1000", "TrdType"=>"0", 
    #       "TradeTime"=>"2019-09-20 01:49:49.000000"
    #     }
    #   ]
  # }

  # $logger.info "=============ANSBOOK_PROXY_#{msg_type}_#{security}=================="
  # $logger.info  @bigmap
  # $logger.info "===================================================================="
  rescue => e
    $logger.warn "Error search #{msg_type} for security #{security} from log!!!!!"
    reuturn nil
  end

end

def gen_excel_tab_from_proxy(ws, msg_type, config, watch_security, f_border_title, f_border_content)
  
  # generate excel table from data been collected into @bigmap

  # for each securiyt / msgtype, there would be a loop

  # [at_row, at_column] was the overall co-ordinates in 2d array
  # debug_table is to show the conbination of overall result

  # while a new security code meet
  # at_row should reset 
  # at_column should shift / add a specific width 

  # f_border_title, f_border_content are just format description

  at_column = 0
  at_row = 0
  
  # upper descrition
  for row in config["description"]
    ws.write(at_row, at_column, row)
    at_row += 1
  end
  at_row += 1

  require 'pp'
  product = "Securities Standard"
  # puts "\n-------------------------------generate for #{msg_type}"

  debug_table = []

  if "Trade_and_Trade_Cancel" == msg_type 
    for security in watch_security
      if gen_trade_and_tradeCancel(ws, security, at_row, at_column, debug_table, f_border_title, f_border_content)
        at_column += 7
      end
      at_row = 2
    end
    pp debug_table
    return nil
  elsif "TradeTicker" == msg_type   
    for security in watch_security
      if gen_trade_ticker(msg_type, ws, security, at_row, at_column, debug_table, f_border_title, f_border_content)
        at_column += 7
      end
      at_row = 2
    end  
    pp debug_table
    return nil                            
  elsif ["TradingSessionStatus", "StockConnectDailyQuotaBalance", "StockConnectMarketTurnover" ].include? msg_type
      if gen_trading_session_status(msg_type, ws, config, at_row, at_column, debug_table, f_border_title, f_border_content)
      end
    return nil  
  elsif "News"== msg_type
    # for security in watch_security
      if gen_news(msg_type, ws, config, at_row, at_column, debug_table, f_border_title, f_border_content)
      end
      # at_column += 6
    # end  
    return nil  
  elsif "IndicativeEquilibriumPrice" == msg_type   
    for p in ["Securities Standard", "Securities FullTick", "Securities Premium"]
      start_column = at_column
      if gen_IEP(p, watch_security, ws, config, at_row, start_column, debug_table, f_border_title, f_border_content)
      end
      at_row += 6
    end  
    # pp debug_table
    return nil  
  elsif "Order_Imbalance" == msg_type   
    for p in ["Securities Standard", "Securities FullTick", "Securities Premium"]
      start_column = at_column
      if gen_order_imbalance(p, watch_security, ws, config, at_row, start_column, debug_table, f_border_title, f_border_content)
      end
      at_row += 6
    end  
    # pp debug_table
    return nil  
  end

  pp debug_table
  # debug_table header at left
  for row in config["header"]
    for c, i in row.each_with_index
      ws.write(at_row + i, at_column, c, f_border_title)
    end
    at_column += 1
  end

  fetched = Set.new(@bigmap.select{|x| x.start_with?("#{config["data_source"]}_#{msg_type}_")}.keys().map{|x| x.sub(/\..*/, "")})
  if fetched.length == 0
    $logger.warn "Cann't find #{config["data_source"]}_#{msg_type}_ , ignore"
    return nil
  else
    $logger.info "found #{fetched.length} #{config["data_source"]}_#{msg_type}_ record"
  end

  # sample data row, this would later retrive / fulfilled from client tool or omd proxy
  for found_data in fetched
  # for row in config["sample_data"]
    $logger.info "found_data #{found_data}"

    ws.write_string(at_row, at_column, "Expected Value", f_border_content)
#    at_row += 1
    
  # for column_name, i in (["Expected Value"] + config["header"][1][1..-1]).each_with_index
    for column_name, i in (config["header"][1][1..-1]).each_with_index
    # for c, i in (["Expected Value"] + row).each_with_index
        #
      # in order to support things like LPBroderNumber (1) / (2)
        #

      $logger.info "on column #{column_name}, retrived data #{@bigmap["#{found_data}.#{column_name}"]}"
      # if "Expected Value" == #{column_name}
      #   #{@bigmap["#{found_data}.#{column_name}"] = "Expected Value"
      # end
      ws.write_string(at_row + 1 + i, at_column, "#{@bigmap["#{found_data}.#{column_name}"].to_s}", f_border_content)
    end

    at_column += 1
 
    # empty line
    for c, i in (["Expected Value"] + config["header"][1][1..-1]).each_with_index
      ws.write(at_row + 1 + i, at_column, "")
    end
 
    at_column += 1
  end
 
end

def gen_orderbook( ws, security, at_row, at_column, debug_table, f_border_title, f_border_content)
  product = "Securities Standard" 

  bid_header = ["BidAOBNumOfOrder", "BidAOBQuantity", "BidAOBPrice", "BidAOBPriceLevel"]
  ask_header = ["AskAOBNumOfOrder", "AskAOBQuantity", "AskAOBPrice", "AskAOBPriceLevel"]
  # header = bid_header + ask_header
  header = ["No. of Orders", "AggregatedQuantity", "Price", "PriceLevel", "PriceLevel", "Price", "AggregatedQuantity", "No. of Orders"]
  debug_table.push(header)

  for c, i in ["StockCode", security].each_with_index
    ws.write(at_row, at_column + i, c, f_border_title)
  end
  at_row += 1

  for c, i in header.each_with_index
    ws.write(at_row, at_column + i, c, f_border_title)
  end
  at_row += 1

  # if (@bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfBidAOB"] == "0" and @bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfAskAOB"] == "0")
  #   tmp_buy = ["", "Empty Book", "","", "","" ,"", ""]
  #   tmp_ask = ["", "", "","", "","Empty Book" ,"", ""]
     
  #   for c, i in tmp_bug.each_with_index
  #     ws.write(at_row, at_column + i , c, f_border_content)
  #   end
  #   for c, i in tmp_ask.each_with_index
  #     ws.write(at_row + 1, at_column + i , c, f_border_content)
  #   end
    
  #   return false
  # end

  if @bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfBidAOB"] != "0"
    for i in (1..@bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfBidAOB"].to_i)
      number = "0#{i}"[-2..-1]
      # puts "work on number #{number}"
      # row = ["", "", "", ""] + bid_header.map{ |x| @bigmap["ANSBOOK_CT_#{product}_#{security}.#{x}#{number}"]}.reverse
      row =  bid_header.map{ |x| @bigmap["ANSBOOK_CT_#{product}_#{security}.#{x}#{number}"]} + ["", "", "", ""]

      for c, i in row.each_with_index
	#display 1K as 1000, 1M as 1000000
        c = c.gsub('K','000')
        c = c.gsub('M','000000')
	    ws.write(at_row, at_column + i, c, f_border_content)
      end
      at_row += 1

      debug_table.push(row)
    end
  else
    tmp_src = [" ", "Empty Book", "", "", "","", "", ""]
    for c, i in tmp_src.each_with_index
      ws.write(at_row, at_column + i , c, f_border_content)
    end
    at_row += 1
  end

  if @bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfAskAOB"] != "0"
    for i in (1..@bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfAskAOB"].to_i)
      number = "0#{i}"[-2..-1]
      row = ["", "", "", ""] + ask_header.map{ |x| @bigmap["ANSBOOK_CT_#{product}_#{security}.#{x}#{number}"]}.reverse
      for c, i in row.each_with_index
        c = c.gsub('K','000')
        c = c.gsub('M','000000')
        ws.write(at_row, at_column + i, c, f_border_content)
      end
      at_row += 1

      debug_table.push(row)
    end
  else
    tmp_src = ["", "", "","", "", "Empty Book","", ""] 
    for c, i in tmp_src.each_with_index
      ws.write(at_row, at_column  + i, c, f_border_content)
    end
  end
  return true
end

def gen_broadLot(ws, security, at_row, at_column, debug_table, f_border_title, f_border_content)

  product = "Securities FullTick" 

  bid_header = ["BidBoardLotOrderID", "BidBoardLotType", "BidBoardLotQuantity", "BidBoardLotPrice"]
  ask_header = ["AskBoardLotOrderID", "AskBoardLotType", "AskBoardLotQuantity", "AskBoardLotPrice"]
  # header = bid_header + ask_header
  header = ["OrderID", "OrderType", "Quantity", "Price", "Price", "Quantity", "OrderType", "OrderID"]
  
  for c, i in ["StockCode", security].each_with_index
    ws.write(at_row, at_column + i, c, f_border_title)
  end
  at_row += 1

  for c, i in ["", "", "Buy", "", "", "", "Sell", ""].each_with_index
    ws.write(at_row, at_column + i, c, f_border_title)
  end
  at_row += 1

  for c, i in header.each_with_index
    ws.write(at_row, at_column + i, c, f_border_title)
  end
  at_row += 1

  if nil == @bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfBidBoardLot"] or
    nil == @bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfAskBoardLot"]
    return nil 
  end 
  # if (@bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfBidAOB"] == "0" and @bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfAskAOB"] == "0")
  #   tmp_buy = ["", "Empty Book", "","", "","" ,"", ""]
  #   tmp_ask = ["", "", "","", "","Empty Book" ,"", ""]
     
  #   for c, i in tmp_bug.each_with_index
  #     ws.write(at_row, at_column + i , c, f_border_content)
  #   end
  #   for c, i in tmp_ask.each_with_index
  #     ws.write(at_row + 1, at_column + i , c, f_border_content)
  #   end
    
  #   return false
  # end

  # p "----------------==----------#{"ANSBOOK_CT_#{product}_#{security}.NumOfBidBoardLot"}------------------------"
  # p @bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfBidBoardLot"]
  # p @bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfAskBoardLot"]
  debug_table.push(header)

  if @bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfBidBoardLot"] != "0"
    for i in (1..@bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfBidBoardLot"].to_i)
      number = "0#{i}"[-2..-1]
      row =  bid_header.map{ |x| @bigmap["ANSBOOK_CT_#{product}_#{security}.#{x}#{number}"]} + ["", "", "", ""]

      for c, i in row.each_with_index
        #display 1K as 1000, 1M as 1000000
        c = c.gsub('K','000')
        c = c.gsub('M','000000')
      ws.write(at_row, at_column + i, c, f_border_content)
      end
      at_row += 1

      debug_table.push(row)
    end
  else
    tmp_src = [" ", "Empty Book","", "", "","", "", ""]
    for c, i in tmp_src.each_with_index
      ws.write(at_row, at_column + i , c, f_border_content)
    end
    at_row += 1
  end

  if @bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfAskBoardLot"] != "0"
    for i in (1..@bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfAskBoardLot"].to_i)
      number = "0#{i}"[-2..-1]
      row = ["", "", "", ""] + ask_header.map{ |x| @bigmap["ANSBOOK_CT_#{product}_#{security}.#{x}#{number}"]}.reverse

      for c, i in row.each_with_index
        c = c.gsub('K','000')
        c = c.gsub('M','000000')
        ws.write(at_row, at_column + i, c, f_border_content)
      end
      at_row += 1

      debug_table.push(row)
    end
  else
    tmp_src = ["", "", "","", "", "Empty Book", "", ""] 
    for c, i in tmp_src.each_with_index
      ws.write(at_row, at_column + i , c, f_border_content)
    end
  end
  return true
end

def gen_OddLot(ws, security, at_row, at_column, debug_table, f_border_title, f_border_content)
  product = "Securities FullTick" 

  bid_header = ["BidMOddLotOrderID", "BidMOddLotBrokerID", "BidMOddLotQuantity", "BidMOddLotPrice"]
  ask_header = ["AskMOddLotOrderID", "AskMOddLotBrokerID", "AskMOddLotQuantity", "AskMOddLotPrice"]

  header = ["Order ID", "Broker ID", "Quantity", "Price", "Price" ,"Quantity", "Broker ID", "Order ID"]
  debug_table.push(header)

  for c, i in ["StockCode", security].each_with_index
    ws.write(at_row, at_column + i, c, f_border_title)
  end
  at_row += 1

  for c, i in ["", "", "Buy", "", "", "", "Sell", ""].each_with_index
    ws.write(at_row, at_column + i, c, f_border_title)
  end
  at_row += 1

  for c, i in header.each_with_index
    ws.write(at_row, at_column + i, c, f_border_title)
  end
  at_row += 1

  if nil == @bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfBidMOddLot"] or
    nil == @bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfAskMOddLot"]
    return nil 
  end 

  if @bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfBidMOddLot"] != "0"
    for i in (1..@bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfBidMOddLot"].to_i)
      number = "0#{i}"[-2..-1]
      # puts "-------------------------work on number #{number}"
      row =  bid_header.map{ |x| @bigmap["ANSBOOK_CT_#{product}_#{security}.#{x}#{number}"]} + ["", "", "", ""]

      for c, i in row.each_with_index
        #display 1K as 1000, 1M as 1000000
        c = c.gsub('K','000')
        c = c.gsub('M','000000')
      ws.write(at_row, at_column + i, c, f_border_content)
      end
      at_row += 1

      debug_table.push(row)
    end
  else
    tmp_src = [" ", "Empty Book","", "", "","", "", ""]
    for c, i in tmp_src.each_with_index
      ws.write(at_row, at_column + i , c, f_border_content)
    end
    at_row += 1

  end

  if @bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfAskMOddLot"] != "0"
    for i in (1..@bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfAskMOddLot"].to_i)
      number = "0#{i}"[-2..-1]
      # puts "work on number #{number}"
      row = ["", "", "", ""] + ask_header.map{ |x| @bigmap["ANSBOOK_CT_#{product}_#{security}.#{x}#{number}"]}.reverse

      for c, i in row.each_with_index
        c = c.gsub('K','000')
        c = c.gsub('M','000000')
        ws.write(at_row, at_column + i, c, f_border_content)
      end
      at_row += 1

      debug_table.push(row)
    end
  else
    tmp_src = ["", "", "","", "","Empty Book" ,"", ""] 
    for c, i in tmp_src.each_with_index
      ws.write(at_row, at_column + i , c, f_border_content)
    end
  end
  return true
end

def gen_indexData(ws, at_row, at_column, debug_table, f_border_title, f_border_content)
  title_head  = ["OMD Message Type", "71", "71", "71", "71", "71", "71", "71", "71", "71", "71", "71", "71", "71", "71","71"]
  field_title = ["OMD Field Name", "IndexCode", "IndexStatus", "IndexTime", "IndexValue", "NetChgPrevDay",
                    "HighValue", "LowValue", "EASValue", "IndexTurnover", "OpeningValue", "ClosingValue", 
                    "PreviousSesClose", "IndexVolume", "NetChgPrevDayPct", "Exception"]
  field_data  = ["IndexCode", "IndexStatus", "IndexTime", "IndexSpot", "NetChgPrevDay", 
                    "IndexHigh", "IndexLow", "IndexEAS", "IndexTurnover", "IndexOpen", "IndexClose",
                    "IndexPrevClose", "IndexVolume", "NetChgPrevDayPct", "Exception"]

  for c, i in title_head.each_with_index
    ws.write(at_row + i, at_column, c, f_border_title)
  end
  at_column += 1

  for c, i in field_title.each_with_index
    ws.write(at_row + i, at_column, c, f_border_title)
  end
  at_column += 1

  fetch = Set.new(@bigmap.select{|x| x.start_with?("ANSBOOK_CT_Index")}.keys().map{|x| x.sub(/\..*/, "")})
  if fetch.length == 0
    $logger.info "=========Can't fine the ANSBOOK_CT_Index Data===================="
    return nil
  end

  changeValue=""
  changePct=""

  if @bigmap["ANSBOOK_CT_Index.NumOfIndex"] != "0"
    for i in (1..@bigmap["ANSBOOK_CT_Index.NumOfIndex"].to_i)
      number = "0#{i}"[-2..-1]
      ws.write_string(at_row, at_column, "Expected Value", f_border_content)

      indexChangeValue = @bigmap["ANSBOOK_CT_Index.IndexChange#{number}"].to_s
      if nil != indexChangeValue and "" != indexChangeValue # "+123(-1233%)" or "(%)"
        pos1 = indexChangeValue.index('(')
        pos2 = indexChangeValue.index('%')
        changeValue = indexChangeValue[0, pos1]
        changePct   = indexChangeValue[pos1 + 1, pos2 - pos1 - 1]
      end

      for field, j in field_data.each_with_index
        if "NetChgPrevDay" == field
            tmp_value = changeValue
        elsif "NetChgPrevDayPct" == field
            tmp_value = changePct
        else
            tmp_value =  @bigmap["ANSBOOK_CT_Index.#{field}#{number}"].to_s
        end

        ws.write_string(at_row + 1 + j, at_column,  tmp_value, f_border_content)
      end
    at_column += 2
    end
  end
end

def gen_brokerqueue(product, ws, security, at_row, at_column, debug_table, f_border_title, f_border_content)
  header = ["Buy", "Sell"]
  debug_table.push(header)

  header = ["Broker ID", "Broker ID"]
  debug_table.push(header)

  # pp @bigmap.keys().select{|k| /ANSBOOK_CT_#{product}_#{security}.NumOfBidBQ\d+/.match(k)}
  # pp @bigmap.keys().select{|k| /ANSBOOK_CT_#{product}_#{security}.NumOfBidBQ\d+/.match(k)}.map{|c| /^ *$/.match(@bigmap[c])}
  # pp @bigmap.keys().select{|k| /ANSBOOK_CT_#{product}_#{security}.NumOfAskBQ\d+/.match(k)}
  # pp @bigmap.keys().select{|k| /ANSBOOK_CT_#{product}_#{security}.NumOfAskBQ\d+/.match(k)}.map{|c| /^ *$/.match(@bigmap[c])}

  # TODO, remove empty broker queue
  if not false
    for c, i in ["StockCode", security].each_with_index
      ws.write(at_row, at_column + i, c, f_border_title)
    end
    at_row += 1

    for c, i in ["Buy", "Sell"].each_with_index
      ws.write(at_row, at_column + i, c, f_border_title)
    end
    at_row += 1

    for c, i in header.each_with_index
      ws.write(at_row, at_column + i, c, f_border_title)
    end
    at_row += 1
  else
    return false
  end

  if @bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfBidBQ"] != "0"

    for i in (1..@bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfBidBQ"].to_i)
      number = "0#{i}"[-2..-1]
      # puts "work on number #{number}"
      row = [@bigmap["ANSBOOK_CT_#{product}_#{security}.BidBQBrokerID#{number}"]] + [""]

      if not row.map{|c| /^ *$/.match(c)}.all?
        for c, i in row.each_with_index
		# display '-1s' as '(1)'
			c = c.gsub('-','(').gsub('s',')')
          ws.write(at_row, at_column + i, c, f_border_content)
        end
        at_row += 1
        debug_table.push(row)
      end
    end
  end

  if @bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfAskBQ"] != "0"
    for i in (1..@bigmap["ANSBOOK_CT_#{product}_#{security}.NumOfAskBQ"].to_i)
      number = "0#{i}"[-2..-1]
      # puts "work on number #{number}" row = [""] + [@bigmap["ANSBOOK_CT_#{product}_#{security}.AskBQBrokerID#{number}"]]
      #
      row = [""] + [@bigmap["ANSBOOK_CT_#{product}_#{security}.AskBQBrokerID#{number}"]]

      if not row.map{|c| /^ *$/.match(c) }.all?
        for c, i in row.each_with_index
        #display '+1s' as '(1)'
    	c = c.gsub('+','(').gsub('s',')') 
	     ws.write(at_row, at_column + i, c, f_border_content)
        end
        at_row += 1
        debug_table.push(row)
      end
    end
  end
  return true

end

def gen_trade_and_tradeCancel(ws, security, at_row, at_column, debug_table, f_border_title, f_border_content)

  title  = ["TradeTime", "TradeID", "TradeType", "Price", "Quantity", "Cancel (Yes Or No)"]
  header = ["TradeTime", "TradeID", "TrdType", "Price", "Quantity", "Cancel (Yes Or No)"]

  for c, i in ["Stock Code", security].each_with_index
    ws.write(at_row, at_column + i, c, f_border_title)
  end 
  at_row += 1

  for c, i in title.each_with_index
    ws.write(at_row, at_column + i, c, f_border_title)
  end 
  at_row += 1

  fetchedTrade = Set.new(@bigmap.select{|x| x.start_with?("ANSBOOK_PROXY_Trade_#{security}_")}.keys().map{|x| x.sub(/\..*/, "")})
  if fetchedTrade.length == 0
    return nil
  end
 
  fetchedCancel = Set.new(@bigmap.select{|x| x.start_with?("ANSBOOK_PROXY_TradeCancel_#{security}_")}.keys().map{|x| x.sub(/\..*/, "")})
  # if fetchedCancel.length == 0
  #   $logger.warn " Cann't find ANSBOOK_PROXY_TradeCancel_#{security}"
  # end

  # if nil == @bigmap["ANSBOOK_PROXY_Trade_#{security}"]
  #   return nil
  # end

  for r in @bigmap["ANSBOOK_PROXY_Trade_#{security}_"]
    current_row = []
    for c, i in header.each_with_index
      current_row.push(r[c])

      if "Cancel (Yes Or No)" == c 
        if fetchedCancel.length > 0  # there is tradecancel in bigmap

          for k in @bigmap["ANSBOOK_PROXY_TradeCancel_#{security}_"]
            if r["TradeID"] == k["TradeID"]
              ws.write(at_row, at_column + i, "Y", f_border_content)
              current_row.push("Y")
              break
            end
            ws.write(at_row, at_column + i, " ", f_border_content)
            # current_row.push(" ")
          end
        else
          ws.write(at_row, at_column + i, " ", f_border_content)
          current_row.push(" ")
        end
      else
        ws.write(at_row, at_column + i, r[c], f_border_content)
      end
    end

    # decide if current row / trade was canceled
    at_row += 1
    debug_table.push(current_row)
  end
end


def gen_trade_ticker(msg_type, ws, security, at_row, at_column, debug_table, f_border_title, f_border_content)

  title  = ["TradeTime", "TickerID", "TradeType", "Price", "AggregateQuantity", "TrdCancelFlag"]
  header = ["TradeTime", "TickerID", "TrdType", "Price", "AggregateQuantity", "TrdCancelFlag"]

  fetchedTrade = Set.new(@bigmap.select{|x| x.start_with?("ANSBOOK_PROXY_#{msg_type}_#{security}_")}.keys().map{|x| x.sub(/\..*/, "")})
  if fetchedTrade.length == 0
    return nil
  end

  for c, i in ["StockCode", security].each_with_index
    ws.write(at_row, at_column + i, c, f_border_title)
  end 
  at_row += 1
  for c, i in title.each_with_index
    ws.write(at_row, at_column + i, c, f_border_title)
  end 
  at_row += 1

  for r in @bigmap["ANSBOOK_PROXY_#{msg_type}_#{security}_"]
    current_row = []
    for c, i in header.each_with_index
      current_row.push(r[c])
      ws.write(at_row, at_column + i, r[c], f_border_content)
    end

    # decide if current row / trade was canceled
    at_row += 1
    debug_table.push(current_row)
  end

end

def gen_trading_session_status(msg_type, ws, config, at_row, at_column, debug_table, f_border_title, f_border_content)
  for row in config["header"]
    for c, i in row.each_with_index
      ws.write(at_row + i, at_column, c, f_border_title)
      $logger.debug "write to x: #{at_row + i} y:#{at_column} , value: #{c}"
    end
    at_column += 1
  end

  fetch = Set.new(@bigmap.select{|x| x.start_with?("ANSBOOK_PROXY_#{msg_type}_")}.keys().map{|x| x.sub(/\..*/, "")})
  if fetch.length == 0
    return nil
  end

  # $logger.info "======bigmap: ===#{@bigmap["ANSBOOK_PROXY_#{msg_type}_"]}====== "
  for oneMsg in @bigmap["ANSBOOK_PROXY_#{msg_type}_"]
    #$logger.info "oneMsg is #{oneMsg}"
    start_row = at_row
    ws.write_string(start_row, at_column, "Expected Value", f_border_content)
    start_row += 1

    for column_name, i in (config["header"][1][1..-1]).each_with_index
      if nil == oneMsg[column_name]
        ws.write_string(start_row + i, at_column, "", f_border_content)
      else
        $logger.debug "at i: #{i}, write to x: #{start_row + i} y: #{at_column} , value: #{oneMsg[column_name].to_s}"
        ws.write_string(start_row + i, at_column, oneMsg[column_name].to_s, f_border_content)
      end
    end

    if at_column >= 1000
      break
    end

    at_column += 2
  end
end

def gen_news(msg_type, ws, config, at_row, at_column, debug_table, f_border_title, f_border_content)
  head = ["NewsID","NewsType","Headline","CancelFlag","LastFragment","ReleaseTime","NoMarketCodes",
    "MarketCode","NoSecurityCodes","SecurityCode", "NoNewsLines", "NewsLine (1)","NewsLine (2)",
    "NewsLine (3)","NewsLine (4)","NewsLine (5)","NewsLine (6)" ]

  for row in config["header"]
    for c, i in row.each_with_index
      ws.write(at_row + i, at_column, c, f_border_title)
    end
    at_column += 1
  end

  fetch = Set.new(@bigmap.select{|x| x.start_with?("ANSBOOK_PROXY_#{msg_type}_")}.keys().map{|x| x.sub(/\..*/, "")})
  if fetch.length == 0
    return nil
  end

  for oneMsg in @bigmap["ANSBOOK_PROXY_#{msg_type}_"]
    # $logger.info "=========oneMsg====== #{oneMsg}"
    lineData = []

    start_row = at_row
    ws.write_string(start_row, at_column, "Expected Value", f_border_content)
    start_row += 1

    for column_name, i in head.each_with_index
      if nil == oneMsg[column_name]
        ws.write_string(start_row + i, at_column, " ", f_border_content)
      else
        ws.write_string(start_row + i, at_column, oneMsg[column_name].to_s, f_border_content)
      end
    end
    at_column += 2
  end
end

def gen_IEP(product, watch_security, ws, config, at_row, at_column, debug_table, f_border_title, f_border_content)
# "ANSBOOK_PROXY_IEP_Securities Standard_30056"=>[
#   {"MsgTime"=>"2019-09-23 09:45:17.538000", "ChannelID"=>"10", "SeqNum"=>"2483", "MsgSize"=>"20", "MsgType"=>"41", "SecurityCode"=>"30056", "Price"=>"0", "AggregateQuantity"=>"0"},
#   {"MsgTime"=>"2019-09-23 16:08:10.851000", "ChannelID"=>"10", "SeqNum"=>"47699", "MsgSize"=>"20", "MsgType"=>"41", "SecurityCode"=>"30056", "Price"=>"0", "AggregateQuantity"=>"0"}], 
# "ANSBOOK_PROXY_IEP_Securities Standard_2405"=>[
#   {"MsgTime"=>"2019-09-23 09:45:18.450000", "ChannelID"=>"10", "SeqNum"=>"9690", "MsgSize"=>"20", "MsgType"=>"41", "SecurityCode"=>"2405", "Price"=>"0", "AggregateQuantity"=>"0"}, 
#   {"MsgTime"=>"2019-09-23 16:08:11.086000", "ChannelID"=>"10", "SeqNum"=>"48577", "MsgSize"=>"20", "MsgType"=>"41", "SecurityCode"=>"2405", "Price"=>"0", "AggregateQuantity"=>"0"}], 
# "ANSBOOK_PROXY_IEP_Securities FullTick_30056"=>[
#   {"MsgTime"=>"2019-09-23 09:45:17.493000", "ChannelID"=>"31", "SeqNum"=>"535", "MsgSize"=>"20", "MsgType"=>"41", "SecurityCode"=>"30056", "Price"=>"0", "AggregateQuantity"=>"0"}, 
#   {"MsgTime"=>"2019-09-23 16:08:10.819000", "ChannelID"=>"31", "SeqNum"=>"10383", "MsgSize"=>"20", "MsgType"=>"41", "SecurityCode"=>"30056", "Price"=>"0", "AggregateQuantity"=>"0"}], 
# "ANSBOOK_PROXY_IEP_Securities FullTick_2405"=>[
#   {"MsgTime"=>"2019-09-23 09:45:18.429000", "ChannelID"=>"30", "SeqNum"=>"1298", "MsgSize"=>"20", "MsgType"=>"41", "SecurityCode"=>"2405", "Price"=>"0", "AggregateQuantity"=>"0"},
#   {"MsgTime"=>"2019-09-23 16:08:11.080000", "ChannelID"=>"30", "SeqNum"=>"10707", "MsgSize"=>"20", "MsgType"=>"41", "SecurityCode"=>"2405", "Price"=>"0", "AggregateQuantity"=>"0"}], 
# "ANSBOOK_PROXY_IEP_Securities Premium_30056"=>[
#   {"MsgTime"=>"2019-09-23 09:45:17.493000", "ChannelID"=>"21", "SeqNum"=>"760", "MsgSize"=>"20", "MsgType"=>"41", "SecurityCode"=>"30056", "Price"=>"0", "AggregateQuantity"=>"0"}, 
#   {"MsgTime"=>"2019-09-23 16:08:10.819000", "ChannelID"=>"21", "SeqNum"=>"14482", "MsgSize"=>"20", "MsgType"=>"41", "SecurityCode"=>"30056", "Price"=>"0", "AggregateQuantity"=>"0"}], 
# "ANSBOOK_PROXY_IEP_Securities Premium_2405"=>[
#   {"MsgTime"=>"2019-09-23 09:45:18.430000", "ChannelID"=>"20", "SeqNum"=>"2312", "MsgSize"=>"20", "MsgType"=>"41", "SecurityCode"=>"2405", "Price"=>"0", "AggregateQuantity"=>"0"},
#   {"MsgTime"=>"2019-09-23 16:08:11.080000", "ChannelID"=>"20", "SeqNum"=>"14803", "MsgSize"=>"20", "MsgType"=>"41", "SecurityCode"=>"2405", "Price"=>"0", "AggregateQuantity"=>"0"}]
# }
  title_head = ["OMD Message Type", "41", "41", "41", "41"]
  sp_title   = ["OMD Field Name", "\"SP\" SeqNum", "SecurityCode", "Price", "AggregateQuantity"]
  sf_title   = ["OMD Field Name", "\"SF\" SeqNum", "SecurityCode", "Price", "AggregateQuantity"]
  ss_title   = ["OMD Field Name", "\"SS\" SeqNum", "SecurityCode", "Price", "AggregateQuantity"]

  data_element  = ["SeqNum", "SecurityCode", "Price", "AggregateQuantity"]

  head_data = []

  if "Securities Premium"     == product
   head_data = sp_title
  elsif "Securities Standard" == product
    head_data = ss_title
  elsif "Securities FullTick" == product
    head_data = sf_title
  end

  for security in watch_security

    fetch = Set.new(@bigmap.select{|x| x.start_with?("ANSBOOK_PROXY_IEP_#{product}_#{security}_")}.keys().map{|x| x.sub(/\..*/, "")})
    if fetch.length == 0
      return nil
    end

    for oneMsg in @bigmap["ANSBOOK_PROXY_IEP_#{product}_#{security}_"]    #ANSBOOK_PROXY_#{product}_#{security}
      # $logger.info "=========oneMsg: #{oneMsg}"
      for c, i in title_head.each_with_index
        ws.write(at_row + i, at_column, c, f_border_title)
      end
      at_column += 1

      for c, i in head_data.each_with_index
        ws.write(at_row + i, at_column, c, f_border_title)
      end
      at_column += 1

      ws.write_string(at_row, at_column, "Expected Value", f_border_content)

      for row_name, j in data_element.each_with_index
        ws.write_string(at_row  + j + 1, at_column, oneMsg[row_name].to_s, f_border_content)
      end

      at_column += 2
    end
  end
end

def gen_order_imbalance(product, watch_security, ws, config, at_row, at_column, debug_table, f_border_title, f_border_content)
  title_head = ["OMD Message Type", "56", "56", "56", "56"]
  sp_title   = ["OMD Field Name", "\"SP\" SeqNum", "SecurityCode", "OrderImbalanceDirection", "OrderImbalanceQuantity"]
  sf_title   = ["OMD Field Name", "\"SF\" SeqNum", "SecurityCode", "OrderImbalanceDirection", "OrderImbalanceQuantity"]
  ss_title   = ["OMD Field Name", "\"SS\" SeqNum", "SecurityCode", "OrderImbalanceDirection", "OrderImbalanceQuantity"]

  data_element  = ["SeqNum", "SecurityCode", "OrderImbalanceDirection", "OrderImbalanceQuantity"]

  head_data = []

  if "Securities Premium"     == product
    head_data = sp_title
  elsif "Securities Standard" == product
    head_data = ss_title
  elsif "Securities FullTick" == product
    head_data = sf_title
  end

  for security in watch_security

    fetch = Set.new(@bigmap.select{|x| x.start_with?("ANSBOOK_PROXY_OImbalance_#{product}_#{security}_")}.keys().map{|x| x.sub(/\..*/, "")})
    if fetch.length == 0
      return nil
    end

    for oneMsg in @bigmap["ANSBOOK_PROXY_OImbalance_#{product}_#{security}_"]    #ANSBOOK_PROXY_#{product}_#{security}
      # $logger.info "=========oneMsg: #{oneMsg}"
      for c, i in title_head.each_with_index
        ws.write(at_row + i, at_column, c, f_border_title)
      end
      at_column += 1

      for c, i in head_data.each_with_index
        ws.write(at_row + i, at_column, c, f_border_title)
      end
      at_column += 1

      ws.write_string(at_row, at_column, "Expected Value", f_border_content)

      for row_name, j in data_element.each_with_index
        ws.write_string(at_row  + j + 1, at_column, oneMsg[row_name].to_s, f_border_content)
      end

      at_column += 2
    end
  end
end

def gen_excel_tab_from_client_tool(ws, msg_type, config, watch_security, f_border_title, f_border_content)
  at_column = 0
  at_row = 0

  # upper descrition
  for row in config["description"]
    ws.write(at_row, at_column, row)
    at_row += 1
  end
  at_row += 1

  require 'pp'
  product = "Securities Standard"
  puts "\ngenerate for #{msg_type}"
  debug_table = []

  if msg_type == "IndexData"
      if gen_indexData(ws, at_row, at_column, debug_table, f_border_title, f_border_content)
        at_column = 1
      end
  elsif msg_type == "OrderBook_1"
    for security in watch_security
      if gen_broadLot(ws, security, at_row, at_column, debug_table, f_border_title, f_border_content)
        at_column += 9
      end
    end
  elsif msg_type == "OrderBook_2"
    for security in watch_security
      if gen_OddLot(ws, security, at_row, at_column, debug_table, f_border_title, f_border_content)
        at_column += 9
      end
    end
  elsif msg_type == "OrderBook_3"
    for security in watch_security
      if gen_orderbook(ws, security, at_row, at_column, debug_table, f_border_title, f_border_content)
        at_column += 9
      end
    end
  elsif msg_type == "BrokerQueue"
    for security in watch_security
      if gen_brokerqueue(product, ws, security, at_row, at_column, debug_table, f_border_title, f_border_content)
        at_column += 3
      end
    end
  end

  pp debug_table
end

def gen_excel_tab(wb, ref, tab_name, answerbook_search)

  watch_security = answerbook_search["SecurityCode"]

  config = ref[tab_name]
  msg_type = tab_name.sub(/^\d+_/, "").sub(/ /, "")

  if "Trading_Session_Status" == msg_type
    msg_type = "TradingSessionStatus"
  elsif "IEP" == msg_type
    msg_type = "IndicativeEquilibriumPrice"
  elsif "SCD_Quota_Balance" == msg_type
    msg_type = "StockConnectDailyQuotaBalance"
  elsif "SCD_Market_Turnover" == msg_type
    msg_type = "StockConnectMarketTurnover"
  end

  ws = wb.add_worksheet(tab_name)
  $logger.info "handle tab_name #{tab_name} msg_type #{msg_type} for excel"

  f_border_title = wb.add_format
  f_border_title.set_border(1)
  f_border_title.set_align("left")

  f_border_content = wb.add_format
  f_border_content.set_border(1)
  f_border_content.set_align("right")
  f_border_content.set_text_wrap
  # puts "template were #{JSON.pretty_generate(config)}"
  # puts "finding data from bigmap"
  # puts JSON.pretty_generate(@bigmap.select{ |x| x.start_with?("ANSBOOK_PROXY_#{product}_#{msg_type}")})

  # to_smash = @bigmap.select{|x| x.start_with?(config["data_source"]) and x.include?(msg_type)}
  # if to_smash
  #   puts JSON.pretty_generate(to_smash)
  # end

  if config["data_source"] == "ANSBOOK_PROXY"
    gen_excel_tab_from_proxy(ws, msg_type, config, watch_security, f_border_title, f_border_content)
  elsif config["data_source"] == "ANSBOOK_CT"
    gen_excel_tab_from_client_tool(ws, msg_type, config, watch_security, f_border_title, f_border_content)
  else
    $logger.warn "unknown data source #{config["data_source"]}"
  end

end
