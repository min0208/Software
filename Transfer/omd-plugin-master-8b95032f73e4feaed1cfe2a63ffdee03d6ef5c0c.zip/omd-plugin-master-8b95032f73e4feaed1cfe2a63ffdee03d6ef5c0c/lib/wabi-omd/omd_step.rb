# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd cucumber step

# @!method <Product>_print_OMD_response_after_<TimeStamp>
# @param OMD Product [Product]
# @param TimeStamp [Wabi Timestamp]
# @example
# * Set timestamp as TS1
# * Index print OMD response after TS1
Given(/^([,a-zA-Z0-9 ]*) print OMD response after (.*?)$/) do |subject, ts|
  @omd_proxy.timeout = @timeout if @timeout
  table_handler = OMDTableHandler.new(@omd_proxy, @omd_rg_handler, @omd_cmp)
  # set subjects
  table_handler.set_subject(subject)
  # set start time
  @omd_proxy.stime = OMDUtil.get_time($timestamps[ts]) if $timestamps[ts]
  # print out response
  table_handler.get_response
end

# @!method <Product>_print_OMD_response_from_<TS1>_to_<TS2>
# @param OMD Product [Product]
# @param TS1 [Wabi Timestamp]
# @param TS2 [Wabi Timestamp]
# @example
# * Set timestamp as TS1
# ...
# * Set timestamp as TS2
# * Index print OMD response from TS1 to TS2
Given(/^([,a-zA-Z0-9 ]*) print OMD response from (.*?) to (.*?)$/) do |subject, ts1, ts2|
  @omd_proxy.timeout = @timeout if @timeout
  table_handler = OMDTableHandler.new(@omd_proxy, @omd_rg_handler, @omd_cmp)
  # set subjects
  table_handler.set_subject(subject)
  # set start time
  @omd_proxy.stime = OMDUtil.get_time($timestamps[ts1]) if $timestamps[ts1]
  @omd_proxy.etime = OMDUtil.get_time($timestamps[ts2]) if $timestamps[ts2]
  # print out response
  table_handler.get_response
  # restore the endtime
  @omd_proxy.etime = nil
end

# print the response
Given(/^([,a-zA-Z0-9 ]*) print OMD response$/) do |subject|
  # set the timeout
  @omd_proxy.timeout = @timeout if @timeout
  table_handler = OMDTableHandler.new(@omd_proxy, @omd_rg_handler, @omd_cmp)
  # set subjects
  table_handler.set_subject(subject)
  # print out response
  table_handler.get_response(@omd_response_hash)
end

Given(/^([,a-zA-Z0-9 ]*) receive(.*?):$/) do |subject, options, table|
  begin
    # intial proxy
    OMDUtil::Logger.debug "@omd_proxy.timeout: #{@omd_proxy.timeout}"
    @omd_proxy.timeout = @timeout if @timeout
    @omd_proxy.stime   = @scenario_starttime
    # initial refresh handler
    if not @refresh_handler
      @refresh_handler = OMDRefreshHandler.new(ENV['OMD_PROJECT'], @omd_proxy, @refresh_verify_timeout)
      @refresh_handler.set_wait_full_refresh_cycle(@wait_full_refresh_cycle)
      @refresh_handler.set_refresh_publish_duration(@refresh_publish_duration)
      @refresh_handler.set_start_timestamp(Time.now)
    end
    # intial table handler
    table_handler = OMDTableHandler.new(@omd_proxy, @omd_cmp)
    table_handler.rg_handler      = @omd_rg_handler
    table_handler.refresh_handler = @refresh_handler
    table_handler.scenario_stime  = @scenario_starttime
    table_handler.set_subject(subject)
    table_handler.set_timerange(options)
    # inherit bigmap from WABI-WEB
    $omd_validator.bigmap = @bigmap
    # submit table
    res = table_handler.submit(table.hashes)
    # update the bigmap
    @bigmap = @bigmap.merge res
    # clean up
    $error_handler.clean
    @omd_proxy.etime = nil
  rescue Exception => e
    # clean up
    $error_handler.clean
    @omd_proxy.etime = nil
    # mark scenario status as failed
    @scenario_status = 'Failed'
    if @pre_run_case == 'true'
      OMDUtil.print_prerun_error(e.message)
    else
      raise e
    end
  end
end

Given(/^Set OMD (.*?) as (.*?):$/) do |groupname, var, table|
  # inherit bigmap from WABI-WEB
  $omd_validator.bigmap = @bigmap
  tablehash = []
  table.hashes.each do |row|
    row = $omd_alias_handler.handle row if $omd_alias_handler
    row = $omd_validator.validate_group row, groupname if $omd_validator
    tablehash << row
  end
  OMDUtil::Logger.debug tablehash
  @omd_rg_handler.add_rg var, tablehash
  @bigmap["#{var}.Count"] = table.hashes.size if @bigmap
end

Given(/^([,a-zA-Z0-9 ]*) retransmitted:$/) do |subject, table|
  begin
    # inherit bigmap from WABI-WEB
    $omd_validator.bigmap = @bigmap
    # intial proxy
    # set proxy default time range
    @omd_proxy.timeout = @timeout if @timeout
    @omd_proxy.stime   = @scenario_starttime
    @omd_proxy.etime   = OMDUtil.get_time Time.now
    # initial retrans handler
    retrans_handler = OMDRetransHandler.new(ENV['OMD_PROJECT'], \
                                            @retrans_server_host, \
                                            @retrans_server_port, \
                                            @omd_proxy)
    # set retransmission timedout,interval, case_id
    retrans_handler.timedout = @retrans_timedout if @retrans_timedout
    retrans_handler.interval = @retrans_interval if @retrans_interval
    retrans_handler.latency  = @retrans_latency  if @retrans_latency
    retrans_handler.case_id  = @case_id          if @case_id
    # handle subject
    retrans_handler.set_subject(subject)
    # submit table
    retrans_handler.submit(table.hashes)
    # clean up
    $error_handler.clean
    @omd_proxy.etime = nil
  rescue Exception => e
    # clean up
    $error_handler.clean
    @omd_proxy.etime = nil
    # mark scenario status as failed
    @scenario_status = 'Failed'
    if @pre_run_case == 'true'
      OMDUtil.print_prerun_error(e.message)
    else
      raise e
    end
  end
end

Given(/^Lookup OMD refresh cycles:$/) do |table|
  # to record refresh cycle for cared channels

  # instance or overwrite the refresh handler
  refresh_handler = OMDRefreshHandler.new(ENV['OMD_PROJECT'], @omd_proxy, @refresh_verify_timeout)
  refresh_handler.set_wait_full_refresh_cycle(@wait_full_refresh_cycle)
  refresh_handler.set_refresh_publish_duration(@refresh_publish_duration)
  refresh_handler.set_start_timestamp(Time.now)

  @refresh_handler = refresh_handler

  # parse table, to replace refs 
  parsed_table = []
  table.hashes.each do | row |
    parsed_row = {}
    row.each_key do | key |
      if @bigmap.include?(row[key])
        parsed_row[key] = @bigmap[row[key]]
      else
        parsed_row[key] = row[key]
      end
    end

    parsed_table.push(parsed_row)
  end

  # let refresh handler to track all cycle of channels
  refresh_handler.lookup_refresh_cycle_by_channel(parsed_table)
end

Given(/^Lookup MMDH refresh cycles:$/) do |table|
  # to record refresh cycle for cared channels
  # instance or overwrite the refresh handler
  refresh_handler = OMDRefreshHandler.new(ENV['OMD_PROJECT'], @omd_proxy, @refresh_verify_timeout)
  refresh_handler.set_wait_full_refresh_cycle(@wait_full_refresh_cycle)
  refresh_handler.set_refresh_publish_duration(@refresh_publish_duration)
  refresh_handler.set_start_timestamp(Time.now)
  refresh_handler.mmdh_refresh_ind = true
  @refresh_handler = refresh_handler
  # parse table, to replace refs 
  table = table.clone
  table.hashes.each do | row |
    row['RealtimeChannelID'] = '0'
  end
  # let refresh handler to track all cycle of channels
  refresh_handler.lookup_refresh_cycle_by_channel(table.hashes)
end

Given(/^([,a-zA-Z0-9 ]*) dump client tool data:$/) do |subject, table|
  # inherit bigmap from WABI-WEB
  $omd_validator.bigmap = @bigmap
  # intial proxy
  ct_handler = OMDClientToolHandler.new(ENV['OMD_PROJECT'])
  # inherit bigmap from WABI-WEB
  ct_handler.bigmap = @bigmap
  # handle subject
  ct_handler.set_subject(subject)
  # submit table
  ct_handler.submit(table.hashes)
  # update the bigmap
  @bigmap = @bigmap.merge ct_handler.bigmap
  # clean old error info
  $error_handler.clean
end

Given(/^([,a-zA-Z0-9 ]*) dump last bid and ask:$/) do |subject, table|
  # inherit bigmap from WABI-WEB
  $omd_validator.bigmap = @bigmap
  # intial proxy
  ct_handler = OMDClientToolHandler.new(ENV['OMD_PROJECT'])
  ct_handler.lastbbo_ind = true
  # inherit bigmap from WABI-WEB
  ct_handler.bigmap = @bigmap
  # handle subject
  ct_handler.set_subject(subject)
  # submit table
  ct_handler.submit(table.hashes)
  # update the bigmap
  @bigmap = @bigmap.merge ct_handler.bigmap
  # clean old error info
  $error_handler.clean
end

Given(/^([,a-zA-Z0-9 ]*) verify client tool table:$/) do |subject, table|
  # inherit bigmap from WABI-WEB
  $omd_validator.bigmap = @bigmap
  # intial proxy
  ct_handler = OMDClientToolHandler.new(ENV['OMD_PROJECT'])
  # inherit bigmap from WABI-WEB
  ct_handler.bigmap = @bigmap
  # handle subject
  ct_handler.set_subject(subject)
  # submit table
  ct_handler.verify(table.hashes)
  # clean old error info
  $error_handler.clean
end

Given(/^([,a-zA-Z0-9 ]*) submit (.*?) table:$/) do |subject, type, table|
  begin
    # inherit bigmap from WABI-WEB
    $omd_validator.bigmap = @bigmap
    # intial proxy
    # set proxy default time range
    @omd_proxy.timeout = @timeout if @timeout
    @omd_proxy.stime   = @scenario_starttime
    @omd_proxy.etime   = OMDUtil.get_time Time.now
    # initial OMD-MMDH handler
    omd_mmdh_handler = OMDMMDHHandler.new(ENV['OMD_PROJECT'], @omd_proxy)
    # set type/timedout/duration
    omd_mmdh_handler.type     = type
    omd_mmdh_handler.timeout  = @mmdh_timeout  if @mmdh_timeout
    omd_mmdh_handler.duration = @mmdh_duration if @mmdh_duration
    omd_mmdh_handler.case_id  = @case_id       if @case_id
    # handle subject
    omd_mmdh_handler.set_subject(subject)
    # submit table
    res = omd_mmdh_handler.submit(table.hashes)
    # update the bigmap
    @bigmap = @bigmap.merge res
    # clean up
    $error_handler.clean
    @omd_proxy.etime = nil
  rescue Exception => e
    # clean up
    $error_handler.clean
    @omd_proxy.etime = nil
    raise e
  end
end

Given(/^Set OMD alias:$/) do |table|
  $world.puts "Set OMD alias:"
  table.hashes.each do |entry|
    name  = entry['Alias']
    value = entry['Value']
    raise 'Invalid alias data: ' + entry.to_s if name.nil? || name.strip == ''
    $omd_alias_handler.set(name, value)
    $world.puts entry.to_s if $world
  end
end

Given(/^Check the status of test scenario$/) do
  $world.puts "scenario status: #{@scenario_status}" if $world
  if @scenario_status == 'Failed'
    raise "scenario status is failed."
  end
end

Given(/^([,a-zA-Z0-9 ]*) search last message(.*?):$/) do |subject, options, table|
  begin
    # intial proxy
    OMDUtil::Logger.debug "@omd_proxy.timeout: #{@omd_proxy.timeout}"
    @omd_proxy.timeout = @timeout if @timeout
    @omd_proxy.stime   = @scenario_starttime
    # intial table handler
    table_handler = OMDTableHandler2.new(@omd_proxy, @omd_cmp)
    table_handler.rg_handler      = @omd_rg_handler
    table_handler.scenario_stime  = @scenario_starttime
    table_handler.duration        = @search_last_message_duration if @search_last_message_duration
    table_handler.timeout         = @search_last_message_timeout  if @search_last_message_timeout
    table_handler.search_proxy_only_once = @search_proxy_only_once if @search_proxy_only_once
    table_handler.set_subject(subject)
    table_handler.set_timerange(options)
    # inherit bigmap from WABI-WEB
    $omd_validator.bigmap = @bigmap
    # submit table
    res = table_handler.submit(table.hashes)
    # update the bigmap
    @bigmap = @bigmap.merge res
    # clean up
    $error_handler.clean
    @omd_proxy.etime = nil
  rescue Exception => e
    # clean up
    $error_handler.clean
    @omd_proxy.etime = nil
    # mark scenario status as failed
    @scenario_status = 'Failed'
    if @pre_run_case == 'true'
      OMDUtil.print_prerun_error(e.message)
    else
      raise e
    end
  end
end

Given(/^([,a-zA-Z0-9 ]*) search all the message(.*?):$/) do |subject, options, table|
  begin
    # intial proxy
    OMDUtil::Logger.debug "@omd_proxy.timeout: #{@omd_proxy.timeout}"
    @omd_proxy.timeout = @timeout if @timeout
    @omd_proxy.stime   = @scenario_starttime
    # intial table handler
    table_handler = OMDTableHandler2.new(@omd_proxy, @omd_cmp)
    table_handler.rg_handler      = @omd_rg_handler
    table_handler.scenario_stime  = @scenario_starttime
    table_handler.duration        = @search_last_message_duration if @search_last_message_duration
    table_handler.timeout         = @search_last_message_timeout  if @search_last_message_timeout
    table_handler.search_proxy_only_once = @search_proxy_only_once if @search_proxy_only_once
    table_handler.set_subject(subject)
    table_handler.set_timerange(options)
    # inherit bigmap from WABI-WEB
    $omd_validator.bigmap = @bigmap
    # submit table
    res = table_handler.sendRequest(table.hashes)

    # $logger.info "omd-plugin got response from omd-proxy for search all"
    # $logger.info res
    # update the bigmap

    # coudl only happened here
    # table_handler does not have @bigmap

    # @bigmap could considered as this.bigmap / self.bigmap refering other lanauges

    @bigmap = @bigmap.merge res
    # clean up
    $error_handler.clean
    @omd_proxy.etime = nil
  rescue Exception => e
    # clean up
    $error_handler.clean
    @omd_proxy.etime = nil
    # mark scenario status as failed
    @scenario_status = 'Failed'
    if @pre_run_case == 'true'
      OMDUtil.print_prerun_error(e.message)
    else
      raise e
    end
  end
end

Given(/^Answerbook set search entry:$/) do | table |
  @answerbook_search ||= {}
  # puts table
  for row in table.hashes
    for watch_field in ["SecurityCode", "IndexCode"]
      if row[watch_field]

        # fetch from @bigmap if variable been used
        actual_value = row[watch_field]
        actual_value = @bigmap[row[watch_field]] if @bigmap.has_key?(row[watch_field])

        begin
          @answerbook_search[watch_field].push(actual_value)
        rescue
          @answerbook_search[watch_field] = []
          @answerbook_search[watch_field].push(actual_value)
        end
      end
    end
  end

  # remove duplicate
  for k in @answerbook_search.keys()
      @answerbook_search[k] = @answerbook_search[k].uniq
  end

  if not @answerbook_search.keys().include?("SecurityCode")
    @answerbook_search["SecurityCode"] = []
    $logger.warn "setting answerbook search entry but SecurityCode is empty"
  end

  if not @answerbook_search.keys().include?("IndexCode")
    @answerbook_search["IndexCode"] = []
  end

  $logger.debug "@answerbook_search is now #{@answerbook_search}"

end

Given(/^Answerbook print to excel$/) do

  require 'write_xlsx'
  require 'json'

  # FIXME: currently answerbook was limited to OMD-C, while OMD-D is also possible
  # template config were empty
  #
  omd_flavor = "OMD-C"

  # find config file
  omd_flavor = omd_flavor.sub("-", "").downcase
  ansbook_template = "#{File.dirname(__FILE__)}/../../config/#{omd_flavor}/#{omd_flavor}_ansbook_template.json"
  if not File.exist?(ansbook_template)
    $world.puts "answer book template for #{omd_flavor} not exist at #{ansbook_template}"
    raise "answer book template for #{omd_flavor} not exist at #{ansbook_template}"
  end
  template = JSON.parse(File.open(ansbook_template, "r:utf-8").readlines().join(""))

  # init excel
  excel_name = "#{omd_flavor}_AnswerBook_#{DateTime.now.strftime("%Y%m%d_%H%M%S")}.xlsx"
  wb = WriteXLSX.new(excel_name)
  wb.worksheets.clear()

  # interpretate security code

  # clear old keys
  # @bigmap.select{ |x| x.start_with?("ANSBOOK_") }.keys().map{ |old_key| @bigmap.delete(old_key)}

  # to client tool
  begin
    # obj_data = JSON.parse(File.open("/home/jarven/client-tool_data.json", "r:utf-8").readlines().join(""))
    # @bigmap = @bigmap.merge obj_data

    search_on_client_tool(@answerbook_search)
  rescue
    puts "W: some message not fetched from client tool, answerbook may not be complete"
    puts $@
    puts $!
  end

  begin
    search_on_proxy_message(@answerbook_search)
  rescue
    puts "W: some message not fetched from omd proxy, answerbook may not be complete"
    puts $@
    puts $!
  end
  # to proxy

  # watch_security.each_with_index do | security, idx |
  #   puts JSON.pretty_generate(@bigmap.select{|x| x.start_with?("CT_REF_#{idx}")})
  # end
 
  # loop and generate answer book tabs
  for tab_name in template.keys()
    gen_excel_tab(wb, template, tab_name, @answerbook_search)
  end

  # end
  wb.close()
  $world.puts "answer book for #{omd_flavor} output to #{excel_name}"
   
end

