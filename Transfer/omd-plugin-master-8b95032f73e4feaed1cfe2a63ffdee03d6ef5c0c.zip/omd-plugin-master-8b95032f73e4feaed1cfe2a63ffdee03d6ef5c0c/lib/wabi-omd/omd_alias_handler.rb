# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd alias handler

# omd-pluginAliasHandler is a class to handle omd alias conversation
class OMDAliasHandler
  def initialize(project, version)
    # default alias setting
    default_alias = "#{File.dirname(__FILE__)}/../../" \
      + "/config/#{project}/omd_alias_#{version}.csv"
    @alias_hash = generate_hash default_alias
    # customizing alias setting
    cust_alias = "features/#{project}_alias.csv"
    generate_hash_from_fixformat_alias cust_alias if File.exist? cust_alias
  end

  # @param csv [File] default alias csv file
  # @return [Hash] internal format alias hash
  # update alias_hash with fix format alias csv
  def generate_hash_from_fixformat_alias(csv)
    res = {}
    # OMDUtil::Logger.info "Loading cust alias from #{csv}"
    $logger.info "Loading cust alias from #{csv}"

    index = 0
    CSV.foreach(csv) do |row|
      key = { template: '<GLOBAL>' }
      # skip the first row
      if index == 0
        index += 1
        next
      end
      if row.size != 2
        # OMDUtil::Logger.warn "Customizing alias: #{row} is malformed "
        $logger.warn "Customizing alias: #{row} is malformed "
        next
      end
      k = row.first
      v = row.last
      arr = k.split('=')
      key[:field] = arr.first.strip
      key[:value] = arr.last.strip
      value = {}
      # golden alias existing
      if @alias_hash[key]
        # OMDUtil::Logger.warn "Customizing alias: #{row[0]} cannot overwrite default alias"
        $logger.warn "Customizing alias: #{row[0]} cannot overwrite default alias"

        res[key] = value
        next
      # not existing
      else
        arr = v.split(';')
        arr.each do |p|
          temp_arr = p.split '='
          value[temp_arr.first] = temp_arr.last
        end
        res[key] = value
        @alias_hash[key] = value
      end
    end
    res
  end

  # @param csv [File] default alias csv file
  # @return [Hash] internal alias hash
  def generate_hash(csv)
    csv = CSV.read(csv)
    array = csv.map { |arr| { arr[0..1] => arr[2..-1] } }
    hash = {}
    array.each do |temp_hash|
      key = temp_hash.keys.first
      template = key[0]
      ali_field = key[1].split('=').first.strip
      ali_value = key[1].split('=').last.strip
      reskey = { template: template, field: ali_field, value: ali_value }
      value = {}
      temp_hash[key].each do |ele|
        next unless ele
        value[ele.split('=').first.strip] = ele.split('=').last.strip
      end
      hash[reskey] = value
    end
    hash
  end

  # set alias
  def set(k, v)
      key = { template: '<GLOBAL>' }
      arr = k.split('=')
      key[:field] = arr.first.strip
      key[:value] = arr.last.strip
      value = {}
      v.split(';').each do |p|
        temp_arr = p.split('=')
        value[temp_arr.first] = temp_arr.last
      end
      @alias_hash[key] = value
  end

  # @param row [Hash] row of data talbe
  def handle(row)
    # TODO: no handling
    arr = match(row)
    arr.each { |v| row = row.merge v }
    row
  end

  # @return [Array<Hash<subRow>>]
  # delete the alias field in row, the resulting sub row is returned for merge
  def match(row)
    res = []
    @alias_hash.each do |k, v|
      next unless k[:template] == row['Template'] || k[:template] == '<GLOBAL>'
      if row[k[:field]] == k[:value].strip
        row.delete k[:field]
        res << v
      end
    end
    res
  end
end
