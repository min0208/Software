# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd refresh hanlder

# OMDRefreshHandler class function for omd
class OMDRefreshHandler
  attr_accessor :mmdh_refresh_ind
  def initialize(project, proxy, refresh_verify_timeout)
    @proxy                    = proxy
    @refresh_verify_timeout   = refresh_verify_timeout
    @wait_full_refresh_cycle  = true
    @mmdh_refresh_ind         = false
    @refresh_publish_duration = 30
    @start_ts                 = Time.now
    @channel_complete_hash    = {}
    url = "#{File.dirname(__FILE__)}/../../config/#{project}/refresh_channel_map.csv"
    @refresh_channel_map_hash = get_channel_map_hash(url)
  end

  def get_channel_map_hash(csv)

    # csv title is Product,RealtimeChannel,RefreshChannel
    # the "Product" here means the corresponding realtime product name

    hash = {}
    CSV.foreach(csv, options={:headers => true} ) do |row|
      next if !row[0].nil? && row[0].match(/^ *#/)
      # key: product + real time channel
      # value: refresh channel
      hash[row["Product"]  + " " + row["RealtimeChannel"]] = row["RefreshChannel"]
      # hash[row[0]] = row[1]
    end
    OMDUtil::Logger.debug "channal map hash loaded: #{hash}"
    return hash
  end

  def set_start_timestamp(start_ts)
    @start_ts = start_ts
  end

  def set_wait_full_refresh_cycle(wrc)
    @wait_full_refresh_cycle = wrc
  end

  def set_refresh_publish_duration(rpd)
    @refresh_publish_duration = rpd
  end

  def is_refresh_product(subject)
    subject.strip.split(',').each do |sub|
      sub = sub.strip
      valid_subs = $product_config.get_valid_subjects
      if valid_subs.include? sub
        sub_inner = $product_config.get_product sub
        return true if sub_inner =~ /^.*_refresh$/
      end
    end
    return false
  end

  def process_refresh_channel_id(sub, row)

    # if access from "Lookup refresh cycle"
    #   find mapping using the "Product" column within the table content

    # else if access from "OMDxxx refersh receive:"
    #   trim off the " Refresh", and use the product pattern at table title (the "sub") to find the mapping


    if !row.has_key?('RealtimeChannelID') and !row.has_key?('ChannelID')
      throw "Error: ChannelID is a mandatory field for refresh"
    end

    OMDUtil::Logger.debug "trying to locate #{sub} #{row} refresh channel"
    if row.has_key?('RealtimeChannelID')

      if row['Product']
        channel = @refresh_channel_map_hash[row['Product'] + " " + row['RealtimeChannelID']]
      elsif sub
        channel = @refresh_channel_map_hash[sub.gsub(" Refresh", "") + " " + row['RealtimeChannelID']]
      else
        OMDUtil::Logger.warn "no product given from title or row when handle OMD refresh channel, sub: #{sub}, row: #{row}"
      end

      if !channel.nil?
        row['ChannelID'] = channel
      else
        raise "unable to locate corresponing refresh channel id with product #{row['Product']} realtime channel #{row['RealtimeChannelID']}"
      end
      
      row.delete('RealtimeChannelID')
    end
  end

  def is_valid_refresh_complete_time(hash)
    if (hash['prev_comp_time'].nil? or hash['prev_comp_time'].strip == "") \
      or (hash['last_comp_time'].nil? or hash['last_comp_time'].strip == "")
      return false
    end
    return true
  end


  def get_channel_refresh_complete(channel)
    throw "Error: Invalid channel ID: #{channel}" if channel.nil? or channel.strip == ""
    return @channel_complete_hash[channel] if @channel_complete_hash[channel]

    refresh_comp = { 'LAST_COMP_TIME' => @start_ts, 'PREV_COMP_TIME' => @start_ts }
    loop do
      sleep(1)
      res = @proxy.send_refresh_complete(channel)
      next if res.nil? or !is_valid_refresh_complete_time(res)
      prev_comp_time = Time.parse(res['prev_comp_time'])
      last_comp_time = Time.parse(res['last_comp_time'])
      if (prev_comp_time > @start_ts)
        refresh_comp['LAST_COMP_TIME'] = last_comp_time
        refresh_comp['PREV_COMP_TIME'] = prev_comp_time + 1
        break
      end
      if !@wait_full_refresh_cycle and (last_comp_time - @start_ts > @refresh_publish_duration)
        refresh_comp['LAST_COMP_TIME'] = last_comp_time
        break
      end

      break if (Time.now - @start_ts) > @refresh_verify_timeout
    end

    @channel_complete_hash[channel] = refresh_comp
    OMDUtil::Logger.info "refrsh cycle detected for channel #{channel}: #{refresh_comp}"
    return @channel_complete_hash[channel]
  end

  def ask_proxy_for_refresh_cycle(channel)
    refresh_comp = { 'LAST_COMP_TIME' => @start_ts, 'PREV_COMP_TIME' => @start_ts }

    res = @proxy.send_refresh_complete(channel)
    return nil if res.nil? or !is_valid_refresh_complete_time(res)
    prev_comp_time = Time.parse(res['prev_comp_time'])
    last_comp_time = Time.parse(res['last_comp_time'])
    if (prev_comp_time > @start_ts)
      refresh_comp['LAST_COMP_TIME'] = last_comp_time
      refresh_comp['PREV_COMP_TIME'] = prev_comp_time + 1

      return refresh_comp
    end
    if !@wait_full_refresh_cycle and (last_comp_time - @start_ts > @refresh_publish_duration)
      refresh_comp['LAST_COMP_TIME'] = last_comp_time

      return refresh_comp

    end
    if @mmdh_refresh_ind
      refresh_comp['LAST_COMP_TIME'] = last_comp_time
      refresh_comp['PREV_COMP_TIME'] = prev_comp_time
      return refresh_comp
    end

    return nil
  end

  def scan_table_for_refresh_cycle(table, ref_to_cycle)
    table.each do | row |
      if not ref_to_cycle[row["ChannelRef"]]
        OMDUtil::Logger.debug "check refresh cycle for #{row["ChannelID"]} #{row["ChannelRef"]}"
        channel = row["ChannelID"]
        refresh_comp = ask_proxy_for_refresh_cycle(channel)

        # bind to current track
        ref_to_cycle[row["ChannelRef"]] = refresh_comp
        # also to make a copy for original sets, to fast return if exist / checked before
        @channel_complete_hash[channel] = refresh_comp
      end
    end
  end

  def proxy_check_timeout(ref_to_cycle)
    if (Time.now - @start_ts) > @refresh_verify_timeout
      OMDUtil::Logger.debug "Time.now #{Time.now} - @start_ts #{@start_ts} > @refresh_verify_timeout #{@refresh_verify_timeout}"
      OMDUtil::Logger.debug "refresh cycle detected timeout: #{ref_to_cycle}"
      return true
    else
      return false
    end
  end

  def all_channel_ref_found(ref_to_cycle)
    if ref_to_cycle.keys.map{ |x| ref_to_cycle[x]}.all?
      OMDUtil::Logger.debug "all refresh cycle detected: #{ref_to_cycle}"
      return true
    else
      return false
    end
  end


  def init_ref_to_cycle(table)
    ref_to_cycle = {}

    # create result set and substitute realtime channel id
    table.each do | row |
      process_refresh_channel_id(nil, row)
      ref_to_cycle[row["ChannelRef"]] = nil
      # OMDUtil::Logger.debug "regist channel #{row["ChannelID"]} for checking it's refreh cycle"
    end

    OMDUtil::Logger.info "created refresh cycle slot for channels: #{ref_to_cycle}"
    return ref_to_cycle
  end

  def map_refresh_cycle_to_ref(ref_to_cycle)
    ref_to_cycle.keys.select { |x| ref_to_cycle[x] != nil }.each do | ref |
      $timestamps["#{ref.strip}.RefreshStartTime"] = Time.parse(OMDUtil.get_time(ref_to_cycle[ref]["PREV_COMP_TIME"]))
      $timestamps["#{ref.strip}.RefreshEndTime"]   = Time.parse(OMDUtil.get_time(ref_to_cycle[ref]["LAST_COMP_TIME"]))

      #OMDUtil::Logger.info "product / channel #{ref.strip}.RefreshStartTime collected as #{Time.parse(OMDUtil.get_time(ref_to_cycle[ref]["PREV_COMP_TIME"]))}"
      #OMDUtil::Logger.info "product / channel #{ref.strip}.RefreshEndTime collected as #{Time.parse(OMDUtil.get_time(ref_to_cycle[ref]["LAST_COMP_TIME"]))}"
      $world.puts "Refresh cycle found: " if $world
      $world.puts "#{ref.strip}.RefreshStartTime=#{OMDUtil.get_time(ref_to_cycle[ref]["PREV_COMP_TIME"])}" if $world
      $world.puts "#{ref.strip}.RefreshEndTime=#{OMDUtil.get_time(ref_to_cycle[ref]["LAST_COMP_TIME"])}" if $world
    end
  end

  def lookup_refresh_cycle_by_channel(table)
    ref_to_cycle = init_ref_to_cycle(table)

    # same as get_channel_refresh_complete, but loop all channels, and track in ref_to_cycle
    loop do
      sleep(1)

      # loop all channels within a sleep(1)
      scan_table_for_refresh_cycle(table, ref_to_cycle)

      # break if fully collected
      break if proxy_check_timeout(ref_to_cycle)
      break if all_channel_ref_found(ref_to_cycle)

    end

    # assign to bigmap / timestamp as refs
    map_refresh_cycle_to_ref(ref_to_cycle)
  end
end
