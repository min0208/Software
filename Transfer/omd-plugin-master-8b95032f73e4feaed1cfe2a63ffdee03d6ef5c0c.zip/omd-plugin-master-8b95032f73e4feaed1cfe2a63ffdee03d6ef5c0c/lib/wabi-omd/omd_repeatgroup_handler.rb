# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd repeat group handler

# OMDRepeatGroupHandler class is function for handling OMD Repat group 
class OMDRepeatGroupHandler
  # constructor
  def initialize(project, version, rg_config = nil)
    @rgs = {}
    unless rg_config
      rg_config = "#{File.dirname(__FILE__)}/../../" \
        + "/config/#{project}/repeat_group_#{version}.csv"
    end
    @rg_def = OMDRepeatGroupHandler.generate_hash rg_config
  end

  # generate repeating group hash
  def self.generate_hash(csv)
    csv = CSV.read csv
    array = csv.map { |arr| { arr[0] => arr[1..-1] } }
    hash = {}
    array.each do |temp_hash|
      key = temp_hash.keys.first
      res = {}
      res[:name] = temp_hash[key].first
      res[:fields] = temp_hash[key][1..-1]
      # news repeating group
      if key == '22'
        hash[key] = if hash[key]
                      # afterwards insert
                      hash[key] << res
                    else
                      # frist time insert
                      [res]
                    end
      else
        # other normal repeating group
        hash[key] = res
      end
    end
    hash
  end

  # @param name [String] repeating group name
  # @param table_hash [Hash] repeating group hashes
  def add_rg(name, table_hash)
    @rgs[name] = table_hash
  end

  def handle(row)
    row = row.clone
    msgtype = row['MsgType']
    return row unless @rg_def[msgtype]
    # if the message has repeating group
    if msgtype == '22'
    # if @rg_def[msgtype] == '22'
      # news
      @rg_def[msgtype].each do |group|
        # the repeating group is contained
        row[group[:name]] = @rgs[row[group[:name]]] if row[group[:name]]
      end
    else
      # if repeating group is defined in the row
      repeating_group_name = @rg_def[msgtype][:name]
      return row unless row.keys.include? repeating_group_name
      # update the repeating group field
      row[repeating_group_name] = @rgs[row[repeating_group_name]]
      group_name = @rg_def[msgtype][:name]
      group_hash = {}
      @rg_def[msgtype][:fields].each do |f|
        group_hash[f] = '<anyvalue>'
      end
      # map the repeating groups with default def hash
      row[group_name].each do |group|
        group = group_hash.merge group
      end
    end
    OMDUtil::Logger.debug row
    row
  end

  # check repeating group
  # @return [bool] if has repeating group
  def has_group?
    @rgs.keys.size > 0
  end
end
