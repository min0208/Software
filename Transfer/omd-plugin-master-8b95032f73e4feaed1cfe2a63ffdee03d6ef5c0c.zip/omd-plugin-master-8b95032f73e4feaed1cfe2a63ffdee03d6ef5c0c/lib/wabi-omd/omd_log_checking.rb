require 'json'
require 'pp'
require 'date'

# OMD Proxy Log Checking
# 
#  Jump to last paragraph for CLI interface

# Logic
#  
#  load field limitation from csv
#  and to through every field of every record line


def field_value_is_valid(limit, value)
    if limit["type"] == "regexp"
        pattern = limit["pattern"]

        # $logger.debug "pattern: #{pattern} value: #{value}, match: #{pattern.match(value)}"
        if pattern.match(value)
            return true
        else
            # $logger.debug "pattern: #{pattern} value: #{value}, match: #{pattern.match(value)}"
            # $logger.debug "not matched"
            return false
        end
    elsif limit["type"] == "range"
        if not /^[0-9.+-]+$/.match(value)
            return false
        end

        if limit["minimum"] <= value.to_i and limit["maximum"] >= value.to_i
            return true
        else
            return false
        end
    else
        return false
    end
end
def field_is_valid(limit, values)
    # apply 'limit' on 'value'
    return values.map{|value| field_value_is_valid(limit, value)}.all?
end


def parse_field_limit(limit)
    # scan for definition of regex or range
    parsed = {}
    field = limit.split("=")[0].strip()
    value = limit.split("=")[1].strip()
    
    parsed = {}
    if /\(.*\)/.match(value)
        parsed["type"] = "regexp"
        parsed["pattern"] = Regexp.new(value)
    elsif /\[.*\.\..*\]/.match(value)
        left = /\[(.*)\.\.(.*)\]/.match(value)[1].to_i
        right = /\[(.*)\.\.(.*)\]/.match(value)[2].to_i
        parsed["type"] = "range"
        parsed["minimum"] = /\[(.*)\.\.(.*)\]/.match(value)[1].to_i
        parsed["maximum"] = /\[(.*)\.\.(.*)\]/.match(value)[2].to_i
    else
        $logger.error "invalid field limit #{value}, support 'regexp' and 'range' only"
        raise "invalid rule line"
    end
    parsed["original_limit"] = value
    return parsed
end

def parse_rule_line(line)
    # load rule csv line 

    if line[1].split("=")[0].strip != "MsgType"
        $logger.error "invalid rules: #{line}, suppose second column is MsgType"
        raise "invalid rule line"
    end

    rule = {}
    rule["rule_name"] = line[0]
    rule["msg_type"] = line[1].split("=")[1].strip

    $logger.info ""
    $logger.info "rule detected for msg #{rule["rule_name"]}, type #{rule["msg_type"]}"
    
    # load fields definition for msg types
    rule["fields"] = {}
    line[2..-1].each do | limit |
        parsed = parse_field_limit(limit)
        field = limit.split("=")[0].strip()
        rule["fields"][field] = parsed
        $logger.info "  field: #{field}, limit: #{parsed}"
    end
    return rule
end

def load_rules(spec_version, result)
    # load spec csv, full name expected

    if not File.exist?(spec_version)
        $logger.error "rule file not found, expect #{spec_version}"
        raise "file not found"
    else
        $logger.info "rules detected at #{spec_version}"
    end

    # read files, filter out empty lines, remove line end, and split
    contents = File.open(spec_version).readlines().map{ |x| x.strip().split(",")}.select { |x| not x.empty? }
    rules = {}

    contents.each do | line |

        if /^ *#.*/.match(line.join(","))
            $logger.info "found comment in rule: #{line.join(",")}"
            if /.*TODO.*/.match(line.join(","))
                result["Notes"].push(line.join(","))
            end
            next
        end

        msg_type = line[1].split("=")[1].strip

        # allow to define one msg type multiple times, at least one of them should match, specical consideration for msg type 
        if rules[msg_type]
            rules[msg_type].push(parse_rule_line(line))
        else            
            rules[msg_type] = [parse_rule_line(line)]
        end
    end

    return rules
end

def report_process(i)
   if i % 1000 == 0
       $logger.info "#{i} line scanned"
   end
end

def parse_log_record(line)
    # parse line to "field -> value" pairs
    record = {}
    line.scan(/\w+=[^;]*/).map { |x| x.split("=") }.each do | field, value |
        # for repeating group, collect values in a list, which means, any field could contains multiple value
        value  = "" if value.nil?
        if not record[field]
            record[field] = [value]
        else
            record[field].push(value)
        end

    end
    return record
end

def has_defined_rules(record, rules)
    return rules.keys().include?(record["MsgType"][0])
end

def record_is_valid(proxy_log_path, i, record, rules, result)
    msg_type = record["MsgType"][0]

    # go loop all field constrain
    # there might be more than one lines of limit of a certain msg type, says MsgType=11
    at_least_one_match = []

    rules[msg_type].each do | limit |
        valid_flag = []
        limit["fields"].each do | field_name, limit |
            if not record.keys().include?(field_name)
                next
            end

            if not field_is_valid(limit, record[field_name])
                valid_flag.push(false)
            else
                valid_flag.push(true)
            end
        end
        at_least_one_match.push(valid_flag.all?)
    end

    if not at_least_one_match.any?
        $logger.warn "record: #{record}"

        rules[msg_type].each do | sub_rule |
            # $logger.warn " for limit #{sub_rule}"
            valid_flag = []
            sub_rule["fields"].each do | field_name, limit |
                if not record.keys().include?(field_name)
                    next
                end

                if not field_is_valid(limit, record[field_name])
                    $logger.warn "  #{proxy_log_path}\t#{i}\t#{msg_type}\t#{sub_rule["rule_name"]}\t#{field_name}\t#{limit["original_limit"]}\t\"#{record[field_name]}\""
                    result["Error Message"].push([proxy_log_path, i, msg_type, sub_rule["rule_name"], field_name, limit["original_limit"], record[field_name].join("|")])
                    valid_flag.push(false)
                else
                    valid_flag.push(true)
                end
            end
            $logger.info " this sub_rule match? #{valid_flag.all?}"
        end
    end
    return at_least_one_match.any?
end

def check_omd_proxy_log(rules, proxy_log_path, result)
    # load rules
    # rules = load_rules(spec_version, result)
    # result["Interface Spec version"] = spec_version
    result["Execution time"] = DateTime.now().to_s

    if not File.exist?(proxy_log_path)
        $logger.info ""
        $logger.error "log file not found, expect #{proxy_log_path}"

        result["Notes"].push("\n# WARN: log file #{proxy_log_path} not found\n")
        return nil
        # raise "file not found"
    else
        $logger.info ""
        $logger.info "log file detected at #{proxy_log_path}"
        $logger.info ""
    end
    fh_r = File.open(proxy_log_path)

    i = 0
    failed = 0
    fh_r.each_line do | line |
        i += 1

        report_process(i)
        record = parse_log_record(line)

        if record["MsgType"].nil? or record["MsgType"].empty? or record["MsgType"][0].nil?
            $logger.warn "MsgType not found in #{record}, skip"
            next
        end

        begin
            result["Msg count"][proxy_log_path + "\t" + record["MsgType"][0]] += 1
        rescue
            result["Msg count"][proxy_log_path + "\t" + record["MsgType"][0]] = 1
        end

        # if such msg type is limited, then 
        if has_defined_rules(record, rules)
            if not record_is_valid(proxy_log_path, i, record, rules, result)
                failed += 1
            end
        end
    end

    if failed == 0
        $logger.info "all #{i} record are valid, scan finish"
        result["Overall Status"].push("Passed")
        result["All record(s)"] += i
        result["Valid record(s)"] += i
        result["Invalid record(s)"] += 0


    else
        $logger.warn "#{failed} out of #{i} record is invalid, scan finish"
        result["Overall Status"].push("Failed")
        result["All record(s)"] += i
        result["Valid record(s)"] += (i - failed)
        result["Invalid record(s)"] += failed
    end
    
end

def dump_result(result)
    fh = open("proxy_log_checking.csv", "w")
    fh.write("""
OMD Proxy log checking
Interface Spec version,#{result["Interface Spec version"]}
Execution time,#{result["Execution time"]}
""")

    if result["Notes"]
        fh.write("""
Notes
#{result["Notes"].join("\n")}
"""
)
    end

fh.write("""
Overall Status,#{result["Overall Status"]}
All record(s),#{result["All record(s)"]}
Valid record(s),#{result["Valid record(s)"]}
Invalid record(s),#{result["Invalid record(s)"]}

Proxy Log Path,Msg Type,Msg Count
#{result["Msg count"].map{|x| x[0].split("\t").join(",") + "," + x[1].to_s}.join("\n")}
""")

    if result["Error Message"].length > 0
        fh.write("""
Error Message
Proxy Log Path,Line Number,Msg Type,Rule Name,Field Name,Expect Value,Actual Value
#{result["Error Message"].map{ |x| x.join(",")}.join("\n")}

"""
)
    end
    fh.close()
end

if $0 == __FILE__

    require 'logger'
    $logger = Logger.new(STDOUT)

    # initiate report collector
    result ={"Interface Spec version" => nil, "Execution time" => nil, "Notes" => [],
             "Overall Status" => [], "All record(s)" => 0, "Valid record(s)" => 0, "Invalid record(s)" => 0,
             "Msg count" => {},
             "Error Message" => []}

    spec_version = ARGF.argv[0]

    # to load csv file
    rules = load_rules(spec_version, result)
    result["Interface Spec version"] = spec_version

    # loop through all proxy log files, like standard or premium
    for log_file in ARGF.argv[1..-1]
        check_omd_proxy_log(rules, log_file, result)
    end

    # for more than one input file, all pass means pass, else fail
    if result["Overall Status"].length == result["Overall Status"].select{ |x| x == "Passed"}.length
        result["Overall Status"] = "Passed"
    else
        result["Overall Status"] = "Failed"
    end
    pp result

    dump_result(result)

    # change cli return status, better indication
    if result["Overall Status"] == "Passed" and not /WARN/.match(result["Notes"].join(""))
        exit(0)
    else
        exit(1)
    end
end
