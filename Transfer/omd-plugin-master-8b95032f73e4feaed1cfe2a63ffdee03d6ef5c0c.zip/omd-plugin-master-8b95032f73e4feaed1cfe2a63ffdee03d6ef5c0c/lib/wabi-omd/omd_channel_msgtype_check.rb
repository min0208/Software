# read log path from config

# Usage:

# ruby omd_channel_msgtype_check.rb path_spec_file proxy_log_folder

require 'set'
require 'pp'
require 'date'

def channel_msgtype_check(spec_path, proxy_log_folder, result)

	fh_config = open(spec_path)
	fh_config.readline()

	config_content = fh_config.readlines().select{|x| x.strip() != "" and not x =~ /^ *#/}.map{|x| x.strip().split(",")}
	config = {}

	for l in config_content
        filename = l[1]
        ch = l[2]
        prod_and_ch = "#{filename},#{ch}"
        allowed_msgtypes = l[3]
		config[prod_and_ch] = {}
		config[prod_and_ch]["pattern"] = Regexp.new(allowed_msgtypes)
		config[prod_and_ch]["text"]    = allowed_msgtypes
	end

	$logger.info "rule loaded as #{config}"

	log_files = config_content.map{|x| x[1]}.to_set

	skip_msgtype = ["100"]
	skip_channel = ["90", "91", "92"]

    result["Notes"].push("# TODO Msg Type #{skip_msgtype} were ignored")
    result["Notes"].push("# TODO Channel #{skip_channel} were ignored")

	# pp log_files
	for filename in log_files
		log_path = "#{proxy_log_folder}/#{filename}.log"
		if not File.exists?(log_path)
			$logger.warn "proxy log #{log_path} not exist, skip"
			next
		end

		fh = open(log_path)
		i = 0
		for l in fh
			i += 1
			# puts l
            if i % 1000 == 0
                $logger.info "scan #{i}000 lines of #{log_path}"
            end
			if /MsgType=(\d+)/.match(l)
				ch = /^\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}.\d{6} (\d+)\]/.match(l)[1]
				msgtype = /MsgType=(\d+)/.match(l)[1]

				if skip_msgtype.include?(msgtype)
					$logger.info "#{log_path}:#{i}, msgtype in #{skip_msgtype}, skip"
					next
				end

				if skip_channel.include?(ch)
					$logger.info "#{log_path}:#{i}, channel in #{skip_channel}, dummy, skip"
					next
				end

				# puts filename, ch, msgtype, allowed_pairs["#{filename}:#{ch}"], 

                group_key = "#{log_path},#{ch},#{msgtype}"
				begin
					result["Counter"][group_key] += 1
				rescue
					result["Counter"][group_key] = 1
				end

                prod_and_ch = "#{filename},#{ch}"
				if not config[prod_and_ch]["pattern"] =~ msgtype
                    $logger.warn "#{log_path},#{i},#{ch},#{config[prod_and_ch]["text"]},#{msgtype},#{l}"
					result["Error"].push("#{log_path},#{i},#{ch},#{config[prod_and_ch]["text"]},#{msgtype}")
                    result["Fail"] += 1
					# puts "bad"
					# puts l
					# puts allowed_pairs["#{filename}:#{ch}"], msgtype
					# raise "bad"
                else
                    result["Pass"] += 1
				end
			end
		end
	end
	# puts result
end


def dump_result(result, spec_path)
    log_file = "omd_channel_msgtype_check.csv"
    fh = open(log_file, "w")

    fh.write("OMD Proxy Log Checking on ChannelID -> MsgType binding\n\n")
    fh.write("Connectivity Guide version,#{File.basename(spec_path)}\n")
    fh.write("Execution time,#{DateTime.now()}\n")
    fh.write("\n")

    if result["Fail"] == 0
        fh.write("Overall Status,Pass\n")
    else
        fh.write("Overall Status,Fail\n")
    end

    fh.write("All record(s),#{result["Pass"] + result["Fail"]}\n")
    fh.write("Valid record(s),#{result["Pass"]}\n")
    fh.write("Invalid record(s),#{result["Fail"]}\n")

    if not result["Counter"].nil?
        fh.write("\nMsg Counts\n")
        fh.write("Log Path,Channel,Msg Type,Count\n")

        for k in result["Counter"].keys().sort
            fh.write("#{k},#{result["Counter"][k]}\n")
        end
    end

    if result["Error"].length > 0
        fh.write("\nError Message\n")
        fh.write("Log Path,Line Number,Channel,Expected Msg Type, Actual Msg Type\n")
        for l in result["Error"]
            fh.write(l+"\n")
        end
        # fh.write("\nSomething wrong\n")
    # else
        # fh.write("\nAll Good\n")
    end
    fh.write("\n")
    fh.close()
    $logger.info "output write to #{File.absolute_path(log_file)}"
end


if $0 == __FILE__
    require 'logger'
    $logger = Logger.new(STDOUT)

	result = {}
	result["Counter"] = {}
    result["Notes"] = []
	result["Error"] = []

    result["Pass"] = 0
    result["Fail"] = 0


    puts ARGF.argv
    puts ARGF.argv.length
	if ARGF.argv.length != 2
		$logger.warn "Usage: ruby omd_channel_msgtype_check.rb path_spec_file proxy_log_folder"
		exit(2)
	end

	spec_path = ARGF.argv[0]
	proxy_log_folder = ARGF.argv[1]

	if not File.exist?(spec_path)
		$logger.warn "spec not found #{spec_path}"
		raise "spec not found #{spec_path}"
	end

	if not Dir.exist?(proxy_log_folder)
		$logger.warn "proxy log folder not found #{proxy_log_folder}"
		raise "proxy log folder not found #{proxy_log_folder}"
	end

	begin
		channel_msgtype_check(spec_path, proxy_log_folder, result)
	rescue
		$logger.warn $!
		$logger.warn "something wrong, fail"
		exit(1)
	end

    dump_result(result, spec_path)
	# $logger.info result

	if result["Error"].nil?
		exit(0)
	else
		exit(1)
	end
end
