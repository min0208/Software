# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd template handler

require 'csv'
# OMDTemplateHandler is class for function for OMD template
class OMDTemplateHandler
  # @param default_template [File] default template csv
  def initialize(project, version)
    # if default_template not there, use the default config file
    default_template = "#{File.dirname(__FILE__)}/../../" \
      + "/config/#{project}/omd_template_#{version}.csv"
    @template_hash = generate_hash(default_template)
    custom_template = "features/#{project}_template.csv"
    generate_hash_from_fixformat_template custom_template if File.exist? custom_template
  end

  # @parm csv [File] csv file
  # @return [Hash<TemplateName:{<FieldName>:<Value>}>] hash with template info
  def generate_hash_from_fixformat_template(csv)
    res = {}
    index = 0
    CSV.foreach(csv) do |row|
      # malformed case
      if index == 0
        index += 1
        next
      end
      # malfromed case
      if row.size != 2
        OMDUtil::Logger.warn "Customizing template: #{row} is malformed "
        next
      end
      # correct format
      key = row.first.strip
      value = {}
      v = row.last.strip
      arr = v.split ';'
      arr.each do |e|
        temp_arr = e.split '='
        value[temp_arr.first] = temp_arr.last
      end
      res[key] = value
      # overlap name with golden template
      if @template_hash[key]
        OMDUtil::Logger.warn "Template #{key} cannot be overwitten "
      else
        # insert the customizing template
        @template_hash[key] = value
      end
    end
    OMDUtil::Logger.debug res
    res
  end

  # @parm csv [File] csv file
  # @return [Hash<TemplateName:{<FieldName>:<Value>}>] a hash comtain template info
  # Accquire the template hash object from a valid template csv file
  def generate_hash(csv)
    csv = CSV.read(csv)
    array = csv.map { |arr| { arr[0] => arr[1..-1] } }
    hash = {}
    array.each do |temp_hash|
      key = temp_hash.keys.first
      value = {}
      temp_hash[key].each do |ele|
        next unless ele
        value[ele.split('=').first.strip] = ele.split('=').last.strip
      end
      hash[key] = value
    end
    hash
  end

  # @param row [Hash] Hash from Datatable after alias handling
  # @return [Hash] handled row of data
  def handle(row)
    template = row['Template']
    if @template_hash[template]
      @template_hash[template].each do |k, v|
        row[k] = v if row[k].nil?
      end
    else
      $error_handler.report(:invalid_template, [template])
    end
    row.delete 'Template'
    row
  end
end
