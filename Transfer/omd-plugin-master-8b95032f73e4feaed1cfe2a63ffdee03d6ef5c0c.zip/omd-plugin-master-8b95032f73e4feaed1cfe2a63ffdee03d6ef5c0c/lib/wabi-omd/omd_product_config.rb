# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd product config handler

class OMDProductConfig
  # constructor
  def initialize(project)
    url = "#{File.dirname(__FILE__)}/../../" \
      + "/config/#{project}/product_config.csv"
    @product_hash = get_hash(url)
    @mmdh_product_array = ['MMDH']
  end

  # @param url [File] import config file
  # @return [Hash] config hash
  def get_hash(csv)
    hash = {}
    CSV.foreach(csv) do |row|
      next if !row[0].nil? && row[0].match(/^ *#/)
      hash[row[0]] = { file: row[1], channel: row[2] }
    end
    hash
  end

  # @param name [String] product name
  # @return [String] configured real product file name
  def get_subject(name)
    @product_hash.each do |key, value|
      return key if value[:file] == name
    end
    return nil
  end

  # @param name [String] product name
  # @return [String] configured real product file name
  def get_product(name)
    res = @product_hash[name]
    if res
      return res[:file]
    else
      return nil
    end
  end

  # @return [Array] valid subjects
  def get_valid_subjects
    @product_hash.keys
  end

  def is_mmdh_product(product)
    res = false
    res = true if @mmdh_product_array.include? product 
    res
  end
end
