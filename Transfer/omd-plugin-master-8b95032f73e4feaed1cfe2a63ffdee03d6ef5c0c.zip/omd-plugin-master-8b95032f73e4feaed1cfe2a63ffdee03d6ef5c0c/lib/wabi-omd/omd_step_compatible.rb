# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd cucumber compatible step

# @!method <Product>_print_OMD_response_after_<TimeStamp>
# @param OMD Product [Product]
# @param TimeStamp [Wabi Timestamp]
# @example
# * Set timestamp as TS1
# * Index print OMD response after TS1
# step for compatible with old version
Given(/^([,a-zA-Z0-9 ]*) print OMD-C response after (.*?)$/) do |subject, ts|
  step "#{subject} print OMD response after #{ts}"
end

# @!method <Product>_print_OMD_response_from_<TS1>_to_<TS2>
# @param OMD Product [Product]
# @param TS1 [Wabi Timestamp]
# @param TS2 [Wabi Timestamp]
# @example
# * Set timestamp as TS1
# ...
# * Set timestamp as TS2
# * Index print OMD response from TS1 to TS2
Given(/^([,a-zA-Z0-9 ]*) print OMD-C response from (.*?) to (.*?)$/) do |subject, ts1, ts2|
  step "#{subject} print OMD response from #{ts1} to #{ts2}"
end

# print the response
Given(/^([,a-zA-Z0-9 ]*) print OMD-C response$/) do |subject|
  step "#{subject} print OMD response"
end

# set group
Given(/^Set OMD-C (.*?) as (.*?):$/) do |groupname, var, table|
  step "Set OMD #{groupname} as #{var}:", table
end

# MMDH send admin message
Given(/^([,a-zA-Z0-9 ]*) send admin:$/) do |subject, table|
  step "#{subject} submit send table:", table
end

# MMDH verify message
Given(/^([,a-zA-Z0-9 ]*) batch verify message:$/) do |subject, table|
  step "#{subject} submit verify table:", table
end

# MMDH retrieve retransmit complete time
# count all of message type with time range 1 second
# save result with TS
Given(/^([a-zA-Z0-9 ]*) save retransmit completed time as (.*?)$/) do |subject, obj|
  arr           = obj.split(' ')
  refer_ts      = arr[0]
  index_of_from = (arr.index 'from') || (arr.index 'after')
  start_ts      = index_of_from ? arr[index_of_from + 1] : nil

  if start_ts
    steps %Q{
      * #{subject} submit check table:
      | MsgType | ReferenceVar | From        |
      | (.*)    | #{refer_ts}  | #{start_ts} |
    }
  else
    steps %Q{
      * #{subject} submit check table:
      | MsgType | ReferenceVar |
      | (.*)    | #{refer_ts}  |
    }
  end
end

# MMDH retrieve last message
# lookup all of message type with current time
# save result with Ref
Given(/^([a-zA-Z0-9 ]*) lookup last message as (.*?)$/) do |subject, ref|
  steps %Q{
    * #{subject} submit lookup table:
    | MsgType | ReferenceVar |
    | (.*)    | #{ref}       |
  }
end

# print product supports table template
Given(/^Print OMD-C client tool product support template$/) do
  # intial proxy
  ct_handler = OMDClientToolHandler.new(ENV['OMD_PROJECT'])
  ct_handler.print_product_table
end
