# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd table handler

# OMDTableHandler is class for handling OMD table
class OMDTableHandler2
  #      rg_handler: repeat group handler
  # refresh_handler: refresh handler
  #  scenario_stime: scenario start time
  attr_accessor :rg_handler, :refresh_handler, :scenario_stime, :duration, :timeout, :search_proxy_only_once

  # constructor
  def initialize(proxy, cmp)
    @proxy            = proxy
    @cmp              = cmp == 'Y' ? true : false
    @ins              = false
    @rg_handler       = nil
    @refresh_handler  = nil
    @scenario_stime   = nil
    @duration         = 1
    @timeout          = 30
    @search_proxy_only_once = false
    @subjects         = {}
  end

  # @param sub [String] subjec tin the table
  # add subjects
  def set_subject(sub)
    subjects = sub.strip.split ','
    subjects.each do |sub|
      sub = sub.strip
      valid_subs = $product_config.get_valid_subjects
      if valid_subs.include? sub
        @subjects[sub] = $product_config.get_product sub
      else
        # invalid subject name
        $error_handler.report(:invalid_subject, [sub, valid_subs.join(',')])
      end
    end
  end

  # @param options [String] empty| from A to B | from A
  # set time range
  def set_timerange(options)
    options = options.strip
    # handle in sequence
    if options.include? 'in sequence'
      @ins = true
      # remove in sequence
      options['in sequence'] = ''
      options = options.strip
    end
    # handle exactly
    if options.include? 'exactly'
      @proxy.exact = true
      options['exactly'] = ''
      options = options.strip
    else
      @proxy.exact = false
    end
    # handle afterwards
    if options.include? 'afterwards'
      # set the last match as the start time
      if $omd_latest_match
        @proxy.stime = $omd_latest_match if $omd_latest_match
      end
      # remove afterwards
      options['afterwards'] = ''
      options = options.strip
    end
    ## handle from and to
    $error_handler.report(:no_wabi, []) unless $timestamps
    arr = options.split(' ')
    from_ts = nil
    to_ts   = nil
    at_ts   = nil
    # get from TS
    index_of_from = (arr.index 'from') || (arr.index 'after')
    if index_of_from
      if arr[index_of_from + 1]
        from_ts = arr[index_of_from + 1]
        if $timestamps[from_ts]
          from_ts = $timestamps[from_ts]
        else
          # error handling
          $error_handler.report(:invalid_timestamp, [from_ts])
        end
      else
        # error handling
        $error_handler.report(:wrong_option, [options])
      end
    end

    $logger.debug "from_ts is #{from_ts}" 

    # get to TS
    if arr.index 'to'
      if arr[arr.index('to') + 1]
        to_ts = arr[arr.index('to') + 1]
        if $timestamps[to_ts]
          to_ts = $timestamps[to_ts]
        else
          # error handling
          $error_handler.report(:invalid_timestamp, [to_ts])
        end
      else
        # error handling
        $error_handler.report(:wrong_option, [options])
      end
    end

    $logger.debug "to_ts is  #{to_ts}" 

    # search message timestamp given
    if arr.index 'at'
      if arr[arr.index('at') + 1]
        at_ts = arr[arr.index('at') + 1]
        if $timestamps[at_ts]
          @at_ts = $timestamps[at_ts]
        else
          # error handling
          $error_handler.report(:invalid_timestamp, [at_ts])
        end
      else
        # error handling
        $error_handler.report(:wrong_option, [options])
      end
    end
    # overwrite the default proxy start and
    # end time
    # default start time
    @dstime = @proxy.stime = OMDUtil.get_time(from_ts) if from_ts
    # default end time
    @detime = @proxy.etime = OMDUtil.get_time(to_ts) if to_ts
  end

  # @response_hash [Hash]
  # get the proxy reponse
  def get_response(response_hash = nil)
    @subjects.each do |sub, product|
      # set the default start time
      if response_hash
        @proxy.stime = response_hash[sub]
        # update the time iterator of the product
        response_hash[sub] = OMDUtil.get_time(Time.now)
      end
      # set the proxy product
      @proxy.product = product
      @proxy.send_get_response
    end
  end

  # check if current is a refresh product
  # return true if it is a refresh product
  #  otherwise return false
  def is_refresh_product(sub)
    if !@refresh_handler.nil? and @refresh_handler.is_refresh_product(sub)
      return true
    end
    return false
  end


  def bind_refresh_cycle_to_ref(ref)
    # record refresh time range to ref
    if ref
      ref = ref.strip if ref.to_s.size > 0
      $timestamps["#{ref}.RefreshStartTime"] = Time.parse @proxy.stime
      $timestamps["#{ref}.RefreshEndTime"]   = Time.parse @proxy.etime
    end
  end


  # @param row, test case row
  # @param 
  # process refresh start and end time,
  # 
  def handle_refresh(sub, row)

    # first check from table, if not, then query proxy / search back
    # gain corresponding refresh channel id from realtime channel id, based on the csv config
    # like realtime ch10 => refresh ch510
    @refresh_handler.process_refresh_channel_id(sub, row)

    if handle_from_timestamp(row) && handle_to_timestamp(row)
      $world.puts "Refresh search time range set by From / To column:" \
        "start_time=#{@proxy.stime}," \
        "end_time=#{@proxy.etime}," \
        "channelID=#{row['ChannelID']}" if $world
    else
      if !@refresh_handler.nil?

        refresh_complete = @refresh_handler.get_channel_refresh_complete(row['ChannelID'])
        if !refresh_complete.nil?
          @proxy.stime = OMDUtil.get_time refresh_complete['PREV_COMP_TIME']
          @proxy.etime = OMDUtil.get_time refresh_complete['LAST_COMP_TIME']
        # else
        #   pass
        #   # some logging complain about uncompleted refresh ?
        end
      # else
      #   pass
      #   # some logging complain about nil handler ?
      end
      $world.puts "Refresh search time range set by query proxy:" \
        "start_time=#{@proxy.stime}," \
        "end_time=#{@proxy.etime}," \
        "channelID=#{row['ChannelID']}" if $world
    end    

    if ! @proxy.stime or ! @proxy.etime
      raise "faile to check refresh cycle"
    end
    
    bind_refresh_cycle_to_ref(row["ResponseRef"])

  end

  # @param row, test case row
  # 
  # process test row start time
  #  based on the given From input
  def handle_from_timestamp(row)
    # handle from and to column in row
    tag = 'From'
    ts  = row[tag]
    if ts
      unless ts.empty?
        # invalid timestamp
        $error_handler.report(:invalid_timestamp, [ts]) unless $timestamps[ts]
        @proxy.stime = OMDUtil.get_time $timestamps[ts]
        row.delete tag
        return true
      end
    end

    return false
  end

  # @param row, test case row
  # 
  # process test row end time
  #  based on the given To input
  def handle_to_timestamp(row)
    # check to timestamp
    tag = 'To'
    ts = row[tag]
    if ts
      unless ts.empty?
        # invalid timestamp
        $error_handler.report(:invalid_timestamp, [ts]) unless $timestamps[ts]
        @proxy.etime = OMDUtil.get_time $timestamps[ts]
        row.delete tag
        return true
      end
    end

    return false
  end

  # @param row, test case row
  # 
  # process test row start time
  # based on the given At input
  def handle_at_timestamp(row)
    @at_ts_row = nil

    tag = 'At'
    ts  = row[tag]
    if ts
      unless ts.empty?
        # invalid timestamp
        $error_handler.report(:invalid_timestamp, [ts]) unless $timestamps[ts]
        @at_ts_row = $timestamps[ts]
        row.delete tag
        return true
      end
    end

    return false
  end

  # @param row, test case row
  # 
  # process test row start and end time
  #  based on the given From/To input
  def handle_realtime(row)
    # handle from and to column in row
    handle_from_timestamp(row)
    handle_to_timestamp(row)
    handle_at_timestamp(row)
  end

  # param row, test case hash
  #
  # 1. process alias for the test row
  # 2. process template for the test row
  # 3. validate the test row
  # 4. process repeating groups for the test row
  def pre_process_test_row(row)
    # handle alias
    # $logger.info 'handle alias'
    row = $omd_alias_handler.handle(row) if $omd_alias_handler
    # handle template
    # $logger.info 'handle template'
    row = $omd_template_handler.handle(row) if $omd_template_handler
    # handle validation
    # $logger.info 'handle validation'
    row = $omd_validator.validate(row) if $omd_validator
    # handle repeating group
    # $logger.info 'handle repeating group'
    row = @rg_handler.handle(row) if @rg_handler.has_group?

    return row
  end

  # @param tablehash [Array<hash>] hash of the AST::DATATABLE
  # @param 
  # search the table
  def sendRequest(tablehash)
    ref_hash = {}
    @subjects.each do |sub, product|
      @proxy.product         = product
      $error_handler.subject = sub
      index = 1
      tablehash.each do |row|
        $error_handler.index = index
        row      = row.clone
        template = row['Template']
        row      = pre_process_test_row(row)
        handle_realtime(row)
        ref_result = lookup_message_list(row)

        ref_hash   = ref_hash.merge ref_result if ref_result
        index += 1
      end
    end
    ref_hash
  end

  def lookup_message_list(row)
    result = {}

    ref_to_return = row['ResponseRef']

    tag = 'ResponseRef'
    if row[tag]
      ref = row[tag].strip if row[tag].to_s.size > 0
      row.delete tag
    end

    res = send_search_all_messages(row)

    result[ref_to_return] = []
    for msg in res["messages"].split("\n")
      hash_msg = {}
      # p "------------------msg:#{msg}--------"
      i = 1
      for field_and_value in msg.split(";")
        field = field_and_value.split("=")[0]
        value = field_and_value.split("=")[1]

        if "NewsLine" == field
          field = "NewsLine (#{i})"
          i +=1
        end

        # p "--i:#{i}--field: #{field} ------value:#{value}---------------"
        hash_msg[field] = value        
      end
      result[ref_to_return].push(hash_msg)
    end
    
    if result[ref_to_return].length > 0
      return result
    end

    return nil
  end

  def send_search_all_messages(row)

    message = { 'product'    => @proxy.product,
                'channel'    => '',
                'action'     => 'search_all',
                'message'    => {},
                'start_time' => @dstime,
                'end_time'   => @detime,
                # 'start_time' => @proxy.stime,
                # 'end_time'   => @proxy.etime,
                'timeout'    => @proxy.timeout.to_s }
                
    message['message']['fields'] = OMDUtil.get_fields(row)

    $logger.debug "at omd_table_handler2, send_search_all_messages, send #{message.to_json}"

    return JSON.parse @proxy.send_raw(message.to_json)
  end

  # @param tablehash [Array<hash>] hash of the AST::DATATABLE
  # @param 
  # search the table
  def submit(tablehash)
    ref_hash = {}
    @subjects.each do |sub, product|
      @proxy.product         = product
      $error_handler.subject = sub
      index = 1
      tablehash.each do |row|
        $error_handler.index = index
        row      = row.clone
        template = row['Template']
        row      = pre_process_test_row(row)
        handle_realtime(row)
        ref_result = lookup_last_message(row)
        ref_hash   = ref_hash.merge ref_result if ref_result
        index += 1
      end
    end
    ref_hash
  end

  def lookup_last_message(row)
    result = {}
    ref = nil
    tag = 'ResponseRef'
    if row[tag]
      ref = row[tag].strip if row[tag].to_s.size > 0
      row.delete tag
    end

    cur_time  = Time.now
    end_time  = @at_ts ? @at_ts : cur_time
    end_time  = @at_ts_row if @at_ts_row
    @last_msg = nil
    begin
      @proxy.stime = OMDUtil.get_time(end_time - @duration)
      @proxy.etime = OMDUtil.get_time(end_time)

      # @proxy.stime = @dstime
      # @proxy.etime = @detime

      count        = send_lookup_last_message(row)
      end_time     = end_time - @duration
      break if Time.now - cur_time > @timeout
      break if @search_proxy_only_once
    end until (count > 0)

    if  @last_msg
      
      $logger.debug "@last_msg is #{@last_msg}"

      # parse message
      highlighted_keys = OMDUtil.get_highlighted_keys row
      omd_msg          = OMDUtil.convert_omd_msg(@last_msg, highlighted_keys)
      omd_msg          = OMDUtil.handle_mmdh_msg(omd_msg, @proxy.product)
      # output pdf
      sub    = $product_config.get_subject @proxy.product
      tables = [ { 'Title'       => "Received #{sub} message fields",
                   'NumOfColumn' => 4,
                   'Template'    => '',
                   'TextMsg'     => omd_msg,
                   'BinMsg'      => '' } ]
      OMDUtil.print_pdf_table(tables)
      # keep response
      if ref
        msg_time = $1 if @last_msg =~ /^MsgTime=(\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d.\d\d\d\d\d\d);.*$/
        $timestamps["#{ref}.Timestamp"] = Time.parse(msg_time) if msg_time
        res = {}
        m_fields = OMDUtil.get_msg_fields_hash @last_msg

        $logger.debug "m_fields is #{m_fields}"
        # D, [2019-07-10T15:41:04.454198 #15769] DEBUG -- : m_fields is [{"MsgTime"=>"2019-04-22 07:56:50.675000"}, {"ChannelID"=>"1"}, {"SeqNum"=>"9361"}, {"MsgSize"=>"20"}, {"MsgType"=>"13"}, {"SecurityCode"=>"2405"}, {"NoLiquidityProviders"=>"5"}, {"LPBrokerNumber"=>"9733"}, {"LPBrokerNumber"=>"9729"}, {"LPBrokerNumber"=>"9717"}, {"LPBrokerNumber"=>"9702"}, {"LPBrokerNumber"=>"9726"}]


        # D, [2019-07-11T11:55:50.256491 #30684] DEBUG -- : m_fields is [{"MsgTime"=>"2019-04-22 07:56:50.351000"}, {"ChannelID"=>"1"}, {"SeqNum"=>"7006"}, {"MsgSize"=>"464"}, {"MsgType"=>"11"}, {"SecurityCode"=>"30056"}, {"MarketCode"=  >"GEM "}, {"ISINCode"=>"HK0008011667"}, {"InstrumentType"=>"EQTY"}, {"ProductType"=>"1"}, {"SpreadTableCode"=>"01"}, {"SecurityShortName"=>"PCCW                                    "}, {"CurrencyCode"=>"EUR"}, {"SecurityNameGCC  S"=>"　　　　　　　　　　　　　　　"}, {"SecurityNameGB"=>"　　　　　　　　　　　　　　　"}, {"LotSize"=>"1000"}, {"PreviousClosingPrice"=>"10"}, {"VCMFlag"=>"Y"}, {"ShortSellFlag"=>"Y"}, {"CASFlag"=>"Y"}, {"CCASSFlag"=>"N"},   {"DummySecurityFlag"=>"N"}, {"StampDutyFlag"=>"N"}, {"ListingDate"=>"20161103"}, {"DelistingDate"=>"0"}, {"FreeText1"=>"                                                  "}, {"FreeText2"=>"                                                    "}, {"EFNFlag"=>"EFNFlag"}, {"AccruedInterest"=>"0"}, {"CouponRate"=>"0"}, {"FaceValue"=>"0"}, {"DecimalsInFaceValue"=>"0"}, {"FaceValueCurrency"=>"   "}, {"MaturityDate"=>"0"}, {"InvestorType"=>" "}, {"Conversion  Ratio"=>"0"}, {"StrikePrice1"=>"0"}, {"StrikePrice2"=>"0"}, {"MaturityDate"=>"0"}, {"CallPutFlag"=>"CallPutFlag"}, {"Style"=>"Style"}, {"WarrantType"=>" "}, {"CallPrice"=>"0"}, {"DecimalsInCallPrice"=>"0"}, {"Entitlement"=>"0"  }, {"DecimalsInEntitlement"=>"0"}, {"NoWarrantsPerEntitlement"=>"0"}, {"UnderlyingIndexCode"=>"           "}, {"NoUnderlyingSecurities"=>"0"}]

        # D, [2019-07-11T11:12:48.234758 #30259] DEBUG -- : receive: {
        #     "status": "success",
        #     "count": "2",
        #     "messages": "MsgTime=2019-04-22 09:00:01.408000;ChannelID=42;SeqNum=50;MsgSize=112;MsgType=71;IndexCode=000001     ;IndexStatus= ;IndexTime=2018-11-20 00:59:56.000000;IndexValue=2703.5116;NetChgPrevDay=0;HighValue=0;LowValue=0;EASValue=;IndexTurnover=0;OpeningValue=0;ClosingValue=0;PreviousSesClose=2703.5116;IndexVolume=0;NetChgPrevDayPct=0;Exception= ;\nMsgTime=2019-04-22 10:14:51.118000;ChannelID=42;SeqNum=9020;MsgSize=112;MsgType=71;IndexCode=000001     ;IndexStatus= ;IndexTime=2018-11-20 01:24:51.000000;IndexValue=2703.5116;NetChgPrevDay=0;HighValue=0;LowValue=0;EASValue=;IndexTurnover=0;OpeningValue=0;ClosingValue=0;PreviousSesClose=2703.5116;IndexVolume=0;NetChgPrevDayPct=0;Exception= ;"
        # }
        # 
        # D, [2019-07-11T11:12:48.234979 #30259] DEBUG -- : @last_msg is MsgTime=2019-04-22 10:14:51.118000;ChannelID=42;SeqNum=9020;MsgSize=112;MsgType=71;IndexCode=000001     ;IndexStatus= ;IndexTime=2018-11-20 01:24:51.000000;IndexValue=2703.5116;NetChgPrevDay=0;HighValue=0;LowValue=0;EASValue=;IndexTurnover=0;OpeningValue=0;ClosingValue=0;PreviousSesClose=2703.5116;IndexVolume=0;NetChgPrevDayPct=0;Exception= ;
        # D, [2019-07-11T11:12:48.235494 #30259] DEBUG -- : result parsed for search_last is {"ANSBOOK_PROXY_IndexData_\"000001     \".MsgTime"=>"2019-04-22 10:14:51.118000", "ANSBOOK_PROXY_IndexData_\"000001     \".ChannelID"=>"42", "ANSBOOK_PROXY_IndexData_\"000001     \".SeqNum"=>"9020", "ANSBOOK_PROXY_IndexData_\"000001     \".MsgSize"=>"112", "ANSBOOK_PROXY_IndexData_\"000001     \".MsgType"=>"71", "ANSBOOK_PROXY_IndexData_\"000001     \".IndexCode"=>"000001     ", "ANSBOOK_PROXY_IndexData_\"000001     \".IndexStatus"=>" ", "ANSBOOK_PROXY_IndexData_\"000001     \".IndexTime"=>"2018-11-20 01:24:51.000000", "ANSBOOK_PROXY_IndexData_\"000001     \".IndexValue"=>"2703.5116", "ANSBOOK_PROXY_IndexData_\"000001     \".NetChgPrevDay"=>"0", "ANSBOOK_PROXY_IndexData_\"000001     \".HighValue"=>"0", "ANSBOOK_PROXY_IndexData_\"000001     \".LowValue"=>"0", "ANSBOOK_PROXY_IndexData_\"000001     \".EASValue"=>"EASValue", "ANSBOOK_PROXY_IndexData_\"000001     \".IndexTurnover"=>"0", "ANSBOOK_PROXY_IndexData_\"000001     \".OpeningValue"=>"0", "ANSBOOK_PROXY_IndexData_\"000001     \".ClosingValue"=>"0", "ANSBOOK_PROXY_IndexData_\"000001     \".PreviousSesClose"=>"2703.5116", "ANSBOOK_PROXY_IndexData_\"000001     \".IndexVolume"=>"0", "ANSBOOK_PROXY_IndexData_\"000001     \".NetChgPrevDayPct"=>"0", "ANSBOOK_PROXY_IndexData_\"000001     \".Exception"=>" "}
        # I, [2019-07-11T11:12:48.235617 #30259]  INFO -- : searching ANSBOOK_PROXY_IndexData_
        # I, [2019-07-11T11:12:48.235663 #30259]  INFO -- : found 20 ANSBOOK_PROXY_IndexData_ records
        # I, [2019-07-11T11:12:48.235742 #30259]  INFO -- : {
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".MsgTime": "2019-04-22 10:14:51.118000",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".ChannelID": "42",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".SeqNum": "9020",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".MsgSize": "112",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".MsgType": "71",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".IndexCode": "000001     ",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".IndexStatus": " ",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".IndexTime": "2018-11-20 01:24:51.000000",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".IndexValue": "2703.5116",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".NetChgPrevDay": "0",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".HighValue": "0",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".LowValue": "0",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".EASValue": "EASValue",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".IndexTurnover": "0",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".OpeningValue": "0",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".ClosingValue": "0",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".PreviousSesClose": "2703.5116",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".IndexVolume": "0",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".NetChgPrevDayPct": "0",
        #   "ANSBOOK_PROXY_IndexData_\"000001     \".Exception": " "

        #
        field_name_list = []

        # $logger.debug "all fields are #{m_fields.map{|key_pair| key_pair.keys()[0]}}"
        all_fields = m_fields.map{|key_pair| key_pair.keys()[0]}
        # $logger.debug "all fields are #{all_fields}"

        m_fields.each do | field |
          field.each do |k, v|
            field_name_list.push(k)
            # $logger.debug "field_name_list is now #{field_name_list}"

            # check field name duplicate
            if all_fields.select {|n| n == k}.length > 1

              additional_suffix = field_name_list.select {|field_name| field_name == k}.length
              # $logger.debug "k #{k} is duplicate, currently field_name_list is #{field_name_list}, and additional_suffix should be #{additional_suffix}"
              res["#{ref}.#{k} (#{additional_suffix})"] = v
            end

            res["#{ref}.#{k}"] = v
          end
        end
        result = result.merge res
      end
    else
      $error_handler.error_msg = "process timed out"
      $error_handler.trigger
    end

    $logger.debug "result parsed for search_last is #{result}"

    return result
  end

  def send_lookup_last_message(row)

    message = { 'product'    => @proxy.product,
                'channel'    => '',
                'action'     => 'rt_count',
                'message'    => {},
                'start_time' => @dstime,
                'end_time'   => @detime,
                # 'start_time' => @proxy.stime,
                # 'end_time'   => @proxy.etime,
                'timeout'    => @proxy.timeout.to_s }
                
    message['message']['fields'] = OMDUtil.get_fields(row)

    $logger.debug "at omd_table_handler2, send_lookup_last_message, send #{message.to_json}"


    res = JSON.parse @proxy.send_raw(message.to_json)
    count = res['count'].to_i
    unless count == 0
      @last_msg = res['messages'].split("\n")[-1]
    end
    count
  end

end
