# encoding: utf-8
#      Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
#      All rights reserved.
#      Project  : omd-plugin
#      Description: omd validator

# OMDValidator class for validating OMD

require 'csv'

class OMDValidator
  # bigmap connecting to external bigmap
  attr_accessor :bigmap

  # constructor
  def initialize(project, version)
    # wabi support fields
    @wabi_fields = OMDUtil.wabi_fields
    # valid fields
    valid_fields = "#{File.dirname(__FILE__)}/../../" \
      + "/config/#{project}/valid_fields_#{version}.csv"
    @valid_fields = get_fields_hash valid_fields
    # valid groups
    group_fields = "#{File.dirname(__FILE__)}/../../" \
      + "/config/#{project}/repeat_group_#{version}.csv"
    @valid_rg = get_repeating_group_hash group_fields
  end

  # @param csv [File] valid field config csv file
  # @teturn [Hash] field hash
  # generate internal valid fields hash
  def get_fields_hash(csv)
    res = {}
    CSV.foreach(csv) do |row|
      res[row[0]] = { name: row[1], fields: row[2..-1]|@wabi_fields }
    end
    res
  end

  # @param csv [File] valid repeating group config csv file
  # @return [Hash] repeating group hash
  # generate internal valid repeating group hash
  def get_repeating_group_hash(csv)
    res = {}
    CSV.foreach(csv) do |row|
      res[row[1]] = row[2..-1]
    end
    res
  end

  # @param row [Hash] row of Data table
  # @return [Hash] validated row
  # validate 'receive' message
  def validate(row)
    row.default = nil
    row = Marshal.load(Marshal.dump(row))
    handle_null(row)
    handle_variable(row)
    handle_valid_fields(row)
    handle_value_normalization(row)
    row
  end

  # @param row [Hash] row of Data table
  # @return [Hash] validated row
  # validate if repeating group definition is correct
  def validate_group(row, groupname)
    row.default = nil
    row = Marshal.load(Marshal.dump(row))
    handle_null(row)
    handle_variable(row)
    handle_valid_rg row, groupname
    handle_value_normalization(row)
    row
  end

  # @param row [Hash] row of Data table
  # @return [Hash] validated row
  # check if all fields in table is vlaid
  def handle_valid_fields(row)
    msg_type = row['MsgType']
    $error_handler.report :no_msgtype unless msg_type
    if msg_type && @valid_fields[msg_type]
      keys = row.keys
      invalid = keys - @valid_fields[msg_type][:fields]
      # found in valid fields
      if !invalid.empty? && $error_handler
        invalid = invalid.join ','
        $error_handler.report :invalid_msg_field, [invalid,\
                                                   @valid_fields[msg_type][:name], msg_type]
      end
    end
  end

  # @param row [Hash] row of Data table
  # @return [Hash] handled row of data
  # check if all fields in repeating group  is valid
  # and if the repeating group name is valid
  def handle_valid_rg(row, groupname)
    if @valid_rg.keys.include? groupname
      row_keys = row.keys
      valid_keys = @valid_rg[groupname]
      invalid = row_keys - valid_keys
      if invalid.size > 0
        $error_handler.report :invalid_rg_field, [invalid.join(','), groupname, @valid_rg[groupname].join(',')]
      end
    else
      $error_handler.report :invalid_rg, [groupname, @valid_rg.keys.join(',')]
    end
    row
  end

  # @param row [Hash] row of Data table
  # @return [Hash] handled row of data
  # get rid of empty in table cell
  def handle_null(row)
    # delete empty
    row.each do |k, v|
      # skip the repeating group case
      row.delete k if v.class != Array && v.strip == ''
    end
  end

  # @param row [Hash] row of Data table
  # @return [Hash] handled row of data
  # replace the variable in table
  def handle_variable(row)
    return row unless @bigmap
    row.each do |k, v|
      row[k] = @bigmap[v] if @bigmap[v]
    end
    row
  end

  # @param row [Hash] row of Data table
  # @return [Hash] handled row of data
  # replace the regex expression in table
  # remove quotation marks
  def handle_value_normalization(row)
    row.each do |k, v|
      next if v.nil?
      if v.is_a? String
        v.gsub!('regex(', '(')
        OMDUtil::remove_quotation_marks(v)
        OMDUtil::fill_with_space(v)
      end
    end
    row
  end
end
