# WABI Cucumber Plugin for OMD-C/D/M

JIRA Project: http://10.18.103.1:8090/mtl/jira/projects/OMD

## Features:

* Use WABI to match/count/retrieve OMD messages
* Able to talk with OMD-C/D/M Proxies using TCP socket

## Module omd-plugin

## Versions

omd-c
* 2.0
* 1.23
* 1.14

omd-d
* 1.27
* 1.28
* 1.24_g4

omd-m
* 1.1
* 1.2
* 1.3
* 1.4

## TODO

* there are way too much timeout for this, needs explain
* and way too much different forms of json requests seperated in each .rb file, needs explain
* extract common func out, do some analyze / refactor if good, like logger
* stop using "handler"
* prepare some reasonable comments

