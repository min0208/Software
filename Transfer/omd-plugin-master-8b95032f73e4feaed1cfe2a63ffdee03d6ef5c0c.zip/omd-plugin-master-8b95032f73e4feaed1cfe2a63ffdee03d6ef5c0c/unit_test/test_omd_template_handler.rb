require 'testhelper'
require 'logger'
class OMDTemplateHandlerTest < MiniTest::Unit::TestCase
  def setup
    @ot = OMDTemplateHandler.new('omdc', '2.0')
  end

  def test_generate_hash
    hash = @ot.generate_hash('unit_test/data/omd_template.csv')
    assert_equal(hash['MarketTurnoverGEM']['MsgType'], '61')
  end

  def test_generate_hash_from_fixformat_template
    res = @ot.generate_hash_from_fixformat_template 'unit_test/data/omd_template.csv'
    assert_equal '11', res['ABC']['MsgType']
    assert_equal 'value', res['ABC']['field']
  end

  def test_handle
    row = { 'Template' => 'Statistics', 'Test_Property' => '123' }
    result = @ot.handle(row)
    assert_equal(result['Template'], nil)
    assert_equal(result['Test_Property'], '123')
    assert_equal(result['MsgType'], '60')
  end
end
