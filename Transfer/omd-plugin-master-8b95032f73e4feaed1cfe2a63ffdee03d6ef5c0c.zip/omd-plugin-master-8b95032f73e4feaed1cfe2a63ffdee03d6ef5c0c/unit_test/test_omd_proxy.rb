# encoding: UTF-8
require 'testhelper'
class OMDProxyTest < MiniTest::Unit::TestCase
  def setup
    @proxy = OMDProxy.new '127.0.0.1', 5555
    @proxy.stime = OMDUtil.begin_time
    @proxy.etime = OMDUtil.now_time
    @proxy.product = 'OMDSecuritiesStandard'
    $world = STDOUT
    $error_handler = OMDErrorReporter.new
    $timestamps ||= {}
  end

  def test_send_get_response
    @proxy.send_get_response
    assert true
  end
  
  def test_send_count
    message = '{"product":"OMDSecuritiesStandard","action":"count","start_time":"1900-01-01 00:00:00.000000","end_time":"2016-06-29 09:55:49.027614","message":{"fields":[{"MsgType":"10"},{"MsgSize":"40"}]}}'
    res = @proxy.send(:send_raw, message)
    assert res =~ /"count": "4"/
  end

  def test_send_first_match
    row = {}
    row['MsgType'] = '10'
    row['MsgSize'] = '40'
    @proxy.send(:send_first_match, row)
    assert true
  end

  def test_send_first_match_not_found
    row = {}
    row['MsgType'] = '10'
    row['MsgSize'] = '400'
    begin
    @proxy.send(:send_first_match, row)
    rescue
    assert true
    end
  end


  def test_send_raw
    message = '{"product":"OMDSecuritiesStandard","action":"match","start_time":"1900-01-01 00:00:00.000000","end_time":"2016-06-29 09:55:49.027614","message":{"fields":[{"MsgType":"10"},{"MsgSize":"40"},{"MarketCode":"ETS"}]}}'
    res = @proxy.send(:send_raw, message)
    # just test some message back
    assert res.size > 0
  end

  def test_get_checking_fields
    row = { 'abc' => '123', 'cde' => '234', 'group' => [{ 'a' => '1', 'b' => '2' }, { 'a' => '3', 'b' => '4' }] }
    res = @proxy.get_checking_fields row
    assert_equal res, [{ 'abc' => '123' }, { 'cde' => '234' }, { 'group' => 'a=1,b=2' }, { 'group' => 'a=3,b=4' }]
  end

  def test_get_highlighted_keys
    row = { 'abc' => '123', 'cde' => '234', 'group' => [{ 'a' => '1', 'b' => '2' }, { 'a' => '3', 'b' => '4' }] }
    res = @proxy.get_highlighted_keys row
    res = %w(abc cde a b)
  end

  def test_send_sce_start
    res = @proxy.send_sce_start '123', '123'
    assert res.include? 'received'
  end

  def test_send_sce_end
    res = @proxy.send_sce_end '123', '123'
    assert res.include? 'received'
  end

  def test_send_out
    row = {}
    row['SecurityCode'] = '7326'
    row['MarketCode'] = 'MAIN'
    #row['UnderlyingSecurities'] = [{ 'UnderlyingSecurityCode' => '1211'}]
    row['LotSize'] = '200'
    row['MsgType'] = '11'
    @proxy.send_out row
    assert true
    row['Count'] = '1'
    @proxy.send_out row
    assert true
  end

  def test_send_out_with_check_result
    row = {}
    row['SecurityCode'] = '27774'
    row['MarketCode'] = 'MAIN'
    row['LotSize'] = '5000'
    row['MsgType'] = '11'
    res = @proxy.send_out row
    assert_equal({},res)
  end

  def test_send_out_with_ref_check_result
    row = {}
    row['SecurityCode'] = '27774'
    row['MarketCode'] = 'MAIN'
    row['LotSize'] = '5000'
    row['MsgType'] = '11'
    row['ResponseRef'] = 'T001'
    res = @proxy.send_out row
    puts res.values
    assert(res.keys.size > 0)
  end

  def test_send_out_with_none_ref_check_result
    row = {}
    row['SecurityCode'] = '27774'
    row['MarketCode'] = 'MAIN'
    row['LotSize'] = '5000'
    row['MsgType'] = '11'
    row['ResponseRef'] = ''
    res = @proxy.send_out row
    assert_equal({},res)
  end

  def test_send_out_with_ref_check_result_with_group
    row = {}
    row['SecurityCode'] = '7326'
    row['MarketCode'] = 'MAIN'
    row['LotSize'] = '200'
    row['MsgType'] = '11'
    row['ResponseRef'] = 'T001'
    #row['UnderlyingSecurities'] = [{ 'UnderlyingSecurityCode' => '1211', 'UnderlyingSecurityWeight' => '0.0' }]
    res = @proxy.send_out row
    puts res.values
    assert(res.keys.size > 0)
  end

  def test_send_out_with_none_ref_check_result_with_group
    row = {}
    row['SecurityCode']         = '7326'
    row['MarketCode']           = 'MAIN'
    row['LotSize']              = '200'
    row['MsgType']              = '11'
    row['ResponseRef']          = ''
#    row['UnderlyingSecurities'] = [{ 'UnderlyingSecurityCode' => '1211', 'UnderlyingSecurityWeight' => '0.0' }]
    res = @proxy.send_out row
    assert_equal({},res)
  end



  def test_send_match_in_sequence
    row = { 'MsgType' => '10', 'MsgSize' => '40', 'MarketCode' => 'MAIN' }
    stime = @proxy.stime
    @proxy.send_match row, true
    assert stime != @proxy.stime
    stime = @proxy.stime
    puts stime
    row = { 'MsgType' => '10', 'MsgSize' => '40', 'MarketCode' => 'GEM' }
    @proxy.send_match row, true
    assert true
  end

  def test_retrieve
    row = {}
    row['SecurityCode'] = '2600'
    row['NoEntries'] = '2'
    row['MsgType'] = '53'
    row['MsgSize'] = '60'
    res = @proxy.send_retrieve row
    STDOUT.puts res
    # STDOUT.puts hash.inspect
  end

  def test_get_exact_result
    row = {}
    row['SecurityCode'] = '1088'
    row['NoEntries'] = '2'
    row['Entries'] = [{ 'AggregateQuantity' => '2000', 'Price' => '12.6', 'NumberOfOrders' => '1' }, { 'AggregateQuantity' => '1370000', 'Price' => '11.24', 'NumberOfOrders' => '2' }]
    row['MsgType'] = '53'
    res = @proxy.get_exact_result row, @proxy.stime
    STDOUT.puts res
  end

  def test_check_missing_package
    res = @proxy.check_missing_package
    STDOUT.puts res
  end
end
