require 'testhelper'
class OMDAliasHandlerTest < MiniTest::Unit::TestCase
  def setup
    @ah = OMDAliasHandler.new('omdc', '2.0')
  end

  def test_generate_hash_from_fixformat_alias
    res = @ah.generate_hash_from_fixformat_alias 'unit_test/data/omd_alias.csv'
    key = res.keys.first
    assert_equal '<GLOBAL>', key[:template]
    assert_equal 'abc', key[:field]
    assert_equal 'cdf', key[:value]
    value = res.values.first
    # {"UnderlyingSecurity"=>"group", "LotSize"=>"5000"}}
    assert_equal 'group', value['UnderlyingSecurity']
  end
end
