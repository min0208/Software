require 'testhelper'
class OMDTableHandlerTest < MiniTest::Unit::TestCase
  def setup
    $omd_validator = OMDValidator.new('omdc', '2.0')
    $omd_template_handler = OMDTemplateHandler.new('omdc', '2.0')
    $omd_alias_handler = OMDAliasHandler.new('omdc', '2.0')
    $timestamps = {}
    $error_handler = OMDErrorReporter.new
    $product_config = OMDProductConfig.new('omdc')
    @proxy = OMDProxy.new('127.0.0.1', 5555)
    rg = OMDRepeatGroupHandler.new('omdc', '2.0')
    @th = OMDTableHandler.new(@proxy, rg, 'N')
  end

  def test_set_subject
    @th.set_subject 'Index'
    assert_equal 1, @th.subjects.size
  end

  def test_get_response
    ts_now = OMDUtil.get_time(Time.now)
    rsp_hash = { 'Securities Standard' => ts_now }
    @th.set_subject 'Securities Standard'
    sleep 1
    @th.get_response rsp_hash
    assert_equal ts_now, @proxy.stime
    assert_equal false, rsp_hash['Securities Standard'] == ts_now
  end

  def test_in_sequence_check
    ts1 = Time.new(2016, 6, 13, 2, 7, 0)
    ts2 = Time.new(2016, 6, 13, 2, 9, 0)
    $timestamps['TS1'] = ts1
    $timestamps['TS2'] = ts2
    @th.set_subject 'Securities Standard'
    @th.set_timerange 'in sequence from TS1 to TS2'
    puts @proxy.stime
    puts @proxy.etime
    tablehash = []
    tablehash << { 'Template' => 'MarketDefinition', 'MarketCode' => 'MAIN', 'CurrencyCode' => 'HKD' }
    tablehash << { 'Template' => 'MarketDefinition', 'MarketCode' => 'GEM', 'CurrencyCode' => 'HKD' }
    tablehash << { 'Template' => 'MarketDefinition', 'MarketCode' => 'NASD', 'CurrencyCode' => 'HKD' }
    tablehash << { 'Template' => 'MarketDefinition', 'MarketCode' => 'ETS', 'CurrencyCode' => 'USD' }
    @th.submit(tablehash)
    assert true
  end

  def test_alias_check
    @proxy.stime = OMDUtil.begin_time
    @proxy.etime = OMDUtil.now_time
    @th.set_subject 'Securities Standard'
    tablehash = []
    tablehash << { 'Template' => 'CurrencyRate', 'CurrencyRate' => '71.51', 'CurrencyCode' => 'JPY' }
    @th.submit(tablehash)
    assert true
  end

  def test_repeat_group
    @proxy.stime = OMDUtil.begin_time
    @proxy.etime = OMDUtil.now_time
    @th.set_subject 'Securities Standard'
    tablehash = []
    tablehash << { 'Template' => 'AggregateOrderBookUpdate', 'SecurityCode' => '1088', 'NoEntries' => '2', 'Entries' => [{ 'AggregateQuantity' => '2000', 'Price' => '12.6', 'NumberOfOrders' => '1' }, { 'AggregateQuantity' => '1370000', 'Price' => '11.24', 'NumberOfOrders' => '2' }] }
    @th.submit(tablehash)
    assert true
  end
end
