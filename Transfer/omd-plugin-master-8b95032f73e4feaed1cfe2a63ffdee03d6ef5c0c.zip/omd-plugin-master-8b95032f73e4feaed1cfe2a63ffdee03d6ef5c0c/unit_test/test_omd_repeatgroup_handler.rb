require 'testhelper'
require 'logger'
class OMDRepeatGroupHandlerTest < MiniTest::Unit::TestCase
  def test_generate_RG_hash
    logger = Logger.new STDOUT
    hash = OMDRepeatGroupHandler.generate_hash('unit_test/data/repeat_group.csv')
    assert hash['53']

    assert_equal hash['53'][:name], 'Entries'
    assert_equal hash['53'][:fields].size, 6
    assert_equal 3, hash['22'].size
    assert_equal 'MarketCodes', hash['22'][1][:name]
  end

  def test_handle
    rh = OMDRepeatGroupHandler.new("omdc", "2.0")
    validator = OMDValidator.new("omdc", "2.0")
    group = []
    gr = { 'AggregateQuantity' => '2000', 'Price' => '12.6' }
    group << gr
    assert_equal gr, validator.validate_group(gr, 'Entries')
    group << { 'AggregateQuantity' => '1370000', 'Price' => '11.24' }
    rh.add_rg 'AQE', group
    row = { 'MsgType' => '53', 'SecurityCode' => '1088', 'Entries' => 'AQE' }
    row = rh.handle row
    puts row
    assert_equal 2, row['Entries'].size
  end
end
