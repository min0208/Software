if ENV['COVERAGE']
  require 'simplecov'
  SimpleCov.start do
    add_filter '/unit_test'
  end
end

require 'minitest/autorun'
require 'wabi-omd/omd_util'
require 'wabi-omd/omd_alias_handler'
require 'wabi-omd/omd_proxy'
require 'wabi-omd/omd_table_handler'
require 'wabi-omd/omd_template_handler'
require 'wabi-omd/omd_validator'
require 'wabi-omd/omd_error_reporter'
require 'wabi-omd/omd_repeatgroup_handler'
require 'wabi-omd/omd_product_config'
require 'wabi-omd/omd_refresh_hanlder.rb'
