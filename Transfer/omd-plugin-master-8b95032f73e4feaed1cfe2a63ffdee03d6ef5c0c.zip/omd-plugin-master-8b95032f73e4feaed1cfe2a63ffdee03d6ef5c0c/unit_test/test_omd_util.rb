require 'testhelper'
class OMDUtilTest < MiniTest::Unit::TestCase
  def test_begin_time
    assert_equal(OMDUtil.begin_time, '1900-01-01 00:00:00.000000')
  end

  def test_now_time
    str = Time.now.strftime('%Y-%m-%d %H:%M:%S')
    assert(OMDUtil.now_time.start_with? str)
  end

  def test_ts_nil
    assert_equal(OMDUtil.get_time(nil), nil)
  end

  def test_ts_timestamp
    ts = Time.new(2000, 01, 02)
    assert_equal(OMDUtil.get_time(ts), '2000-01-02 00:00:00.000000')
  end

  def test_get_next_time
    assert_equal '2000-01-02 00:00:00.000001', OMDUtil.get_next_time('2000-01-02 00:00:00.000000')
  end
  
  def test_get_identical_msg
    old_message = "multiple responses matched. \nRefMsg: MsgTime=2017-03-01 07:58:56.554000;ChannelID=3;SeqNum=1;MsgSize=8;MsgType=100;NewSeqNo=1;  MsgTime=2017-03-01 07:58:56.554000;ChannelID=3;SeqNum=1;MsgSize=8;MsgType=100;NewSeqNo=1;  "
    assert_equal 'MsgTime=2017-03-01 07:58:56.554000;ChannelID=3;SeqNum=1;MsgSize=8;MsgType=100;NewSeqNo=1;', OMDUtil.get_identical_msg(old_message)
  end
end
