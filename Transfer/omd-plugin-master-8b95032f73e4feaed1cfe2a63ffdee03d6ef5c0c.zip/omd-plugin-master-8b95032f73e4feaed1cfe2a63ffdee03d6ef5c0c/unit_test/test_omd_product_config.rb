require 'testhelper'
class OMDProductConfigTest < MiniTest::Unit::TestCase
  def setup
    @pc = OMDProductConfig.new('omdc')
  end

  def test_get_hash
    res = @pc.get_hash 'unit_test/data/product_config.csv'
    assert_equal 'OMDIndex', res['Index'][:file]
  end
end
