# encoding: UTF-8
require 'testhelper'
class OMDValidatorTest < MiniTest::Unit::TestCase
  def setup
    @validator = OMDValidator.new('omdc', '2.0')
  end

  def test_get_fields_hash
    res = @validator.get_fields_hash 'unit_test/data/valid_fields.csv'
    assert_equal 'Market Definitoin', res['10'][:name]
    assert_equal 10, res['10'][:fields].size
  end

  def test_get_rf_fields_hash
    res = @validator.get_repeating_group_hash 'unit_test/data/repeat_group.csv'
    assert_equal 2, res['UnderlyingSecurities'].size
    assert_equal 'LPBrokerNumber', res['LiquidityProviders'].first
  end
end
