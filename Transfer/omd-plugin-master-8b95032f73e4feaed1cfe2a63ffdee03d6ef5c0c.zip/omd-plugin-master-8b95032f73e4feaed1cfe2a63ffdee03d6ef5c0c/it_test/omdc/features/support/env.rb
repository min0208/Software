$LOAD_PATH.unshift "#{File.dirname(__FILE__)}/../../../lib"
require 'wabi'
require 'wabi-omd'

ENV['OMD_PROJECT'] = 'omdc'
ENV['OMD_VERSION'] = '2.0'
ENV['OMD_IP']      = '127.0.0.1'
ENV['OMD_PORT']    = '5555'
ENV['OMD_CMP']     = 'Y'

