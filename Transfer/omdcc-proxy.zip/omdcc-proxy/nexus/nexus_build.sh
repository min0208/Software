#!/bin/sh

WORK_DIR=$(readlink -e $(dirname $0)/..)
$WORK_DIR/nexus/nexus_pull.sh download

cp -r $WORK_DIR/nexus/files/include/* $WORK_DIR

cd $WORK_DIR/src
make -j4
