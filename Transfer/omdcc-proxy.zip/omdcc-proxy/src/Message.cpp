#include "Message.h"

namespace OMDCCPROXY
{

Message::Message(uint16_t msgSize) : mMsgData(NULL)
{
    mMsgSize = (msgSize > MAX_PACKET_SIZE) ? MAX_PACKET_SIZE : msgSize;
    mMsgData = new char[mMsgSize];
}

Message::~Message()
{
    delete [] mMsgData;
}

uint16_t Message::GetMsgSize() 
{
    return mMsgSize;
}

char* Message::GetMsgData() 
{
    return mMsgData;
}

}