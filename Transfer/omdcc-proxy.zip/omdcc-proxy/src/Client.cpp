#include "Client.h"

namespace OMDCCPROXY
{

Client::Client(const char* address, int port)
       : m_bConnected(false)
{
    memset(&m_SocketAddr, 0, sizeof(m_SocketAddr));
    m_SocketAddr.sin_family         = AF_INET;
    m_SocketAddr.sin_port           = htons(port);
    m_SocketAddr.sin_addr.s_addr    = inet_addr(address);
}

Client::~Client()
{

}

void Client::ConnectToServer(int timeout)
{
    std::cout << " -- Client::Connecting to OMD-CC server " << std::endl;

    // create tcp stream
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
    {
        //::ErrorHandler::print(logger, "socket()", true);
        std::cout << "Cannot create socket" << std::endl;
    }
    m_Socketfd = sockfd;

    // connect to server
    int retVal = connect(m_Socketfd, (struct sockaddr *)&m_SocketAddr, sizeof(m_SocketAddr));
    if (retVal < 0) 
    {
        std::cout << "Cannot connect to server" << std::endl;
        close(sockfd);
        m_bConnected = false;
        return;
    }

    std::cout << "Connected to server successfully" << std::endl;
    m_bConnected = true;
}

void Client::StartReadingThred()
{  
    pthread_create(&m_ReadThreadId, NULL, &threadReadMessage, this);
}

void Client::ReadFromServer()
{  
    std::cout << " -- Client::ReadFromServer" << std::endl;

    int nfds    = 1;
    int timeout = -1;

    struct pollfd fds[nfds];
    fds[0].fd = m_Socketfd;
    fds[0].events = POLLIN | POLLERR;

    char aReadBuffer[MAX_PACKET_SIZE];
    memset(aReadBuffer, 0, sizeof(aReadBuffer));

    int nReadBufferOffset = 0;

    uint16_t headerSize = sizeof(OMD_PROXY_MESSAGE::PacketHeader);

    while (poll(fds, nfds, timeout) > 0 || errno == EINTR)
    {
        if (fds[0].revents & POLLIN)
        {
            std::cout << " -- Client::ReadFromServer  -- message received " << std::endl;
            
            // Read the data on the socket
            ssize_t len = recv(fds[0].fd, &aReadBuffer[nReadBufferOffset], sizeof(aReadBuffer)-nReadBufferOffset, 0);

            if (len < 1)
            {
                break;
            }

            nReadBufferOffset += len;

            while (nReadBufferOffset >= headerSize)
            {
                char* pPacketData = aReadBuffer;

                OMD_PROXY_MESSAGE::PacketHeader* pPacketHeader = (OMD_PROXY_MESSAGE::PacketHeader*)pPacketData;
                uint16_t pktSize = pPacketHeader->mPktSize;
                if (nReadBufferOffset >= pktSize)
                {
                    ProcessCTServerMsg(pPacketData);
                    memmove(pPacketData, &pPacketData[pktSize], sizeof(aReadBuffer)-pktSize);
                    nReadBufferOffset -= pktSize;
                }
                else
                {
                    break;
                }
            }
        }
    }

    close(m_Socketfd);
}

void Client::ProcessCTServerMsg(char* pPacketData)
{
    std::cout << " -- Client::ProcessCTServerMsg" << std::endl;

    OMD_PROXY_MESSAGE::PacketHeader* pPacketHeader = (OMD_PROXY_MESSAGE::PacketHeader*)pPacketData;
    uint16_t pktSize = pPacketHeader->mPktSize;

    if (!IsValidPacket(pPacketData, pktSize))
    {
        return;
    }

    if (pPacketHeader->mMsgCount > 0)
    {
        char* pRecvMsgData = 0;
        uint32_t seqNum = pPacketHeader->mSeqNum;
        CTRespondHeader*  pCTHeader;
        
        while (pRecvMsgData = GetNextPacketMsg(pPacketData, pktSize, pRecvMsgData))
        {
            pCTHeader = (OMD_PROXY_MESSAGE::CTRespondHeader*)pRecvMsgData;

            switch (pCTHeader->mInfoType)
            {
                case CT_OMDCC_SECURITY_SEARCH_RESPOND:
                    //LOG4_DEBUG(mLogger, "OMDCC Security Search Respond: " << translateRspCode(pCTHeader->mRespondCode));
                    break;
                case CT_OMDCC_SECURITY_SNAPSHOT_RESPOND:
                    //LOG4_DEBUG(mLogger, "OMDCC Security Snap Shot Respond: " << translateRspCode(pCTHeader->mRespondCode));
                    break;
                default:
                    OMD_PROXY_MESSAGE::MsgHeader* pMsgHeader=(OMD_PROXY_MESSAGE::MsgHeader*)pRecvMsgData;
                    if (pMsgHeader->mMsgType < OMD_PROXY_MESSAGE::SEQUENCE_RESET_TYPE && 
                        pMsgHeader->mMsgType > OMD_PROXY_MESSAGE::END_MSG_TYPE)
                    {
                        //LOG4_DEBUG(mLogger, "Unknown CT Message: " << pCTHeader->mRespondCode);
                    }
                    else
                    {
                        ProcessMsg(101, 0/*recvTime*/, pktSize, pMsgHeader->mMsgType, pRecvMsgData);
                    }
                    break;
            }
        } 
    }
    else
    {
        // LOG4_WARNING(mLogger, "MsgCount is 0");
    }
}

bool Client::IsValidPacket(char* pPacketData, uint16_t packetSize) 
{
    if (packetSize < sizeof(OMD_PROXY_MESSAGE::PacketHeader))
    {
        return false;
    }

    OMD_PROXY_MESSAGE::PacketHeader* pPacketHeader = (OMD_PROXY_MESSAGE::PacketHeader*)pPacketData;
    if (packetSize != pPacketHeader->mPktSize)
    {
        return false;
    }

    if (packetSize == sizeof(OMD_PROXY_MESSAGE::PacketHeader) && pPacketHeader->mMsgCount == 0) 
    {
        return true;
    }

    char* pEndPacketData = pPacketData + packetSize;
    char* pData = pPacketData + sizeof(OMD_PROXY_MESSAGE::PacketHeader);
    for (int i=0; i<pPacketHeader->mMsgCount; i++) 
    {
        if (pData + sizeof(OMD_PROXY_MESSAGE::MsgHeader) > pEndPacketData)
        {
            // LOG4_ERR(mLogger, "MsgHeader goes over end of packet");
            return false;
        }
        OMD_PROXY_MESSAGE::MsgHeader* pMsgHeader = (OMD_PROXY_MESSAGE::MsgHeader*)pData;
        uint16_t msgSize = pMsgHeader->mMsgSize;
        if (pData + msgSize > pEndPacketData)
        {
            // LOG4_ERR(mLogger, "Msg goes over end of packet");
            return false;
        }
        pData += msgSize;
    }
    return true;
}

char* Client::GetNextPacketMsg(char* pPacketData, uint16_t packetSize, char* pMsgData) 
{
    std::cout << " -- Client::GetNextPacketMsg" << std::endl;

    OMD_PROXY_MESSAGE::PacketHeader* pPacketHeader = (OMD_PROXY_MESSAGE::PacketHeader*)pPacketData;

    if (pPacketHeader->mMsgCount == 0) 
    {
        return 0;
    }

    // Return pointer to first byte of first message
    if (!pMsgData) 
    {
        return pPacketData + sizeof(OMD_PROXY_MESSAGE::PacketHeader);
    }

    OMD_PROXY_MESSAGE::MsgHeader* pMsgHeader = (OMD_PROXY_MESSAGE::MsgHeader*)pMsgData;
    uint16_t msgSize = pMsgHeader->mMsgSize;

    if (pMsgData + msgSize < pPacketData + packetSize) 
    {
        return pMsgData + msgSize;
    } 

    return 0;
}

void Client::ProcessMsg(uint16_t channelID, uint64_t sendTime, uint16_t msgSize, uint16_t msgType, char* pMsgData)
{
    std::cout << " -- Client::ProcessMsg" << std::endl;

    //LOG4_DEBUG(mLogger, "ClientToolP4::processMsg() - MsgSize:" << msgSize << " MsgType:" << msgType);

    OMD_PROXY_MESSAGE::MsgHeader* pMsgHeader= (OMD_PROXY_MESSAGE::MsgHeader*)pMsgData;
    char pMsg[msgSize];
    memcpy(pMsg, pMsgData, msgSize);

    uint16_t sseszseConvention;

    switch (msgType) 
    {
        case OMD_PROXY_MESSAGE::REFRESH_COMPLETE_TYPE:
            {
                std::cout << "-1 msgType: Xdp::REFRESH_COMPLETE_TYPE" << std::endl;
                OMD_PROXY_MESSAGE::RefreshComplete* pStruct = (OMD_PROXY_MESSAGE::RefreshComplete*)pMsg;                
                
                std::cout << "ym log -- RefreshComplete message";    
                std::cout << "ym log -- msgSize    :" << pStruct->mMsgSize << std::endl;  
                std::cout << "ym log -- msgtype    :" << pStruct->mMsgType << std::endl;  
                std::cout << "ym log -- lastSeqNum :" << pStruct->mLastSeqNum << std::endl;   

                break;
            }
        case OMD_PROXY_MESSAGE::LINE_STATUS_TYPE: 
            {
                std::cout << "-2 msgType: Xdp::LINE_STATUS_TYPE" << std::endl;
                OMD_PROXY_MESSAGE::LineStatus* pStruct = (OMD_PROXY_MESSAGE::LineStatus*)pMsg;

                uint16_t channelID = pStruct->mChannelID;
                uint8_t newStatus;

                switch (pStruct->mStatus)
                {
                    case 1: newStatus = 2; break;  //UP
                    case 2: newStatus = 1; break;  //Part
                    case 3: newStatus = 0; break;  //Down       
                }

                break;
            }
        case OMD_PROXY_MESSAGE::OMDCC_MARKET_DEFINITION_TYPE:
            {
                std::cout << "-3 msgType: Xdp::OMDCC_MARKET_DEFINITION_TYPE" << std::endl;

                OMD_PROXY_MESSAGE::OMDCC_MarketDefinition* pStruct = (OMD_PROXY_MESSAGE::OMDCC_MarketDefinition*)pMsg;      

                std::cout << "ym log -- OMDCC_MarketDefinition message" << std::endl; 
                std::cout << "ym log -- msgSize           :" << pStruct->mMsgSize << std::endl;   
                std::cout << "ym log -- msgtype           :" << pStruct->mMsgType << std::endl;   
                //dumpBufferString(  "ym log -- market code         :", pStruct->mMarketCode, 4);
                //dumpBufferString(  "ym log -- market name         :", pStruct->mMarketName, 25);
                //dumpBufferString(  "ym log -- currency code   :", pStruct->mCurrencyCode, 3);
                std::cout << "ym log -- numOfSecurities   :" << pStruct->mNumberOfSecurities << std::endl;    

                break;
            }
        case OMD_PROXY_MESSAGE::OMDCC_SECURITY_DEFINITION_TYPE:
            {
                std::cout << "-4 msgType: Xdp::OMDCC_SECURITY_DEFINITION_TYPE" << std::endl;

                OMD_PROXY_MESSAGE::OMDCC_SecurityDefinition* pStruct = (OMD_PROXY_MESSAGE::OMDCC_SecurityDefinition*)pMsg;

                std::cout << "ym log -- OMDCC_SecurityDefinition message";   
                std::cout << "ym log -- msgSize           :" << pStruct->mMsgSize << std::endl;   
                std::cout << "ym log -- msgtype           :" << pStruct->mMsgType << std::endl;   
                std::cout << "ym log -- security code     :" << pStruct->mSecurityCode << std::endl;  
                //dumpBufferString(  "ym log -- market code         :", pStruct->mMarketCode, 4);
                //dumpBufferString(  "ym log -- isin code       :", pStruct->mISINCode, 12);
                //dumpBufferString(  "ym log -- instrument type     :", pStruct->mInstrumentType, 4);
                //dumpBufferString(  "ym log -- filler1             :", pStruct->mFiller1, 2);
                //dumpBufferString(  "ym log -- security shortname:", pStruct->mSecurityShortName, 40);
                //dumpBufferString(  "ym log -- currency code   :", pStruct->mCurrencyCode, 3);
                //dumpBufferString(  "ym log -- security name gccs:", pStruct->mSecurityNameGCCS, 60);
                //dumpBufferString(  "ym log -- security name gb    :", pStruct->mSecurityNameGB, 60);
                std::cout << "ym log -- log size          :" << pStruct->mLotSize << std::endl;
                std::cout << "ym log -- pre closing price :" << pStruct->mPreviousClosingPrice << std::endl;
                ///dumpBufferString(  "ym log -- filler2            :", pStruct->mFiller2, 1);
                //dumpBufferString(  "ym log -- short sell flag     :", pStruct->mShortSellFlag, 1);
                //dumpBufferString(  "ym log -- filler3             :", pStruct->mFiller3, 6);
                //dumpBufferString(  "ym log -- filler4             :", pStruct->mFiller4, 3);
                std::cout << "ym log -- listing Date      :" << pStruct->mListingDate << std::endl;   
                std::cout << "ym log -- delisting Date    :" << pStruct->mDelistingDate << std::endl; 

                break;
            }
        case OMD_PROXY_MESSAGE::OMDCC_SECURITY_STATUS_TYPE:
            {
                std::cout << "-5 msgType: Xdp::OMDCC_SECURITY_STATUS_TYPE" << std::endl;

                OMD_PROXY_MESSAGE::OMDCC_SecurityStatus* pStruct = (OMD_PROXY_MESSAGE::OMDCC_SecurityStatus*)pMsg;

                std::cout << "ym log -- OMDCC_SecurityStatus message";   
                std::cout << "ym log -- msgSize           :" << pStruct->mMsgSize << std::endl;   
                std::cout << "ym log -- msgtype           :" << pStruct->mMsgType << std::endl;   
                std::cout << "ym log -- security code     :" << pStruct->mSecurityCode << std::endl;  
                std::cout << "ym log -- security trading status :" << pStruct->mSecurityTradingStatus << std::endl;
                //dumpBufferString(  "ym log -- filler3             :", pStruct->mFiller, 3);
                //dumpBufferString(  "ym log -- circuit breaker trading status:", pStruct->mCircuitBreakerTradingState, 1);

                break;
            }
        case OMD_PROXY_MESSAGE::OMDCC_TOP_OF_BOOK_TYPE:
            {
                std::cout << "-6 msgType: Xdp::OMDCC_TOP_OF_BOOK_TYPE" << std::endl;
                OMD_PROXY_MESSAGE::OMDCC_TopOfBook* pStruct = (OMD_PROXY_MESSAGE::OMDCC_TopOfBook*)pMsg;
                
                std::cout << "ym log -- OMDCC_TopOfBook message";    
                std::cout << "ym log -- msgSize           :" << pStruct->mMsgSize << std::endl;   
                std::cout << "ym log -- msgtype           :" << pStruct->mMsgType << std::endl;   
                std::cout << "ym log -- security code     :" << pStruct->mSecurityCode << std::endl;  
                std::cout << "ym log -- agg bid qty       :" << pStruct->mAggBidQty << std::endl;
                std::cout << "ym log -- agg ask qty       :" << pStruct->mAggAskQty << std::endl;
                std::cout << "ym log -- agg bid price     :" << pStruct->mBidPrice << std::endl;
                std::cout << "ym log -- agg ask price     :" << pStruct->mAskPrice << std::endl;
                //dumpBufferString(  "ym log -- filler          :", pStruct->mFiller, 8);

                break;
            }
        case OMD_PROXY_MESSAGE::OMDCC_STATISTICS_TYPE:
            {
                std::cout << "-7 msgType: Xdp::OMDCC_STATISTICS_TYPE" << std::endl;
                OMD_PROXY_MESSAGE::OMDCC_Statistics* pStruct = (OMD_PROXY_MESSAGE::OMDCC_Statistics*)pMsg;
                
                std::cout << "ym log -- OMDCC_TopOfBook message";    
                std::cout << "ym log -- msgSize           :" << pStruct->mMsgSize << std::endl;   
                std::cout << "ym log -- msgtype           :" << pStruct->mMsgType << std::endl;   
                std::cout << "ym log -- security code     :" << pStruct->mSecurityCode << std::endl;  
                std::cout << "ym log -- share traded      :" << pStruct->mSharesTraded << std::endl;
                std::cout << "ym log -- turn over         :" << pStruct->mTurnover << std::endl;
                std::cout << "ym log -- high price        :" << pStruct->mHighPrice << std::endl;
                std::cout << "ym log -- low price         :" << pStruct->mLowPrice << std::endl;
                std::cout << "ym log -- last price        :" << pStruct->mLastPrice << std::endl;
                std::cout << "ym log -- opening price     :" << pStruct->mOpeningPrice << std::endl;
                //dumpBufferString(  "ym log -- filler          :", pStruct->mFiller, 16);

                break;
            }
        default:
            std::cout << "-8 msgType not found : " << msgType << std::endl;
            break;
    } // switch
}

void Client::SendRequest()
{
    std::cout << " -- Client::SendRequest" << std::endl;

    //Pack data struct
    
    m_SecuritySearchReq.mSize = sizeof(m_SecuritySearchReq);
    m_SecuritySearchReq.mInfoType = CT_OMDCC_SECURITY_SEARCH_REQUEST;
    m_SecuritySearchReq.mCTType = 88;
    memcpy(m_SecuritySearchReq.mMarketCode, "ASHR", 4);
    m_SecuritySearchReq.mSecurityCode = 0;

    SentToServer(m_SecuritySearchReq);
}

void Client::SentToServer(CTSecuritySearchRequest reqData)
{
    std::cout << " -- Client::SentToServer" << std::endl;
    
    if (reqData.mCTType > 100)
    {
        reqData.mCTType -= 100;
    }

    if (!PreSendChecking(CT_OMDCC_SECURITY_SEARCH_REQUEST, (const char*)&reqData))
    {
        std::cout << " -- Client::PreSendChecking failed" << std::endl;
        return;
    }

    Message* pMsg = CreateMsg(reqData.mSize);
    if ( pMsg->GetMsgSize() < reqData.mSize )
    {
        std::cout << "SentToServer() - buffer size is not enough. request size=" << reqData.mSize << " buffer size=" << pMsg->GetMsgSize() << std::endl;
        delete pMsg;
        return;
    }

    char* pMsgData = pMsg->GetMsgData();
    memcpy(pMsgData, &reqData, reqData.mSize);

    if (SendMsg(pMsgData))
    {
    }
}

bool Client::PreSendChecking(uint16_t infoType, const char* data)
{
    std::cout << " -- Client::PreSendChecking" << std::endl;

    CTSecuritySearchRequest     *securitySearch;
    CTFuturesSearchRequest      *futuresSearch;

    //Check server status
    if (!Connected())
    {
        std::cout << " -- Client::PreSendChecking - Server not connected" << std::endl;
        return false;
    }

    //Check criteria
    switch (infoType)
    {
        //------------------------------------------------------------------------------
        // For OMDCC
        //------------------------------------------------------------------------------
        case CT_OMDCC_SECURITY_SEARCH_REQUEST:
            securitySearch = (CTSecuritySearchRequest*)data; 
            if (securitySearch->mSecurityCode==0 && securitySearch->mMarketCode[0]==' ')
            {
                std::cout << " -- Client::PreSendChecking - Security Search: Ignored. No searching criteria." << std::endl;
                return false;
            }
            break;
        case CT_OMDCC_FUTURES_SEARCH_REQUEST:
            futuresSearch = (CTFuturesSearchRequest*)data;
            if (futuresSearch->mCFFExID[0]==' ' && futuresSearch->mSettleGroupID[0]==' ' && futuresSearch->mSettleID==0)
            {
                std::cout << " -- Client::PreSendChecking - Futures Search: Ignored. No searching criteria." << std::endl;
                return false;
            }
            break;
    }//switch    
    return true;
}

Message* Client::CreateMsg(uint16_t msgSize) 
{
    Message* pMsg = new Message(msgSize);
    return pMsg;
}

bool Client::SendMsg(char* pData)
{
    std::cout << " -- Client::SendMsgs" << std::endl;
    
    //Check server status
    if (!Connected())
    {
        return false;
    }
    
    int nSize = ((OMD_PROXY_MESSAGE::CTRequestHeader*)pData)->mSize;
    ssize_t bytesSent = send(m_Socketfd, pData, nSize, 0);
    if (bytesSent < 0) 
    {
        std::cout << " -- Client::SendMsgs failed" << std::endl;
        return false;
    } 
    else if (bytesSent == 0) 
    {
        std::cout << " Connection Closed " << std::endl;
        return false;
    } 

    for ( int i=0; i<nSize; i++ )
    {
        std::cout << " count " << i << ":" <<  (char)pData[i] << std::endl;
    }

    return true;
}

void* Client::threadReadMessage(void *arg)
{
    Client* pClient = (Client*)arg;
    pClient->ReadFromServer();
}

}