/****************************************************************************
 *     Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *     All rights reserved.
 *
 *     Filename : omd-proxy.cpp
 *     Project  : Wabi omd project
 *     Description: main function for omd proxy
 *
 *     Created  : 2020/01/20
 *     Author   : Min YXie
****************************************************************************/
#include <string>
#include <iostream>

#include "Logger.h"

#include "Client.h"
#include "Server.h"

#include <stdlib.h>

bool handleWabiOMDConnection()
{
    return true;
}

bool handleOMDCCServerConnection()
{
    // omd-cc server ip & port
    const std::string ipAddress= "10.1.90.97";
    const int port = 56388;

    // TODO: handle argments from input

    // TODO: message log
    // Logger omd_logger = Logger::getInstance("omd_proxy_logger");

    
    OMDCCPROXY::Client *pClient;
    try
    {
        pClient = new OMDCCPROXY::Client((char*)ipAddress.c_str(), port);
        pClient->ConnectToServer();
        if (pClient->Connected())
        {
            pClient->StartReadingThred();
        }
        else
        {
            // connect to server failed
            std::cout << "Server not connected";
        }
    }
    catch (std::exception& e)
    {
        std::cout << e.what();
        return false;
    }

    // TODO: work ad server, listen connect from wabi-feature-test
    // TODO: syn read from client
    // TODO: send to omd-cc
    try
    {
        // Test: send message to OMDCC server
        pClient->SendRequest();
    }
    catch (std::exception& e)
    {
        std::cout << e.what();
        return false;
    }

    while(true)
    {
        ::sleep(200);
    }

    std::cout << "program close" << std::endl;

    if (pClient)
    {
        delete pClient;
    }
    
    return true;
}

int main(int argc, char *argv[])
{
    std::cout << " -- omdcc proxy begin" << std::endl;

    handleOMDCCServerConnection();

    handleWabiOMDConnection();

    return 0;
}

