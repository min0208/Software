
#include <chrono>
#include <memory>

// boost
#include <boost/asio/io_service.hpp>
#include <boost/asio/ip/tcp.hpp>
#include <boost/asio/spawn.hpp>
#include <boost/asio/read.hpp>
#include <boost/asio/read_until.hpp>
#include <boost/asio/write.hpp>
#include <boost/asio/streambuf.hpp>

#include "Session.h"
#include "Converter.h"

using boost::asio::ip::tcp;

namespace OMDCCPROXY
{
// Session entrance
// it uses a coroutine to handle incoming requests,
// and handle timeout in another coroutine.
void Session::Go() noexcept
{
    // a shared ptr refer to self to make sure
    // this shared_ptr object doesn't destruct itself
    auto self(shared_from_this());
    // spawn a coroutine handing icoming request
    boost::asio::spawn(m_strand,
        [this, self](boost::asio::yield_context yield)
    {
        HandleRequest(yield);
    });
    // spawn a coroutine handing timeout
    boost::asio::spawn(m_strand,
        [this, self](boost::asio::yield_context yield)
    {
        HandleTimeout(yield);
    });
}

void Session::HandleRequest(boost::asio::yield_context& yield) noexcept
{
	try
	{
        // start a timer expires in 30s
        // close this socket if a session hangs up for 30 seconds
        const int16_t timeout = 30;
        m_timer.expires_from_now(std::chrono::seconds(timeout));

        std::string strRequest;
        std::string strAction;
        std::string strTime;
        std::string strMessageText;

        strRequest = ReadRequest(yield);
        if (!Converter::ParseJSONRequest(strRequest,
                                         strAction,
                                         strMessageText,
                                         strTime))
        {
            const std::string err = "failed to parse JSON request";
            //std::cout << "Error: " << err << ":" << requestsStr << std::endl;
            WriteResponse(yield, GenerateFailedResponse(err));
            CancelTimer();
            return;
        }

        if ("send" == strAction)
        {
            const std::string timestamp = Utils::getTimeString();
            if (HandleSendMessage(strMessageText))
            {
                WriteResponse(yield, GenerateSendingResponse(timestamp));
            }
            else
            {
                WriteResponse(yield, GenerateFailedResponse("failed to handle sending message"));
            }
        }
        else if ("matchresponse" == strAction)
        {
            std::string errorMsg;
            if (HandleMatchResponse(strMessageText, time, m_isTimedout, errorMsg))
            {
                WriteResponse(yield, GenerateSucceedResponse());
            }
            else
            {
                WriteResponse(yield, GenerateFailedResponse(errorMsg));
            }
        }
        else
        {
            //std::cout << "Warning: Unknown request action: " << action << std::endl;
            WriteResponse(yield, GenerateFailedResponse("Unknown request action: " + strAction));
        }
	}
	catch (std::exception& e)
    {
        WriteResponse(yield, GenerateFailedResponse("exception in OMDCC proxy: " + std::string(e.what())));
    }

    CancelTimer();
}

// read JSON request from client asynchrously
// it read a request till reached a line end '\n'
// return request JSON text if success,
// else return an empty string
std::string Session::ReadRequest(boost::asio::yield_context& yield) noexcept
{
    boost::asio::streambuf buf;
    boost::system::error_code ec;
    boost::asio::async_read_until(m_socket, buf, '\n', yield[ec]);

    if (ec)
    {
        //std::cout << "Error: failed to read request" << "\n";
        return std::string();
    }

    // use a thread local object for buffer to
    // convert boost::asio::streambuf to string
    thread_local std::ostringstream ss;
    ss.str("");
    ss.clear();
    ss << &buf;

    return ss.str();
}

// write JSON resposne back to user asynchrously
// it convert JSON string response to boost::asio::streambuf,
// then send out the response.
// print an error message if sending failure
void Session::WriteResponse(boost::asio::yield_context& yield,
                            const std::string& jsonResponseStr) noexcept
{
    boost::system::error_code ec;
    boost::asio::streambuf jsonResponse;

    std::ostream rs(&jsonResponse);
    rs << jsonResponseStr;
    boost::asio::async_write(m_socket, jsonResponse, yield[ec]);

    if (ec)
    {
        //std::cout << "Error: failed to write response" << std::endl;
    }

    m_socket.close();
}

// Timeout Handler
// loop to check if timeout while socket is open.
//  - close socket on timeout if still open
//  - yield to scheduler if not timed out
void Session::HandleTimeout(boost::asio::yield_context& yield) noexcept
{
    m_timer.async_wait(std::bind(&Session::ProcessTimedout,
                                 shared_from_this(),
                                 std::placeholders::_1));
}

// process timed out
// m_isTimedout is as a shared variable to
// indicate if it's timed out or not
// update the indicator if it's timed out
void Session::ProcessTimedout(const boost::system::error_code& ec) noexcept
{
    if (m_timer.expires_from_now() <= std::chrono::seconds(0))
    {
        m_isTimedout = true;
        //std::cout << "Error: Process timed out" << std::endl;
    }
}

bool Session::HandleSendMessage(const std::string& message) noexcept
{
    return true;
    //return m_app.sendFIXMessage(message);
}

// Lookup matched response with a pattern and time constraint
// and set error message properly if don't find a match
bool Session::HandleMatchResponse(const std::string& messageText,
                                  const std::string& time,
                                  const bool& isTimedout,
                                  std::string& errorMsg) noexcept
{
    return true;
    //return m_app.matchFIXResponse(messageText,
    //                              time,
    //                              isTimedout,
    //                              errorMsg);
}

}
