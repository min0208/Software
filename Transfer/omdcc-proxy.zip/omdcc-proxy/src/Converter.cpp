#include <boost/algorithm/string.hpp>
#include <boost/regex.hpp>
#include <boost/mpl/set.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>
#include <boost/regex.hpp>
#include <boost/fusion/tuple.hpp>

#include <vector>
#include <string>
#include <functional>

#include "Converter.h"

namespace OMDCCPROXY
{
// init private static members
std::mutex Converter::m_ReadJsonMutex;


// Convert a json string to OMDd message
// The JSON string is spected for have those attributes
//   - action: request type
//   - message: OMD message request with sub attributes 'tags' and 'text'
//   - time: request time
//
// The JSON string is parsed by boost::property_tree::ptree.
// return true if parsed successfully
// input: json text
// output: action
//         message text
//         time
// e.g.  input: "{ \"action\" : \"send\", \"message\": { \"tags\":
//               [ { \"8\": \"FIX.4.2\" }, { \"9\": \"187\" } ] },
//               \"time\" : \"2015-05-22 19:28:19.972954\" }"
//      output: "send",
//              "8=FIX.4.2;9=187;",
//              "2015-05-22 19:28:19.972954"
bool Converter::ParseJSONRequest(const std::string& jsonStr,
								       std::string& action,
								       std::string& message,
								       std::string& time) noexcept
{
    // use a thread local std::stringstream to avoid
    // multiple constructions
    thread_local std::stringstream ss;
    ss.str("");
    ss.clear();
    ss << jsonStr;

    boost::property_tree::ptree pt;
    try
    {
        // boost::property_tree::read_json has a bug and isn't
        // thread-safe in this boost version, so a lock is used here
        std::lock_guard<std::mutex> readJsonLock(m_ReadJsonMutex);
        boost::property_tree::read_json(ss, pt);
    }
    catch (std::exception& e)
    {
        return false;
    }

    action = pt.get<std::string>("action", std::string());
    time = pt.get<std::string>("time", std::string());
    std::string messageText;

    // if messages child not exist
    if (pt.count("message") == 0)
    {
        return true;
    }

    auto tags_pt = pt.get_child_optional("message.tags");
    if (!tags_pt)
    {
        return true;
    }

    // loop getting each tag & value
    for (auto const& child : pt.get_child("message.tags"))
    {
        for (auto const& entry : child.second)
        {
            std::string tag = entry.first;
            std::string value = entry.second.data();
            if (tag.empty())
            {
                std::cout << "Waning: empty tag ingored" << '\n';
                continue;
            }

            // construct the FIX message string
            messageText += tag + "="
              + Utils::hideSpecChars(value, "space|semicolon") + ";";
        }
    }

    // move the message as it is no longer being used
    message = std::move(messageText);

    return true;
}
}