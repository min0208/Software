#ifndef OMD_PROXY_CONVERTER
#define OMD_PROXY_CONVERTER

#include <mutex>

namespace OMDCCPROXY
{
class Converter
{
public:
    // parse  a json string
    static bool ParseJSONRequest(const std::string& jsonStr,
                                 std::string& action,
                                 std::string& message,
                                 std::string& time) noexcept;
private:
    // static mutex for read json
    static std::mutex m_ReadJsonMutex;
};
}

#endif
