#ifndef OMD_PROXY_MESSAGE
#define OMD_PROXY_MESSAGE

#include <iostream>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "Common.h"

namespace OMDCCPROXY
{
class Message 
{
public:
    Message(uint16_t msgSize);
    ~Message();

    uint16_t GetMsgSize();
    char*    GetMsgData();

private:
    uint16_t mMsgSize;
    char*    mMsgData; 
};
}
#endif