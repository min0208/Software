#ifndef OMD_PROXY_CLIENT
#define OMD_PROXY_CLIENT

#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/fcntl.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <poll.h>

#include <errno.h>
#include <unistd.h>

#include "Message.h"

namespace OMDCCPROXY
{
class Client {
public:

    static void* threadReadMessage(void *arg);

    Client(const char* address, int port);
    ~Client();

    void ConnectToServer(int timeout = 0);

    void StartReadingThred();

    void SendRequest();

public:

    bool Connected() {return m_bConnected;}

private:
    void ReadFromServer();
    void ProcessCTServerMsg(char* pPacketData);
    bool IsValidPacket(char* pPacketData, uint16_t packetSize);
    char* GetNextPacketMsg(char* pPacketData, uint16_t packetSize, char* pMsgData);
    void ProcessMsg(uint16_t channelID, uint64_t sendTime, uint16_t msgSize, uint16_t msgType, char* pMsgData);

    bool PreSendChecking(uint16_t infoType, const char* data);
    Message* CreateMsg(uint16_t msgSize);
    void SentToServer(CTSecuritySearchRequest reqData);
    bool SendMsg(char* pData);

private:
    bool                        m_bConnected;
    pthread_t                   m_ReadThreadId;

    int                         m_Socketfd;
    struct sockaddr_in          m_SocketAddr;

    CTSecuritySearchRequest     m_SecuritySearchReq;
    //-----------------------------------------------------------------
    // For OMDCC
    //-----------------------------------------------------------------
    char                        mOMDCC_MarketCode_CFFExID[31+1];
    char                        mOMDCC_SecurityCode_CFFExGpID[9+1];

};
}

#endif