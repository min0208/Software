#include <iostream>
#include <thread>
#include <memory>
#include <functional>
#include <boost/asio/io_service.hpp>
#include <boost/asio/ip/tcp.hpp>
#include <boost/asio/spawn.hpp>

#include "Session.h"
#include "Server.h"

using boost::asio::ip::tcp;

namespace OMDCCPROXY
{

Server::Server(const int port)
      : m_port(port)
{
    if (!Start())
    {
        throw "failed to handle client session";
    }
}

bool Server::Start() noexcept
{
    try
    {
        boost::asio::spawn(m_io_service, [&](boost::asio::yield_context yield)
        {
            tcp::acceptor acceptor(m_io_service, tcp::endpoint(tcp::v4(), m_port));

            for (;;)
            {
                boost::system::error_code ec;
                tcp::socket socket(m_io_service);
                acceptor.async_accept(socket, yield[ec]);
                if (!ec)
                {
                    std::shared_ptr<Session>(new Session(std::move(socket)))->Go();
                }
            }
          }
        );

        //runIOService(); 
    }
    catch (std::exception& e)
    {
        std::cout << "Error: failed to handle incoming tcp session\n";
        return false;
    }

    return true;
}

}
