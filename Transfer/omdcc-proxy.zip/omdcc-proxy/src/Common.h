#ifndef OMD_PROXY_COMMON
#define OMD_PROXY_COMMON

#define MAX_PACKET_SIZE               1472 // 1500 includes 28 bytes TCP header

namespace OMD_PROXY_MESSAGE
{
    enum XdpMessageTypes
    {
        UNDEFINED_TYPE = 0,

        SEQUENCE_RESET_TYPE = 100,

        LOGON_TYPE = 101,
        LOGON_RESPONSE_TYPE = 102,

        RETRANSMISSION_REQUEST_TYPE = 201,
        RETRANSMISSION_RESPONSE_TYPE = 202,

        REFRESH_COMPLETE_TYPE = 203,

        COMMODITY_DEFINITION_TYPE = 301,
        CLASS_DEFINITION_TYPE = 302,
        SERIES_DEFINITION_BASE_TYPE = 303,
        SERIES_DEFINITION_EXTENDED_TYPE = 304,
        COMBINATION_DEFINITION_TYPE = 305,
        MARKET_STATUS_TYPE = 320,
        SERIES_STATUS_TYPE = 321,
        COMMODITY_STATUS_TYPE = 322,
        ADD_ORDER_TYPE = 330,
        MODIFY_ORDER_TYPE = 331,
        DELETE_ORDER_TYPE = 332,
        TOP_OF_BOOK_TYPE = 355,
        AGGREGATE_ORDER_BOOK_UPDATE_TYPE = 353,
        ORDERBOOK_CLEAR_TYPE = 335,
        QUOTE_REQUEST_TYPE = 336,
        TRADE_TYPE = 350,
        TRADE_AMENDMENT_TYPE = 356,
        TRADE_STATISTICS_TYPE = 360,
        SERIES_STATISTICS_TYPE = 363,
        CALCULATED_OPENING_PRICE_TYPE = 364,
        ESTIMATED_AVERAGE_SETTLEMENT_PRICE_TYPE = 365,
        MARKET_ALERT_TYPE = 323,
        OPEN_INTEREST_TYPE = 366,
        IMPLIED_VOLATILITY_TYPE = 367,

        LINE_STATUS_TYPE = 405,
        ACTIVE_RETRANS_TYPE = 406,

        OMDCC_MARKET_DEFINITION_TYPE = 610,
        OMDCC_SECURITY_DEFINITION_TYPE = 611,
        OMDCC_SECURITY_STATUS_TYPE = 621,
        OMDCC_TOP_OF_BOOK_TYPE = 655,
        OMDCC_TOP_OF_BOOK_FUTURES_TYPE = 656,
        OMDCC_STATISTICS_TYPE = 660,
        OMDCC_STATISTICS_FUTURES_TYPE = 661,

        //SNAPSHOT_REQUEST_TYPE = 888,
        //SNAPSHOT_RESPOND_TYPE = 889,
        END_MSG_TYPE
    };

    // Information types [Client <-> Server]
    enum CTInfoType
    {
        CT_SERIES_SEARCH_REQUEST = 18,
        CT_SERIES_SEARCH_RESPOND,
        CT_SNAPSHOT_REQUEST,
        CT_SNAPSHOT_RESPOND,
        CT_RETRANSMISSION_REQUEST,
        CT_RETRANSMISSION_RESPOND,
        CT_NEWS_REQUEST,
        CT_NEWS_REQUEST_RESPOND,

        CT_OMDCC_SECURITY_SEARCH_REQUEST,
        CT_OMDCC_SECURITY_SEARCH_RESPOND,
        CT_OMDCC_FUTURES_SEARCH_REQUEST,
        CT_OMDCC_FUTURES_SEARCH_RESPOND,
        CT_OMDCC_SECURITY_SNAPSHOT_REQUEST,
        CT_OMDCC_SECURITY_SNAPSHOT_RESPOND,
        CT_OMDCC_FUTURES_SNAPSHOT_REQUEST,
        CT_OMDCC_FUTURES_SNAPSHOT_RESPOND,
    };

    // Respond code [Server -> Client]
    enum CTRespondCode
    {
        SUCCESS = 0,
        ERR_NOTFOUND,
        ERR_INVALID_CTTYPE,
        ERR_INVALID_REQUEST,
        //...
    };

    // prevents compiler padding (structs not aligned).
    #pragma pack(1) 

    // message definition
    struct PacketHeader 
    {
        uint16_t mPktSize;
        uint8_t  mMsgCount;
        char     mFiller[1];
        uint32_t mSeqNum;
        uint64_t mSendTime;
    };

    struct MsgHeader 
    {
        uint16_t mMsgSize;
        uint16_t mMsgType;
    };

    // Request header [Client -> Server]
    struct CTRequestHeader
    {
        uint16_t mSize;
        uint16_t mInfoType;       //Information type, refer to "enum CTInfoType"
        uint16_t mCTType;         //ClientTool Product Type, refer to "enum CTProductType"
    };

    // Respond header [Server -> Client]
    struct CTRespondHeader
    {
        uint16_t mSize;
        uint16_t mInfoType;      //Information type, refer to "enum CTInfoType"
        uint16_t mRespondCode;   //refer to "enum CTRespondCode"
    };

    struct RefreshComplete 
    {
        uint16_t mMsgSize;
        uint16_t mMsgType;
        uint32_t mLastSeqNum;
    };

    struct LineStatus 
    {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint16_t mChannelID;

    char mLineType; // R=real-time, F=refresh, T=retransmission

    // 0 = both lines are down
    // 1 = one of the lines is up
    // 2 = both lines are up

    // 10 = both lines have no data for real-time or refresh
    // 11 = one of the lines has data for real-time or refresh
    // 12 = both lines have data for real-time or refresh
    uint8_t mStatus;
  };

  //-----------------------------------------
  // For OMDCC
  //-----------------------------------------
  struct OMDCC_MarketDefinition
  {
    uint16_t    mMsgSize;
    uint16_t    mMsgType;
    char        mMarketCode[4];
    char        mMarketName[25];
    char        mCurrencyCode[3];
    uint32_t    mNumberOfSecurities;    
  };

  struct OMDCC_SecurityDefinition
  {
    uint16_t    mMsgSize;
    uint16_t    mMsgType;
    uint32_t    mSecurityCode;
    char        mMarketCode[4];
    char        mISINCode[12];
    char        mInstrumentType[4];
    char        mFiller1[2];
    //char        mSpreadTableCode[2];
    char        mSecurityShortName[40];
    char        mCurrencyCode[3];
    char        mSecurityNameGCCS[60];
    char        mSecurityNameGB[60];
    uint32_t    mLotSize;
    int32_t     mPreviousClosingPrice;
    char        mFiller2;
    char        mShortSellFlag;
    char        mFiller3[6];
    uint32_t    mListingDate;
    uint32_t    mDelistingDate;
    char        mFiller4[3];  
  };

  struct OMDCC_SecurityStatus
  {
    uint16_t    mMsgSize;
    uint16_t    mMsgType;
    uint32_t    mSecurityCode;
    uint8_t     mSecurityTradingStatus;
    char        mFiller[3];
    char        mCircuitBreakerTradingState[8];
  };

  struct OMDCC_TopOfBook
  {
    uint16_t    mMsgSize;
    uint16_t    mMsgType;
    uint32_t    mSecurityCode;
    uint64_t    mAggBidQty;
    uint64_t    mAggAskQty;
    int32_t     mBidPrice;
    int32_t     mAskPrice;
    char        mFiller[8];    
  };

  struct OMDCC_TopOfBook_Futures
  {
    uint16_t    mMsgSize;
    uint16_t    mMsgType;
    char        mCFFExID[31];
    uint64_t    mAggBidQty;
    uint64_t    mAggAskQty;
    int64_t     mLongBidPrice;
    int64_t     mLongAskPrice;
    uint16_t    mDecimalInPremium;
  };

  struct OMDCC_Statistics
  {
    uint16_t    mMsgSize;
    uint16_t    mMsgType;
    uint32_t    mSecurityCode;
    uint64_t    mSharesTraded;
    int64_t     mTurnover;
    int32_t     mHighPrice;
    int32_t     mLowPrice;
    int32_t     mLastPrice;
    int32_t     mOpeningPrice;
    char        mFiller[16];
  };

  struct OMDCC_Statistics_Futures
  {
    uint16_t    mMsgSize;
    uint16_t    mMsgType;
    char        mCFFExID[31];
    uint16_t    mDecimalInPremium;
    char        mTradingDay[9];
    char        mSettleGpID[9];
    int16_t     mSettleID;
    int64_t     mLastPrice;
    int64_t     mPreSettlePrice;
    int64_t     mPreClosePrice;
    int64_t     mPreOpenInterest;
    int64_t     mOpenPrice;
    int64_t     mHighestPrice;
    int64_t     mLowestPrice;
    int64_t     mVolume;
    int64_t     mTurnover;
    int64_t     mOpenInterest;
    int64_t     mClosePrice;
    int64_t     mSettlePrice;
    int64_t     mUpperLimitedPrice;
    int64_t     mLowerLimitedPrice;
    char        mUpdatedTime[9];
    int32_t     mUpdatedMillisec;
    char        mActionDay[9];
    char        mFiller[4];
  };


    //---------------------------------------------------------------------------------------------------------
    // For OMDCC
    //---------------------------------------------------------------------------------------------------------
    struct CTSecuritySearchRequest
    {
        uint16_t         mSize;
        uint16_t         mInfoType;          //Information type, refer to "enum CTInfoType"
        uint16_t         mCTType;        //ClientTool Product Type, refer to "enum CTProductType"
        char             mMarketCode[4];
        uint32_t         mSecurityCode;
    };

    struct CTFuturesSearchRequest
    {
        uint16_t         mSize;
        uint16_t         mInfoType;      //Information type, refer to "enum CTInfoType"
        uint16_t         mCTType;        //ClientTool Product Type, refer to "enum CTProductType"
        char             mCFFExID[31];
        char             mSettleGroupID[9];
        int16_t          mSettleID;
    };

    #pragma pack()

}


#endif