#ifndef OMD_PROXY_SESSION
#define OMD_PROXY_SESSION

#include <boost/asio/ip/tcp.hpp>
#include <boost/asio/spawn.hpp>
#include <boost/asio/steady_timer.hpp>
#include <boost/asio/read.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>

using boost::asio::ip::tcp;

namespace OMDCCPROXY
{
// This session class is used to handle a incoming connection
// from client side.
// server will spwan one session for each connection.
//
// As it inherits from std::enable_shared_from_this<T>,
// its instances are constructed from heap and has shared_from_this()
// to access itsself.
class Session : public std::enable_shared_from_this<Session>
{
public:
    explicit Session(tcp::socket socket)
      : m_socket(std::move(socket)),
        m_timer(m_socket.get_io_service()),
        m_strand(m_socket.get_io_service())
    {
    }

    // Session entrance
    void Go() noexcept;

private:
    // handler for incomming request
    void HandleRequest(boost::asio::yield_context&) noexcept;
    // handle sending request message
    bool HandleSendMessage(const std::string&) noexcept; 
    // handle response matching
    bool HandleMatchResponse(const std::string&,
                             const std::string&,
                             const bool&,
                             std::string&) noexcept;

    // handler for timeout
    void HandleTimeout(boost::asio::yield_context&) noexcept;

    // read request from socket
    std::string ReadRequest(boost::asio::yield_context&) noexcept;

    // write response to socket
    void WriteResponse(boost::asio::yield_context&, const std::string&) noexcept;

  	// process timed out
    void ProcessTimedout(const boost::system::error_code&) noexcept;

    inline void CancelTimer() noexcept
    {
        if (m_timer.expires_from_now() >= std::chrono::seconds(0))
        {
            m_timer.cancel();
        }
    }

    inline std::string GenerateSucceedResponse() const
    {
        return "{ \"status\": \"success\" }";
    }

    // generate sending request's JSON response
    inline std::string GenerateSendingResponse(const std::string& time) const
    {
        return "{ \"status\": \"received\", \"time\" : \"" + time + "\" }";
    }

    // generate failed response with error message
    inline std::string GenerateFailedResponse(const std::string& errorMsg) const
    {
        boost::property_tree::ptree pt;
        pt.put("status", "failed");
        pt.put("error_msg", errorMsg);

        thread_local std::ostringstream oss;
        oss.str("");
        oss.clear();
        boost::property_tree::write_json(oss, pt);
        return oss.str();
    }

private:
	tcp::socket                       m_socket;
    boost::asio::steady_timer         m_timer;
    boost::asio::io_service::strand   m_strand;
    bool                              m_isTimedout;

};
}

#endif