#ifndef OMD_PROXY_LOGGER
#define OMD_PROXY_LOGGER

class Logger
{
public:
    static Logger getInstance(std::string loggerName);

private:
    Logger();
    Logger(std::string logerName);
    ~Logger();
};


#endif