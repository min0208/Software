#ifndef OMD_PROXY_SERVER
#define OMD_PROXY_SERVER

#include <boost/asio/io_service.hpp>

namespace OMDCCPROXY
{
class Server {
public:
    Server(const int port);

    bool Start() noexcept;

private:
    int m_port;
    boost::asio::io_service m_io_service;
};
}

#endif