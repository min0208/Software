#ifndef ClientToolStructsH
#define ClientToolStructsH

#include "TypeDef.h"

#pragma pack(1) // prevents compiler padding (structs not aligned).

//***********************************************************
// Message protocal between ClientTool Server and Client
//***********************************************************

// Recognize correct connection between server and client [Client -> Server]
enum CTProductType
{
    PT_NONE = 0,
	PT_SECURITIES_STANDARD = 1,
	PT_SECURITIES_PREMIUM = 2,
	PT_SECURITIES_FULLTICK = 3,
	PT_DERIVATIVES_STANDARD = 4,
	PT_DERIVATIVES_PREMIUM = 5,
	PT_DERIVATIVES_FULLTICK = 11,
    PT_OMDCC = 88
};

// Information types [Client <-> Server]
enum CTInfoType
{
	CT_SERIES_SEARCH_REQUEST = 18,
	CT_SERIES_SEARCH_RESPOND,
	CT_SNAPSHOT_REQUEST,
	CT_SNAPSHOT_RESPOND,
	CT_RETRANSMISSION_REQUEST,
	CT_RETRANSMISSION_RESPOND,
    CT_NEWS_REQUEST,
    CT_NEWS_REQUEST_RESPOND,

    CT_OMDCC_SECURITY_SEARCH_REQUEST,
    CT_OMDCC_SECURITY_SEARCH_RESPOND,
    CT_OMDCC_FUTURES_SEARCH_REQUEST,
    CT_OMDCC_FUTURES_SEARCH_RESPOND,
    CT_OMDCC_SECURITY_SNAPSHOT_REQUEST,
    CT_OMDCC_SECURITY_SNAPSHOT_RESPOND,
    CT_OMDCC_FUTURES_SNAPSHOT_REQUEST,
    CT_OMDCC_FUTURES_SNAPSHOT_RESPOND,
};

// Respond code [Server -> Client]
enum CTRespondCode
{
	SUCCESS = 0,
	ERR_NOTFOUND,
	ERR_INVALID_CTTYPE,
	ERR_INVALID_REQUEST,
	//...
};

// Request header [Client -> Server]
struct CTRequestHeader
{
        uint16_t                 mSize;
        uint16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
	uint16_t			mCTType;			//ClientTool Product Type, refer to "enum CTProductType"
};

// Series search criteria [Client -> Server]
struct CTSeriesSearchRequest
{
	//CTRequestHeader	mHeader;
        uint16_t                 mSize;
        uint16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        uint16_t                        mCTType;                        //ClientTool Product Type, refer to "enum CTProductType"

	uint16_t			mCommodityCode;
	uint8_t			mMarketCode;
	uint8_t			mInstrumentGroup;
	uint32_t			mOrderBookID;
	char			mSymbol[32];
};

// Snapshot criteria [Client -> Server]
struct CTSnapShotRequest
{
	//CTRequestHeader	mHeader;
        uint16_t                 mSize;
        uint16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        uint16_t                        mCTType;                        //ClientTool Product Type, refer to "enum CTProductType"

	uint32_t			mOrderBookID;
	uint32_t			mTradeCount;
	uint32_t			mTradeOffset;
	uint32_t			mCommodityKey;
	uint32_t			mClassKey;
	w_u64_t			mStatisticsKey;
	w_u64_t			mOpenInterestKey;
	char			mInstrumentCode[20];
};

// Retransmission criteria [Client -> Server]
struct CTRetransRequest
{
//	CTRequestHeader	mHeader;
        uint16_t                 mSize;
        uint16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        uint16_t                        mCTType;                        //ClientTool Product Type, refer to "enum CTProductType"
	
	uint16_t 		mChannelId;
	uint32_t	 		mBeginSeqNum;
	uint32_t 		mEndSeqNum;
};

struct CTNewsRequest
{
        uint16_t                 mSize;
        uint16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
	uint16_t		 mCTType;			//ClientTool Product Type, refer to "enum CTProductType"
};

// Respond header [Server -> Client]
struct CTRespondHeader
{
        uint16_t                 mSize;
        uint16_t                 mInfoType;      //Information type, refer to "enum CTInfoType"
	uint16_t			mRespondCode;	//refer to "enum CTRespondCode"
};

// Series search respond [Server -> Client]
struct CTSeriesSearchRespond
{
//	CTRespondHeader	mHeader;
        uint16_t                 mSize;
        uint16_t                 mInfoType;      //Information type, refer to "enum CTInfoType"
        uint16_t                        mRespondCode;   //refer to "enum CTRespondCode"	
};

// Snapshot respond [Server -> Client]
struct CTSnapShotRespond
{
//	CTRespondHeader	mHeader;
        uint16_t                 mSize;
        uint16_t                 mInfoType;      //Information type, refer to "enum CTInfoType"
        uint16_t                        mRespondCode;   //refer to "enum CTRespondCode"

};

// Retransmission respond [Server -> Client]
struct CTRetransRespond
{
//	CTRespondHeader	mHeader;
        uint16_t                 mSize;
        uint16_t                 mInfoType;      //Information type, refer to "enum CTInfoType"
        uint16_t                        mRespondCode;   //refer to "enum CTRespondCode"

	uint16_t 		mChannelId;
	uint32_t	 		mBeginSeqNum;
	uint32_t 		mEndSeqNum;
	// + list of messages
};

//---------------------------------------------------------------------------------------------------------
// For OMDCC
//---------------------------------------------------------------------------------------------------------
struct CTSecuritySearchRequest
{
    w_u16_t         mSize;
    w_u16_t         mInfoType;          //Information type, refer to "enum CTInfoType"
    w_u16_t         mCTType;        //ClientTool Product Type, refer to "enum CTProductType"
    char            mMarketCode[4];
    w_u32_t         mSecurityCode;
};
//---------------------------------------------------------------------------------------------------------
struct CTSecuritySearchRespond
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mRespondCode;       //refer to "enum CTRespondCode"
};
//---------------------------------------------------------------------------------------------------------
struct CTSecuritySnapShotRequest
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;              //Information type, refer to "enum CTInfoType"
        w_u16_t                 mCTType;                //ClientTool Product Type, refer to "enum CTProductType"
        w_u32_t                 mSecurityCode;
};
//---------------------------------------------------------------------------------------------------------
struct CTSecuritySnapShotRespond
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mRespondCode;       //refer to "enum CTRespondCode"
};
//---------------------------------------------------------------------------------------------------------
struct CTFuturesSearchRequest
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;      //Information type, refer to "enum CTInfoType"
    w_u16_t         mCTType;        //ClientTool Product Type, refer to "enum CTProductType"
    char            mCFFExID[31];
    char            mSettleGroupID[9];
    w_i16_t         mSettleID;
};
//---------------------------------------------------------------------------------------------------------
struct CTFuturesSearchRespond
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mRespondCode;       //refer to "enum CTRespondCode"
};
//---------------------------------------------------------------------------------------------------------
struct CTFuturesSnapShotRequest
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;              //Information type, refer to "enum CTInfoType"
        w_u16_t                 mCTType;                //ClientTool Product Type, refer to "enum CTProductType"
    char            mCFFExID[31];
};
//---------------------------------------------------------------------------------------------------------
struct CTFuturesSnapShotRespond
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mRespondCode;       //refer to "enum CTRespondCode"
};
//---------------------------------------------------------------------------------------------------------

#pragma pack()

#endif //ClientToolStructsH

