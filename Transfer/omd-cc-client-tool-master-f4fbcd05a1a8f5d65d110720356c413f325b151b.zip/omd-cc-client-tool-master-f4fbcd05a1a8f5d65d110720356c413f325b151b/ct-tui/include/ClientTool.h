#ifndef ClientToolH
#define ClientToolH 1

#include <iostream>
#include <sstream>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "Common.h"
#include "CommonOutput.h"
#include "Global.h"
#include "Logger.h"
#include "Message.h"
#include "NcursesWrapper.h"
#include "XdpStructs.h"

#pragma pack(1)

#ifdef LOG4CPLUS
using namespace log4cplus;
#endif

using namespace std;

class ClientTool : public CommonOutput {

	public:

		enum FieldType {
			//301 - Commodity Definition
			UNDERLYING_PRICE_UNIT,	
			UNDERLYING_TYPE,
			EFFECTIVE_TOMORROW,
			//302 - Class Definition
			RANKING_TYPE,
			TRADABLE,
			PREMIUM_UNIT_4_PRICE,
			IS_FRACTIONS,
			//EFFECTIVE_TOMORROW,	
			//303 - Series Definition Base
			//304 - 
		};

		enum ClientTool::FieldType FieldType;

		ClientTool(int argc, char** argv, Logger& logger, Logger& userLogger);
		virtual ~ClientTool();

		virtual void output(int row, int col, const char* pStr, bool lock=true);
		virtual void output(const char* pStr, bool lock=true);
		virtual void output(int row, int col, ostringstream& oss, bool lock=true);
		virtual void output(ostringstream& oss, bool lock=true);
		virtual void processNcurses(pthread_cond_t& cond);
		virtual void refreshNcursesWindows();

		int getProductIndex() { return mProductIndex; }

		virtual void processMsg
			(uint16_t channelID, uint64_t sendTime, uint16_t msgSize, uint16_t msgType
			 , char* pMsgData);

		ostringstream* getostringstream() { return mpostringstream; }

		void startEventLoop();

		pthread_cond_t mCond;

		string TrimLeadingSpace(char *src, int iLen);
		string TrimTrailingSpace(char *src, int iLen);
		string FieldTranslation(uint16_t msgType, enum ClientTool::FieldType field, uint8_t value);

	protected:

		ostringstream* mpostringstream;

		Logger& getLogger() {
			return mLogger;
		}

		Logger& getUserLogger() { 
			return mUserLogger;
		}

	protected:
		Logger& mLogger;
		Logger& mUserLogger;
		NcursesWrapper* mpNcursesWrapper;

	private:
		static void* startDispatch(void* arg);

		static void refresh_ncurses_windows_cb(union sigval sigev_value);
		static void sigHandler(int);
		static void* threadProcessNcurses(void *arg);

		int mProductIndex;

		struct timespec mTimespecRefreshNcursesWindows;
		Timer* mpTimerRefreshNcursesWindows;

		int mSockfd[MAX_CHANNEL_ID+1];

		char mReadBufferClient[MAX_CHANNEL_ID+1][MAX_PACKET_SIZE];
		int  mReadBufferClientOffset[MAX_CHANNEL_ID+1];

		struct ThreadFeedHandlerArg {
			uint16_t channelID;
		};
};

#pragma pack()

extern ClientTool* gpClientTool;

#endif
