#ifndef TimerH
#define TimerH 1

#include <signal.h>

#include "Common.h"

#pragma pack(1)

class Timer {
  
 public:
  Timer
    (Logger& logger, void (*pFunc)(union sigval), void* pArg
     , struct timespec* it_value, struct timespec* it_interval);
  ~Timer();

  struct Arg {
    Timer* pTimer;
    void* pArg;
  };

  void* getArg() { return mArg.pArg; }

  void setArg(void* pArg) { mArg.pArg = pArg; }

 private:
  Logger& mLogger;
  timer_t mCreated_timer_id;
  Arg mArg;

  bool mTimerCreated;
};

#pragma pack()

#endif
