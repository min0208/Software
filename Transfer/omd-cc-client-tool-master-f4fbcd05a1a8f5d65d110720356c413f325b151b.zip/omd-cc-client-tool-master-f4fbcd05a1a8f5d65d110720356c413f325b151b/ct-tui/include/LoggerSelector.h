#ifndef LoggerSelectorH
#define LoggerSelectorH 1

#include <fstream>
#include <syslog.h>

/*
  LOG_EMERG      system is unusable
  LOG_ALERT      action must be taken immediately
  LOG_CRIT       critical conditions
  LOG_ERR        error conditions
  LOG_WARNING    warning conditions
  LOG_NOTICE     normal, but significant, condition
  LOG_INFO       informational message
  LOG_DEBUG      debug-level message
*/

using namespace std;

#ifdef LOG4CPLUS

// log4cplus
#include <log4cplus/logger.h>
#include <log4cplus/loggingmacros.h>
#include <log4cplus/configurator.h>
#include <log4cplus/hierarchy.h>

using namespace log4cplus;

// log4cplus-1.1.0/include/log4cplus/loggingmacros.h
// log4cplus-1.1.0/src/syslogappender.cxx
#define LOG4_EMERG(logger, logEvent)   LOG4CPLUS_FATAL(logger, logEvent)
#define LOG4_ALERT(logger, logEvent)   LOG4CPLUS_FATAL(logger, logEvent)
#define LOG4_CRIT(logger, logEvent)    LOG4CPLUS_FATAL(logger, logEvent)
#define LOG4_ERR(logger, logEvent)     LOG4CPLUS_ERROR(logger, logEvent)
#define LOG4_WARNING(logger, logEvent) LOG4CPLUS_WARN(logger, logEvent)
#define LOG4_NOTICE(logger, logEvent)  LOG4CPLUS_INFO(logger, logEvent)
#define LOG4_INFO(logger, logEvent)    LOG4CPLUS_INFO(logger, logEvent)
#define LOG4_DEBUG(logger, logEvent)   LOG4CPLUS_DEBUG(logger, logEvent)

#else

#include "Logger.h"
#define LOG4_MACRO_BODY(logger, logEvent, logLevel)	\
  logger.lock();					\
  *logger.getOfstream() << logger.getPrefix(logLevel)	\
  << logEvent << endl;					\
  logger.unlock();

 #define LOG4_EMERG(logger, logEvent) \
   LOG4_MACRO_BODY(logger, logEvent, LOG_EMERG)
 #define LOG4_ALERT(logger, logEvent) \
   LOG4_MACRO_BODY(logger, logEvent, LOG_ALERT)
 #define LOG4_CRIT(logger, logEvent) \
   LOG4_MACRO_BODY(logger, logEvent, LOG_CRIT)
 #define LOG4_ERR(logger, logEvent) \
   LOG4_MACRO_BODY(logger, logEvent, LOG_ERR)
 #define LOG4_WARNING(logger, logEvent) \
   LOG4_MACRO_BODY(logger, logEvent, LOG_WARNING)
 #define LOG4_NOTICE(logger, logEvent) \
   LOG4_MACRO_BODY(logger, logEvent, LOG_NOTICE)
 #define LOG4_INFO(logger, logEvent) \
   LOG4_MACRO_BODY(logger, logEvent, LOG_INFO)
 #define LOG4_DEBUG(logger, logEvent) \
    LOG4_MACRO_BODY(logger, logEvent, LOG_DEBUG)
   
//#define LOG4_EMERG(logger, logEvent) 
//#define LOG4_ALERT(logger, logEvent) 
//#define LOG4_CRIT(logger, logEvent) 
//#define LOG4_ERR(logger, logEvent) 
//#define LOG4_WARNING(logger, logEvent) 
//#define LOG4_NOTICE(logger, logEvent) 
//#define LOG4_INFO(logger, logEvent) 
//#define LOG4_DEBUG(logger, logEvent)

#define LOG4_USER(logger, logEvent) \
  LOG4_MACRO_BODY(logger, logEvent, LOG_USER)   
  //#define LOG4_USER(logger, logEvent)
#define LOG4_NODATETIMESTAMP(logger, logEvent) \
  LOG4_MACRO_BODY(logger, logEvent, LOG_AUTH)

#endif

#pragma pack(1)

class LoggerSelector {
  
 public:
  LoggerSelector();
  ~LoggerSelector();

  static void createPropertiesFile();
  static void configure();
  static void resetConfigure(Logger& logger);
};

#pragma pack()

#endif
