#ifndef ClientToolScreenH
#define ClientToolScreenH 1

#include "Logger.h"
#include "MultiIndexContainer.h"
#include "NcursesWrapper.h"

using namespace std;

#define MAX_HEADER_ROWS 6
#define MAX_MENU_ROWS 1
#define MAX_FORM_ROWS 46
#define MAX_STATUS_ROWS 4
#define MAX_FORM_COLS 130//164//170//178
#define MAX_SCREEN_ROWS MAX_HEADER_ROWS + MAX_MENU_ROWS + MAX_FORM_ROWS + MAX_STATUS_ROWS
#define MAX_SCREEN_COLS MAX_FORM_COLS

#include <iconv.h>
#include <iomanip>
#include <math.h>
#include <string.h>

#include "Common.h"
#include "Global.h"
#include "NcursesWrapper.h"

class ClientToolScreen
{
	public:
		enum FieldValueDesc {
			FIELD_VALUE_ONLY,
			FIELD_DESC_ONLY,
			FIELD_VALUE_DESC
		};

		ClientToolScreen(Logger& logger);
		virtual ~ClientToolScreen();

		wchar_t ch[MAX_SCREEN_ROWS][MAX_SCREEN_COLS];

	protected:

		virtual void createForms();
		virtual void printFieldLabels();
		virtual void clearScr(uint16_t msgType, uint16_t side = Common::BID_SIDE);
		virtual void updateScr(uint16_t msgSize, uint16_t msgType, char* pMsgData
				, Common::Source source);

		int64_t pow10(int exp);

		string getCharMapStr(Global::FieldValueMapChar fieldValueMap
				, char fieldValue, string strNotFound = "?");
		string getUint8MapStr(Global::FieldValueMapUint8 fieldValueMap
				, uint8_t fieldValue, string strNotFound = "?");
		string getUint16MapStr(Global::FieldValueMapUint16 fieldValueMap
				, uint16_t fieldValue, string strNotFound = "?");

		void newField
			(FIELD** ppField, int fieldIndex, int height, int width, int toprow
			 , int leftcol, int offscreen, int nbuffers
			 , string value = "", int justification = NO_JUSTIFICATION
			 , Field_Options optsOn = 0, Field_Options optsOff = O_ACTIVE
			 , chtype attr = 0);
		void newFieldWithLabel
			(FIELD** ppField, const char* label, int fieldIndexLabel, int fieldIndexEdit
			 , int row, int startCol, int totalFieldLen);
		void setFieldBack(int fieldIndex, chtype attr);
		void setFieldBuffer(int fieldIndex, string value);
		void setFieldBuffer(int fieldIndex, uint64_t value);
		// //By Louis 27-06-2013
		// void setFieldBuffer(int fieldIndex, int32_t value, int decimalPlaces);
		void setFieldBuffer(int fieldIndex, uint64_t value, int decimalPlaces);
		void setFieldBuffer
			(int fieldIndex, Global::FieldValueMapChar fieldValueMap, char value
			 , enum FieldValueDesc enumFieldValueDesc = FIELD_VALUE_DESC);
		void setFieldBuffer
			(int fieldIndex, Global::FieldValueMapUint8 fieldValueField, uint8_t value
			 , enum FieldValueDesc enumFieldValueDesc = FIELD_VALUE_DESC);
		void setFieldBuffer
			(int fieldIndex, Global::FieldValueMapUint16 fieldValueField, uint16_t value
			 , enum FieldValueDesc enumFieldValueDesc = FIELD_VALUE_DESC);

		WINDOW* mpFormSub[2];
		enum Common::Screen mScreen;

	protected:
		Logger& mLogger;
		NcursesWrapper* mpNcursesWrapper;
};

#endif
