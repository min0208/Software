#ifndef CommonOutputH
#define CommonOutputH 1

#include <iostream>
#include <sstream>
#include <pthread.h>

#include "Common.h"

#ifdef LOG4CPLUS
using namespace log4cplus;
#endif
using namespace std;

#pragma pack(1)

class CommonOutput {

 public:

  CommonOutput();
  virtual ~CommonOutput();

  virtual void output
    (Logger& logger, int row, int col, const char* pStr, bool lock=true);
  virtual void output
    (Logger& logger, const char* pStr, bool lock=true);
  virtual void output
    (Logger& logger, int row, int col, ostringstream& oss, bool lock=true);
  virtual void output
    (Logger& logger, ostringstream& oss, bool lock=true);

 protected:

  pthread_mutex_t mMutexOutput;

};

#pragma pack()

#endif
