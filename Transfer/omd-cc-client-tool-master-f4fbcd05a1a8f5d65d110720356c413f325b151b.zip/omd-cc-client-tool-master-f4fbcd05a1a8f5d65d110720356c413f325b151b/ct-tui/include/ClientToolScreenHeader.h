#ifndef ClientToolScreenHeaderH
#define ClientToolScreenHeaderH 1

#include <sstream>
#include <stdint.h>
#include <wchar.h>

#include "Common.h"
#include "ClientToolScreen.h"
#include "Logger.h"
#include "XdpStructs.h"

using namespace std;

class ClientToolScreenHeader : public ClientToolScreen {
 public:

  enum FieldName {
    BEGIN_FIELD,

    CLIENT_TOOL_LABEL = BEGIN_FIELD,
    FILTER_CRITERIA_LABEL,
/*    
    COMMODITY_CODE_LABEL,
    COMMODITY_CODE_ENTRY,
    ORDER_BOOK_ID_LABEL,
    ORDER_BOOK_ID_ENTRY,
    MARKET_LABEL,
    MARKET_ENTRY,
    SYMBOL_LABEL,
    SYMBOL_ENTRY,
    INSTRUMENT_GROUP_LABEL,
    INSTRUMENT_GROUP_ENTRY,
    SEARCH_OPEN_LABEL,
    SEARCH_LABEL,
    SEARCH_CLOSE_LABEL,
*/
    OMDCC_MKTCODE_CFFEXID_LABEL,
    OMDCC_MKTCODE_CFFEXID_ENTRY,
    OMDCC_SECCODE_FFXGPID_LABEL,
    OMDCC_SECCODE_FFXGPID_ENTRY,
    NOTICE_ENTRY,
    END_FIELD,
    INVALID_FIELD,
//just for dummy
    COMMODITY_CODE_LABEL,
    COMMODITY_CODE_ENTRY,
    ORDER_BOOK_ID_LABEL,
    ORDER_BOOK_ID_ENTRY,
    MARKET_LABEL,
    MARKET_ENTRY,
    SYMBOL_LABEL,
    SYMBOL_ENTRY,
    INSTRUMENT_GROUP_LABEL,
    INSTRUMENT_GROUP_ENTRY,
    SEARCH_OPEN_LABEL,
    SEARCH_LABEL,
    SEARCH_CLOSE_LABEL,
  };

  ClientToolScreenHeader(Logger& logger);
  ~ClientToolScreenHeader();

  void createForms();
  void printFieldLabels();
  void updateScrAllMsgs();
  void clearScr(uint16_t msgType, uint16_t side);
  void updateScr(uint16_t msgSize, uint16_t msgType, char* pMsgData
		  , Common::Source source);
  void refresh();

  bool getOrderBookIDMatch(uint32_t orderBookID);
  bool getNextCommodityCodeMatch(uint16_t commodityCode, string& symbol);
  bool getNextOrderBookIDMatch(uint32_t orderBookID, string& symbol);
  bool getNextMarketMatch(uint8_t market, string& symbol);
  bool getNextSymbolMatch(string inputSymbol, string& symbol);
  bool getNextInstrumentGroupMatch(uint8_t instrumentGroup, string& symbol);

  MultiIndexContainer::SeriesDefinitionBase_OrderBookID_Symbol::iterator mSeriesDefinitionBase_OrderBookID_Symbol_iterator;
  MultiIndexContainer::SeriesDefinitionExtended_Symbol::iterator mSeriesDefinitionExtended_Symbol_iterator;

  MultiIndexContainer::SeriesDefinitionExtended_CommodityCode_Symbol::iterator mSeriesDefinitionExtended_CommodityCode_Symbol_iterator;
  MultiIndexContainer::SeriesDefinitionExtended_Market_Symbol::iterator mSeriesDefinitionExtended_Market_Symbol_iterator;
  MultiIndexContainer::SeriesDefinitionExtended_InstrumentGroup_Symbol::iterator mSeriesDefinitionExtended_InstrumentGroup_Symbol_iterator;

  //For OMDCC
  MultiIndexContainer::OMDCC_SecurityDefinition_SecurityCode::iterator mOMDCC_SecurityDefinition_SecurityCode_iterator;
  MultiIndexContainer::OMDCC_SecurityDefinition_MarketCode::iterator mOMDCC_SecurityDefinition_MarketCode_iterator;  

  MultiIndexContainer::OMDCC_MarketDefinition_MarketCode::iterator mOMDCC_MarketDefinition_MarketCode_iterator;

  void setNotice(string msg);
};

#endif

