#ifndef ClientToolScreenQuitH
#define ClientToolScreenQuitH 1

#include <stdint.h>
#include <wchar.h>

#include "Common.h"
#include "ClientToolScreen.h"
#include "XdpStructs.h"

using namespace std;

class ClientToolScreenQuit : public ClientToolScreen {
 public:

  enum FieldName {
    BEGIN_FIELD,

    TITLE_LABEL = BEGIN_FIELD,
    CONFIRM_LABEL,// = BEGIN_FIELD,
    CONFIRM_ENTRY,

    END_FIELD,
    INVALID_FIELD
  };

  ClientToolScreenQuit(Logger& logger);
  ~ClientToolScreenQuit();

  void createForms();
  void printFieldLabels();
  void clearScr(uint16_t msgType, uint16_t side);
  void updateScr(uint16_t msgSize, uint16_t msgType, char* pMsgData
		  , Common::Source source);
  void refresh();
  void processChar(int ch);
};

#endif

