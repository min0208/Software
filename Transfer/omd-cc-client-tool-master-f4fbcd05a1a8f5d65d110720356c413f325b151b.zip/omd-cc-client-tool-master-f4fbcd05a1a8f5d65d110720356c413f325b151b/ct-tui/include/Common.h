#ifndef CommonH
#define CommonH 1

#ifdef __CYGWIN__
#define _XOPEN_SOURCE_EXTENDED
#endif

#include <locale.h>
#ifdef __CYGWIN__
#include <ncursesw/curses.h> /* curses.h includes stdio.h */
#include <ncursesw/form.h>
#include <ncursesw/menu.h>
#else
#include <curses.h>
#include <form.h>
#include <menu.h>
#endif

#include <time.h>
#include <sys/time.h>
#include <sys/types.h>

#include <cstdlib>
#include <errno.h>
#include <iconv.h>
#include <iomanip>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "LoggerSelector.h"
#include "ErrorHandler.h"

#define REALTIME_LINES   2
#define REFRESH_LINES    2

#define RETRANS_SITES    1
#define RETRANS_SERVERS  1

// Product Index
#define PRODUCT_INDEX "pi"

// Channel ID
#define CHANNEL_ID "cid"

// Config File
#define CONFIG_FILE "config"

#define REALTIME_CHAR      'R'
#define REFRESH_CHAR       'F'
#define RETRANS_CHAR       'T'
#define RETRANS_PROXY_CHAR 'P'

#define MAX_CHANNELS                  500//235
#define MAX_FORM_FIELDS               500
#define MAX_PACKET_SIZE               1472 // 1500 includes 28 bytes TCP header

#define MAX_SERIES_DEFINITION_ROWS      15
#define MAX_COMBINATION_DEFINITION_ROWS 15
#define MAX_SIDES                       2
#define MAX_FB_ROWS                     11
#define MAX_AOB_ROWS                    11
#define MAX_TRADE_ROWS                  11
#define MAX_MARKET_ALERT_HEADER_ROWS    12
#define MARKET_ALERT_HEADER_LEN         320
#define MAX_MARKET_ALERT_CONTENT_LINES  3
#define MARKET_ALERT_CONTENT_LEN        320//160

// OMDCC
#define SECURITY_LIST_HEADER_ROW	24
#define MAX_SECURITY_LIST_ROWS		15


#define MAX_CHANNEL_ID                100//999
#define MAX_PRODUCT_REALTIME_CHANNELS         40//74
#define MAX_PRODUCT_REFRESH_CHANNELS          40//70

#define INDEX_NULL                    0x8000000000000000

#define OMD_TAG "OMD"
#define DEFAULT_SECURITY_CODE_TAG "DefaultSecurityCode"
#define REFRESH_SCREEN_TAG "RefreshScreen"
#define SEQ_RESET_THRESHOLD_TAG "SeqResetThreshold"
#define HEARTBEAT_TAG "Heartbeat"
#define MULTICAST_TAG "Multicast"
#define INTERVAL_TAG "Interval"
#define FAILOVER_THRESHOLD_TAG "FailoverThreshold"
#define CHANNELS_TAG "Channels"
#define CHANNEL_TAG "Channel"
#define SERVER_TAG "Server"
#define REAL_TAG "RealTime"
#define REF_TAG "Refresh"
#define RET_TAG "Retransmission"
#define ATO_TAG "ArbitrationTimeout"
#define MPTO_TAG "MissingPacketTimeout"
#define LINE_TAG "Line"
#define INTERFACE_TAG "Interface"
#define MCADDR_TAG "MulticastAddress"
#define PORT_TAG "Port"
#define LINE_HANDLER_TAG "LineHandler"
#define THRESHOLD_TAG "Threshold"
#define RECONNECT_INTERVAL_TAG "ReconnectInterval"
#define RECONNECT_TIMES_TAG "ReconnectTimes"
#define RESPONSE_TIMEOUT_TAG "ResponseTimeout"
#define MAXIMUM_REQUESTS_TAG "MaximumRequests"
#define MAXIMUM_MESSAGES_TAG "MaximumMessages"
#define USERNAME_TAG "UserName"
#define ADDR_TAG "Address"
#define LOG_TAG "Log"
#define SEVERITY_CEILING_TAG "SeverityCeiling"
#define FILE_TAG "File"
#define CONSOLE_TAG "Console"
#define SYSLOG_TAG "Syslog"
#define BINARY_TAG "Binary"
#define PATH_TAG "Path"
#define DECODED_TAG "Decoded"
#define ENABLE_TAG "Enable"
#define VALIDATE_TAG "Validate"
#define NAME_TAG "Name"
#define HHMM_TAG "HHMM"
#define MISSING_TAG "Missing"
#define RAW_TAG "Raw"
#define PRIMARY_SITE_TAG "PrimarySite"
#define DR_SITE_TAG "DRSite"
#define PROXY_TAG "Proxy"
#define PRODUCTS_TAG "Products"
#define PRODUCT_TAG "Product"
#define INDEX_TAG "Index"
#define MESSAGE_QUEUE_TAG "MessageQueue"
#define KEY_TAG "Key"
#define CHANNEL_ID_TAG "ChannelID"
#define CHANNEL_NAME_TAG "ChannelName"
#define CURRENCY_TAG "Currency"
#define CODE_TAG "Code"
#define SNAPSHOT_INTERVAL_TAG "SnapShotInterval"
//By Louis 2013-06-13
//#define PROGRAM_VERSION "1.0-8" // Code Review for better program resource allocation. OMD-CC UI will be open to all HKEX internal business users
#define PROGRAM_VERSION "1.0-9" // Resolve "Previous Closing Price" not updated if UI keep running overnight(s).

#define TRANSLATE_TO_NULL "NULL"
#define MARKET_STATUS_MAX	5000

#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))

#define MEMCMP(source, target)                  \
  memcmp(source, target, sizeof(source))
#define MEMCPY(dest, src)			\
  memcpy(dest, src, sizeof(dest))

#ifdef LOG4CPLUS
using namespace log4cplus;
#endif

using namespace std;

#pragma pack(1)

class Common {

 public:

  enum Component {
    SERVER_COMPONENT,
    RETRANS_PROXY_COMPONENT,
    RETRANS_TEST_COMPONENT,
    FEED_HANDLER_COMPONENT,
    SIP_RECEIVER_COMPONENT,
    CLIENT_TOOL_COMPONENT
  };

  enum Mode {
    DISCONNECTED_MODE,
    REALTIME_MODE,
    REFRESH_MODE
  };

  enum RetransStatus {
    REQUEST_ACCEPTED = 0,
    UNKNOWN_OR_UNAUTHROIZED_CHANNEL_ID = 1,
    MESSAGES_NOT_AVAILABLE = 2,
    EXCEEDS_MAXIMUM_SEQUENCE_RANGE = 100,
    EXCEEDS_MAXIMUM_REQUESTS_IN_A_DAY = 101
  };

  enum SessionStatus {
    UNKNOWN_SESSION_STATUS = -1,
    SESSION_ACTIVE = 0,
    INVALID_USERNAME = 5,
    USER_ALREADY_CONNECTED = 100
  };

  enum Source {
    REFRESH_SOURCE,
    REALTIME_SOURCE,
    CACHE_SOURCE
  };

  enum OrderSide {
    BID_SIDE,
    OFFER_SIDE
  };

  enum ColorPair {
    RED_BLACK_COLOR_PAIR = 1,
    GREEN_BLACK_COLOR_PAIR,
    CYAN_BLACK_COLOR_PAIR,
    YELLOW_BLACK_COLOR_PAIR,
    WHITE_BLACK_COLOR_PAIR,
    WHITE_MAGENTA_COLOR_PAIR,
    BLACK_WHITE_COLOR_PAIR,
    MAGENTA_BLACK_COLOR_PAIR,
    BLUE_BLACK_COLOR_PAIR,
    WHITE_BLUE_COLOR_PAIR,
    BLACK_BLUE_COLOR_PAIR,
    BLACK_MAGENTA_COLOR_PAIR,
    BLACK_YELLOW_COLOR_PAIR,
    BLACK_GREEN_COLOR_PAIR,
    WHITE_GREEN_COLOR_PAIR
  };

  enum Screen {
    BEGIN_SCREEN,
    HEADER_SCREEN = BEGIN_SCREEN,
    FOOTER_SCREEN,
    //DEFINITION_SCREEN,
    //ORDER_AND_TRADE_SCREEN,
    SSESZSE_SCREEN,    
    //CFFEX_SCREEN,
    //NEWS_SCREEN,
    //REFRESH_SCREEN,
    //RETRANSMISSION_SCREEN, //20150914
    //SETTING_SCREEN,
    QUIT_SCREEN,
    END_SCREEN,
    REFRESH_SCREEN,
    SETTING_SCREEN,
    //RETRANSMISSION_SCREEN, //20150914
    CFFEX_SCREEN
  };

  enum StateLevel {
    STATE_LEVEL_MARKET = 1,
    STATE_LEVEL_INSTRUMENT_TYPE = 2,
    STATE_LEVEL_INSTRUMENT_CLASS = 3,
    STATE_LEVEL_INSTRUMENT_SERIES = 4,
    STATE_LEVEL_UNDERLYING = 5,
    STATE_LEVEL_END_OF_BUSINESS_DAY = 99
  };

  enum ScreenSession {
       SSESZSE_SECURITY_LIST_SESSION,
       SSESZSE_MARKET_DEFINITION_SESSION,
       SSESZSE_SECURITY_DEFINITION_SESSION,
       SSESZSE_STATUS_TOB_STATISTICS_SESSION,
  };

  Common();
  ~Common();

  struct less_str
  {
    bool operator() (char* a, char* b)
    {
      return strcmp(a, b) < 0;
    }
  };

  static uint64_t getUint64Time(Logger& logger);

  // YYYYMMDDHHMMSSdddmmmnnn

  // YY...SS
  static string getUint64TimeYYSS(uint64_t uint64Time);

  // YY...SS.12
  static string getUint64TimeYYSS2(uint64_t uint64Time);

  // YY...SS.123
  static string getUint64TimeYYSS3(uint64_t uint64Time);

  // YY...SS.123456789
  static string getUint64TimeYYSS9(uint64_t uint64Time);

  static string getUint64TimeDDMMYYYYSS(uint64_t uint64Time);

  // HHMM
  static string getUint64TimeHHMM(uint64_t uint64Time);

  // HHMM
  static string getUint64TimeBinDecHHMM(uint64_t uint64Time);

  // YY...DD
  static string getUint32DateYYMMDD(uint32_t uint32Date);

  // YYYY...DD
  static string getUint32DateYYYYMMDD(uint32_t uint32Date);

  // DD...YYYY
  static string getUint32DateDDMMYYYY(uint32_t uint32Date);

  static void exit(int status);

  static short getColorFromLineStatus(uint16_t status);

  static void lock(Logger& logger, pthread_mutex_t* pMutex);

  static void unlock(Logger& logger, pthread_mutex_t* pMutex);

  static uint64_t getOffset
    (uint64_t uint64time, int hour, int minute, int second);

  static char* UTF16LE_to_BIG5
    (char** inbuf, size_t& inbytesleft);	
	
  static char* UTF16LE_to_UTF8
    (Logger& logger, char** inbuf, size_t& inbytesleft);
  static void UTF16LE_to_UTF8
    (Logger& logger, char** inbuf, size_t& inbytesleft, char* output);

  static string excelEscapeDoubleQuotes(string src);

  static string toHex ( const char* data, size_t dataLen);
};

#pragma pack()

#endif
