#ifndef ErrorHandlerH
#define ErrorHandlerH 1

#include <errno.h>
#include <iostream>

#include "Common.h"
#include "LoggerSelector.h"

#ifdef LOG4CPLUS
using namespace log4cplus;
#endif

using namespace std;

#pragma pack(1)

class ErrorHandler {

 public:

  ErrorHandler();
  ~ErrorHandler();
  static void print(Logger& logger, const char* pPrefix, bool bExit=false);
};

#pragma pack()

#endif
