// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef GlobalH
#define GlobalH 1

// Network Includes
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

// Other Includes
#include <stdio.h>
#include <unistd.h>
#include <getopt.h>
#include <string.h>
#include <deque>
#include <map>
#include <set>
#include <errno.h>
#include <iostream>

// NGMDS Includes
#include "Common.h"
#include "LoggerSelector.h"
#include "XdpStructs.h"
#include "PacketSpool.h"

// Boost includes
#include <boost/icl/interval_set.hpp>

// Xerces includes
#include <xercesc/dom/DOM.hpp>
#include <xercesc/framework/LocalFileFormatTarget.hpp>
#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/sax/HandlerBase.hpp>
#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/util/XMLString.hpp>

using namespace std;
using namespace boost::icl;
using namespace xercesc;

#pragma pack(1)

class Global {

	public:
		Global();
		void init(int component, string loggerName);
		~Global();

		Logger& getLogger() {
			return mLogger;
		}

		Logger& getUserLogger() {
			return mUserLogger;
		}

		// Information about command line options
		void printHelp();

		// Set various options. If any aren't given, default value is used.
		bool parseCommandLine(int argc, char** argv);

		void printConfiguration();

		bool isValidPacket(char* pPacketData, uint16_t packetSize);
		char* getNextPacketMsg(char* pPacketData, uint16_t packetSize, char* pMsgData);

		Message* createMsg(uint16_t msgSize);

		DOMElement* getElement(DOMElement* pParent, const char* nodeName);
		bool fileExist(const char *filename);
		void readXmlConfig(int component);

		string mLoggerName;
		Logger mLogger;

		string mUserLoggerName;
		Logger mUserLogger;

		bool DirectoryExists( const char* pzPath );
		// ===========================================================

		// Create a MessageHandler object

		// Buffers
		char            mReadBufferTcpClient[MAX_PACKET_SIZE];
		int             mReadBufferTcpClientOffset;
		char            mReadBufferTcpServer[MAX_PACKET_SIZE];
		int             mReadBufferTcpServerOffset;

		string mChannelName[MAX_CHANNELS+1];
		uint32_t			uRFTimes[MAX_CHANNELS+1];
		uint32_t		  	uRFLastSeq[MAX_CHANNELS+1];

		// Retrans specific
		struct retrans {
			retrans() {}
			retrans(string addr, uint32_t port, string username, uint16_t channelID
					, PacketSpool* pPacketSpool)
				: addr(addr), port(port), username(username), channelID(channelID)
				  , pPacketSpool(pPacketSpool) {}
			string        addr;
			uint32_t      port;
			string        username;
			uint16_t      channelID;
			PacketSpool*  pPacketSpool;
		};

		struct retrans mRet[RETRANS_SITES][RETRANS_SERVERS];

		struct RetransProxy {
			RetransProxy() {}
			RetransProxy(string addr, uint32_t port, PacketSpool* pPacketSpool)
				: addr(addr), port(port), pPacketSpool(pPacketSpool) {}
			string        addr;
			uint32_t      port;
			PacketSpool*  pPacketSpool;
		};

		struct RetransProxy mRetProxy;

		bool mRetransActive;
		int mRetThreshold;
		int mRetReconnectInterval;
		int mRetReconnectTimes;
		int mRetRespTO;
		int mRetMaxReqs;
		int mRetMaxMsgs;
		int mRetReqs;

		// Line handler specific
		int mMulticastHeartbeatInterval;
		int mMulticastHeartbeatFailoverThreshold;

		struct feedHandler {
			feedHandler() {}
			feedHandler(uint16_t refreshChannelID, string addr, uint32_t port, PacketSpool* pPacketSpool)
				: refreshChannelID(refreshChannelID), addr(addr), port(port)
				  , pPacketSpool(pPacketSpool) {}
			uint16_t      refreshChannelID;
			string        addr;
			uint32_t      port;
			PacketSpool*  pPacketSpool;
		} mFeedHandler;

		typedef map<uint16_t /* key is channelID */, struct feedHandler*> FeedHandlerMapType;
		FeedHandlerMapType mFeedHandlerMap;
		FeedHandlerMapType::iterator mFeedHandlerMapIterator;

		// Other
		string mLogFilePath;

		int mBinDecEnable;
		int mBinDecValidate;
		string mLogFileNameBinDec;

		int mBinRawEnable;
		string mLogFileNameBinRawRealTime;
		string mLogFileNameBinRawRefresh;
		string mLogFileNameBinRawRetrans;

		int mHHMM;
		string mLogFileNameBinMiss;

		int mProductIndex;
		uint16_t mRealTimeChannelID;
		string mXMLFile;

		char mCommodityCode[5+1];
		char mOrderBookID[10+1];
		char mMarketCode[3+1];
		char mSymbol[32+1];
		char mInstrumentGroup[3+1];

		// By Louis
		//char mDateFolder[10];
		char mDateFolder[15];

		Common::Mode mMode;

		typedef map<char /* key is field value */, string>
			FieldValueMapChar;
		typedef map<uint8_t /* key is field value */, string>
			FieldValueMapUint8;
		typedef map<uint16_t /* key is field value */, string>
			FieldValueMapUint16;

		FieldValueMapUint16 mMsgTypeMap;
		FieldValueMapUint8 mRetransStatusMap;
		FieldValueMapUint8 mUnderlyingPriceUnitMap;
		FieldValueMapUint8 mUnderlyingTypeMap;
		FieldValueMapUint8 mEffectiveTomorrowMap;
		FieldValueMapUint8 mMarketMap;
		FieldValueMapUint8 mInstrumentGroupMap;
		FieldValueMapUint8 mModifierMap;
		FieldValueMapUint16 mRankingTypeMap;
		FieldValueMapUint8 mTradableMap;
		FieldValueMapUint8 mPremiumUnit4PriceMap;
		FieldValueMapChar mIsFractionsMap;
		FieldValueMapUint8 mFinancialProductMap;
		FieldValueMapUint8 mPutOrCallMap;

		FieldValueMapUint8 mSeriesStatusMap;
		FieldValueMapChar mLegSideMap;
		FieldValueMapUint16 mStateLevelMap;
		FieldValueMapUint16 mStateMap;
		FieldValueMapUint8 mSuspendedMap;
		FieldValueMapUint8 mOrderSideMap;
		FieldValueMapUint8 mLotTypeMap;
		FieldValueMapUint16 mOrderTypeMap;
		FieldValueMapUint8 mUpdateActionMap;
		FieldValueMapUint8 mBidAskFlagMap;
		FieldValueMapUint8 mTradeSideMap;
		FieldValueMapUint8 mDealTypeMap;
		FieldValueMapUint16 mTradeConditionMap;
		FieldValueMapUint16 mDealInfoMap;
		FieldValueMapUint8 mTradeStateMap;
		FieldValueMapUint8 mDealSourceMap;
		FieldValueMapUint8 mSessionMap;
		FieldValueMapChar mEASTypeMap;
		FieldValueMapChar mLastFragmentMap;
		FieldValueMapUint8 mInfoTypeMap;
		FieldValueMapUint8 mPriorityMap;
		FieldValueMapUint16 mDayIndicatorMap;

		ITEM** mppItems;
		MENU* mpMenu;
		WINDOW* mpMenuWin;
		WINDOW* mpMenuSub;

		FIELD* mpField[Common::END_SCREEN][2][MAX_FORM_FIELDS];
		FORM* mpForm[Common::END_SCREEN][2];
		WINDOW* mpFormWin[Common::END_SCREEN][2];
		WINDOW* mpFormSub[Common::END_SCREEN][2];

		typedef set<uint16_t> ChannelSet;
		ChannelSet mRealTimeChannelSet;
		ChannelSet mRefreshChannelSet;

		key_t mMessageQueueKey;

		uint64_t mSeqResetThreshold;

		int mRefreshScreen;
		int mSnapshotInterval;

		typedef set<pthread_t> ThreadIdSet;
		ThreadIdSet mThreadIdSet;

		int thisComponent_;

		uint16_t	uRtsChID_;
		//for server client version of CT
		bool		mServerConnected_;
		uint32_t	mCurOrderBookID_;

		//-----------------------------------------------------------------
		// For OMDCC
		//-----------------------------------------------------------------
		char    mOMDCC_MarketCode_CFFExID[31+1];
		char    mOMDCC_SecurityCode_CFFExGpID[9+1];
};

#pragma pack()

extern Global* gpGlobal;

#endif
