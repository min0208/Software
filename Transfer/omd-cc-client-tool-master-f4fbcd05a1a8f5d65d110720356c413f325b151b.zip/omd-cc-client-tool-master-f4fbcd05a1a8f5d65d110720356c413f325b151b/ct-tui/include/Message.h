#ifndef MessageH
#define MessageH 1

#include <iostream>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "Common.h"
//#include "TypeDef.h"

#ifdef LOG4CPLUS
using namespace log4cplus;
#endif

using namespace std;

#pragma pack(1)

class Message 
{
	public:
		Message(Logger& logger, uint16_t msgSize);
		~Message();

		uint16_t getMsgSize();
		char*    getMsgData();

	private:
		uint16_t mMsgSize;
		char*    mMsgData; 
};

#pragma pack()

#endif
