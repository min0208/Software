#ifndef SocketH
#define SocketH 1

#include <iostream>

#include <errno.h>
#include <stdlib.h>
#include <string.h>

#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/fcntl.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/types.h>

#include "Common.h"
#include "XdpStructs.h"

#pragma pack(1)

using namespace std;

class Socket {

 public:
  Socket();
  ~Socket();

  static int createListen(Logger& logger, char* ipAddr, int port);
  static int acceptConn(Logger& logger, int sockfd);
  static int createMcClient
    (Logger& logger, char* interface, char* multiaddr, uint32_t port);
  static int createMcServer
    (Logger& logger, char* multiaddr, uint32_t port, char* interface
     , struct sockaddr_in& sin);
  static int createConnect(Logger& logger, char* ipAddr, int port);
  static void joinMcGroup
    (Logger& logger, int sockfd, char* interface, char* multiaddr);
  static void leaveMcGroup
    (Logger& logger, int sockfd, char* interface, char* multiaddr);

 private:
  static int createTcp(Logger& logger);
  static void setReuseAddr(Logger& logger, int sockfd);
  static void setNonBlock(Logger& logger, int sockfd);
  static void bindAddr(Logger& logger, int sockfd, char* ipAddr, int port);
  static int createUdp(Logger& logger);
  static void disableMcLoopback(Logger& logger, int sockfd);
  static void setMcLocalInterface(Logger& logger, int sockfd, char* interface);
  static int connectAddr(Logger& logger, int sockfd, char* ipAddr, int port);
};

#pragma pack()

#endif
