#ifndef ClientToolP4H
#define ClientToolP4H 1


#include <string.h>

#include "Common.h"
#include "ClientTool.h"
#include "ClientToolScreenHeader.h"
#include "ClientToolScreenFooter.h"
#include "ClientToolScreenSSESZSE.h"
#include "ClientToolScreenQuit.h"
#include "Logger.h"
#include "MultiIndexContainer.h"
#include "ClientToolStructs.h"

using namespace std;

class ClientToolP4 : public ClientTool 
{
	public:

		void createCommonWindows();
		void initNcurses();
		void unpostForm(int screenIndex, int formIndex);
		void unpostAllForms();
		void postAllForms(enum Common::Screen screen);
		void clearAllFormSubs(int screenIndex);
		void processNcurses(pthread_cond_t& cond);
		void refreshNcursesWindows();

		ClientToolP4(int argc, char** argv, Logger& logger, Logger& userlogger);
		~ClientToolP4();

		void output(int row, int col, const char* pStr, bool lock=true);
		void output(const char* pStr, bool lock=true);
		void output(int row, int col, ostringstream& oss, bool lock=true);
		void output(ostringstream& oss, bool lock=true);

		void processMsg(uint16_t channelID, uint64_t sendTime, uint16_t msgSize, uint16_t msgType, char* pMsgData);

		void sendSecuritySearchRequest(CTSecuritySearchRequest reqData);
		void sendSecuritySnapShotRequest(CTSecuritySnapShotRequest reqData);

		bool PreSendChecking(w_u16_t infoType, const char* data);

		ClientToolScreenSSESZSE *mpScreenSSESZSE;

		void createSecurityShell(uint32_t securityCode);

	private:
		void processCTServerMsg(char* pPacketData);
		void connectToCTServer();
		static void* threadTcp(void *arg);
		void startPollCTServer();


		void deleteCommonWindows();
		void deleteForm(FORM*& pForm);
		void deleteFormWin(WINDOW*& pFormWin);
		void deleteField(FIELD*& pField);

		ClientToolScreenHeader *mpScreenHeader;
		ClientToolScreenFooter *mpScreenFooter;
		ClientToolScreenQuit *mpScreenQuit;

		enum Common::Screen mScreen;

		Common::Source mSource;

		enum Common::Screen mRefreshOrder[Common::END_SCREEN][3];

		void dumpBuffer( const char* pBuf, int nBufSize );

		int mSockfdCTServer;
		pthread_t mThreadId;
		char mReadBufferClient[MAX_PACKET_SIZE];
		int  mReadBufferClientOffset;
};

#endif
