#ifndef XdpStructsH
#define XdpStructsH 1

#include <stdint.h>

namespace Xdp
{

  enum XdpMessageTypes
  {
    UNDEFINED_TYPE = 0,

    SEQUENCE_RESET_TYPE = 100,

    LOGON_TYPE = 101,
    LOGON_RESPONSE_TYPE = 102,

    RETRANSMISSION_REQUEST_TYPE = 201,
    RETRANSMISSION_RESPONSE_TYPE = 202,

    REFRESH_COMPLETE_TYPE = 203,

    COMMODITY_DEFINITION_TYPE = 301,
    CLASS_DEFINITION_TYPE = 302,
    SERIES_DEFINITION_BASE_TYPE = 303,
    SERIES_DEFINITION_EXTENDED_TYPE = 304,
    COMBINATION_DEFINITION_TYPE = 305,
    MARKET_STATUS_TYPE = 320,
    SERIES_STATUS_TYPE = 321,
    COMMODITY_STATUS_TYPE = 322,
    ADD_ORDER_TYPE = 330,
    MODIFY_ORDER_TYPE = 331,
    DELETE_ORDER_TYPE = 332,
    TOP_OF_BOOK_TYPE = 355,
    AGGREGATE_ORDER_BOOK_UPDATE_TYPE = 353,
    ORDERBOOK_CLEAR_TYPE = 335,
    QUOTE_REQUEST_TYPE = 336,
    TRADE_TYPE = 350,
    TRADE_AMENDMENT_TYPE = 356,
    TRADE_STATISTICS_TYPE = 360,
    SERIES_STATISTICS_TYPE = 363,
    CALCULATED_OPENING_PRICE_TYPE = 364,
    ESTIMATED_AVERAGE_SETTLEMENT_PRICE_TYPE = 365,
    MARKET_ALERT_TYPE = 323,
    OPEN_INTEREST_TYPE = 366,
    IMPLIED_VOLATILITY_TYPE = 367,

    LINE_STATUS_TYPE = 405,
    ACTIVE_RETRANS_TYPE = 406,

    OMDCC_MARKET_DEFINITION_TYPE = 610,
    OMDCC_SECURITY_DEFINITION_TYPE = 611,
    OMDCC_SECURITY_STATUS_TYPE = 621,
    OMDCC_TOP_OF_BOOK_TYPE = 655,
    OMDCC_TOP_OF_BOOK_FUTURES_TYPE = 656,
    OMDCC_STATISTICS_TYPE = 660,
    OMDCC_STATISTICS_FUTURES_TYPE = 661,

    //SNAPSHOT_REQUEST_TYPE = 888,
    //SNAPSHOT_RESPOND_TYPE = 889,
    END_MSG_TYPE
  };

#pragma pack(1) // prevents compiler padding (structs not aligned).

  // ==== Administration ====

  struct MessageHeader {
    uint16_t mMsgLength;
    char     mFiller[2];
    uint32_t mSeqNum;
    uint32_t mInternalSeqNum;
    uint64_t mSendTime;
  };

  struct MsgHeader {
    uint16_t mMsgSize;
    uint16_t mMsgType;
  };

  struct RetransRequest {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint16_t mChannelID;
    char     mFiller[2];
    uint32_t mBeginSeqNum;
    uint32_t mEndSeqNum;
  };

  struct RetransResponse {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint16_t mChannelID;
    uint8_t  mRetransStatus;
    char     mFiller;
    uint32_t mBeginSeqNum;
    uint32_t mEndSeqNum;
  };

  struct AggregateOrderBookUpdateEntry {
    uint64_t mAggregateQuantity;
    int32_t  mPrice;
    uint32_t mNumberOfOrders;
    // uint16_t mSide; // New
    uint8_t mSide;
    char mFiller1;
    uint8_t  mPriceLevel;
    uint8_t  mUpdateAction;
    char     mFiller2[4];
  };

  struct MarketAlertContent {
    char mContent[MARKET_ALERT_CONTENT_LEN];
  };

  // ==== Change mode ====
  struct ChangeModeRequest
  {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint8_t  mMode; // 0 = disconnected, 1 = real time, 2 = refresh
    char     mFiller;
  };

  struct ChangeModeResponse {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint8_t  mMode; // 0 = disconnected, 1 = real time, 2 = refresh
    uint8_t  mStatus; // 0 = success, 1 = fail
  };

  struct RefreshStartEnd {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint16_t mChannelID;
  };

  struct LineStatus {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint16_t mChannelID;

    char mLineType; // R=real-time, F=refresh, T=retransmission

    // 0 = both lines are down
    // 1 = one of the lines is up
    // 2 = both lines are up

    // 10 = both lines have no data for real-time or refresh
    // 11 = one of the lines has data for real-time or refresh
    // 12 = both lines have data for real-time or refresh
    uint8_t mStatus;
  };

  struct ActiveRetrans {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint8_t  mSite;
    uint8_t  mServer;
  };

  // ==== Other messages ====
  struct PacketHeader {
    uint16_t mPktSize;
    uint8_t mMsgCount;
    char mFiller[1];
    uint32_t mSeqNum;
    uint64_t mSendTime;
  };

  struct SequenceReset {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mNewSeqNo;
  };

  struct Logon {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    char mUsername[12];
  };

  struct LogonResponse {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint8_t mSessionStatus;
    char mFiller[3];
  };

  struct RetransmissionRequest {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint16_t mChannelID;
    char mFiller[2];
    uint32_t mBeginSeqNum;
    uint32_t mEndSeqNum;
  };

  struct RetransmissionResponse {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint16_t mChannelID;
    uint8_t mRetransStatus;
    char mFiller;
    uint32_t mBeginSeqNum;
    uint32_t mEndSeqNum;
  };

  struct RefreshComplete {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mLastSeqNum;
  };

  struct CommodityDefinition {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint16_t mCommodityCode;
    uint16_t mDecimalInUnderlyingPrice;
    char mISINCode[12];
    char mBaseCurrency[3];
    uint8_t mUnderlyingPriceUnit;
    char mCommodityName[32];
    int64_t mNominalValue;
    char mUnderlyingCode[20];
    uint8_t mUnderlyingType;
    uint8_t mEffectiveTomorrow;
    char mFiller[2];
  };

  struct ClassDefinition {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint8_t mCountry;
    uint8_t mMarket;
    uint8_t mInstrumentGroup;
    uint8_t mModifier;
    uint16_t mCommodityCode;
    char mFiller[2];
    int32_t mPriceQuotationFactor;
    uint32_t mContractSize;
    uint16_t mDecimalInStrikePrice;
    uint16_t mDecimalInContractSize;
    uint16_t mDecimalInPremium;
    uint16_t mRankingType;
    uint8_t mTradable;
    uint8_t mPremiumUnit4Price;
    char mBaseCurrency[3];
    char mInstrumentClassID[14];
    char mInstrumentClassName[32];
    char mIsFractions;
    char mSettlementCurrencyID[32];
    uint8_t mEffectiveTomorrow;
    char mFiller2;
  };

  struct SeriesDefinitionBase {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID;
    char mSymbol[32];
    uint8_t mFinancialProduct;
    uint16_t mDecimalsInPremium;
    uint8_t mNumberOfLegs;
    int32_t mStrikePrice;
    char mExpirationDate[8];
    uint16_t mDecimalsInStrikePrice;
    uint8_t mPutOrCall;
    char mFiller;
  };

  struct SeriesDefinitionExtended {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID;
    char mSymbol[32];
    uint8_t mCountry;
    uint8_t mMarket;
    uint8_t mInstrumentGroup;
    uint8_t mModifier;
    uint16_t mCommodityCode;
    uint16_t mExpirationDate;
    int32_t mStrikePrice;
    int64_t mContractSize;
    char mISINCode[12];
    uint8_t mSeriesStatus;
    uint8_t mEffectiveTomorrow;
    char mFiller[6];
    char mEffectiveExpDate[8];
    int64_t mDateTimeLastTrading;
  };

  struct CombinationDefinition {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mComboOrderBookID;
    uint32_t mLegOrderBookID;
    char mFiller[3];
    char mLegSide;
    int32_t mLegRatio;
  };

  struct MarketStatus {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint16_t mStateLevel;
    uint8_t mMarket;
    uint8_t mInstrument;
    uint32_t mOrderBookID;
    uint16_t mCommodityCode;
    char mFiller[2];
    char mActualStartDate[8];
    char mActualStartTime[6];
    char mPlannedStartDate[8];
    char mPlannedStartTime[6];
    uint16_t mSecondsToStateChange;
    uint16_t mState;
    uint8_t mPriority;
    char mFiller2[3];
  };

  struct SeriesStatus {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID;
    char mSuspended;
    char mFiller[3];
  };

  struct CommodityStatus {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint16_t mCommodityCode;
    char mSuspended;
  };

  struct AddOrder {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID;
    uint64_t mOrderID;
    int32_t mPrice;
    uint32_t mQuantity;
    uint8_t mSide;
    uint8_t mLotType;
    uint16_t mOrderType;
    uint32_t mOrderBookPosition;
  };

  struct ModifyOrder {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID;
    uint64_t mOrderID;
    int32_t mPrice;
    uint32_t mQuantity;
    uint8_t mSide;
    char mFiller;
    uint16_t mOrderType;
    uint32_t mOrderBookPosition;
  };

  struct DeleteOrder {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID;
    uint64_t mOrderID;
    uint8_t mSide;
  };

  struct TopOfBook {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID;
    uint64_t mAggregateBidQuantity;
    uint64_t mAggregateAskQuantity;
    int32_t mBidPrice;
    int32_t mAskPrice;
    uint32_t mNumberBidOrders;
    uint32_t mNumberAskOrders;
  };

  struct AggregateOrderBookUpdate {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID;
    char mFiller[3];
    uint8_t mNoEntries;
  };

  struct OrderBookClear {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID;
  };

  struct QuoteRequest {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID ;
    int32_t mNumberOfLots;
    uint8_t mBidAskFlag;
    char mFiller[3];
  };

  struct Trade {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID;
    uint64_t mOrderID;
    int32_t mPrice;
	//uint32_t mPrice;
    uint64_t mTradeID;
    uint32_t mComboGroupID;
    uint8_t mSide;
    uint8_t mDealType;
    uint16_t mTradeCondition;
    uint16_t mDealInfo;
    //char mFiller[6];
	char mFiller[2];
    uint64_t mQuantity;
    uint64_t mTradeTime;
  };

  struct TradeAmendment {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint64_t mTradeID;
    uint32_t mComboGroupID;
    int32_t mPrice;
    uint64_t mQuantity;
    uint64_t mTradeTime;
    uint8_t mTradeState;
    char mFiller[3];
  };

  struct TradeStatistics {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID;
    int32_t mPrice;
    uint8_t mDealSource;
    uint8_t mSession;
    char mFiller[2];
    int64_t mAggregateQuantity;
    int32_t mOpen;
    int32_t mHigh;
    int32_t mLow;
    char mFiller2[4];
    uint64_t mTradeReportVolume;
    uint32_t mDealCount;
    uint64_t mTurnover;
  };

  struct SeriesStatistics {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID;
    uint8_t mSession;
    char mFiller[3];
    int32_t mOpen;
    int32_t mHigh;
    int32_t mLow;
    uint64_t mTradeReportVolume;
    uint32_t mDealCount;
    int32_t mPrice ;
    uint64_t mTurnover;
  };

  struct CalculatedOpeningPrice {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID;
    int32_t mCalculatedOpeningPrice ;
    char mFiller[4];
    uint64_t mQuantity;
  };

  struct EstimatedAverageSettlementPrice {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    char mEASType;
    char mInstrumentCode[20];
    int64_t mEAS;
    char mFiller[3];
  };

  struct MarketAlert {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint16_t mAlertID;
	char mSource;
	char mFiller;
    char mHeader[320];
    char mLastFragment;
    uint8_t mInfoType;
    uint8_t mPriority;
    //char mFiller;
    uint8_t mNoLines;
  };

  struct OpenInterest {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint16_t mDayIndicator;
    char mFiller[6];
    uint32_t mOrderBookID;
    int32_t mSettlement;
    uint32_t mDealCount;
    uint32_t mGrossOI;
    uint32_t mNetOI;
    uint64_t mTurnover;
  };

  struct ImpliedVolatility {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID;
    uint32_t mImpliedVolatility;
  };

  struct SnapShotRequest {
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID; 
  };

  struct SnapShotResponse {  
    uint16_t mMsgSize;
    uint16_t mMsgType;
    uint32_t mOrderBookID;
  };

  //-----------------------------------------
  // For OMDCC
  //-----------------------------------------
  struct OMDCC_MarketDefinition
  {
    uint16_t    mMsgSize;
    uint16_t    mMsgType;
    char        mMarketCode[4];
    char        mMarketName[25];
    char        mCurrencyCode[3];
    uint32_t    mNumberOfSecurities;    
  };

  struct OMDCC_SecurityDefinition
  {
    uint16_t    mMsgSize;
    uint16_t    mMsgType;
    uint32_t    mSecurityCode;
    char        mMarketCode[4];
    char        mISINCode[12];
    char        mInstrumentType[4];
    char	mFiller1[2];
    //char        mSpreadTableCode[2];
    char        mSecurityShortName[40];
    char        mCurrencyCode[3];
    char        mSecurityNameGCCS[60];
    char        mSecurityNameGB[60];
    uint32_t    mLotSize;
    int32_t     mPreviousClosingPrice;
    char        mFiller2;
    char	mShortSellFlag;
    char        mFiller3[6];
    uint32_t    mListingDate;
    uint32_t    mDelistingDate;
    char        mFiller4[3];  
  };

  struct OMDCC_SecurityStatus
  {
    uint16_t    mMsgSize;
    uint16_t    mMsgType;
    uint32_t    mSecurityCode;
    uint8_t     mSecurityTradingStatus;
    char        mFiller[3];
    char        mCircuitBreakerTradingState[8];
  };

  struct OMDCC_TopOfBook
  {
    uint16_t    mMsgSize;
    uint16_t    mMsgType;
    uint32_t    mSecurityCode;
    uint64_t    mAggBidQty;
    uint64_t    mAggAskQty;
    int32_t     mBidPrice;
    int32_t     mAskPrice;
    char        mFiller[8];    
  };

  struct OMDCC_TopOfBook_Futures
  {
    uint16_t    mMsgSize;
    uint16_t    mMsgType;
    char        mCFFExID[31];
    uint64_t    mAggBidQty;
    uint64_t    mAggAskQty;
    int64_t     mLongBidPrice;
    int64_t     mLongAskPrice;
    uint16_t    mDecimalInPremium;
  };

  struct OMDCC_Statistics
  {
    uint16_t    mMsgSize;
    uint16_t    mMsgType;
    uint32_t    mSecurityCode;
    uint64_t    mSharesTraded;
    int64_t     mTurnover;
    int32_t     mHighPrice;
    int32_t     mLowPrice;
    int32_t     mLastPrice;
    int32_t	mOpeningPrice;
    char        mFiller[16];
  };

  struct OMDCC_Statistics_Futures
  {
    uint16_t    mMsgSize;
    uint16_t    mMsgType;
    char        mCFFExID[31];
    uint16_t    mDecimalInPremium;
    char        mTradingDay[9];
    char        mSettleGpID[9];
    int16_t     mSettleID;
    int64_t     mLastPrice;
    int64_t     mPreSettlePrice;
    int64_t     mPreClosePrice;
    int64_t     mPreOpenInterest;
    int64_t     mOpenPrice;
    int64_t     mHighestPrice;
    int64_t     mLowestPrice;
    int64_t     mVolume;
    int64_t     mTurnover;
    int64_t     mOpenInterest;
    int64_t     mClosePrice;
    int64_t     mSettlePrice;
    int64_t     mUpperLimitedPrice;
    int64_t     mLowerLimitedPrice;
    char        mUpdatedTime[9];
    int32_t     mUpdatedMillisec;
    char        mActionDay[9];
    char        mFiller[4];
  };

#pragma pack()
} // namespace Xdp

#endif // XdpStructsH
