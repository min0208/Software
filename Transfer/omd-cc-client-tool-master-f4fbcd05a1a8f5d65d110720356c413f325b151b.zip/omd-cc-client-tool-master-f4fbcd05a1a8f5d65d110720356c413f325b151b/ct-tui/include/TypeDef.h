#ifndef TypeDefH
#define TypeDefH

//*********************************************
// Data type compatible with Wombat in OMD
//*********************************************
typedef int8_t            w_i8_t;
typedef int16_t           w_i16_t;
typedef int32_t           w_i32_t;
typedef int64_t           w_i64_t;
typedef uint8_t           w_u8_t;
typedef uint16_t          w_u16_t;
typedef uint32_t          w_u32_t;
typedef uint64_t          w_u64_t;

#endif //TypeDefH

