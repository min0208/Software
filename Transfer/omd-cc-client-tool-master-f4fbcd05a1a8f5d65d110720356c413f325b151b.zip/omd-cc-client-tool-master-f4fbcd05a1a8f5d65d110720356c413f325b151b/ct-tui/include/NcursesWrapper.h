#ifndef NcursesWrapperH
#define NcursesWrapperH 1

#include <sstream>

#include "ErrorHandler.h"

using namespace std;

class NcursesWrapper {

 public:

  NcursesWrapper(Logger& logger);
  ~NcursesWrapper();

  FIELD* current_field(const FORM * form);
  WINDOW* derwin
    (WINDOW *orig, int nlines, int ncols, int begin_y, int begin_x);
  int form_driver(FORM *form, int c);
  FIELD* new_field
    (int height, int width, int toprow, int leftcol, int offscreen, int nbuffers);
  FORM* new_form(FIELD **fields);
  WINDOW* newwin
    (int nlines, int ncols, int begin_y, int begin_x);
  int post_form(FORM *form);
  int scale_form(const FORM *form, int *rows, int *columns);

  int set_field_buffer(FIELD *field, int buf, const char *value);

 private:
  Logger&  mLogger;

};

#endif
