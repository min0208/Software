#ifndef LoggerH
#define LoggerH 1

#ifndef LOG4CPLUS

#include <errno.h>
#include <fstream>
#include <iomanip>
#include <pthread.h>
#include <sstream>
#include <syslog.h>
#include <time.h>
#include <dirent.h>

#pragma pack(1)

using namespace std;

class Logger {
  
 public:
  Logger();
  //Logger(string loggerName);
  Logger(string loggerName, bool bCSV=false);
  //LoggerCSV(string loggerName);
  ~Logger();

  void lock();
  void unlock();

  static Logger getInstance(string loggerName);
  static Logger getInstanceCSV(string loggerName);

  ofstream* getOfstream();
  string getPrefix(int level);
  
  bool DirectoryExists( const char* pzPath );

 private:
  ofstream* mpOfstream;

  pthread_mutex_t mMutex;

  struct timespec mTpLast;
  struct tm mCurrentTime;
  char mCurrentTimeStr[20];
};

#pragma pack()

#endif
#endif
