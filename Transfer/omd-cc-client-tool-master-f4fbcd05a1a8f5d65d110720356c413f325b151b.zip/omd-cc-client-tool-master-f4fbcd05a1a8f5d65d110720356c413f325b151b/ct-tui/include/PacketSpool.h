#ifndef PacketSpoolH
#define PacketSpoolH 1

#include <stdint.h>
#include <deque>

// Network includes
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "Common.h"
#include "Message.h"
#include "Timer.h"
#include "XdpStructs.h"

#ifdef LOG4CPLUS
using namespace log4cplus;
#endif

using namespace std;

typedef deque<char*> PacketDeque;

#pragma pack(1)

class PacketSpool {

	public:
		PacketSpool(Logger& logger);

		void init(int sockfd);

		~PacketSpool();

		Logger& getLogger() {
			return mLogger;
		}

		bool sendMsgs();

		pthread_mutex_t mMutexHeartbeat;

		void addTcpMsg(Message* pMsg);

	private:
		Logger& mLogger;

		bool sendPacket(char* pPacketData);

		char* mpPacketData;

		PacketDeque mPacketDeque;

		int mSockfd; // TCP

		uint32_t mNumPacketsSent;

		bool mInitialized;
		void dumpBuffer( const char* pBuf, int nBufSize );
};

#pragma pack()

#endif
