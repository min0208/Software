#include "Common.h"

using namespace std;

int yearOffset = 1900;

Common::Common() {
}

Common::~Common() {
}

uint64_t Common::getUint64Time(Logger& logger) {
	struct timespec tp;
	if (clock_gettime(CLOCK_REALTIME, &tp) != 0) {
		::ErrorHandler::print(logger, "clock_gettime", true);
	}

	uint64_t uint64Time = (uint64_t)tp.tv_sec*1000*1000*1000 + tp.tv_nsec;

	return uint64Time;
}

string Common::getUint64TimeYYSS(uint64_t uint64Time) {
	struct timespec tp;
	tp.tv_sec = uint64Time / 1000000000;
	tp.tv_nsec = uint64Time % 1000000000;

	struct tm time;
	localtime_r(&tp.tv_sec, &time);

	ostringstream oss;
	oss << setfill('0')
		<< setw(2) << time.tm_year+yearOffset
		<< "-" << setw(2) << time.tm_mon+1
		<< "-" << setw(2) << time.tm_mday
		//<< "T" << setw(2) << time.tm_hour
		<< " " << setw(2) << time.tm_hour
		<< ":" << setw(2) << time.tm_min
		<< ":" << setw(2) << time.tm_sec;
	return oss.str();
}

string Common::getUint64TimeYYSS2(uint64_t uint64Time) {
	struct timespec tp;
	tp.tv_sec = uint64Time / 1000000000;
	tp.tv_nsec = uint64Time % 1000000000;

	struct tm time;
	localtime_r(&tp.tv_sec, &time);

	ostringstream oss;
	oss << setfill('0')
		<< setw(2) << time.tm_year+yearOffset
		<< "-" << setw(2) << time.tm_mon+1
		<< "-" << setw(2) << time.tm_mday
		//<< "T" << setw(2) << time.tm_hour
		<< " " << setw(2) << time.tm_hour
		<< ":" << setw(2) << time.tm_min
		<< ":" << setw(2) << time.tm_sec
		<< "." << setw(2) << tp.tv_nsec/10000000;
	return oss.str();
}

string Common::getUint64TimeYYSS3(uint64_t uint64Time) {
	struct timespec tp;
	tp.tv_sec = uint64Time / 1000000000;
	tp.tv_nsec = uint64Time % 1000000000;

	struct tm time;
	localtime_r(&tp.tv_sec, &time);

	ostringstream oss;
	oss << setfill('0')
		<< setw(2) << time.tm_year+yearOffset
		<< "-" << setw(2) << time.tm_mon+1
		<< "-" << setw(2) << time.tm_mday
		//<< "T" << setw(2) << time.tm_hour
		<< " " << setw(2) << time.tm_hour
		<< ":" << setw(2) << time.tm_min
		<< ":" << setw(2) << time.tm_sec
		<< "." << setw(3) << tp.tv_nsec/1000000;
	return oss.str();
}

string Common::getUint64TimeYYSS9(uint64_t uint64Time) {
	struct timespec tp;
	tp.tv_sec = uint64Time / 1000000000;
	tp.tv_nsec = uint64Time % 1000000000;

	tm result; 

	struct tm time;
	localtime_r(&tp.tv_sec, &time);

	ostringstream oss;
	oss << setfill('0')
		<< setw(2) << time.tm_year+yearOffset
		<< "-" << setw(2) << time.tm_mon+1
		<< "-" << setw(2) << time.tm_mday
		//<< "T" << setw(2) << time.tm_hour
		<< " " << setw(2) << time.tm_hour
		<< ":" << setw(2) << time.tm_min
		<< ":" << setw(2) << time.tm_sec
		<< "." << setw(9) << tp.tv_nsec;
	return oss.str();
}

string Common::getUint64TimeDDMMYYYYSS(uint64_t uint64Time) {
	struct timespec tp;
	tp.tv_sec = uint64Time / 1000000000;
	tp.tv_nsec = uint64Time % 1000000000;

	struct tm time;
	localtime_r(&tp.tv_sec, &time);

	ostringstream oss;
	oss << setfill('0')
		<< setw(2) << time.tm_mday
		<< "/" << setw(2) << time.tm_mon+1
		<< "/" << setw(2) << time.tm_year+yearOffset
		<< " " << setw(2) << time.tm_hour
		<< ":" << setw(2) << time.tm_min
		<< ":" << setw(2) << time.tm_sec;
	return oss.str();
}

string Common::getUint64TimeHHMM(uint64_t uint64Time) {
	struct timespec tp;
	tp.tv_sec = uint64Time / 1000000000;
	tp.tv_nsec = uint64Time % 1000000000;

	struct tm time;
	localtime_r(&tp.tv_sec, &time);

	int hour = time.tm_hour;
	int minute = time.tm_min;

	ostringstream oss;
	oss << setfill('0')
		<< setw(2) << hour
		<< ":" << setw(2) << minute;
	return oss.str();
}

string Common::getUint64TimeBinDecHHMM(uint64_t uint64Time) {
	struct timespec tp;
	tp.tv_sec = uint64Time / 1000000000;
	tp.tv_nsec = uint64Time % 1000000000;

	struct tm time;
	localtime_r(&tp.tv_sec, &time);

	int hour = time.tm_hour;
	int minute = time.tm_min / 15 * 15;
	if (hour < 9) {
		hour = 0;
		minute = 0;
	} else if (hour > 15) {
		hour = 16;
		minute = 0;
	} else {
		if (minute < 15) {
			minute = 0;
		} else if (minute < 30) {
			minute = 15;
		} else if (minute < 45) {
			minute = 30;
		} else {
			minute = 45;
		}
	}

	ostringstream oss;
	oss << setfill('0')
		<< "_" << setw(2) << hour
		<< setw(2) << minute;
	return oss.str();
}

string Common::getUint32DateYYMMDD(uint32_t uint32Date) {
	int day = uint32Date % 100;
	uint32Date /= 100;
	int month = uint32Date % 100;
	uint32Date /= 100;
	int year = uint32Date % 100;

	ostringstream oss;
	oss << setfill('0')
		<< setw(2) << year
		<< setw(2) << month
		<< setw(2) << day;
	return oss.str();
}

string Common::getUint32DateYYYYMMDD(uint32_t uint32Date) {
	int day = uint32Date % 100;
	uint32Date /= 100;
	int month = uint32Date % 100;
	uint32Date /= 100;
	int year = uint32Date;

	ostringstream oss;
	oss << setfill('0')
		<< setw(4) << year
		<< setw(2) << month
		<< setw(2) << day;
	return oss.str();
}

string Common::getUint32DateDDMMYYYY(uint32_t uint32Date) {
	int day = uint32Date % 100;
	uint32Date /= 100;
	int month = uint32Date % 100;
	uint32Date /= 100;
	int year = uint32Date;

	ostringstream oss;
	oss << setfill('0')
		<< setw(2) << day
		<< "/" << setw(2) << month
		<< "/" << setw(4) << year;
	return oss.str();
}

void Common::exit(int status) {
	::exit(status);
}

short Common::getColorFromLineStatus(uint16_t status) {
	switch (status) {
		case 0:
			return Common::RED_BLACK_COLOR_PAIR;
		case 1:
			return Common::YELLOW_BLACK_COLOR_PAIR;
		case 2:
			return Common::GREEN_BLACK_COLOR_PAIR;
	} // switch
}

void Common::lock(Logger& logger, pthread_mutex_t* pMutex) {
	errno = pthread_mutex_lock(pMutex);
	if (errno) {
		::ErrorHandler::print(logger, "pthread_mutex_lock", true);
	}
}

void Common::unlock(Logger& logger, pthread_mutex_t* pMutex) {
	errno = pthread_mutex_unlock(pMutex);
	if (errno) {
		::ErrorHandler::print(logger, "pthread_mutex_unlock", true);
	}
}

uint64_t Common::getOffset
(uint64_t uint64time, int hour, int minute, int second) {
	return uint64time + (uint64_t)(((hour*60+minute)*60)+second)*1000000000;
}

char* Common::UTF16LE_to_BIG5(char** inbuf, size_t& inbytesleft) 
{
	int maxOutLen = inbytesleft/2*6;
	char* output = new char[maxOutLen+1];
	char* outbuf = output;
	memset(outbuf, 0, maxOutLen+1);
	size_t outbytesleft = maxOutLen;

	iconv_t cd = iconv_open("BIG5", "UTF16LE");

	// if (cd == (iconv_t)-1) {
	// ::ErrorHandler::print(logger, "iconv_open", true);
	// }

	iconv(cd, inbuf, &inbytesleft, &outbuf, &outbytesleft);
	// if (iconv(cd, inbuf, &inbytesleft, &outbuf, &outbytesleft) == (size_t)-1) {
	// ::ErrorHandler::print(logger, "iconv", true);
	// }

	iconv_close(cd);
	// if (iconv_close(cd)) {
	// ::ErrorHandler::print(logger, "iconv_close", true);
	// }
	return output;
}

char* Common::UTF16LE_to_UTF8(Logger& logger, char** inbuf, size_t& inbytesleft) 
{
	int maxOutLen = inbytesleft/2*6;
	char* output = new char[maxOutLen+1];
	char* outbuf = output;
	memset(outbuf, 0, maxOutLen+1);
	size_t outbytesleft = maxOutLen;

	iconv_t cd = iconv_open("UTF8", "UTF16LE");
	if (cd == (iconv_t)-1) {
		::ErrorHandler::print(logger, "iconv_open", true);
	}

	if (iconv(cd, inbuf, &inbytesleft, &outbuf, &outbytesleft) == (size_t)-1) {
		::ErrorHandler::print(logger, "iconv", true);
	}

	if (iconv_close(cd)) {
		::ErrorHandler::print(logger, "iconv_close", true);
	}
	return output;
}

void Common::UTF16LE_to_UTF8
(Logger& logger, char** inbuf, size_t& inbytesleft, char* output) {
	int maxOutLen = inbytesleft/2*6;
	char* outbuf = output;
	memset(outbuf, 0, maxOutLen+1);
	size_t outbytesleft = maxOutLen;

	iconv_t cd = iconv_open("UTF8", "UTF16LE");
	if (cd == (iconv_t)-1) {
		::ErrorHandler::print(logger, "iconv_open", true);
	}

	if (iconv(cd, inbuf, &inbytesleft, &outbuf, &outbytesleft) == (size_t)-1) {
		::ErrorHandler::print(logger, "iconv", true);
	}

	if (iconv_close(cd)) {
		::ErrorHandler::print(logger, "iconv_close", true);
	}
}

string Common::excelEscapeDoubleQuotes(string src) {
	string dest = "\"=\"\"";

	for (int i=0; i<src.size(); i++) {
		if (src[i] == 0) {
			break;
		} else if (src[i] == '\"') {
			dest += "\"\"";
		} else {
			dest += src[i];
		}
	}

	dest += "\"\"\"";
	return dest;
}

string Common::toHex (const char* data, size_t dataLen)
{
	static char buffer[8];
	string output;

	for (unsigned i =0; i < dataLen; i++)
	{
		sprintf (buffer, "%02x",  (unsigned char)data[i]);
		output += buffer;
	}
	return output;
}

