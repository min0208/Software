#include "ClientToolScreenHeader.h"

ClientToolScreenHeader::ClientToolScreenHeader(Logger& logger)
  : ClientToolScreen(logger) {
  mScreen = Common::HEADER_SCREEN;
  int formIndex = 0;

  int row = 0;  
  char	cStr[100];
  int 	iPos;
  
  FIELD** ppField = gpGlobal->mpField[mScreen][formIndex];

  sprintf(cStr, "OMDCC Client Tool v%s", PROGRAM_VERSION);
  iPos = sizeof(cStr);
 
  newField(ppField, CLIENT_TOOL_LABEL
	   , 1, iPos, row, 0, 0, 0, cStr, NO_JUSTIFICATION
           , 0, O_ACTIVE, COLOR_PAIR(Common::GREEN_BLACK_COLOR_PAIR) | A_BOLD);
  row++;
  row++;
  newField(ppField, FILTER_CRITERIA_LABEL
         , 1, 16, row, 0, 0, 0, "Filter Criteria", NO_JUSTIFICATION
         , 0, O_ACTIVE, COLOR_PAIR(Common::CYAN_BLACK_COLOR_PAIR) | A_BOLD);

  newField(ppField, NOTICE_ENTRY
	   , 1, 50, row, 20, 0, 0, "", NO_JUSTIFICATION
           , 0, O_ACTIVE, COLOR_PAIR(Common::RED_BLACK_COLOR_PAIR) | A_BOLD);
  row++;

//12345678901234567890
//Market Code
//Security Code
//Instrument ID
//Settlement Group ID

  newField(ppField, OMDCC_MKTCODE_CFFEXID_LABEL 
	   , 1, 23, row, 0, 0, 0, "Market Code   :", NO_JUSTIFICATION
	   //, 1, 23, row, 0, 0, 0, "Instrument ID", NO_JUSTIFICATION
           , 0, O_ACTIVE, COLOR_PAIR(Common::YELLOW_BLACK_COLOR_PAIR) | A_BOLD);
  
  newField(ppField, OMDCC_MKTCODE_CFFEXID_ENTRY
	   , 1, 31, row, 20, 0, 0, "", NO_JUSTIFICATION
	   , 0, O_AUTOSKIP, A_UNDERLINE);

  row++;
  newField(ppField, OMDCC_SECCODE_FFXGPID_LABEL
	   , 1, 19, row, 0, 0, 0, "Security Code :", NO_JUSTIFICATION
	   //, 1, 19, row, 0, 0, 0, "Settlement Group ID", NO_JUSTIFICATION
           , 0, O_ACTIVE, COLOR_PAIR(Common::YELLOW_BLACK_COLOR_PAIR) | A_BOLD);
  
  newField(ppField, OMDCC_SECCODE_FFXGPID_ENTRY 
	   , 1, 9, row, 20, 0, 0, "", NO_JUSTIFICATION
	   , 0, O_AUTOSKIP, A_UNDERLINE);

//  row++;
/*
  newField(ppField, INSTRUMENT_GROUP_LABEL
	   , 1, 16, row, 0, 0, 0, "Instrument Group");
  newField(ppField, INSTRUMENT_GROUP_ENTRY
	   , 1, 3, row, 17, 0, 0, "", NO_JUSTIFICATION
	   , 0, O_AUTOSKIP, A_UNDERLINE);
*/
//  newField(ppField, SEARCH_OPEN_LABEL
//	   , 1, 2, row, 31, 0, 0, "[ ", NO_JUSTIFICATION
//           , 0, O_ACTIVE, COLOR_PAIR(Common::GREEN_BLACK_COLOR_PAIR) | A_BOLD);
//  newField(ppField, SEARCH_LABEL
//	   , 1, 6, row, 33, 0, 0, "SEARCH", NO_JUSTIFICATION
//           , 0, O_AUTOSKIP, COLOR_PAIR(Common::GREEN_BLACK_COLOR_PAIR) | A_BOLD);
//  newField(ppField, SEARCH_CLOSE_LABEL
//	   , 1, 2, row, 39, 0, 0, " ]", NO_JUSTIFICATION
//           , 0, O_ACTIVE, COLOR_PAIR(Common::GREEN_BLACK_COLOR_PAIR) | A_BOLD);


  static wchar_t* rows[MAX_FORM_ROWS] = {
    (wchar_t*)L"",
    0
  };

  for (int i=1; i<MAX_FORM_ROWS-1; i++) {
    if (rows[i-1]) {
      memcpy(&ch[i][1], rows[i-1], sizeof(wchar_t) * wcslen(rows[i-1]));
    }
  }
}

ClientToolScreenHeader::~ClientToolScreenHeader() {
}

void ClientToolScreenHeader::createForms() {
  enum Common::Screen screen = Common::HEADER_SCREEN;
  int formIndex;

  {
    formIndex = 0;

    FORM* pForm = mpNcursesWrapper->new_form(gpGlobal->mpField[screen][formIndex]);
    gpGlobal->mpForm[screen][formIndex] = pForm;

    WINDOW* pFormWin
      = mpNcursesWrapper->newwin(MAX_HEADER_ROWS, MAX_FORM_COLS, 0, 0);
    gpGlobal->mpFormWin[screen][formIndex] = pFormWin;
    set_form_win(pForm, pFormWin);

    WINDOW* pFormSub
      = mpNcursesWrapper->derwin(pFormWin, MAX_HEADER_ROWS, MAX_FORM_COLS, 0, 0);
    gpGlobal->mpFormSub[screen][formIndex] = pFormSub;
    set_form_sub(pForm, pFormSub);
    mpFormSub[0] = pFormSub;

    mpNcursesWrapper->post_form(pForm);
  }
}

void ClientToolScreenHeader::printFieldLabels() {
  WINDOW* pFormSub = mpFormSub[0];

  //box(pFormSub, 0, 0);
}

void ClientToolScreenHeader::updateScrAllMsgs() {
}

void ClientToolScreenHeader::clearScr(uint16_t msgType, uint16_t side) {}

void ClientToolScreenHeader::updateScr
(uint16_t msgSize, uint16_t msgType, char* pMsgData, Common::Source source) {
}

void ClientToolScreenHeader::refresh() {
  Common::Source source=Common::CACHE_SOURCE;
  updateScrAllMsgs();

  setNotice(gpGlobal->mServerConnected_?"":"Server not connected.");
}

bool ClientToolScreenHeader::getOrderBookIDMatch(uint32_t orderBookID) {
  const MultiIndexContainer::SeriesDefinitionBase_OrderBookID_Symbol&
    seriesDefinitionBase_OrderBookID_Symbol
    = gpMultiIndexContainer->mSeriesDefinitionBaseContainer
    .get<MultiIndexContainer::seriesDefinitionBase_OrderBookID_Symbol>();

  mSeriesDefinitionBase_OrderBookID_Symbol_iterator
    = seriesDefinitionBase_OrderBookID_Symbol.find(orderBookID);

  if (mSeriesDefinitionBase_OrderBookID_Symbol_iterator
      == seriesDefinitionBase_OrderBookID_Symbol.end()) {
    return false;
  }

  MultiIndexContainer::SeriesDefinitionBase seriesDefinitionBase
    = *mSeriesDefinitionBase_OrderBookID_Symbol_iterator;

  const MultiIndexContainer::SeriesDefinitionExtended_Symbol&
    seriesDefinitionExtended_Symbol
    = gpMultiIndexContainer->mSeriesDefinitionExtendedContainer
    .get<MultiIndexContainer::seriesDefinitionExtended_Symbol>();
    mSeriesDefinitionExtended_Symbol_iterator
    = seriesDefinitionExtended_Symbol.find
    (seriesDefinitionBase.mSymbol);

  if (mSeriesDefinitionExtended_Symbol_iterator
      == seriesDefinitionExtended_Symbol.end()) {
    return false;
  }

  return true;
}

bool ClientToolScreenHeader::getNextCommodityCodeMatch
(uint16_t commodityCode, string& symbol) {
  const MultiIndexContainer::SeriesDefinitionExtended_CommodityCode_Symbol&
    seriesDefinitionExtended_CommodityCode_Symbol
    = gpMultiIndexContainer->mSeriesDefinitionExtendedContainer
    .get<MultiIndexContainer::seriesDefinitionExtended_CommodityCode_Symbol>();

  if (mSeriesDefinitionExtended_CommodityCode_Symbol_iterator
      == seriesDefinitionExtended_CommodityCode_Symbol.end()) {
    return false;
  }

  MultiIndexContainer::SeriesDefinitionExtended seriesDefinitionExtended
    = *mSeriesDefinitionExtended_CommodityCode_Symbol_iterator;
  if (seriesDefinitionExtended.mCommodityCode != commodityCode) {
    return false;
  }

  symbol = seriesDefinitionExtended.mSymbol;
  mSeriesDefinitionExtended_CommodityCode_Symbol_iterator++;
  return true;
}
bool ClientToolScreenHeader::getNextOrderBookIDMatch
(uint32_t orderBookID, string& symbol) {

  gpGlobal->mCurOrderBookID_ = orderBookID;

  const MultiIndexContainer::SeriesDefinitionBase_OrderBookID_Symbol&
    seriesDefinitionBase_OrderBookID_Symbol
    = gpMultiIndexContainer->mSeriesDefinitionBaseContainer
    .get<MultiIndexContainer::seriesDefinitionBase_OrderBookID_Symbol>();

  if (mSeriesDefinitionBase_OrderBookID_Symbol_iterator
      == seriesDefinitionBase_OrderBookID_Symbol.end()) {
    return false;
  }

  MultiIndexContainer::SeriesDefinitionBase seriesDefinitionBase
    = *mSeriesDefinitionBase_OrderBookID_Symbol_iterator;
  if (seriesDefinitionBase.mOrderBookID != orderBookID) {
    return false;
  }

  symbol = seriesDefinitionBase.mSymbol;
  mSeriesDefinitionBase_OrderBookID_Symbol_iterator++;
  return true;
}

bool ClientToolScreenHeader::getNextMarketMatch
(uint8_t market, string& symbol) {
  const MultiIndexContainer::SeriesDefinitionExtended_Market_Symbol&
    seriesDefinitionExtended_Market_Symbol
    = gpMultiIndexContainer->mSeriesDefinitionExtendedContainer
    .get<MultiIndexContainer::seriesDefinitionExtended_Market_Symbol>();

  if (mSeriesDefinitionExtended_Market_Symbol_iterator
      == seriesDefinitionExtended_Market_Symbol.end()) {
    return false;
  }

  MultiIndexContainer::SeriesDefinitionExtended seriesDefinitionExtended
    = *mSeriesDefinitionExtended_Market_Symbol_iterator;
  if (seriesDefinitionExtended.mMarket != market) {
    return false;
  }

  symbol = seriesDefinitionExtended.mSymbol;
  mSeriesDefinitionExtended_Market_Symbol_iterator++;
  return true;
}

bool ClientToolScreenHeader::getNextSymbolMatch
(string inputSymbol, string& symbol) {
  const MultiIndexContainer::SeriesDefinitionExtended_Symbol&
    seriesDefinitionExtended_Symbol
    = gpMultiIndexContainer->mSeriesDefinitionExtendedContainer
    .get<MultiIndexContainer::seriesDefinitionExtended_Symbol>();

  if (mSeriesDefinitionExtended_Symbol_iterator
      == seriesDefinitionExtended_Symbol.end()) {
    return false;
  } 

  MultiIndexContainer::SeriesDefinitionExtended seriesDefinitionExtended
    = *mSeriesDefinitionExtended_Symbol_iterator;
  if (seriesDefinitionExtended.mSymbol != inputSymbol) {
    return false;
  }

  symbol = seriesDefinitionExtended.mSymbol;
  mSeriesDefinitionExtended_Symbol_iterator++;
  return true;
}

bool ClientToolScreenHeader::getNextInstrumentGroupMatch
(uint8_t instrumentGroup, string& symbol) {
  const MultiIndexContainer::SeriesDefinitionExtended_InstrumentGroup_Symbol&
    seriesDefinitionExtended_InstrumentGroup_Symbol
    = gpMultiIndexContainer->mSeriesDefinitionExtendedContainer
    .get<MultiIndexContainer::seriesDefinitionExtended_InstrumentGroup_Symbol>();

  if (mSeriesDefinitionExtended_InstrumentGroup_Symbol_iterator
      == seriesDefinitionExtended_InstrumentGroup_Symbol.end()) {
    return false;
  }

  MultiIndexContainer::SeriesDefinitionExtended seriesDefinitionExtended
    = *mSeriesDefinitionExtended_InstrumentGroup_Symbol_iterator;
  if (seriesDefinitionExtended.mInstrumentGroup != instrumentGroup) {
    return false;
  }

  symbol = seriesDefinitionExtended.mSymbol;
  mSeriesDefinitionExtended_InstrumentGroup_Symbol_iterator++;
  return true;
}

void ClientToolScreenHeader::setNotice(string msg)
{
    setFieldBuffer(NOTICE_ENTRY, msg);
}
