#include "NcursesWrapper.h"

using namespace std;

NcursesWrapper::NcursesWrapper(Logger& logger)
  : mLogger(logger) {
}

NcursesWrapper::~NcursesWrapper() {
}

FIELD* NcursesWrapper::current_field(const FORM * form) {
  return ::current_field(form);
}

WINDOW* NcursesWrapper::derwin
(WINDOW *orig, int nlines, int ncols, int begin_y, int begin_x) {
  WINDOW* pWin = ::derwin(orig, nlines, ncols, begin_y, begin_x);
  if (!pWin) {
    ::ErrorHandler::print(mLogger, "derwin", true);
  }
  return pWin;
}

int NcursesWrapper::form_driver(FORM *form, int c) {
  ostringstream oss;

  errno = ::form_driver(form, c);
  if (errno != E_OK) {
    oss << "form_driver:" << c << ", errno:" << errno;
    ::ErrorHandler::print(mLogger, oss.str().c_str(), true);
    echo();
    endwin();
  }
  return errno;
}

FIELD* NcursesWrapper::new_field
(int height, int width, int toprow, int leftcol, int offscreen, int nbuffers) {
  FIELD* pField
    = ::new_field(height, width, toprow, leftcol, offscreen, nbuffers);
  if (!pField) {
    ::ErrorHandler::print(mLogger, "new_field", true);
  }
  return pField;
}

FORM* NcursesWrapper::new_form(FIELD **fields) {
  FORM* pForm = ::new_form(fields);
  if (!pForm) {
    ::ErrorHandler::print(mLogger, "new_form", true);
  }
  return pForm;
}

WINDOW* NcursesWrapper::newwin
(int nlines, int ncols, int begin_y, int begin_x) {
  WINDOW* pWin = ::newwin(nlines, ncols, begin_y, begin_x);
  if (!pWin) {
    ::ErrorHandler::print(mLogger, "new_win", true);
  }
  return pWin;
}

int NcursesWrapper::post_form(FORM *form) {
  errno = ::post_form(form);
  if (errno != E_OK) {
    ::ErrorHandler::print(mLogger, "post_form", true);
  }
  return errno;
}

int NcursesWrapper::scale_form(const FORM *form, int *rows, int *columns) {
  errno = ::scale_form(form, rows, columns);
  if (errno != E_OK) {
    ::ErrorHandler::print(mLogger, "scale_form", true);
  }
  return errno;
}

int NcursesWrapper::set_field_buffer(FIELD *field, int buf, const char *value) {
  int retVal = ::set_field_buffer(field, buf, value);
  if (!retVal && errno != E_OK) {
    ::ErrorHandler::print(mLogger, "set_field_buffer", true);
  }
  return retVal;
}
