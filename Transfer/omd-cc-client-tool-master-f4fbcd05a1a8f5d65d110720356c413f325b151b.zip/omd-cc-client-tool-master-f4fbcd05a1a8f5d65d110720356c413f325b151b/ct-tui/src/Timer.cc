#include "Timer.h"

Timer::Timer
(Logger& logger, void (*pFunc)(union sigval), void* pArg
 , struct timespec* it_value, struct timespec* it_interval)
  : mLogger(logger) {
  struct sigevent sig;
  memset(&sig, 0, sizeof(sig));
  sig.sigev_notify = SIGEV_THREAD;
  mArg.pTimer = this;
  mArg.pArg = pArg;
  sig.sigev_value.sival_ptr = &mArg;
  sig.sigev_notify_function = pFunc;

  pthread_attr_t attr;
  if (pthread_attr_init(&attr) != 0) {
    LOG4_ERR(mLogger, "pthread_attr_init error:" << errno);
  }

  if (pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED) != 0) {
    LOG4_ERR(mLogger, "pthread_attr_setdetachstate error:" << errno);
  }

  sig.sigev_notify_attributes = &attr;

  long ret = timer_create(CLOCK_REALTIME, &sig, &mCreated_timer_id);
  if (ret == 0) {
    struct itimerspec in, out;
    in.it_value = *it_value;
    if (it_interval) {
      in.it_interval = *it_interval;
    } else {
      memset(&in.it_interval, 0, sizeof(in.it_interval));
    }
    ret = timer_settime(mCreated_timer_id, 0, &in, &out);
    if(ret != 0) {
      LOG4_ERR(mLogger, "timer_settime() failed with " << errno);
      mTimerCreated = false;
      return;
    }
  } else {
      LOG4_ERR(mLogger, "timer_create() failed with " << errno);
      mTimerCreated = false;
      return;
  }
  mTimerCreated = true;
}

Timer::~Timer() {
  if (!mTimerCreated) {
    return;
  }

  if (timer_delete(mCreated_timer_id) != 0) {
    LOG4_ERR(mLogger, "timer_delete() failed with " << errno);
  }
}
