#include "ClientToolScreenQuit.h"

ClientToolScreenQuit::ClientToolScreenQuit(Logger& logger)
  : ClientToolScreen(logger) {
  mScreen = Common::QUIT_SCREEN;
  int formIndex = 0;
  int fieldIndex;

  int row;
  row = 1;

  FIELD** ppField = gpGlobal->mpField[mScreen][formIndex];

  fieldIndex = TITLE_LABEL;
  newField(ppField, fieldIndex, 1, 17, row, 1, 0, 0, "Quit Client Tool ",
                 NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
 
  row=3;

  fieldIndex = CONFIRM_LABEL;
  newField(ppField, fieldIndex, 1, 17, row, 1, 0, 0, "Confirm to quit? ", 
		 NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);

  fieldIndex = CONFIRM_ENTRY;
  newField(ppField, fieldIndex, 1, 1, row, 18, 0, 0, "", NO_JUSTIFICATION
	   , 0, O_AUTOSKIP, A_UNDERLINE | A_BOLD);

  static wchar_t* rows[MAX_FORM_ROWS] = {
    (wchar_t*)L"",
    0
  };

  for (int i=1; i<MAX_FORM_ROWS-1; i++) {
    if (rows[i-1]) {
      memcpy(&ch[i][1], rows[i-1], sizeof(wchar_t) * wcslen(rows[i-1]));
    }
  }
}

ClientToolScreenQuit::~ClientToolScreenQuit() {
}

void ClientToolScreenQuit::createForms()
{
  int formIndex;

  {
    formIndex = 0;

    FORM* pForm = mpNcursesWrapper->new_form(gpGlobal->mpField[mScreen][formIndex]);
    gpGlobal->mpForm[mScreen][formIndex] = pForm;

    WINDOW* pFormWin
      = mpNcursesWrapper->newwin
      (MAX_FORM_ROWS, MAX_FORM_COLS, MAX_HEADER_ROWS+MAX_MENU_ROWS, 0);
    gpGlobal->mpFormWin[mScreen][formIndex] = pFormWin;
    set_form_win(pForm, pFormWin);

    WINDOW* pFormSub
      = mpNcursesWrapper->derwin(pFormWin, MAX_FORM_ROWS, MAX_FORM_COLS, 0, 0);
    gpGlobal->mpFormSub[mScreen][formIndex] = pFormSub;
    set_form_sub(pForm, pFormSub);
    mpFormSub[0] = pFormSub;

    mpNcursesWrapper->post_form(pForm);
  }
}

void ClientToolScreenQuit::printFieldLabels() {
  WINDOW* pFormSub = mpFormSub[0];

//  box(pFormSub, 0, 0);

  wborder(pFormSub,
        COLOR_PAIR(Common::GREEN_BLACK_COLOR_PAIR) | A_BOLD | ACS_VLINE,
        COLOR_PAIR(Common::GREEN_BLACK_COLOR_PAIR) | A_BOLD | ACS_VLINE,
        COLOR_PAIR(Common::GREEN_BLACK_COLOR_PAIR) | A_BOLD | ACS_HLINE,
        COLOR_PAIR(Common::GREEN_BLACK_COLOR_PAIR) | A_BOLD | ACS_HLINE,
        COLOR_PAIR(Common::GREEN_BLACK_COLOR_PAIR) | A_BOLD | ACS_ULCORNER,
        COLOR_PAIR(Common::GREEN_BLACK_COLOR_PAIR) | A_BOLD | ACS_URCORNER,
        COLOR_PAIR(Common::GREEN_BLACK_COLOR_PAIR) | A_BOLD | ACS_LLCORNER,
        COLOR_PAIR(Common::GREEN_BLACK_COLOR_PAIR) | A_BOLD | ACS_LRCORNER);

  set_menu_fore(gpGlobal->mpMenu, COLOR_PAIR(Common::WHITE_GREEN_COLOR_PAIR) | A_BOLD);
  post_menu(gpGlobal->mpMenu);
  wrefresh(gpGlobal->mpMenuWin);

  //mvwaddstr(pFormSub, 1, 1, "Quit Client Tool");
}


void ClientToolScreenQuit::clearScr(uint16_t msgType, uint16_t side) {}

void ClientToolScreenQuit::updateScr
(uint16_t msgSize, uint16_t msgType, char* pMsgData, Common::Source source) {
  switch (msgType) {
  default:
    break;
  } // switch
}

void ClientToolScreenQuit::refresh() {
  Common::Source source=Common::CACHE_SOURCE;
}

void ClientToolScreenQuit::processChar(int ch) {
  printFieldLabels();

  MEVENT event;
  
  int formIndex = 0;
  FORM*& pForm = gpGlobal->mpForm[mScreen][formIndex];

  switch (ch) {
  case KEY_BACKSPACE: {
    FIELD* pCurrentField = mpNcursesWrapper->current_field(pForm);
    char* buffer = field_buffer(pCurrentField, 0);
    FIELD** ppField = gpGlobal->mpField[mScreen][formIndex];

    int bufferLen = -1;
    if (pCurrentField == ppField[CONFIRM_ENTRY]) {
      bufferLen = 1;
    }

    if (bufferLen != -1) {
      //LOG4_DEBUG(mLogger, "bufferLen:" << bufferLen);
      if (buffer[bufferLen-1] == ' ') {
	mpNcursesWrapper->form_driver(pForm, REQ_DEL_PREV);
      } else {
	mpNcursesWrapper->form_driver(pForm, REQ_DEL_CHAR);
      }
      mpNcursesWrapper->form_driver(pForm, REQ_END_FIELD);
    }
    break;
  }
  case KEY_LEFT:
  case KEY_RIGHT: {
    break;
  }
  default: {
    int retVal;
    if ('a' <= ch && ch <= 'z') {
      ch = toupper(ch);
    }
    if (ch != 'Y' &&  ch !='N') {
      return;
    }

    if (ch == ' ') {
      retVal = form_driver(pForm, REQ_RIGHT_CHAR);
    } else {
      retVal = form_driver(pForm, ch);
      mpNcursesWrapper->form_driver(pForm, REQ_END_FIELD);
    } 

    if (retVal == E_REQUEST_DENIED) {
      // Do nothing
    }
    break;
  }
  } // switch
}
