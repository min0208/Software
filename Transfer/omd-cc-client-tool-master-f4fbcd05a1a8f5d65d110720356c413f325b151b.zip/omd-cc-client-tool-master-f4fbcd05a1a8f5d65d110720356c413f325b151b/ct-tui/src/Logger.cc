#ifndef LOG4CPLUS

#include "ErrorHandler.h"
#include "Logger.h"

Logger::Logger() {
	mpOfstream = 0;
	memset(&mTpLast, 0, sizeof(mTpLast));
}

//Logger::Logger(string loggerName) {
Logger::Logger(string loggerName, bool bCSV) {
	// mMutex = PTHREAD_MUTEX_INITIALIZER;
	pthread_mutex_init(&mMutex, NULL);

	//By Louis 2013-06-13 ------------------------------------------------
	char sysCmd[30];
	time_t t = time(NULL);  
	strftime(sysCmd, sizeof(sysCmd), "mkdir -p -m 750 ./log/%Y%m%d/", localtime(&t));

	char folderName[17];
	strftime(folderName, sizeof(folderName), "./log/%Y%m%d/", localtime(&t));

	// char sysCmd[40];
	// time_t t = time(NULL);  
	// strftime(sysCmd, sizeof(sysCmd), "mkdir -m 755 ../log/%Y%m%d/", localtime(&t));

	// char folderName[25];
	// strftime(folderName, sizeof(folderName), "../log/%Y%m%d/", localtime(&t));    
	//sprintf(&folderName[16], "P%d/", iIdx);
	//sprintf(&mDateFolder[9], "P%d/", iIdx); 

	if (!DirectoryExists(folderName))  
		system(sysCmd);

	ostringstream oss;
	if (bCSV)
	{
		oss << folderName << loggerName << ".csv";
	}
	else
	{
		oss << folderName << loggerName << ".log";
	}
	//oss << loggerName << ".log";
	//--------------------------------------------------------------------
	mpOfstream = new ofstream();
	mpOfstream->open(oss.str().c_str(), ios_base::out | ios_base::app);
}

Logger::~Logger() {
	// mpOfstream->close();
	// delete mpOfstream;
	// mpOfstream = 0;
}

void Logger::lock() {
	errno = pthread_mutex_lock(&mMutex);
	if (errno) {
		::ErrorHandler::print(*this, "pthread_mutex_lock", true);
	}
}

void Logger::unlock() {
	errno = pthread_mutex_unlock(&mMutex);
	if (errno) {
		::ErrorHandler::print(*this, "pthread_mutex_unlock", true);
	}
}

Logger Logger::getInstance(string loggerName) {
	return *(new Logger(loggerName));
}

Logger Logger::getInstanceCSV(string loggerName) {
	return *(new Logger(loggerName, true));
}

ofstream* Logger::getOfstream() {
	if (!mpOfstream->is_open()) {
		return 0;
	}
	return mpOfstream;
}

string Logger::getPrefix(int level) {
	struct timespec tp;
	if (clock_gettime(CLOCK_REALTIME, &tp) == -1) {
		::ErrorHandler::print(*this, "clock_gettime()", true);
	}

	if (tp.tv_sec != mTpLast.tv_sec) {
		mTpLast.tv_sec = tp.tv_sec;

		localtime_r(&tp.tv_sec, &mCurrentTime);

		if (level==LOG_USER)
		{
			if (!strftime(mCurrentTimeStr, sizeof(mCurrentTimeStr), "%H:%M:%S"
						, &mCurrentTime)) {
				::ErrorHandler::print(*this, "strftime()", true);
			}
		}
		else
		{
			if (!strftime(mCurrentTimeStr, sizeof(mCurrentTimeStr), "%Y-%m-%d %H:%M:%S"
						, &mCurrentTime)) {
				::ErrorHandler::print(*this, "strftime()", true);
			}
		}
	}  

	ostringstream oss;
	if (level==LOG_AUTH)
	{
		oss << "";
	}
	else if (level==LOG_USER)
	{
		// oss << mCurrentTimeStr << "."
		// << setfill('0') << setw(3) << tp.tv_nsec/1000000;
		oss << "\"" << mCurrentTimeStr << "."
			<< setfill('0') << setw(3) << tp.tv_nsec/1000000 << "\"";
	}
	else
	{  
		oss << mCurrentTimeStr << "."
			<< setfill('0') << setw(3) << tp.tv_nsec/1000000
			<< " [" << pthread_self() << "] ";
	}
	switch (level) {
		case LOG_DEBUG: {
					oss << "DEBUG ";
					break;
				}
		case LOG_INFO: {
				       oss << "INFO ";
				       break;
			       }
		case LOG_NOTICE: {
					 oss << "NOTICE ";
					 break;
				 }
		case LOG_WARNING: {
					  oss << "WARNING ";
					  break;
				  }
		case LOG_ERR: {
				      oss << "ERR ";
				      break;
			      }
		case LOG_CRIT: {
				       oss << "CRIT ";
				       break;
			       }
		case LOG_ALERT: {
					oss << "ALERT ";
					break;
				}
		case LOG_EMERG: {
					oss << "EMERG ";
					break;
				}
		default: {
				 break;
			 }
	} // switch

	return oss.str();
}

bool Logger::DirectoryExists( const char* pzPath )
{
	if ( pzPath == NULL) return false;

	DIR *pDir;
	bool bExists = false;

	pDir = opendir (pzPath);

	if (pDir != NULL)
	{
		bExists = true;    
		(void) closedir (pDir);
	}

	return bExists;
}

#endif
