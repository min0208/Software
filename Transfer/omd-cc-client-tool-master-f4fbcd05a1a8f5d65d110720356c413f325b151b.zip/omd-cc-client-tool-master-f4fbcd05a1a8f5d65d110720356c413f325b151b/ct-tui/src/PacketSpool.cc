#include "PacketSpool.h"

#include <iostream>
#include <stdio.h>
#include <string.h>

#include "Common.h"
#include "../include/ClientToolStructs.h"

PacketSpool::PacketSpool(Logger& logger) : mLogger(logger) 
{
	pthread_mutex_init(&mMutexHeartbeat, NULL);

	mInitialized = false;
	mpPacketData = NULL;
	mNumPacketsSent = 0;
	mSockfd = -1;
}

void PacketSpool::init(int sockfd) 
{
	mInitialized = true;
	mSockfd = sockfd;
}

PacketSpool::~PacketSpool() 
{
}

void PacketSpool::addTcpMsg(Message* pMsg) 
{
	mpPacketData = new char[MAX_PACKET_SIZE];

	if ( pMsg->getMsgSize() > MAX_PACKET_SIZE )
	{
		LOG4_ERR(mLogger, "PacketSpool::addTcpMsg() - buffer size is not enough. request size=" << pMsg->getMsgSize() << " buffer size=" << MAX_PACKET_SIZE );
		return;
	}

	memset(mpPacketData, 0, MAX_PACKET_SIZE);
	memcpy(mpPacketData, pMsg->getMsgData(), pMsg->getMsgSize());

	if (mpPacketData) 
	{
		mPacketDeque.push_back(mpPacketData);
	}
}

bool PacketSpool::sendPacket(char* pPacketData) 
{
	ssize_t bytesSent = send(mSockfd, pPacketData, ((CTRequestHeader*)pPacketData)->mSize, 0);
	if (bytesSent < 0) 
	{
		::ErrorHandler::print(mLogger, "send", false);
		return false;
	} 
	else if (bytesSent == 0) 
	{
		LOG4_ERR(mLogger, "Connection Closed");
		return false;
	} 

	// throttle
	struct timespec req;
	req.tv_sec = 0;
	req.tv_nsec = 100000;
	nanosleep(&req, NULL);

	mNumPacketsSent++;
	return true;
}

bool PacketSpool::sendMsgs()
{
	if (!mInitialized) 
	{
		return false;
	}

	while (!mPacketDeque.empty()) 
	{
		char* pPacketData = mPacketDeque.front();

		if (sendPacket(pPacketData)) 
		{
			delete [] pPacketData;
			mPacketDeque.pop_front();
		} 
		else 
		{
			return false;
		}
	}

	return true;
}

void PacketSpool::dumpBuffer( const char* pBuf, int nBufSize )
{
	string sDisplay;
	char sTemp[ 32];

	sprintf( sTemp, "buf size|%d|", nBufSize );
	sDisplay = sTemp;

	for ( int i=0; i<nBufSize; i++ )
	{
		if ( i % 10 == 0 )
		{
			sDisplay += "\n";
		}

		sprintf( sTemp, "0x%02X ", (unsigned char)pBuf[ i] );
		sDisplay += sTemp;
	}

	//mLog->info() << "Dump: " << sDisplay << "\n";
	LOG4_INFO(mLogger, "Dump: " << sDisplay);
}

