// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include "Global.h"

Global* gpGlobal = 0;

Global::Global() {
}

void Global::init(int component, string loggerName) {

	char folderName[64], sysCmd[256];
	time_t t = time(NULL);

	strftime(folderName, sizeof(folderName), "./log/%Y%m%d/", localtime(&t));
	strftime(mDateFolder, sizeof(mDateFolder), "%Y%m%d/", localtime(&t));

	memcpy(sysCmd, "mkdir -p ", 9);
	memcpy(&sysCmd[9], folderName, 17);

	if (!DirectoryExists(folderName))
		system(sysCmd);

	mLogFilePath = folderName;

	LoggerSelector::createPropertiesFile();
	LoggerSelector::configure();

	thisComponent_ = component;

	ostringstream oss;
	if (component == Common::FEED_HANDLER_COMPONENT) {
		oss << mLogFilePath << loggerName << setfill('0') << setw(3) << mRealTimeChannelID;		
	} else {
		oss << loggerName;
	}
	mLogger = Logger::getInstance(oss.str().c_str());

	//By Louis 2013-07-11 ------------------------------------------------    
	if (component==Common::CLIENT_TOOL_COMPONENT)
	{
		//string	sTmp;
		char sTmp[20];	
		sprintf(sTmp, "P%d", gpGlobal->mProductIndex);
	}  
	for (uint32_t i=0; i<MAX_CHANNELS+1; i++)
	{
		uRFLastSeq[i] = 0;
		uRFTimes[i] = 0;
	}
	uRtsChID_ = 0;
	//--------------------------------------------------------------------  
	mRefreshScreen = 1;
	mSnapshotInterval = 1000;//ms;

	mRetRespTO = 50;
	mRetransActive = false;

	mRetThreshold = 500;
	mRetReconnectInterval = 5;
	mRetReconnectTimes = 5;

	mBinDecEnable = 1;
	mBinDecValidate = 1;
	mLogFileNameBinDec = "BinDec";

	mBinRawEnable = 1;
	mLogFileNameBinRawRealTime = "BinRawR";
	mLogFileNameBinRawRefresh = "BinRawF";
	mLogFileNameBinRawRetrans = "BinRawT";

	mHHMM = 1;
	mLogFileNameBinMiss = "BinMiss";

	memset(mCommodityCode, 0, sizeof(mCommodityCode));
	memset(mOrderBookID, 0, sizeof(mOrderBookID));
	memset(mMarketCode, 0, sizeof(mMarketCode));
	memset(mSymbol, 0, sizeof(mSymbol));
	memset(mInstrumentGroup, 0, sizeof(mInstrumentGroup));

	mMode = Common::DISCONNECTED_MODE;

	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(100, "Sequence Reset"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(101, "Logon"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(102, "Logon Response"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(201, "Retransmission Request"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(202, "Retransmission Response"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(203, "Refresh Complete"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(301, "Commodity Definition"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(302, "Class Definition"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(303, "Series Definition Base"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(304, "Series Definition Extended"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(305, "Combination Definition"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(320, "Market Status"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(321, "Series Status"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(322, "Commodity Status"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(330, "Add Order"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(331, "Modify Order"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(332, "Delete Order"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(355, "Top Of Book"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(353, "Aggregate Order Book Update"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(335, "OrderBook Clear"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(336, "Quote Request"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(350, "Trade"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(356, "Trade Amendment"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(360, "Trade Statistics"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(363, "Series Statistics"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(364, "Calculated Opening Price"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(365, "Estimated Average Settlement Price"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(323, "Market Alert"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(366, "Open Interest"));
	mMsgTypeMap.insert
		(FieldValueMapUint16::value_type(367, "Implied Volatility"));
	mRetransStatusMap.insert
		(FieldValueMapUint8::value_type(0, "Request accepted"));
	mRetransStatusMap.insert
		(FieldValueMapUint8::value_type(1, "Unknown/Unauthorized channel ID"));
	mRetransStatusMap.insert
		(FieldValueMapUint8::value_type(2, "Messages not available"));
	mRetransStatusMap.insert
		(FieldValueMapUint8::value_type(100, "Exceeds maximum sequence range"));
	mRetransStatusMap.insert
		(FieldValueMapUint8::value_type(101, "Exceeds maximum requests in a day"));
	mUnderlyingPriceUnitMap.insert
		(FieldValueMapUint8::value_type(1, "Price"));
	mUnderlyingPriceUnitMap.insert
		(FieldValueMapUint8::value_type(2, "Yield"));
	mUnderlyingPriceUnitMap.insert
		(FieldValueMapUint8::value_type(3, "Points"));
	mUnderlyingPriceUnitMap.insert
		(FieldValueMapUint8::value_type(4, "Yield Diff"));
	mUnderlyingPriceUnitMap.insert
		(FieldValueMapUint8::value_type(5, "IMM Index"));
	mUnderlyingPriceUnitMap.insert
		(FieldValueMapUint8::value_type(6, "Basis Points"));
	mUnderlyingPriceUnitMap.insert
		(FieldValueMapUint8::value_type(7, "Inverted Yield"));
	mUnderlyingPriceUnitMap.insert
		(FieldValueMapUint8::value_type(8, "Percentage of Nominal"));
	mUnderlyingPriceUnitMap.insert
		(FieldValueMapUint8::value_type(9, "Dirty Price"));
	mUnderlyingTypeMap.insert
		(FieldValueMapUint8::value_type(1, "Stock"));
	mUnderlyingTypeMap.insert
		(FieldValueMapUint8::value_type(2, "Currency"));
	mUnderlyingTypeMap.insert
		(FieldValueMapUint8::value_type(3, "Interest rate"));
	mUnderlyingTypeMap.insert
		(FieldValueMapUint8::value_type(4, "Energy"));
	mUnderlyingTypeMap.insert
		(FieldValueMapUint8::value_type(5, "Soft and Agrics"));
	mUnderlyingTypeMap.insert
		(FieldValueMapUint8::value_type(6, "Metal"));
	mUnderlyingTypeMap.insert
		(FieldValueMapUint8::value_type(7, "Stock Index"));
	mUnderlyingTypeMap.insert
		(FieldValueMapUint8::value_type(8, "Currency Index"));
	mUnderlyingTypeMap.insert
		(FieldValueMapUint8::value_type(9, "Interest Rate Index"));
	mUnderlyingTypeMap.insert
		(FieldValueMapUint8::value_type(10, "Energy Index"));
	mUnderlyingTypeMap.insert
		(FieldValueMapUint8::value_type(11, "Softs and Agrics Index"));
	mUnderlyingTypeMap.insert
		(FieldValueMapUint8::value_type(12, "Metal Index"));
	mEffectiveTomorrowMap.insert
		(FieldValueMapUint8::value_type(0, "False"));
	mEffectiveTomorrowMap.insert
		(FieldValueMapUint8::value_type(1, "True"));
	mMarketMap.insert
		(FieldValueMapUint8::value_type(2, "Stock Futures"));
	mMarketMap.insert
		(FieldValueMapUint8::value_type(3, "Three-Year Exchange Fund Note Futures"));
	mMarketMap.insert
		(FieldValueMapUint8::value_type(8, "Gold Futures"));
	mMarketMap.insert
		(FieldValueMapUint8::value_type(16, "Mini Hang Seng Index Futures / Options"));
	mMarketMap.insert
		(FieldValueMapUint8::value_type(20, "Stock Options"));
	mMarketMap.insert
		(FieldValueMapUint8::value_type(24, "HIBOR"));
	mMarketMap.insert
		(FieldValueMapUint8::value_type(27, "HSI Dividend Point Index Futures, HSCEI Dividend Point Index Futures"));
	mMarketMap.insert
		(FieldValueMapUint8::value_type(34, "Hang Seng Index Futures / Options"));
	mMarketMap.insert
		(FieldValueMapUint8::value_type(35, "Flexible Hang Seng Index Options"));
	mMarketMap.insert
		(FieldValueMapUint8::value_type(37, "Flexible H-shares Index Options"));
	mMarketMap.insert
		(FieldValueMapUint8::value_type(38, "H-shares Index Futures / Options"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(4, "Futures"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(6, "Call (American style)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(7, "Put (American style)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(22, "Call (European style)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(23, "Put (European style)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(170, "Options Straddle"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(171, "Options Strangle"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(172, "Standard Combination series for Stock Options Market (SOM) – Synthetic Futures"));

	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(201, "Time Spread (level=01)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(202, "Time Spread (level=02)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(203, "Time Spread (level=03)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(204, "Time Spread (level=04)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(205, "Time Spread (level=05)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(206, "Time Spread (level=06)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(207, "Time Spread (level=07)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(208, "Time Spread (level=08)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(209, "Time Spread (level=09)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(210, "Time Spread (level=10)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(211, "Time Spread (level=11)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(212, "Time Spread (level=12)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(213, "Time Spread (level=13)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(214, "Time Spread (level=14)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(215, "Time Spread (level=15)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(216, "Time Spread (level=16)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(217, "Time Spread (level=17)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(218, "Time Spread (level=18)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(219, "Time Spread (level=19)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(220, "Time Spread (level=20)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(221, "Time Spread (level=21)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(222, "Time Spread (level=22)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(223, "Time Spread (level=23)"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(250, "TMC"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(254, "Exchange Rate"));
	mInstrumentGroupMap.insert
		(FieldValueMapUint8::value_type(255, "Payment Currency"));	
	mModifierMap.insert
		(FieldValueMapUint8::value_type(0, "New"));
	mRankingTypeMap.insert
		(FieldValueMapUint16::value_type(1, "Price, Time"));
	mRankingTypeMap.insert
		(FieldValueMapUint16::value_type(2, "Inverted Price, Time"));
	mRankingTypeMap.insert
		(FieldValueMapUint16::value_type(3, "Price, Traders before MM, Time"));
	mRankingTypeMap.insert
		(FieldValueMapUint16::value_type(4, "Inverted Price, Traders before MM, Time"));
	mRankingTypeMap.insert
		(FieldValueMapUint16::value_type(5, "Price, MM before Traders, Time"));
	mRankingTypeMap.insert
		(FieldValueMapUint16::value_type(6, "Inverted Price, MM before Traders, Time"));
	mRankingTypeMap.insert
		(FieldValueMapUint16::value_type(7, "Price, Baits before Normal Orders, Time"));
	mRankingTypeMap.insert
		(FieldValueMapUint16::value_type(8, "Inverted Price, Baits before Normal Orders, Time"));
	mRankingTypeMap.insert
		(FieldValueMapUint16::value_type(11, "Price, Own Orders, Time"));
	mRankingTypeMap.insert
		(FieldValueMapUint16::value_type(12, "Inverted Price, Own Orders, Time"));
	mTradableMap.insert
		(FieldValueMapUint8::value_type(1, "Yes"));
	mTradableMap.insert
		(FieldValueMapUint8::value_type(2, "No"));
	mPremiumUnit4PriceMap.insert
		(FieldValueMapUint8::value_type(1, "Price"));
	mPremiumUnit4PriceMap.insert
		(FieldValueMapUint8::value_type(2, "Yield"));
	mPremiumUnit4PriceMap.insert
		(FieldValueMapUint8::value_type(3, "Points"));
	mPremiumUnit4PriceMap.insert
		(FieldValueMapUint8::value_type(4, "Yield Diff"));
	mPremiumUnit4PriceMap.insert
		(FieldValueMapUint8::value_type(5, "IMM Index"));
	mPremiumUnit4PriceMap.insert
		(FieldValueMapUint8::value_type(6, "Basis Points"));
	mPremiumUnit4PriceMap.insert
		(FieldValueMapUint8::value_type(7, "Inverted Yield"));
	mPremiumUnit4PriceMap.insert
		(FieldValueMapUint8::value_type(8, "Percentage of Nominal"));
	mPremiumUnit4PriceMap.insert
		(FieldValueMapUint8::value_type(9, "Dirty Price"));
	mIsFractionsMap.insert
		(FieldValueMapChar::value_type('Y', "Yes"));
	mIsFractionsMap.insert
		(FieldValueMapChar::value_type('N', "No"));
	mFinancialProductMap.insert
		(FieldValueMapUint8::value_type(1, "Option"));
	mFinancialProductMap.insert
		(FieldValueMapUint8::value_type(2, "Forward"));
	mFinancialProductMap.insert
		(FieldValueMapUint8::value_type(3, "Future"));
	mFinancialProductMap.insert
		(FieldValueMapUint8::value_type(4, "FRA"));
	mFinancialProductMap.insert
		(FieldValueMapUint8::value_type(5, "Cash"));
	mFinancialProductMap.insert
		(FieldValueMapUint8::value_type(6, "Payment"));
	mFinancialProductMap.insert
		(FieldValueMapUint8::value_type(7, "Exchange Rate"));
	mFinancialProductMap.insert
		(FieldValueMapUint8::value_type(8, "Interest Rate Swap"));
	mFinancialProductMap.insert
		(FieldValueMapUint8::value_type(9, "REPO"));
	mFinancialProductMap.insert
		(FieldValueMapUint8::value_type(10, "Synthetic Box Leg/Reference"));
	mFinancialProductMap.insert
		(FieldValueMapUint8::value_type(11, "Standard Combination"));
	mFinancialProductMap.insert
		(FieldValueMapUint8::value_type(12, "Guarantee"));
	mFinancialProductMap.insert
		(FieldValueMapUint8::value_type(13, "OTC General"));
	mFinancialProductMap.insert
		(FieldValueMapUint8::value_type(14, "Equity Warrant"));
	mFinancialProductMap.insert
		(FieldValueMapUint8::value_type(15, "Security Lending"));
	mPutOrCallMap.insert
		(FieldValueMapUint8::value_type(0, "Undefined"));
	mPutOrCallMap.insert
		(FieldValueMapUint8::value_type(1, "Call"));
	mPutOrCallMap.insert
		(FieldValueMapUint8::value_type(2, "Put"));
	mSeriesStatusMap.insert
		(FieldValueMapUint8::value_type(1, "Active (both expired and not expired)"));
	mSeriesStatusMap.insert
		(FieldValueMapUint8::value_type(2, "Suspended (temporarily stopped)"));
	mSeriesStatusMap.insert
		(FieldValueMapUint8::value_type(3, "Issued"));
	mSeriesStatusMap.insert
		(FieldValueMapUint8::value_type(4, "Delisted"));
	mLegSideMap.insert
		(FieldValueMapChar::value_type('B', "As Defined"));
	mLegSideMap.insert
		(FieldValueMapChar::value_type('C', "Opposite"));
	mStateLevelMap.insert
		(FieldValueMapUint16::value_type(1, "Market"));
	mStateLevelMap.insert
		(FieldValueMapUint16::value_type(2, "Instrument Type"));
	mStateLevelMap.insert
		(FieldValueMapUint16::value_type(3, "Instrument Class"));
	mStateLevelMap.insert
		(FieldValueMapUint16::value_type(4, "Instrument Series"));
	mStateLevelMap.insert
		(FieldValueMapUint16::value_type(5, "Underlying"));
	mStateLevelMap.insert
		(FieldValueMapUint16::value_type(99, "End of Business Day"));
	mStateMap.insert
		(FieldValueMapUint16::value_type(1, "OPEN ALLOCATION SESSION (Part of pre-opening phase, used for COP calculation)"));
	mStateMap.insert
		(FieldValueMapUint16::value_type(2, "TRADING HALT"));
	mStateMap.insert
		(FieldValueMapUint16::value_type(3, "RESUME"));
	mStateMap.insert
		(FieldValueMapUint16::value_type(4, "PREOPEN SESSION"));
	mStateMap.insert
		(FieldValueMapUint16::value_type(5, "PREOPEN ALLOCATION SESSION (Part of pre-opening phase, used for auction order input only)"));
	mStateMap.insert
		(FieldValueMapUint16::value_type(6, "MARKET PAUSE Note: Trade matching for pre-opening or lunch break"));
	mStateMap.insert
		(FieldValueMapUint16::value_type(7, "PRE-MARKET ACTIVITIES (It is applicable to markets without PREOPEN SESSION arrangement)"));
	mStateMap.insert
		(FieldValueMapUint16::value_type(8, "CLEARING SESSION START (Clearing activities can be started)"));
	mStateMap.insert
		(FieldValueMapUint16::value_type(9, "CLEARING SESSION CLOSED (Clearing activities are ended)"));
	mSuspendedMap.insert
		(FieldValueMapChar::value_type('Y', "Yes"));
	mSuspendedMap.insert
		(FieldValueMapChar::value_type('N', "No"));
	mOrderSideMap.insert
		(FieldValueMapUint8::value_type(0, "Bid"));
	mOrderSideMap.insert
		(FieldValueMapUint8::value_type(1, "Offer"));
	mLotTypeMap.insert
		(FieldValueMapUint8::value_type(0, "Undefined"));
	mLotTypeMap.insert
		(FieldValueMapUint8::value_type(1, "Odd Lot"));
	mLotTypeMap.insert
		(FieldValueMapUint8::value_type(2, "Round Lot"));
	mLotTypeMap.insert
		(FieldValueMapUint8::value_type(3, "Block Lot"));
	mLotTypeMap.insert
		(FieldValueMapUint8::value_type(4, "All or None Lot"));
	mOrderTypeMap.insert
		(FieldValueMapUint16::value_type(0, "Not applicable"));
	mOrderTypeMap.insert
		(FieldValueMapUint16::value_type(1, "Force"));
	mOrderTypeMap.insert
		(FieldValueMapUint16::value_type(2, "Short Sell"));
	mOrderTypeMap.insert
		(FieldValueMapUint16::value_type(4, "Market Bid"));
	mOrderTypeMap.insert
		(FieldValueMapUint16::value_type(8, "Price Stabilization"));
	mOrderTypeMap.insert
		(FieldValueMapUint16::value_type(16, "Override Crossing"));
	mOrderTypeMap.insert
		(FieldValueMapUint16::value_type(32, "Undisclosed"));
	mOrderTypeMap.insert
		(FieldValueMapUint16::value_type(1024, "Fill-and-kill immediately"));
	mOrderTypeMap.insert
		(FieldValueMapUint16::value_type(2048, "Firm color disabled"));
	mOrderTypeMap.insert
		(FieldValueMapUint16::value_type(4096, "Convert to aggressive (if locked market)"));
	mOrderTypeMap.insert
		(FieldValueMapUint16::value_type(8192, "Bait/implied order"));
	mUpdateActionMap.insert
		(FieldValueMapUint8::value_type(0, "New"));
	mUpdateActionMap.insert
		(FieldValueMapUint8::value_type(1, "Change"));
	mUpdateActionMap.insert
		(FieldValueMapUint8::value_type(2, "Delete"));
	mUpdateActionMap.insert
		(FieldValueMapUint8::value_type(74, "Clear"));
	mBidAskFlagMap.insert
		(FieldValueMapUint8::value_type(0, "Bid"));
	mBidAskFlagMap.insert
		(FieldValueMapUint8::value_type(1, "Ask"));
	mBidAskFlagMap.insert
		(FieldValueMapUint8::value_type(2, "Bid and Ask"));
	mTradeSideMap.insert
		(FieldValueMapUint8::value_type(0, "Not Available"));
	mTradeSideMap.insert
		(FieldValueMapUint8::value_type(1, "Not Defined"));
	mTradeSideMap.insert
		(FieldValueMapUint8::value_type(2, "Buy Order"));
	mTradeSideMap.insert
		(FieldValueMapUint8::value_type(3, "Sell Order"));
	mDealTypeMap.insert
		(FieldValueMapUint8::value_type(0, "None"));
	mDealTypeMap.insert
		(FieldValueMapUint8::value_type(1, "Printable"));
	mDealTypeMap.insert
		(FieldValueMapUint8::value_type(2, "Occurred at Cross"));
	mDealTypeMap.insert
		(FieldValueMapUint8::value_type(4, "Reported Trade"));
	mTradeConditionMap.insert
		(FieldValueMapUint16::value_type(0, "None"));
	mTradeConditionMap.insert
		(FieldValueMapUint16::value_type(1, "Late Trade"));
	mTradeConditionMap.insert
		(FieldValueMapUint16::value_type(2, "Internal Trade / Crossing"));
	mTradeConditionMap.insert
		(FieldValueMapUint16::value_type(8, "Buy Write"));
	mTradeConditionMap.insert
		(FieldValueMapUint16::value_type(16, "Off Market"));
	mDealInfoMap.insert
		(FieldValueMapUint16::value_type(0, "None"));
	mDealInfoMap.insert
		(FieldValueMapUint16::value_type(1, "Reported Trade"));
	mDealInfoMap.insert
		(FieldValueMapUint16::value_type(2, "All or none"));
	mDealInfoMap.insert
		(FieldValueMapUint16::value_type(4, "Part of combo match"));
	mTradeStateMap.insert
		(FieldValueMapUint8::value_type(0, ""));
	mTradeStateMap.insert
		(FieldValueMapUint8::value_type(2, "Rectified. The trade has been rectified."));
	mTradeStateMap.insert
		(FieldValueMapUint8::value_type(3, "Deleted. The trade has been deleted."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(0, "Internal use. Trades reported directly to the clearing subsystem."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(1, "Matched by system, automatically."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(2, "Matched by system, manually."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(3, "Matched Outside Exchange, Different participants"));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(4, "Matched outside exchange, different brokers, reg. by exchange."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(5, "Matched Outside Exchange, One participant"));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(6, "Matched outside exchange, one broker, reg. by exchange."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(7, "Combination order matched against another combination order when matched by the Exchange, electronically."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(8, "Deal in a Swap Box instrument."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(9, "Matched electronically, member internal."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(10, "Deal in a Swap Box instrument, member internal."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(11, "After market closure, outside system, different brokers"));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(12, "After market closure, outside system, different brokers, registered by the exchange."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(13, "After market closure, outside system, one broker"));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(14, "After market closure, outside system, one broker, registered by the exchange."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(15, "Internally created basis trade."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(16, "Reversing deal made by the exchange manually."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(17, "Reversing deal made by the exchange manually."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(18, "Basis trade."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(19, "Internally created."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(20, "Deal made at the end of an auction."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(21, "Private request for quote."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(22, "Package private request for quote."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(23, "Internally from combo."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(24, "Internally from TM."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(25, "Internally from average."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(26, "Internally from strip."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(27, "Delta hedge."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(28, "CL bundle deal."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(32, "Trade from Bulletin Board."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(33, "Trade from Bulletin Board, standard combo."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(34, "Trade from Bulletin Board, non-standard combo."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(35, "Trade from Bulletin Board, non-standard combo."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(36, "Tailor-made combination."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(37, "Non-standard combination."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(38, "Outside the Exchange, block trade facility."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(39, "Matched outside the Exchange, combinations."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(40, "Outside the Exchange, block trade facility."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(41, "No Deal Price."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(42, "Priority crossing."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(43, "Combination matched outright legs."));
	mDealSourceMap.insert
		(FieldValueMapUint8::value_type(44, "Matched outside exchange, broker."));
	mSessionMap.insert
		(FieldValueMapUint8::value_type(0, "Statistics for T Session"));
	mSessionMap.insert
		(FieldValueMapUint8::value_type(1, "Statistics for T+1 Session"));
	mEASTypeMap.insert
		(FieldValueMapChar::value_type('E', "Stock EAS"));
	mEASTypeMap.insert
		(FieldValueMapChar::value_type('H', "Hang Seng family of Indices EAS"));
	mLastFragmentMap.insert
		(FieldValueMapChar::value_type('Y', " Complete"));
	mLastFragmentMap.insert
		(FieldValueMapChar::value_type('N', " Not complete"));
	mInfoTypeMap.insert
		(FieldValueMapUint8::value_type(0, " Not Specified"));
	mInfoTypeMap.insert
		(FieldValueMapUint8::value_type(1, " Company Announcement"));
	mInfoTypeMap.insert
		(FieldValueMapUint8::value_type(2, " Market Message"));
	mInfoTypeMap.insert
		(FieldValueMapUint8::value_type(3, " Static Line"));
	mInfoTypeMap.insert
		(FieldValueMapUint8::value_type(4, " Notice Received"));
	mPriorityMap.insert
		(FieldValueMapUint8::value_type(0, " Not Specified"));
	mPriorityMap.insert
		(FieldValueMapUint8::value_type(1, " Low priority"));
	mPriorityMap.insert
		(FieldValueMapUint8::value_type(2, " Medium priority"));
	mPriorityMap.insert
		(FieldValueMapUint8::value_type(3, " High priority"));
	mPriorityMap.insert
		(FieldValueMapUint8::value_type(4, " Critical priority"));
	mDayIndicatorMap.insert
		(FieldValueMapUint16::value_type(0, "Previous Trading Day"));
	mDayIndicatorMap.insert
		(FieldValueMapUint16::value_type(1, "Current Trading Day"));

	memset(mpField, 0, sizeof(mpField));
	memset(mpForm, 0, sizeof(mpForm));
	memset(mpFormWin, 0, sizeof(mpFormWin));
	memset(mpFormSub, 0, sizeof(mpFormSub));

	mReadBufferTcpClientOffset = 0;
	mReadBufferTcpServerOffset = 0; 
}

Global::~Global() {
}

/*
 * printHelp()2
 * -----------
 * Information about command line options
 */
void Global::printHelp() {
	cout << "NGMDS Feed Handler" << endl << endl;

	cout << "OPTIONS" << endl;

	cout << "       -h" << endl;
	cout << "              Display this help message" << endl; 
	cout << endl;

	cout << "       --" << PRODUCT_INDEX << endl;
	cout << "              Product index" << endl; 
	cout << "              e.g. 6,8" << endl; 
	cout << endl;

	cout << "       --" << CHANNEL_ID << endl;
	cout << "              Channel ID" << endl; 
	cout << "              e.g. " << mRealTimeChannelID << endl; 
	cout << endl;
}

/*
 * parseCommandLine()
 * ------------------
 * Set various options. If any aren't given, default value is used.
 */
bool Global::parseCommandLine(int argc, char** argv) {
	int c = 0;

	int longindex = 0;
	static struct option longopts[] = {
		{PRODUCT_INDEX,    required_argument, 0,  0 },
		{CHANNEL_ID,       required_argument, 0,  0 },
                {CONFIG_FILE,      required_argument, 0,  0 },
		{0,                0,                 0,  0 }
	};

	while ((c = getopt_long (argc, argv, "hv"
					, longopts, &longindex)) != -1) {
		switch (c) {
			case 0: {
					if (strcmp(PRODUCT_INDEX, longopts[longindex].name) == 0) 
					{
						mProductIndex = atoi(optarg);
					} 
					else if (strcmp(CHANNEL_ID, longopts[longindex].name) == 0) 
					{
						mRealTimeChannelID = atoi(optarg);
					}
					else if (strcmp(CONFIG_FILE, longopts[longindex].name) == 0)
					{
						mXMLFile = optarg;
					}

					break;
				}
			case 'h': {
					  printHelp();
					  Common::exit(0);
					  break;
				  }

		} // switch
	}

	return true;
}

void Global::printConfiguration() {

	//By Louis 2013-06-13  
	LOG4_INFO(mLogger, "===========================================");
	LOG4_INFO(mLogger, " OMD-CC ClientTool P" << gpGlobal->mProductIndex
			<<	 " v" << PROGRAM_VERSION);
	LOG4_INFO(mLogger, "===========================================");
	LOG4_INFO(mLogger, "    XML File:                                              " << gpGlobal->mXMLFile);
}

bool Global::isValidPacket(char* pPacketData, uint16_t packetSize) 
{
	if (packetSize < sizeof(Xdp::PacketHeader)) {
		LOG4_ERR(mLogger, "Invalid packet. packetSize:" << packetSize
				<< " < " << sizeof(Xdp::PacketHeader));
		return false;
	}

	Xdp::PacketHeader* pPacketHeader = (Xdp::PacketHeader*)pPacketData;
	if (packetSize != pPacketHeader->mPktSize) {
		LOG4_ERR(mLogger, "Invalid packet. packetSize:" << packetSize
				<< " <> PktSize: " << pPacketHeader->mPktSize);
		return false;
	}

	if (packetSize == sizeof(Xdp::PacketHeader)
			&& pPacketHeader->mMsgCount == 0) {
		return true;
	}

	char* pEndPacketData = pPacketData + packetSize;
	char* pData = pPacketData + sizeof(Xdp::PacketHeader);
	for (int i=0; i<pPacketHeader->mMsgCount; i++) {
		if (pData + sizeof(Xdp::MsgHeader) > pEndPacketData) {
			LOG4_ERR(mLogger, "MsgHeader goes over end of packet");
			return false;
		}
		Xdp::MsgHeader* pMsgHeader = (Xdp::MsgHeader*)pData;
		uint16_t msgSize = pMsgHeader->mMsgSize;
		if (pData + msgSize > pEndPacketData) {
			LOG4_ERR(mLogger, "Msg goes over end of packet");
			return false;
		}
		pData += msgSize;
	}
	return true;
}

/*
 * Parameters
 *   pPacketData Points to first byte of packet
 *   size        Size of packet
 *   pMsgData    Null or points to first byte of a message within the packet
 *
 * Return values
 *   if pMsgData is null
 *      returns pointer to first byte of first message
 *   if pMsgData points to first byte of a message within the packet
 *      returns pointer to first byte of next message or
 *      returns null if there is no next message
 */

char* Global::getNextPacketMsg(char* pPacketData, uint16_t packetSize, char* pMsgData) 
{
	Xdp::PacketHeader* pPacketHeader = (Xdp::PacketHeader*)pPacketData;

	if (pPacketHeader->mMsgCount == 0) 
	{
		return 0;
	}

	// Return pointer to first byte of first message
	if (!pMsgData) 
	{
		return pPacketData + sizeof(Xdp::PacketHeader);
	}

	Xdp::MsgHeader* pMsgHeader = (Xdp::MsgHeader*)pMsgData;
	uint16_t msgSize = pMsgHeader->mMsgSize;

	if (pMsgData + msgSize < pPacketData + packetSize) 
	{
		return pMsgData + msgSize;
	} else {
		return 0;
	}
}

Message* Global::createMsg(uint16_t msgSize) 
{
	Message* pMsg = new Message(mLogger, msgSize);
	return pMsg;
}

DOMElement* Global::getElement(DOMElement* pParent, const char* nodeName) {
	DOMNodeList* pNodeList = pParent->getChildNodes();
	for (int i=0; i<pNodeList->getLength(); i++) {
		DOMNode* pNode = pNodeList->item(i);
		const XMLCh* pNodeName = pNode->getNodeName();
		char* childNodeName = XMLString::transcode(pNodeName);
		if (pNode->getNodeType() == DOMNode::ELEMENT_NODE
				&& strcmp(childNodeName, nodeName) == 0) {
			return (DOMElement*)pNode;
		}
	}
	return 0;
}

bool Global::fileExist(const char *filename) {
	ifstream ifile(filename);
	return ifile;
}

void Global::readXmlConfig(int component) {

	try {
		XMLPlatformUtils::Initialize();
	}
	catch (const XMLException& toCatch) {
		char* message = XMLString::transcode(toCatch.getMessage());
		LOG4_ERR(mLogger, "Error during initialization! :\n" << message);
		XMLString::release(&message);
	}

	XercesDOMParser* parser = new XercesDOMParser();
	parser->setValidationScheme(XercesDOMParser::Val_Always);
	parser->setDoNamespaces(true);    // optional

	xercesc::ErrorHandler* errHandler = (xercesc::ErrorHandler*) new HandlerBase();
	parser->setErrorHandler(errHandler);

	const char* xmlFile;

	if (mXMLFile.empty())
	{
		xmlFile = "/app/whkex/omdct/client/omdcc/config/OMD.xml";
	}
	else
	{
		xmlFile = mXMLFile.c_str();
	}

	try 
	{
		parser->parse(xmlFile);
		DOMDocument* pDoc = parser->getDocument();

		// OMD
		DOMElement* pElementOMD = pDoc->getDocumentElement();

		// DefaultSecurityCode
		DOMElement* pElementDefaultSecurityCode = getElement(pElementOMD, DEFAULT_SECURITY_CODE_TAG);

		// RefreshScreen
		DOMElement* pElementRefreshScreen = getElement(pElementOMD, REFRESH_SCREEN_TAG);
		mRefreshScreen = XMLString::parseInt(pElementRefreshScreen->getTextContent());

		// SnapShotInterval
		DOMElement* pElementSnapShotInterval = getElement(pElementOMD, SNAPSHOT_INTERVAL_TAG);
		mSnapshotInterval = XMLString::parseInt(pElementSnapShotInterval->getTextContent());

		// Products
		DOMElement* pElementProducts = getElement(pElementOMD, PRODUCTS_TAG);
		DOMNodeList* pNodeListProducts = pElementProducts->getElementsByTagName(XMLString::transcode(PRODUCT_TAG));

		bool bSetServerChannel = false;
		for (int i=0; i<pNodeListProducts->getLength(); i++) 
		{
			// Product
			DOMElement* pElementProduct = (DOMElement*)pNodeListProducts->item(i);
			// Index
			DOMElement* pElementIndex = getElement(pElementProduct, INDEX_TAG);
			int productIndex = XMLString::parseInt(pElementIndex->getTextContent());
			if (productIndex == mProductIndex) 
			{
				DOMElement* pElementCTServer = getElement(pElementProduct, "CTServer");

				// Address
				DOMElement* pElementAddress = getElement(pElementCTServer, ADDR_TAG);
				mRetProxy.addr = XMLString::transcode(pElementAddress->getTextContent());

				// Port
				DOMElement* pElementPort = getElement(pElementCTServer, PORT_TAG);
				mRetProxy.port = XMLString::parseInt(pElementPort->getTextContent());

				// Channels
				DOMElement* pElementProductChannels = getElement(pElementProduct, CHANNELS_TAG);
				DOMNodeList* pNodeListProductChannels = pElementProductChannels->getElementsByTagName(XMLString::transcode(CHANNEL_TAG));

				for (int j=0; j<pNodeListProductChannels->getLength(); j++) 
				{
					// Channel
					DOMElement* pElementProductChannel = (DOMElement*)pNodeListProductChannels->item(j);

					// ChannelID
					DOMElement* pElementProductChannelID = getElement(pElementProductChannel, CHANNEL_ID_TAG);
					uint16_t productChannelID = XMLString::parseInt(pElementProductChannelID->getTextContent());

					// Channels
					DOMElement* pElementChannels = getElement(pElementOMD, CHANNELS_TAG);
					DOMNodeList* pNodeListChannels = pElementChannels->getElementsByTagName(XMLString::transcode(CHANNEL_TAG));

					for (int k=0; k<pNodeListChannels->getLength(); k++) 
					{
						// Channel
						DOMElement* pElementChannel = (DOMElement*)pNodeListChannels->item(k);

						// Server
						DOMElement* pElementServer = getElement(pElementChannel, SERVER_TAG);

						// RealTime
						DOMElement* pElementREAL = getElement(pElementServer, REAL_TAG);

						// ChannelID
						DOMElement* pElementChannelID = getElement(pElementREAL, CHANNEL_ID_TAG);
						uint16_t channelID = XMLString::parseInt(pElementChannelID->getTextContent());

						// ChannelName
						DOMElement* pElementChannelName = getElement(pElementServer, CHANNEL_NAME_TAG);
						mChannelName[channelID] = XMLString::transcode(pElementChannelName->getTextContent());

						if (productChannelID == channelID) 
						{
							mRealTimeChannelSet.insert(channelID);

							if (channelID == mRealTimeChannelID || component == Common::CLIENT_TOOL_COMPONENT) {

								LoggerSelector::resetConfigure(mLogger);
								DOMNodeList* pNodeListREAL = pElementREAL->getElementsByTagName(XMLString::transcode(LINE_TAG));

								// Refresh
								DOMElement* pElementREF = getElement(pElementServer, REF_TAG);

								uint16_t refreshChannelID = 0;
								if (pElementREF) 
								{
									// ChannelID
									DOMElement* pElementREFChannelID = getElement(pElementREF, CHANNEL_ID_TAG);
									refreshChannelID = XMLString::parseInt(pElementREFChannelID->getTextContent());
									mRefreshChannelSet.insert(refreshChannelID);
								}
							}
						}
					} // for k

					bSetServerChannel = true;
				} // for j
			}
		} // for i
	} catch (const XMLException& toCatch) {
		char* message = XMLString::transcode(toCatch.getMessage());
		LOG4_ERR(mLogger, "Exception message is: \n" << message);
		XMLString::release(&message);
	} catch (const DOMException& toCatch) {
		char* message = XMLString::transcode(toCatch.msg);
		LOG4_ERR(mLogger, "Exception message is: \n" << message);
		XMLString::release(&message);
	} catch (...) {
		LOG4_ERR(mLogger, "Unexpected Exception");
	}

	delete parser;
	delete errHandler;
}

bool Global::DirectoryExists( const char* pzPath )
{
	if ( pzPath == NULL) return false;

	DIR *pDir;
	bool bExists = false;

	pDir = opendir (pzPath);

	if (pDir != NULL)
	{
		bExists = true;    
		(void) closedir (pDir);
	}

	return bExists;
}
