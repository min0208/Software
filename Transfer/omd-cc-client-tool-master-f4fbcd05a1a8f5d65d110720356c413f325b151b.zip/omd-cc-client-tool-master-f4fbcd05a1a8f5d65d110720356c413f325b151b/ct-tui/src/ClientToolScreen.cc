#include "ClientToolScreen.h"

ClientToolScreen::ClientToolScreen(Logger& logger) : mLogger(logger) {
	mpNcursesWrapper = new NcursesWrapper(logger);
}

ClientToolScreen::~ClientToolScreen() {
	delete mpNcursesWrapper;
}

void ClientToolScreen::createForms() {
	LOG4_DEBUG(mLogger, "createForms not implemented");
}

void ClientToolScreen::printFieldLabels() {
	LOG4_DEBUG(mLogger, "printFieldLabels not implemented");
}

void ClientToolScreen::clearScr(uint16_t msgType, uint16_t side) {
	LOG4_DEBUG(mLogger, "clearScr not implemented");
}


void ClientToolScreen::updateScr
(uint16_t msgSize, uint16_t msgType, char* pMsgData, Common::Source source) {
	LOG4_DEBUG(mLogger, "updateScr not implemented");
}

int64_t ClientToolScreen::pow10(int exp) {
	int64_t value = 1;
	for (int i=0; i<exp; i++) {
		value *= 10;
	}
	return value;
}

string ClientToolScreen::getCharMapStr
(Global::FieldValueMapChar fieldValueMap, char fieldValue, string strNotFound) {
	Global::FieldValueMapChar::iterator iterChar
		= fieldValueMap.find(fieldValue);
	if (iterChar != fieldValueMap.end()) {
		return iterChar->second;
	} else {
		return strNotFound;

		/*
		// Debug
		int maxFieldLen = 0;
		string maxLenStr;
		iterChar = fieldValueMap.begin();
		while (iterChar != fieldValueMap.end()) {
		int fieldLen = iterChar->second.size();
		if (fieldLen > maxFieldLen) {
		maxLenStr = iterChar->second;
		maxFieldLen = fieldLen;
		}
		iterChar++;
		}
		return string("?").append(maxLenStr.substr(0, maxLenStr.size()-2))
		.append("?");
		*/
	}
}

string ClientToolScreen::getUint8MapStr
(Global::FieldValueMapUint8 fieldValueMap, uint8_t fieldValue
 , string strNotFound) {
	Global::FieldValueMapUint8::iterator iterUint8
		= fieldValueMap.find(fieldValue);
	if (iterUint8 != fieldValueMap.end()) {
		return iterUint8->second;
	} else {
		return strNotFound;

		/*
		// Debug
		int maxFieldLen = 0;
		string maxLenStr;
		iterUint8 = fieldValueMap.begin();
		while (iterUint8 != fieldValueMap.end()) {
		int fieldLen = iterUint8->second.size();
		if (fieldLen > maxFieldLen) {
		maxLenStr = iterUint8->second;
		maxFieldLen = fieldLen;
		}
		iterUint8++;
		}
		return string("?").append(maxLenStr.substr(0, maxLenStr.size()-2))
		.append("?");
		*/
	}
}

string ClientToolScreen::getUint16MapStr
(Global::FieldValueMapUint16 fieldValueMap, uint16_t fieldValue
 , string strNotFound) {
	Global::FieldValueMapUint16::iterator iterUint16
		= fieldValueMap.find(fieldValue);
	if (iterUint16 != fieldValueMap.end()) {
		return iterUint16->second;
	} else {
		return strNotFound;

		/*
		// Debug
		int maxFieldLen = 0;
		string maxLenStr;
		iterUint16 = fieldValueMap.begin();
		while (iterUint16 != fieldValueMap.end()) {
		int fieldLen = iterUint16->second.size();
		if (fieldLen > maxFieldLen) {
		maxLenStr = iterUint16->second;
		maxFieldLen = fieldLen;
		}
		iterUint16++;
		}
		return string("?").append(maxLenStr.substr(0, maxLenStr.size()-2))
		.append("?");
		*/
	}
}

void ClientToolScreen::newField
(FIELD** ppField, int fieldIndex, int height, int width, int toprow
 , int leftcol, int offscreen, int nbuffers, string value
 , int justification, Field_Options optsOn, Field_Options optsOff
 , chtype attr) {
	ppField[fieldIndex] = mpNcursesWrapper->new_field
		(height, width, toprow, leftcol, offscreen, nbuffers);
	FIELD* pField = ppField[fieldIndex];
	if (value != "") {
		mpNcursesWrapper->set_field_buffer(pField, 0, value.c_str());
	}
	set_field_just(pField, justification);
	if (optsOn) {
		field_opts_on(pField, optsOn);
	}
	if (optsOff) {
		field_opts_off(pField, optsOff);
	}

	if (attr) {
		set_field_fore(pField, attr);
		set_field_back(pField, attr);
	}
	// set_field_back(pField, A_REVERSE);
}

void ClientToolScreen::newFieldWithLabel(FIELD** ppField, const char* label, int fieldIndexLabel, int fieldIndexEdit , int row, int startCol, int totalFieldLen) 
{
	size_t labelLen = strlen(label);
	newField(ppField, fieldIndexLabel, 1, labelLen, row, startCol, 0, 0, label);
	newField(ppField, fieldIndexEdit, 1, totalFieldLen-labelLen, row
			, startCol+labelLen, 0, 0);
}

void ClientToolScreen::setFieldBack(int fieldIndex, chtype attr) 
{
	int formIndex = 0;
	FIELD* pField = gpGlobal->mpField[mScreen][formIndex][fieldIndex];
	set_field_back(pField, attr);
}

void ClientToolScreen::setFieldBuffer(int fieldIndex, string value) 
{
	int formIndex = 0;
	FIELD** ppField = gpGlobal->mpField[mScreen][formIndex];

	mpNcursesWrapper->set_field_buffer(ppField[fieldIndex], 0, value.c_str());
}

void ClientToolScreen::setFieldBuffer(int fieldIndex, uint64_t value) {
	int formIndex = 0;
	FIELD** ppField = gpGlobal->mpField[mScreen][formIndex];

	ostringstream oss;
	oss << value;
	mpNcursesWrapper->set_field_buffer(ppField[fieldIndex], 0, oss.str().c_str());
}
// //By Louis 27-06-2013
// void ClientToolScreen::setFieldBuffer
// (int fieldIndex, int32_t value, int decimalPlaces) {
// int formIndex = 0;
// FIELD** ppField = gpGlobal->mpField[mScreen][formIndex];

// ostringstream oss;
// int factor = (int)pow10(decimalPlaces);
// oss << value/factor << "."
// << setfill('0') << setw(decimalPlaces) << value%factor;
// mpNcursesWrapper->set_field_buffer(ppField[fieldIndex], 0, oss.str().c_str());
// }

void ClientToolScreen::setFieldBuffer(int fieldIndex, uint64_t value, int decimalPlaces) 
{
	int formIndex = 0;
	FIELD** ppField = gpGlobal->mpField[mScreen][formIndex];

	ostringstream oss;
	int factor = (int)pow10(decimalPlaces);
	oss << value/factor << "."
		<< setfill('0') << setw(decimalPlaces) << value%factor;
	mpNcursesWrapper->set_field_buffer(ppField[fieldIndex], 0, oss.str().c_str());
}

void ClientToolScreen::setFieldBuffer(int fieldIndex, Global::FieldValueMapChar fieldValueMap, char value, enum FieldValueDesc enumFieldValueDesc) 
{
	int formIndex = 0;
	FIELD** ppField = gpGlobal->mpField[mScreen][formIndex];

	ostringstream oss;
	switch (enumFieldValueDesc) {
		case FIELD_VALUE_ONLY: {
					       oss << value;
					       mpNcursesWrapper->set_field_buffer(ppField[fieldIndex], 0, oss.str().c_str());
					       break;
				       }
		case FIELD_DESC_ONLY: {
					      string valueStr = getCharMapStr(fieldValueMap,value);
					      mpNcursesWrapper->set_field_buffer(ppField[fieldIndex], 0, valueStr.c_str());
					      break;
				      }  
		case FIELD_VALUE_DESC: {
					       oss << value;
					       string valueStr = getCharMapStr(fieldValueMap,value) 
						       + " (" + oss.str() + ")";
					       mpNcursesWrapper->set_field_buffer(ppField[fieldIndex], 0, valueStr.c_str());
					       break;
				       }
	} // switch 
}

void ClientToolScreen::setFieldBuffer(int fieldIndex, Global::FieldValueMapUint8 fieldValueMap, uint8_t value, enum FieldValueDesc enumFieldValueDesc) 
{
	int formIndex = 0;
	FIELD** ppField = gpGlobal->mpField[mScreen][formIndex];

	ostringstream oss;
	switch (enumFieldValueDesc) {
		case FIELD_VALUE_ONLY: {
					       oss << (int)value;
					       mpNcursesWrapper->set_field_buffer(ppField[fieldIndex], 0, oss.str().c_str());
					       break;
				       }
		case FIELD_DESC_ONLY: {
					      string valueStr = getUint8MapStr(fieldValueMap,value);
					      mpNcursesWrapper->set_field_buffer(ppField[fieldIndex], 0, valueStr.c_str());
					      break;
				      }  
		case FIELD_VALUE_DESC: {
					       oss << (int)value;
					       string valueStr = getUint8MapStr(fieldValueMap,value) 
						       + " (" + oss.str() + ")";
					       mpNcursesWrapper->set_field_buffer(ppField[fieldIndex], 0, valueStr.c_str());
					       break;
				       }
	} // switch 
}

void ClientToolScreen::setFieldBuffer (int fieldIndex, Global::FieldValueMapUint16 fieldValueMap, uint16_t value , enum FieldValueDesc enumFieldValueDesc) 
{
	int formIndex = 0;
	FIELD** ppField = gpGlobal->mpField[mScreen][formIndex];

	ostringstream oss;
	switch (enumFieldValueDesc) {
		case FIELD_VALUE_ONLY: {
					       oss << value;
					       mpNcursesWrapper->set_field_buffer(ppField[fieldIndex], 0, oss.str().c_str());
					       break;
				       }
		case FIELD_DESC_ONLY: {
					      string valueStr = getUint16MapStr(fieldValueMap,value);
					      mpNcursesWrapper->set_field_buffer(ppField[fieldIndex], 0, valueStr.c_str());
					      break;
				      }  
		case FIELD_VALUE_DESC: {
					       oss << value;
					       string valueStr = getUint16MapStr(fieldValueMap,value) 
						       + " (" + oss.str() + ")";
					       mpNcursesWrapper->set_field_buffer(ppField[fieldIndex], 0, valueStr.c_str());
					       break;
				       }
	} // switch 
}
