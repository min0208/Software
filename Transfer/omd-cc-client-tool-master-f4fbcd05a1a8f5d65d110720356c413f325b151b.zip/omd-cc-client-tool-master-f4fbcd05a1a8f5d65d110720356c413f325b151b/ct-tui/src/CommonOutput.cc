#include "CommonOutput.h"

using namespace std;

CommonOutput::CommonOutput()
{
  // mMutexOutput = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_init(&mMutexOutput, NULL);
}

CommonOutput::~CommonOutput() {
}


void CommonOutput::output
(Logger& logger, int row, int col, const char* pStr, bool lock)
{
  if (lock) {
    Common::lock(logger, &mMutexOutput);
  }
  LOG4_ERR(logger, "output(int row, int col, char* pStr) not implemented");
  if (lock) {
    Common::unlock(logger, &mMutexOutput);
  }
}

void CommonOutput::output
(Logger& logger, const char* pStr, bool lock)
{
  if (lock) {
    Common::lock(logger, &mMutexOutput);
  }
  LOG4_ERR(logger, "output(char* pStr) not implemented");
  if (lock) {
    Common::unlock(logger, &mMutexOutput);
  }
}

void CommonOutput::output
(Logger& logger, int row, int col, ostringstream& oss, bool lock)
{
  if (lock) {
    Common::lock(logger, &mMutexOutput);
  }
  LOG4_ERR(logger
		  , "output(int row, int col, ostringstream oss) not implemented");
  if (lock) {
    Common::unlock(logger, &mMutexOutput);
  }
}

void CommonOutput::output
(Logger& logger, ostringstream& oss, bool lock)
{
  if (lock) {
    Common::lock(logger, &mMutexOutput);
  }
  LOG4_ERR(logger, "output(ostringstream oss) not implemented");
  if (lock) {
    Common::unlock(logger, &mMutexOutput);
  }
}
