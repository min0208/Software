#include "ClientToolP4.h"
#include "Socket.h"
#include <poll.h>

using namespace std;

ClientToolP4::ClientToolP4(int argc, char** argv, Logger& logger, Logger& userlogger) : ClientTool(argc, argv, logger, userlogger) 
{
	initNcurses();

	mpScreenHeader = new ClientToolScreenHeader(logger);
	mpScreenHeader->createForms();
	mpScreenFooter = new ClientToolScreenFooter(logger);
	mpScreenFooter->createForms();
	mpScreenSSESZSE = new ClientToolScreenSSESZSE(logger, mpScreenHeader);
	mpScreenSSESZSE->createForms();
	mpScreenQuit = new ClientToolScreenQuit(logger);
	mpScreenQuit->createForms();

	gpGlobal->mRetProxy.pPacketSpool = new PacketSpool(mLogger);
	pthread_create(&mThreadId, NULL, &threadTcp, this);
	memset(mReadBufferClient, 0, sizeof(mReadBufferClient));
        mReadBufferClientOffset = 0;

	mSource = Common::REALTIME_SOURCE;

	Common::lock(mLogger, &mMutexOutput);
	mScreen = Common::SSESZSE_SCREEN;
	unpostAllForms();
	postAllForms(Common::FOOTER_SCREEN);
	postAllForms(mScreen);
	postAllForms(Common::HEADER_SCREEN);
	mpScreenHeader->printFieldLabels();
	mpScreenHeader->refresh();
	mpScreenFooter->printFieldLabels();
	mpScreenFooter->refresh();
	mpScreenSSESZSE->printFieldLabels();
	Common::unlock(mLogger, &mMutexOutput);
	refreshNcursesWindows();
}

void ClientToolP4::connectToCTServer()
{
        LOG4_INFO(mLogger, "Connecting to OMD-CC CT Server " << gpGlobal->mRetProxy.addr.c_str() << ":" << gpGlobal->mRetProxy.port );

        while ((mSockfdCTServer = Socket::createConnect(mLogger, (char*)gpGlobal->mRetProxy.addr.c_str(), gpGlobal->mRetProxy.port)) < 0)
        {
                string msg = "Could not connect to OMD-CC CT Server!";
                LOG4_ERR(mLogger, msg.c_str());
                gpGlobal->mServerConnected_ = false;
                sleep(gpGlobal->mRetReconnectInterval);
        }

        string msg = "OMD-CC CT Server connected";
        LOG4_INFO(mLogger, msg.c_str());
        gpGlobal->mRetProxy.pPacketSpool->init(mSockfdCTServer);
        gpGlobal->mServerConnected_ = true;
        startPollCTServer();
}

void* ClientToolP4::threadTcp(void *arg)
{
        ClientToolP4* pClientToolP4 = (ClientToolP4*)arg;
        pClientToolP4->connectToCTServer();
}

void ClientToolP4::startPollCTServer()
{
        struct pollfd fds[1];
        nfds_t nfds = 1;
        int timeout = -1;

        uint16_t headerSize = sizeof(Xdp::PacketHeader);

        char (&readBufferClient)[MAX_PACKET_SIZE] = mReadBufferClient;
        int& readBufferClientOffset = mReadBufferClientOffset;

        fds[0].fd = mSockfdCTServer;
        fds[0].events = POLLIN | POLLERR;
        while (poll(fds, nfds, timeout) > 0 || errno == EINTR)
        {
                if (fds[0].revents & POLLIN)
                {
                        // Read the data on the socket
                        ssize_t len = recv(fds[0].fd, &readBufferClient[readBufferClientOffset], sizeof(readBufferClient)-readBufferClientOffset, 0);

                        if (len < 0)
                        {
                                LOG4_WARNING(mLogger, "socket recv, len < 0");
                                break;
                        }
                        else if (len == 0)
                        {
                                LOG4_WARNING(mLogger, "socket recv, len == 0");
                                break;
                        }

                        //LOG4_DEBUG(mLogger, "recv, len = " << len);
                        readBufferClientOffset += len;

                        while (readBufferClientOffset >= headerSize)
                        {
                                char* pPacketData = readBufferClient;

                                Xdp::PacketHeader* pPacketHeader = (Xdp::PacketHeader*)pPacketData;
                                uint16_t pktSize = pPacketHeader->mPktSize;
                                if (readBufferClientOffset >= pktSize)
                                {
                                        processCTServerMsg(pPacketData);
                                        memmove(pPacketData, &pPacketData[pktSize], sizeof(readBufferClient)-pktSize);
                                        readBufferClientOffset -= pktSize;
                                }
				else
				{
					break;
				}
			}
		}
	}

	::ErrorHandler::print(mLogger, "poll", false);
	LOG4_DEBUG(mLogger, "close() mSockfdCTServer");
	close(mSockfdCTServer);

	pthread_create(&mThreadId, NULL, &threadTcp, this);
}

void ClientToolP4::processCTServerMsg(char* pPacketData)
{
	uint64_t recvTime =  Common::getUint64Time(mLogger);

	Xdp::PacketHeader* pPacketHeader = (Xdp::PacketHeader*)pPacketData;
	uint16_t pktSize = pPacketHeader->mPktSize;

	/////////////////////////////////////////////
	CTRespondHeader*  pCTHeader;
	/////////////////////////////////////////////

	//LOG4_DEBUG(mLogger, __FILE__<< ":" << __LINE__ << " pktSize:" << pktSize);

	if (!gpGlobal->isValidPacket(pPacketData, pktSize))
	{
		return;
	}

	if (pPacketHeader->mMsgCount == 0)
	{
		LOG4_WARNING(mLogger, "MsgCount is 0");
	}
	else
	{
		char* pRecvMsgData = 0;
		uint32_t seqNum = pPacketHeader->mSeqNum;
		while (pRecvMsgData = gpGlobal->getNextPacketMsg(pPacketData, pktSize, pRecvMsgData))
		{
			/////////////////////////////
			pCTHeader = (CTRespondHeader*)pRecvMsgData;

			switch (pCTHeader->mInfoType)
			{
				case CT_OMDCC_SECURITY_SEARCH_RESPOND:
					//LOG4_DEBUG(mLogger, "OMDCC Security Search Respond: " << translateRspCode(pCTHeader->mRespondCode));
					break;
				case CT_OMDCC_SECURITY_SNAPSHOT_RESPOND:
					//LOG4_DEBUG(mLogger, "OMDCC Security Snap Shot Respond: " << translateRspCode(pCTHeader->mRespondCode));
					break;
				default:
					Xdp::MsgHeader* pMsgHeader=(Xdp::MsgHeader*)pRecvMsgData;
					if (pMsgHeader->mMsgType < Xdp::SEQUENCE_RESET_TYPE && pMsgHeader->mMsgType > Xdp::END_MSG_TYPE)
					{
						LOG4_DEBUG(mLogger, "Unknown CT Message: " << pCTHeader->mRespondCode);
					}
					else
					{
						processMsg(101, 0/*recvTime*/, pktSize, pMsgHeader->mMsgType, pRecvMsgData);
					}
					break;
			}
		} // while
	}
}

void ClientToolP4::createCommonWindows() 
{
	const char* menus[] = 
	{
		" SSE/SZSE ",
		" Quit ",
		0
	};

	int n_choices = ARRAY_SIZE(menus);
	gpGlobal->mppItems = (ITEM **)calloc(n_choices, sizeof(ITEM *));
	for(int i = 0; i < n_choices; i++) {
		gpGlobal->mppItems[i] = new_item(menus[i], "");
	}
	gpGlobal->mpMenu = new_menu((ITEM **)gpGlobal->mppItems);

	set_menu_fore(gpGlobal->mpMenu, COLOR_PAIR(Common::BLACK_BLUE_COLOR_PAIR) | A_BOLD);
	set_menu_back(gpGlobal->mpMenu, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	/* Set main window and sub window */
	gpGlobal->mpMenuWin = newwin(2, MAX_SCREEN_COLS, MAX_HEADER_ROWS, 0);
	set_menu_win(gpGlobal->mpMenu, gpGlobal->mpMenuWin);
	gpGlobal->mpMenuSub = derwin(gpGlobal->mpMenuWin, 1, MAX_SCREEN_COLS, 0, 0);
	set_menu_sub(gpGlobal->mpMenu, gpGlobal->mpMenuSub);
	set_menu_format(gpGlobal->mpMenu, 1, n_choices-1);
	set_menu_mark(gpGlobal->mpMenu, 0);

	post_menu(gpGlobal->mpMenu);
	wrefresh(gpGlobal->mpMenuWin);

	if (keypad(gpGlobal->mpMenuWin, TRUE) == ERR) {
		endwin();
		LOG4_ERR(mLogger, "keypad failed:" << ERR);
		Common::exit(1);
	}

	nodelay(gpGlobal->mpMenuWin, TRUE);

	for (int screen = Common::BEGIN_SCREEN; screen < Common::END_SCREEN; screen++) 
	{
		switch (screen) 
		{
			case Common::SSESZSE_SCREEN: 
				{
					mRefreshOrder[screen][0] = (enum Common::Screen)screen;
					mRefreshOrder[screen][1] = Common::FOOTER_SCREEN;
					mRefreshOrder[screen][2] = Common::HEADER_SCREEN;
					break;
				}
			case Common::QUIT_SCREEN: 
				{
					mRefreshOrder[screen][0] = Common::HEADER_SCREEN;
					mRefreshOrder[screen][1] = Common::FOOTER_SCREEN;
					mRefreshOrder[screen][2] = (enum Common::Screen)screen;
					break;
				}
		} // switch
	}
	// beginning with Refresh Mode
	gpGlobal->mMode = Common::REFRESH_MODE;
}

void ClientToolP4::initNcurses() 
{
	setlocale(LC_ALL, "");

	int row,col;

	if (initscr() == 0) {
		LOG4_ERR(mLogger, "initscr failed:0");
		Common::exit(1);
	};

	getmaxyx(stdscr,row, col);
	if (row < MAX_SCREEN_ROWS) {
		endwin();
		LOG4_WARNING(mLogger, "The window has " << row << " rows.");
		LOG4_WARNING(mLogger, "The window requires "
				<< MAX_SCREEN_ROWS << " rows.");
		// Common::exit(1);
	}

	if (col < MAX_SCREEN_COLS) {
		endwin();
		LOG4_WARNING(mLogger, "The window has " << col << " columns.");
		LOG4_WARNING(mLogger, "The window requires "
				<< MAX_SCREEN_COLS << " columns.");
		// Common::exit(1);
	}

	if (start_color() == ERR) {
		endwin();
		LOG4_ERR(mLogger, "start_color failed:" << ERR);
		Common::exit(1);
	}

	if (init_pair(Common::RED_BLACK_COLOR_PAIR, COLOR_RED, COLOR_BLACK) == ERR) {
		endwin();
		LOG4_ERR(mLogger, "init_pair failed:" << ERR);
		Common::exit(1);
	}

	if (init_pair(Common::GREEN_BLACK_COLOR_PAIR, COLOR_GREEN, COLOR_BLACK)
			== ERR) {
		endwin();
		LOG4_ERR(mLogger, "init_pair failed:" << ERR);
		Common::exit(1);
	}

	if (init_pair(Common::CYAN_BLACK_COLOR_PAIR, COLOR_CYAN, COLOR_BLACK)
			== ERR) {
		endwin();
		LOG4_ERR(mLogger, "init_pair failed:" << ERR);
		Common::exit(1);
	}

	if (init_pair(Common::YELLOW_BLACK_COLOR_PAIR, COLOR_YELLOW, COLOR_BLACK)
			== ERR) {
		endwin();
		LOG4_ERR(mLogger, "init_pair failed:" << ERR);
		Common::exit(1);
	}

	if (init_pair(Common::WHITE_BLACK_COLOR_PAIR, COLOR_WHITE, COLOR_BLACK)
			== ERR) {
		endwin();
		LOG4_ERR(mLogger, "init_pair failed:" << ERR);
		Common::exit(1);
	}

	if (init_pair(Common::WHITE_MAGENTA_COLOR_PAIR, COLOR_WHITE, COLOR_MAGENTA)
			== ERR) {
		endwin();
		LOG4_ERR(mLogger, "init_pair failed:" << ERR);
		Common::exit(1);
	}

	if (init_pair(Common::BLACK_WHITE_COLOR_PAIR, COLOR_BLACK, COLOR_WHITE)
			== ERR) {
		endwin();
		LOG4_ERR(mLogger, "init_pair failed:" << ERR);
		Common::exit(1);
	}

	if (init_pair(Common::MAGENTA_BLACK_COLOR_PAIR, COLOR_MAGENTA, COLOR_BLACK)
			== ERR) {
		endwin();
		LOG4_ERR(mLogger, "init_pair failed:" << ERR);
		Common::exit(1);
	}

	if (init_pair(Common::BLUE_BLACK_COLOR_PAIR, COLOR_BLUE, COLOR_BLACK)
			== ERR) {
		endwin();
		LOG4_ERR(mLogger, "init_pair failed:" << ERR);
		Common::exit(1);
	}

	if (init_pair(Common::WHITE_BLUE_COLOR_PAIR, COLOR_WHITE, COLOR_BLUE)
			== ERR) {
		endwin();
		LOG4_ERR(mLogger, "init_pair failed:" << ERR);
		Common::exit(1);
	}

	if (init_pair(Common::BLACK_BLUE_COLOR_PAIR, COLOR_BLACK, COLOR_BLUE)
			== ERR) {
		endwin();
		LOG4_ERR(mLogger, "init_pair failed:" << ERR);
		Common::exit(1);
	}

	if (init_pair(Common::BLACK_MAGENTA_COLOR_PAIR, COLOR_BLACK, COLOR_MAGENTA)
			== ERR) {
		endwin();
		LOG4_ERR(mLogger, "init_pair failed:" << ERR);
		Common::exit(1);
	}

	if (init_pair(Common::BLACK_YELLOW_COLOR_PAIR, COLOR_BLACK, COLOR_YELLOW)
			== ERR) {
		endwin();
		LOG4_ERR(mLogger, "init_pair failed:" << ERR);
		Common::exit(1);
	}

	if (init_pair(Common::BLACK_GREEN_COLOR_PAIR, COLOR_BLACK, COLOR_GREEN)
			== ERR) {
		endwin();
		LOG4_ERR(mLogger, "init_pair failed:" << ERR);
		Common::exit(1);
	}

	if (init_pair(Common::WHITE_GREEN_COLOR_PAIR, COLOR_WHITE, COLOR_GREEN)
			== ERR) {
		endwin();
		LOG4_ERR(mLogger, "init_pair failed:" << ERR);
		Common::exit(1);
	}

	if (cbreak() == ERR) {
		endwin();
		LOG4_ERR(mLogger, "cbreak failed:" << ERR);
		Common::exit(1);
	};

	if (noecho() == ERR) {
		endwin();
		LOG4_ERR(mLogger, "noecho failed:" << ERR);
		Common::exit(1);
	};

	if (mousemask(ALL_MOUSE_EVENTS, NULL) == ERR) {
		endwin();
		LOG4_ERR(mLogger, "mousemask failed:" << ERR);
		Common::exit(1);
	}

	createCommonWindows();
}

void ClientToolP4::unpostForm(int screenIndex, int formIndex) {
	if (gpGlobal->mpForm[screenIndex][formIndex]) {
		unpost_form(gpGlobal->mpForm[screenIndex][formIndex]);
	}
}

void ClientToolP4::unpostAllForms() {
	for (int i=Common::BEGIN_SCREEN; i<Common::END_SCREEN; i++) {
		for (int j=0; j<ARRAY_SIZE(gpGlobal->mpForm[0]); j++) {
			unpostForm(i, j);
		}
	}
}

void ClientToolP4::postAllForms(enum Common::Screen screen) {
	for (int i=0; i<ARRAY_SIZE(gpGlobal->mpForm[screen]); i++) {
		if (gpGlobal->mpForm[screen][i]) {
			mpNcursesWrapper->post_form(gpGlobal->mpForm[screen][i]);
		}
	}
}

void ClientToolP4::clearAllFormSubs(int screenIndex) {
	for (int i=0; i<ARRAY_SIZE(gpGlobal->mpFormSub[screenIndex]); i++) {
		if (gpGlobal->mpFormSub[screenIndex][i]) {
			wclear(gpGlobal->mpFormSub[screenIndex][i]);
		}
	}
}

void ClientToolP4::refreshNcursesWindows() 
{
	Common::lock(mLogger, &mMutexOutput);

	mpScreenHeader->refresh();
	mpScreenFooter->refresh();

	switch (mScreen) {
		case Common::SSESZSE_SCREEN:
			mpScreenSSESZSE->refresh();
			break;
		case Common::QUIT_SCREEN:
			break;
	} // switch

	switch (mScreen) 
	{
		case Common::SSESZSE_SCREEN:
		case Common::QUIT_SCREEN: 
			{
				enum Common::Screen screen;
				switch (mScreen) {
					case Common::SSESZSE_SCREEN:
						{
							screen = Common::HEADER_SCREEN;
							break;
						}
					default: {
							 screen = mScreen;
							 break;
						 }
				} // switch

				int formIndex = 0;
				FORM*& pForm = gpGlobal->mpForm[screen][formIndex];
				FIELD* pCurrentField = mpNcursesWrapper->current_field(pForm);
				mpNcursesWrapper->form_driver(pForm, REQ_END_FIELD);
				int cursorVisibility = 1;
				if (curs_set(cursorVisibility) == ERR) {
					endwin();
					LOG4_ERR(mLogger, "curs_set failed:" << ERR);
					Common::exit(1);
				}
				break;
			}
	} // switch

	for (int refreshIndex=0; refreshIndex<3; refreshIndex++) {
		if (mRefreshOrder[mScreen][refreshIndex] == Common::HEADER_SCREEN) {
			for (int i=0; i<ARRAY_SIZE(gpGlobal->mpFormSub[Common::HEADER_SCREEN]); i++) {
				if (gpGlobal->mpFormSub[Common::HEADER_SCREEN][i]) {
					wrefresh(gpGlobal->mpFormSub[Common::HEADER_SCREEN][i]);
				}
			}
		} else if (mRefreshOrder[mScreen][refreshIndex] == Common::FOOTER_SCREEN) {
			for (int i=0; i<ARRAY_SIZE(gpGlobal->mpFormSub[Common::FOOTER_SCREEN]); i++) {
				if (gpGlobal->mpFormSub[Common::FOOTER_SCREEN][i]) {
					wrefresh(gpGlobal->mpFormSub[Common::FOOTER_SCREEN][i]);
				}
			}
		} else if (mRefreshOrder[mScreen][refreshIndex] == mScreen) {
			for (int i=ARRAY_SIZE(gpGlobal->mpFormSub[mScreen])-1; i>=0; i--) {
				if (gpGlobal->mpFormSub[mScreen][i]) {
					wrefresh(gpGlobal->mpFormSub[mScreen][i]);
				}
			}
		}
	}
	//Update information
	Common::unlock(mLogger, &mMutexOutput);
}

void ClientToolP4::processNcurses(pthread_cond_t& cond) 
{
	wtimeout(gpGlobal->mpMenuWin, 1000);
	halfdelay(2);

	bool	bResizing = false;
	int	ch;

	while (true)
	{
		if (bResizing)
			ch = ERR;
		else
			ch = wgetch(gpGlobal->mpMenuWin);

		if (ch) {
			Common::lock(mLogger, &mMutexOutput);

			if (ch == ERR) {
				// skip
				Common::unlock(mLogger, &mMutexOutput);
			}
			else 
			{
				if (ch == KEY_LEFT) {
					menu_driver(gpGlobal->mpMenu, REQ_LEFT_ITEM);
					wrefresh(gpGlobal->mpMenuWin);
				}

				if (ch == KEY_RIGHT) {
					menu_driver(gpGlobal->mpMenu, REQ_RIGHT_ITEM);
					wrefresh(gpGlobal->mpMenuWin);
				}

				if (ch == KEY_RESIZE) {
					bResizing = true;
					halfdelay(2);
					deleteCommonWindows();

					for (int i=Common::BEGIN_SCREEN; i<Common::END_SCREEN; i++) {
						for (int j=0; j<ARRAY_SIZE(gpGlobal->mpForm[i]); j++) {
							deleteForm(gpGlobal->mpForm[i][j]);
							deleteFormWin(gpGlobal->mpFormSub[i][j]);
							deleteFormWin(gpGlobal->mpFormWin[i][j]);
						}
					}
					createCommonWindows();
					mpScreenHeader->createForms();
					mpScreenFooter->createForms();
					mpScreenSSESZSE->createForms();
					mpScreenQuit->createForms();
				}

				if (ch == KEY_LEFT || ch == KEY_RIGHT) { //KEY_RESIZE will refresh later
					ITEM * pCurrentItem = current_item(gpGlobal->mpMenu);
					clearAllFormSubs(mScreen);
					mScreen = (enum Common::Screen)(item_index(pCurrentItem)+2); // +2 for HEADER and FOOTER
					unpostAllForms();
					postAllForms(Common::FOOTER_SCREEN);
					postAllForms(mScreen);
					postAllForms(Common::HEADER_SCREEN);
				}
				if (ch != KEY_RESIZE)
				{
					if (mScreen == Common::SSESZSE_SCREEN) {
						mpScreenSSESZSE->processChar(ch);
					} else if (mScreen == Common::QUIT_SCREEN) {
						mpScreenQuit->processChar(ch);
						if ('a' <= ch && ch <= 'z') {
							ch = toupper(ch);
						}
						if (ch == 'Y') {
							Common::unlock(mLogger, &mMutexOutput);
							pthread_cond_signal(&cond);
							return;
						}
					}
				}
				if (bResizing)
				{	
					wtimeout(gpGlobal->mpMenuWin, 1000);
					bResizing = false;

					ITEM * pCurrentItem = current_item(gpGlobal->mpMenu);
					clearAllFormSubs(mScreen);
					mScreen = (enum Common::Screen)(item_index(pCurrentItem)+2); // +2 for HEADER and FOOTER
					unpostAllForms();
					postAllForms(Common::FOOTER_SCREEN);
					postAllForms(mScreen);
					postAllForms(Common::HEADER_SCREEN);

					mpScreenSSESZSE->processChar(KEY_LEFT);
				}
				Common::unlock(mLogger, &mMutexOutput);
			}
		}
	}
}

void ClientToolP4::deleteCommonWindows() {
	unpost_menu(gpGlobal->mpMenu);
	free_menu(gpGlobal->mpMenu);
}

void ClientToolP4::deleteForm(FORM*& pForm) {
	if (pForm) {
		unpost_form(pForm);
		free_form(pForm);
		pForm = 0;
	}
}

void ClientToolP4::deleteFormWin(WINDOW*& pFormWin) {
	if (pFormWin) {
		delwin(pFormWin);
		pFormWin = 0;
	}
}

void ClientToolP4::deleteField(FIELD*& pField) {
	if (pField) {
		free_field(pField);
		pField = 0;
	}
}

ClientToolP4::~ClientToolP4() 
{
	int returnVal = echo();
	if (returnVal == OK) {
		//LOG4_INFO(mLogger, "echo OK");
	} else if (returnVal == ERR) {
		LOG4_ERR(mLogger, "echo failed:" << ERR);
		endwin();
		Common::exit(1);
	};

	deleteCommonWindows();
	for (int i=Common::BEGIN_SCREEN; i<Common::END_SCREEN; i++) {
		for (int j=0; j<ARRAY_SIZE(gpGlobal->mpForm[i]); j++) {
			deleteForm(gpGlobal->mpForm[i][j]);
			deleteFormWin(gpGlobal->mpFormSub[i][j]);
			deleteFormWin(gpGlobal->mpFormWin[i][j]);
			for (int k=0; k<ARRAY_SIZE(gpGlobal->mpField[i][j]); k++) {
				deleteField(gpGlobal->mpField[i][j][k]);
			}
		}
	}

	delete mpScreenHeader;
	delete mpScreenFooter;
	delete mpScreenSSESZSE;
	delete mpScreenQuit;

	endwin();
}

void ClientToolP4::output(int row, int col, const char* pStr, bool lock) 
{
	if (lock) {
		Common::lock(mLogger, &mMutexOutput);
	}

	for (int i=0; i<MAX_FORM_COLS-1; i++) {
		if (mvwaddch(gpGlobal->mpFormSub[Common::FOOTER_SCREEN][0], row, i, ' ') == ERR) {
			LOG4_ERR(mLogger, "mvwaddch failed");
			Common::exit(1);
		}
	}

	if (mvwaddstr(gpGlobal->mpFormSub[Common::FOOTER_SCREEN][0], row, col, pStr) == ERR) {
		LOG4_ERR(mLogger, "mvwaddstr failed");
		Common::exit(1);
	}

	wrefresh(gpGlobal->mpFormSub[Common::FOOTER_SCREEN][0]);

	if (lock) {
		Common::unlock(mLogger, &mMutexOutput);
	}
}

void ClientToolP4::output(const char* pStr, bool lock) {
	output(0, 0, pStr, lock);
}

void ClientToolP4::output(int row, int col, ostringstream& oss, bool lock) {
	if (lock) {
		Common::lock(mLogger, &mMutexOutput);
	}

	for (int i=0; i<MAX_FORM_COLS-1; i++) {
		if (mvwaddch(gpGlobal->mpFormSub[Common::FOOTER_SCREEN][0], row, i, ' ') == ERR) {
			LOG4_ERR(mLogger, "mvwaddch failed");
			Common::exit(1);
		}
	}

	if (mvwaddstr(gpGlobal->mpFormSub[Common::FOOTER_SCREEN][0], row, col, oss.str().c_str()) == ERR) {
		LOG4_ERR(mLogger, "mvwaddstr failed");
		Common::exit(1);
	}

	wrefresh(gpGlobal->mpFormSub[Common::FOOTER_SCREEN][0]);

	if (lock) {
		Common::unlock(mLogger, &mMutexOutput);
	}
}

void ClientToolP4::output(ostringstream& oss, bool lock) {
	output(0, 0, oss, lock);
}

void ClientToolP4::processMsg(uint16_t channelID, uint64_t sendTime, uint16_t msgSize, uint16_t msgType, char* pMsgData)
{
	Common::lock(mLogger, &mMutexOutput);

	//LOG4_DEBUG(mLogger, "ClientToolP4::processMsg() - MsgSize:" << msgSize << " MsgType:" << msgType);

	Xdp::MsgHeader* pMsgHeader= (Xdp::MsgHeader*)pMsgData;
	char pMsg[msgSize];
	memcpy(pMsg, pMsgData, msgSize);

	bool bUpdateScr = true;
	uint16_t sseszseConvention;

	switch (msgType) 
	{
		case Xdp::REFRESH_COMPLETE_TYPE:
			{
				Xdp::RefreshComplete* pStruct = (Xdp::RefreshComplete*)pMsg;				
				break;
			}
		case Xdp::LINE_STATUS_TYPE: 
			{
				Xdp::LineStatus* pStruct = (Xdp::LineStatus*)pMsg;

				uint16_t channelID = pStruct->mChannelID;
				uint8_t newStatus;

				switch (pStruct->mStatus)
				{
					case 1: newStatus = 2; break;  //UP
					case 2: newStatus = 1; break;  //Part
					case 3: newStatus = 0; break;  //Down		
				}

				gpMultiIndexContainer->erase_LineStatus(pStruct->mLineType, pStruct->mChannelID);
				gpMultiIndexContainer->mLineStatusContainer.insert(MultiIndexContainer::LineStatus("", channelID, pStruct->mMsgSize, pStruct->mMsgType, pStruct->mLineType, newStatus));

				uint16_t channelIDRf;
				Global::ChannelSet::iterator iterRf;
				iterRf = gpGlobal->mRefreshChannelSet.begin();
				while (iterRf != gpGlobal->mRefreshChannelSet.end())
				{
					channelIDRf = *iterRf;

					if (channelIDRf==channelID+500)
					{
						gpMultiIndexContainer->erase_LineStatus('F', channelIDRf);     
						gpMultiIndexContainer->mLineStatusContainer.insert(MultiIndexContainer::LineStatus("", channelIDRf, pStruct->mMsgSize, pStruct->mMsgType, 'F', newStatus));
						break;
					}
					iterRf++;
				}
				break;
			}
		case Xdp::OMDCC_MARKET_DEFINITION_TYPE:
			{
				Xdp::OMDCC_MarketDefinition* pStruct = (Xdp::OMDCC_MarketDefinition*)pMsg;            
				gpMultiIndexContainer->erase_OMDCC_MarketDefinition(pStruct->mMarketCode);

				gpMultiIndexContainer->mOMDCC_MarketDefinitionContainer.insert
					(
					 MultiIndexContainer::OMDCC_MarketDefinition
					 ("", channelID, pStruct->mMsgSize, pStruct->mMsgType, string(pStruct->mMarketCode,4),
					  pStruct->mMarketName, pStruct->mCurrencyCode, pStruct->mNumberOfSecurities)
					);
				sseszseConvention = Common::SSESZSE_MARKET_DEFINITION_SESSION;
				break;
			}
		case Xdp::OMDCC_SECURITY_DEFINITION_TYPE:
			{
				Xdp::OMDCC_SecurityDefinition* pStruct = (Xdp::OMDCC_SecurityDefinition*)pMsg;
				bool bNeedToInsert = true;

				MultiIndexContainer::OMDCC_SecurityDefinition_SecurityCode& secDef_secCode
					= gpMultiIndexContainer->mOMDCC_SecurityDefinitionContainer.get<MultiIndexContainer::omdcc_securityDefinition_SecurityCode>();

				MultiIndexContainer::OMDCC_SecurityDefinition_SecurityCode::iterator secDef_Iter = secDef_secCode.find(pStruct->mSecurityCode);

				if (secDef_Iter!=secDef_secCode.end()) //replace
				{
					// Delete old record and insert again
					if ( ( secDef_Iter->mPreviousClosingPrice != pStruct->mPreviousClosingPrice ) || ( secDef_Iter->mLotSize != pStruct->mLotSize ) ||
					     ( secDef_Iter->mListingDate != pStruct->mListingDate ) || ( secDef_Iter->mDelistingDate != pStruct->mDelistingDate ) )
					{
						gpMultiIndexContainer->mOMDCC_SecurityDefinitionContainer.erase(secDef_Iter);
					}
					else //no need to update the record
					{
						bNeedToInsert = false;
					}
				}

				if ( bNeedToInsert )
				{
					char cTmp2[2];
					cTmp2[0] = pStruct->mShortSellFlag;
					cTmp2[1] = 0x00;

					gpMultiIndexContainer->mOMDCC_SecurityDefinitionContainer.insert
					(
						 MultiIndexContainer::OMDCC_SecurityDefinition
						 ("", channelID, pStruct->mMsgSize, pStruct->mMsgType, pStruct->mSecurityCode,
						  string(pStruct->mMarketCode,4), string(pStruct->mISINCode,12), string(pStruct->mInstrumentType,4),
						  string(pStruct->mFiller1,2), string(pStruct->mSecurityShortName,40), string(pStruct->mCurrencyCode,3),
						  pStruct->mSecurityNameGCCS,
						  pStruct->mSecurityNameGB,
						  pStruct->mLotSize, pStruct->mPreviousClosingPrice, string(pStruct->mFiller2,1),
						  string(cTmp2),
						  string(pStruct->mFiller3,6),
						  pStruct->mListingDate, pStruct->mDelistingDate, string(pStruct->mFiller4,3))
					);
				}
				sseszseConvention = Common::SSESZSE_SECURITY_DEFINITION_SESSION;
				break;
			}
		case Xdp::OMDCC_SECURITY_STATUS_TYPE:
			{
				Xdp::OMDCC_SecurityStatus* pStruct = (Xdp::OMDCC_SecurityStatus*)pMsg;
				gpMultiIndexContainer->erase_OMDCC_SecurityStatus(pStruct->mSecurityCode);

				createSecurityShell(pStruct->mSecurityCode);

				gpMultiIndexContainer->mOMDCC_SecurityStatusContainer.insert
					(
					 MultiIndexContainer::OMDCC_SecurityStatus
					 ("", channelID, pStruct->mMsgSize, pStruct->mMsgType, pStruct->mSecurityCode, pStruct->mSecurityTradingStatus, pStruct->mFiller, pStruct->mCircuitBreakerTradingState)
					);
				sseszseConvention = Common::SSESZSE_STATUS_TOB_STATISTICS_SESSION;
				break;
			}
		case Xdp::OMDCC_TOP_OF_BOOK_TYPE:
			{
				Xdp::OMDCC_TopOfBook* pStruct = (Xdp::OMDCC_TopOfBook*)pMsg;
				gpMultiIndexContainer->erase_OMDCC_TopOfBook(pStruct->mSecurityCode);

				//LOG4_DEBUG(mLogger, "Xdp::OMDCC_TOP_OF_BOOK_TYPE SCode: " << pStruct->mSecurityCode);
				createSecurityShell(pStruct->mSecurityCode);

				gpMultiIndexContainer->mOMDCC_TopOfBookContainer.insert
					(
					 MultiIndexContainer::OMDCC_TopOfBook
					 ("", channelID, pStruct->mMsgSize, pStruct->mMsgType, pStruct->mSecurityCode,
					  pStruct->mAggBidQty, pStruct->mAggAskQty, pStruct->mBidPrice, pStruct->mAskPrice, pStruct->mFiller)
					);
				sseszseConvention = Common::SSESZSE_STATUS_TOB_STATISTICS_SESSION;
				break;
			}
		case Xdp::OMDCC_STATISTICS_TYPE:
			{
				Xdp::OMDCC_Statistics* pStruct = (Xdp::OMDCC_Statistics*)pMsg;
				gpMultiIndexContainer->erase_OMDCC_Statistics(pStruct->mSecurityCode);

				//LOG4_DEBUG(mLogger, "Xdp::OMDCC_STATISTICS_TYPE SCode: " << pStruct->mSecurityCode);
				createSecurityShell(pStruct->mSecurityCode);

				gpMultiIndexContainer->mOMDCC_StatisticsContainer.insert
					(
					 MultiIndexContainer::OMDCC_Statistics
					 ("", channelID, pStruct->mMsgSize, pStruct->mMsgType, pStruct->mSecurityCode, pStruct->mSharesTraded,
					  pStruct->mTurnover, pStruct->mHighPrice, pStruct->mLowPrice, pStruct->mLastPrice, pStruct->mOpeningPrice, pStruct->mFiller)
					);
				sseszseConvention = Common::SSESZSE_STATUS_TOB_STATISTICS_SESSION;
				break;
			}
		default:
			LOG4_DEBUG(mLogger, "ClientToolP4::processMsg Default (" << msgType << ")");
			break;
	} // switch

	mpScreenHeader->updateScr(msgSize, msgType, pMsgData, mSource);
	mpScreenFooter->updateScr(msgSize, msgType, pMsgData, mSource);

	if (bUpdateScr && msgType == Xdp::SEQUENCE_RESET_TYPE) 
	{
		switch (mScreen) 
		{
			case Common::SSESZSE_SCREEN: 
				{
					mpScreenSSESZSE->updateScr(msgSize, sseszseConvention, pMsgData, mSource);
					break;
				}
			case Common::QUIT_SCREEN: 
				{
					mpScreenQuit->updateScr(msgSize, msgType, pMsgData, mSource);
					break;
				}
		} // switch
	}

	Common::unlock(mLogger, &mMutexOutput);
	if (msgType == Xdp::REFRESH_COMPLETE_TYPE)
	{
		refreshNcursesWindows();
	}
}

int main(int argc, char**argv) 
{
	gpGlobal = new Global();
	if (!gpGlobal->parseCommandLine(argc, argv)) {
		gpGlobal->printHelp();
		Common::exit(1);
	}

	gpGlobal->init(Common::CLIENT_TOOL_COMPONENT, "omdcc-ct-tui");  

	Logger& logger = gpGlobal->getLogger();
	Logger& userlogger = gpGlobal->getUserLogger();  

	gpGlobal->readXmlConfig(Common::CLIENT_TOOL_COMPONENT);
	gpGlobal->printConfiguration();
	gpMultiIndexContainer = new MultiIndexContainer(logger);
	gpMultiIndexContainer->ClearMktStatusNew();

	gpClientTool = new ClientToolP4(argc, argv, logger, userlogger);
	gpClientTool->startEventLoop();
	((ClientToolP4*)gpClientTool)->mpScreenSSESZSE->setClientToolPtr(gpClientTool);  
	((ClientToolP4*)gpClientTool)->mpScreenSSESZSE->sendDummyRequest();

	pthread_mutex_t mutex;
	pthread_mutex_init(&mutex, NULL);
	Common::lock(logger, &mutex);

	pthread_cond_init(&gpClientTool->mCond, NULL);
	pthread_cond_wait(&gpClientTool->mCond, &mutex);

	Global::ThreadIdSet::iterator threadIdSetIterator;
	threadIdSetIterator = gpGlobal->mThreadIdSet.begin();
	while (threadIdSetIterator != gpGlobal->mThreadIdSet.end()) {
		int retVal = pthread_kill(*threadIdSetIterator, SIGRTMIN);
		if (retVal != 0) {
			LOG4_ERR(logger, "pthread_kill failed with error  " << retVal);
		}
		threadIdSetIterator++;
	}

	threadIdSetIterator = gpGlobal->mThreadIdSet.begin();
	while (threadIdSetIterator != gpGlobal->mThreadIdSet.end()) {
		int retVal = pthread_join(*threadIdSetIterator, NULL);
		if (retVal != 0) {
			LOG4_ERR(logger, "pthread_join failed with error  " << retVal);
		}
		threadIdSetIterator++;
	}

	delete gpClientTool;

	LOG4_INFO(logger, "===========================================");
	LOG4_INFO(logger, " End of OMD-CC ClientTool P" << gpGlobal->mProductIndex << " v" << PROGRAM_VERSION);
	LOG4_INFO(logger, "===========================================");    

	return 0; 
}

bool ClientToolP4::PreSendChecking(w_u16_t infoType, const char* data)
{
	CTSeriesSearchRequest* seriesData;
	CTSnapShotRequest*     snapData;
	CTRetransRequest*      rtsData;

	CTSecuritySearchRequest     *securitySearch;
	CTSecuritySnapShotRequest   *securitySnapShot;
	CTFuturesSearchRequest      *futuresSearch;
	CTFuturesSnapShotRequest    *futuresSnapShot;

	//Check server status
	if (!gpGlobal->mServerConnected_)
	{
		mpScreenHeader->setNotice("Server not connected.");
		LOG4_INFO(mLogger, "SnapShotRequest: Ignored. Server not connected.");
		return false;
	}

	//Check criteria
	switch (infoType)
	{
		//------------------------------------------------------------------------------
		// For OMDCC
		//------------------------------------------------------------------------------
		case CT_OMDCC_SECURITY_SEARCH_REQUEST:
			securitySearch = (CTSecuritySearchRequest*)data; 
			if (securitySearch->mSecurityCode==0 && securitySearch->mMarketCode[0]==' ')
			{
				mpScreenHeader->setNotice("No searching criteria.");
				LOG4_INFO(mLogger, " Security Search: Ignored. No searching criteria.");
				return false;
			}
			break;
		case CT_OMDCC_FUTURES_SEARCH_REQUEST:
			futuresSearch = (CTFuturesSearchRequest*)data;
			if (futuresSearch->mCFFExID[0]==' ' && futuresSearch->mSettleGroupID[0]==' ' && futuresSearch->mSettleID==0)
			{
				mpScreenHeader->setNotice("No searching criteria.");
				LOG4_INFO(mLogger, " Futures Search: Ignored. No searching criteria.");
				return false;
			}
			break;
		case CT_OMDCC_SECURITY_SNAPSHOT_REQUEST:
			securitySnapShot = (CTSecuritySnapShotRequest*)data;
			if (securitySnapShot->mSecurityCode==0)
			{                
				mpScreenHeader->setNotice("No Security Code.");
				LOG4_INFO(mLogger, "Snap Shot: Ignored. No Security Code.");
				return false;
			}
			break;
		case CT_OMDCC_FUTURES_SNAPSHOT_REQUEST:
			futuresSnapShot = (CTFuturesSnapShotRequest*)data;                
			if (futuresSnapShot->mCFFExID[0]==' ')
			{                
				mpScreenHeader->setNotice("No CFFEX ID.");
				LOG4_INFO(mLogger, "Snap Shot: Ignored. No CFFEX ID.");
				return false;
			}
			break;
	}//switch    
	return true;
}

void ClientToolP4::dumpBuffer( const char* pBuf, int nBufSize )
{
	string sDisplay;
	char sTemp[ 32];

	sprintf( sTemp, "buf size|%d|", nBufSize );
	sDisplay = sTemp;

	for ( int i=0; i<nBufSize; i++ )
	{
		if ( i % 10 == 0 )
		{
			sDisplay += "\n";
		}

		sprintf( sTemp, "0x%02X ", (unsigned char)pBuf[ i] );
		sDisplay += sTemp;
	}

	//mLog->info() << "Dump: " << sDisplay << "\n";
	LOG4_INFO(mLogger, "Dump: " << sDisplay);
}

void ClientToolP4::sendSecuritySearchRequest(CTSecuritySearchRequest reqData)
{
	if (reqData.mCTType > 100)
	{
		reqData.mCTType -= 100;
	}

	if (!PreSendChecking(CT_OMDCC_SECURITY_SEARCH_REQUEST, (const char*)&reqData))
		return;
	//Send Request
	mpScreenHeader->setNotice("");    

	Message* pMsg = gpGlobal->createMsg(reqData.mSize);
	if ( pMsg->getMsgSize() < reqData.mSize )
	{
		LOG4_ERR(mLogger, "sendSecuritySearchRequest() - buffer size is not enough. request size=" << reqData.mSize << " buffer size=" << pMsg->getMsgSize() );
		delete pMsg;
		return;
	}

	char* pMsgData = pMsg->getMsgData();
	memcpy(pMsgData, &reqData, reqData.mSize);
	PacketSpool* pPacketSpool = gpGlobal->mRetProxy.pPacketSpool;
	pPacketSpool->addTcpMsg(pMsg);
	delete pMsg;

	if (pPacketSpool->sendMsgs())
	{
		//LOG4_INFO(mLogger, "Security Search Request: CTType: " << reqData.mCTType << " | InfoType: " << reqData.mInfoType << " | Size: " << reqData.mSize << " | Security Code: " << reqData.mSecurityCode << " | Market Code: " << TrimTrailingSpace(reqData.mMarketCode, 4) << " |");
	}
}

void ClientToolP4::sendSecuritySnapShotRequest(CTSecuritySnapShotRequest reqData)
{
	if (reqData.mCTType > 100)
	{
		reqData.mCTType -= 100;
	}

	if (!PreSendChecking(CT_OMDCC_SECURITY_SNAPSHOT_REQUEST, (const char*)&reqData))
		return;
	//Send Request
	mpScreenHeader->setNotice("");

	Message* pMsg = gpGlobal->createMsg(reqData.mSize);
	if ( pMsg->getMsgSize() < reqData.mSize )
	{
		LOG4_ERR(mLogger, "sendSecuritySnapShotRequest() - buffer size is not enough. request size=" << reqData.mSize << " buffer size=" << pMsg->getMsgSize() );
		delete pMsg;
		return;
	}

	char* pMsgData = pMsg->getMsgData();
	memcpy(pMsgData, &reqData, reqData.mSize);
	PacketSpool* pPacketSpool = gpGlobal->mRetProxy.pPacketSpool;
	pPacketSpool->addTcpMsg(pMsg);
	delete pMsg;

	if (pPacketSpool->sendMsgs())
	{
		//LOG4_INFO(mLogger, "Security Snap Shot Request: CTType: " << reqData.mCTType << " | InfoType: " << reqData.mInfoType << " | Size: " << reqData.mSize << " | Security Code: " << reqData.mSecurityCode << " |");
	}
}

void ClientToolP4::createSecurityShell(uint32_t securityCode)
{
	MultiIndexContainer::OMDCC_SecurityDefinition_SecurityCode& secDef_secCode = gpMultiIndexContainer->mOMDCC_SecurityDefinitionContainer.get<MultiIndexContainer::omdcc_securityDefinition_SecurityCode>();
	MultiIndexContainer::OMDCC_SecurityDefinition_SecurityCode::iterator secDef_Iter = secDef_secCode.find(securityCode);

	if (secDef_Iter!=secDef_secCode.end()) //already exist
		return;

	Xdp::OMDCC_SecurityDefinition dummySD;
	dummySD.mMsgSize = 220;
	dummySD.mMsgType = 611;
	dummySD.mSecurityCode = securityCode;
	memset(dummySD.mMarketCode, 0x20, 4);
	memset(dummySD.mISINCode, 0x20, 12);
	memset(dummySD.mInstrumentType, 0x20, 4);
	memset(dummySD.mFiller1, 0x20, 2);
	memset(dummySD.mSecurityShortName, 0x20, 40);
	memset(dummySD.mCurrencyCode, 0x20, 3);
	memset(dummySD.mSecurityNameGCCS, 0x20, 60);
	memset(dummySD.mSecurityNameGB, 0x20, 60);
	dummySD.mLotSize = 0;
	dummySD.mPreviousClosingPrice = 0;
	dummySD.mFiller2 = 0x20;
	dummySD.mShortSellFlag = 'N';
	memset(dummySD.mFiller3, 0x20, 6);
	dummySD.mListingDate = 19000101;
	dummySD.mDelistingDate = 0;
	memset(dummySD.mFiller4, 0x20, 3);

	gpMultiIndexContainer->mOMDCC_SecurityDefinitionContainer.insert
		(
		 MultiIndexContainer::OMDCC_SecurityDefinition
		 ("", 301, dummySD.mMsgSize, dummySD.mMsgType, dummySD.mSecurityCode,
		  dummySD.mMarketCode, dummySD.mISINCode, dummySD.mInstrumentType, dummySD.mFiller1,
		  dummySD.mSecurityShortName, dummySD.mCurrencyCode, dummySD.mSecurityNameGCCS,
		  dummySD.mSecurityNameGB, dummySD.mLotSize, dummySD.mPreviousClosingPrice, &dummySD.mFiller2,
		  &dummySD.mShortSellFlag, dummySD.mFiller3,
		  dummySD.mListingDate, dummySD.mDelistingDate, dummySD.mFiller4)
		);
}

