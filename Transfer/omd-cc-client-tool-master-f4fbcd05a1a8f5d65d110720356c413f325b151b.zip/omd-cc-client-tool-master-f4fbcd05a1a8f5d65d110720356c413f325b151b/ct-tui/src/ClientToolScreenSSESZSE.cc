#include "ClientToolScreenSSESZSE.h"
#include "ClientToolP4.h"

ClientToolScreenSSESZSE::ClientToolScreenSSESZSE(Logger& logger, ClientToolScreenHeader* pClientToolScreenHeader) : ClientToolScreen(logger), mpClientToolScreenHeader(pClientToolScreenHeader)
{
	if (END_FIELD > MAX_FORM_FIELDS) {
		::ErrorHandler::print(mLogger, "ClientToolScreenSSESZSE::ClientToolScreenSSESZSE", true);
	}

	mScreen = Common::SSESZSE_SCREEN;
	int formIndex = 0;
	int fieldIndex;

	int i, row;

	mThemeColor_ = Common::BLUE_BLACK_COLOR_PAIR;
	FIELD** ppField = gpGlobal->mpField[mScreen][formIndex];

	row = 1;
	//Market Definition
	fieldIndex = MARKET_DEFINITION_LABEL;
	newField(ppField, fieldIndex, 1, 17, row, 1, 0, 0, "Market Definition", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(mThemeColor_) | A_BOLD | A_UNDERLINE);
	row++;
	fieldIndex = MARKET_DEFINITION_MARKETCODE_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0, "Market Code       : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = MARKET_DEFINITION_MARKETCODE_ENTRY;
	newField(ppField, fieldIndex, 1, 4, row, 21, 0, 0, "");
	fieldIndex = MARKET_DEFINITION_MARKETNAME_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 51, 0, 0, "Market Name       : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = MARKET_DEFINITION_MARKETNAME_ENTRY;
	newField(ppField, fieldIndex, 1, 25, row, 71, 0, 0, "");
	row++;
	fieldIndex = MARKET_DEFINITION_CURRENCYCODE_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0, "Currency Code     : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = MARKET_DEFINITION_CURRENCYCODE_ENTRY;
	newField(ppField, fieldIndex, 1, 3, row, 21, 0, 0, "");
	fieldIndex = MARKET_DEFINITION_NUMBER_OF_SECURITIES_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 51, 0, 0, "No. Of Securities : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = MARKET_DEFINITION_NUMBER_OF_SECURITIES_ENTRY;
	newField(ppField, fieldIndex, 1, 13, row, 71, 0, 0, "");
	row+=2;
	//Security Information
	fieldIndex = SECURITY_DEFINITION_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0, "Security Information", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(mThemeColor_) | A_BOLD | A_UNDERLINE);
	row++;
	fieldIndex = SECURITY_DEFINITION_SECURITY_CODE_ENTRY;
	newField(ppField, fieldIndex, 1, 6, row, 1, 0, 0, "");
	fieldIndex = SECURITY_DEFINITION_SECURITY_SHORT_NAME_ENTRY;
	newField(ppField, fieldIndex, 1, 40, row, 9, 0, 0, "");
	row++;
	fieldIndex = SECURITY_DEFINITION_SECURITY_NAME_GCCS_ENTRY;
	newField(ppField, fieldIndex, 1, 60, row, 9, 0, 0, "");
	row++;
	fieldIndex = SECURITY_DEFINITION_SECURITY_NAME_GB_ENTRY;
	newField(ppField, fieldIndex, 1, 60, row, 9, 0, 0, "");
	row+=2;
	fieldIndex = SECURITY_INFORMATION_BID_LABEL;
	newField(ppField, fieldIndex, 1, 3, row, 22, 0, 0, "BID", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::GREEN_BLACK_COLOR_PAIR));
	fieldIndex = SECURITY_INFORMATION_ASK_LABEL;
	newField(ppField, fieldIndex, 1, 3, row, 36, 0, 0, "ASK", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::YELLOW_BLACK_COLOR_PAIR));
	row++;
	fieldIndex = SECURITY_INFORMATION_PRICE_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0, "Price             : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = TOP_BID_PRICE_ENTRY;
	newField(ppField, fieldIndex, 1, 15, row, 21, 0, 0, "", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::GREEN_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = TOP_ASK_PRICE_ENTRY;
	newField(ppField, fieldIndex, 1, 15, row, 35, 0, 0, "", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::YELLOW_BLACK_COLOR_PAIR) | A_BOLD);
	row++;
	fieldIndex = SECURITY_INFORMATION_AGGREGATE_QTY_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0, "Aggregate Qty.    : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = TOP_AGGREGATE_BID_QTY_ENTRY;
	newField(ppField, fieldIndex, 1, 15, row, 21, 0, 0, "", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::GREEN_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = TOP_AGGREGATE_ASK_QTY_ENTRY;
	newField(ppField, fieldIndex, 1, 15, row, 35, 0, 0, "", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::YELLOW_BLACK_COLOR_PAIR) | A_BOLD);
	row++;
	fieldIndex = STATISTICS_HIGH_PRICE_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0, "High Price        : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = STATISTICS_HIGH_PRICE_ENTRY;
	newField(ppField, fieldIndex, 1, 15, row, 21, 0, 0, "");
	row++; 
	fieldIndex = STATISTICS_LOW_PRICE_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0, "Low Price         : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = STATISTICS_LOW_PRICE_ENTRY;
	newField(ppField, fieldIndex, 1, 15, row, 21, 0, 0, "");
	row++;
	fieldIndex = SECURITY_DEFINITION_PREVIOUS_CLOSING_PRICE_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0, "Previous Closing  : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = SECURITY_DEFINITION_PREVIOUS_CLOSING_PRICE_ENTRY;
	newField(ppField, fieldIndex, 1, 13, row, 21, 0, 0, "");
	row++;
	fieldIndex = STATISTICS_LAST_PRICE_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0, "Last Price        : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = STATISTICS_LAST_PRICE_ENTRY;
	newField(ppField, fieldIndex, 1, 15, row, 21, 0, 0, "");
	row++;
	fieldIndex = STATISTICS_OPENING_PRICE_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0, "Opening Price     : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = STATISTICS_OPENING_PRICE_ENTRY;
	newField(ppField, fieldIndex, 1, 15, row, 21, 0, 0, "");
	row++;
	fieldIndex = STATISTICS_SHARES_TRADED_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0, "Shares Traded     : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = STATISTICS_SHARES_TRADED_ENTRY;
	newField(ppField, fieldIndex, 1, 30, row, 21, 0, 0, "");
	row++;
	fieldIndex = STATISTICS_TURNOVER_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0, "Turnover          : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = STATISTICS_TURNOVER_ENTRY;
	newField(ppField, fieldIndex, 1, 28, row, 21, 0, 0, "");
	fieldIndex = CIRCUIT_BREAKER_STATE_LABEL;
	newField(ppField, fieldIndex, 1, 32, row, 51, 0, 0, "Circuit Breaker Trading State : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = CIRCUIT_BREAKER_STATE_ENTRY;
	newField(ppField, fieldIndex, 1, 8, row, 83, 0, 0, "");
	row++;
	fieldIndex = SECURITY_DEFINITION_LOT_SIZE_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0, "Lot Size          : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = SECURITY_DEFINITION_LOT_SIZE_ENTRY;
	newField(ppField, fieldIndex, 1, 13, row, 21, 0, 0, "");
	fieldIndex = SECURITY_DEFINITION_SECURITY_CURRENCY_CODE_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 51, 0, 0, "Currency Code     : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = SECURITY_DEFINITION_SECURITY_CURRENCY_CODE_ENTRY;
	newField(ppField, fieldIndex, 1, 3, row, 71, 0, 0, "");
	row++;
	fieldIndex = SECURITY_DEFINITION_ISIN_CODE_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0, "ISIN Code         : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = SECURITY_DEFINITION_ISIN_CODE_ENTRY;
	newField(ppField, fieldIndex, 1, 12, row, 21, 0, 0, "");
	fieldIndex = SECURITY_DEFINITION_INSTRUMENT_TYPE_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 51, 0, 0, "Instrument Type   : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = SECURITY_DEFINITION_INSTRUMENT_TYPE_ENTRY;
	newField(ppField, fieldIndex, 1, 4, row, 71, 0, 0, "");
	row++;
	fieldIndex = SECURITY_DEFINITION_SHORT_SELL_FLAG_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0,  "Short Sell Flag   : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = SECURITY_DEFINITION_SHORT_SELL_FLAG_ENTRY;
	newField(ppField, fieldIndex, 1, 1, row, 21, 0, 0, "");
	//  fieldIndex = SECURITY_DEFINITION_SPREAD_TABLE_CODE_LABEL;
	//  newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0, "Spread Table Code : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	//  fieldIndex = SECURITY_DEFINITION_SPREAD_TABLE_CODE_ENTRY;
	//  newField(ppField, fieldIndex, 1, 2, row, 21, 0, 0, "");

	fieldIndex = TRADING_STATUS_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 51, 0, 0, "Trading Status    : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = TRADING_STATUS_ENTRY;
	newField(ppField, fieldIndex, 1, 16, row, 71, 0, 0, "");
	row++;
	fieldIndex = SECURITY_DEFINITION_LISTING_DATE_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 1, 0, 0, "Listing Date      : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = SECURITY_DEFINITION_LISTING_DATE_ENTRY;
	newField(ppField, fieldIndex, 1, 20, row, 21, 0, 0, "");
	fieldIndex = SECURITY_DEFINITION_DELISTING_DATE_LABEL;
	newField(ppField, fieldIndex, 1, 20, row, 51, 0, 0, "Delisting Date    : ", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = SECURITY_DEFINITION_DELISTING_DATE_ENTRY;
	newField(ppField, fieldIndex, 1, 20, row, 71, 0, 0, "");
	//
	row+=2;
	fieldIndex = SECURITY_LIST_LABEL;
	newField(ppField, fieldIndex, 1, 13, row, 1, 0, 0, "Security List", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(mThemeColor_) | A_BOLD | A_UNDERLINE);
	row+=2;
	fieldIndex = SECURITY_LIST_SECURITY_CODE_LABEL;
	newField(ppField, fieldIndex, 1, 13, row/*SECURITY_LIST_HEADER_ROW*/, 1, 0, 0, "Security Code", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = SECURITY_LIST_SHORT_NAME_LABEL;
	newField(ppField, fieldIndex, 1, 40, row/*SECURITY_LIST_HEADER_ROW*/, 15, 0, 0, "Security Short Name", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = SECURITY_LIST_MARKET_CODE_LABEL;
	newField(ppField, fieldIndex, 1, 11, row/*SECURITY_LIST_HEADER_ROW*/, 56, 0, 0, "Market Code", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	fieldIndex = SECURITY_LIST_INSTRUMENT_TYPE_LABEL;
	newField(ppField, fieldIndex, 1, 15, row/*SECURITY_LIST_HEADER_ROW*/, 68, 0, 0, "Instrument Type", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	row++;

	for (i=0; i<MAX_SECURITY_LIST_ROWS; i++)
	{
		fieldIndex = SECURITY_LIST_SECURITY_CODE_ENTRY_0 + i;
		newField(ppField, fieldIndex, 1, 13, row, 1, 0, 0, "", JUSTIFY_RIGHT, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR));

		fieldIndex = SECURITY_LIST_SHORT_NAME_ENTRY_0 + i;
		newField(ppField, fieldIndex, 1, 40, row, 15, 0, 0, "", JUSTIFY_RIGHT, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR));

		fieldIndex = SECURITY_LIST_MARKET_CODE_ENTRY_0 + i;
		newField(ppField, fieldIndex, 1, 11, row, 56, 0, 0, "", JUSTIFY_RIGHT, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR));

		fieldIndex = SECURITY_LIST_INSTRUMENT_TYPE_ENTRY_0 + i;
		newField(ppField, fieldIndex, 1, 15, row, 68, 0, 0, "", JUSTIFY_RIGHT, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR));
		row++;
	}
	fieldIndex = SECURITY_LIST_RECORD_ENTRY;
	newField(ppField, fieldIndex, 1, 24, row, 1, 0, 0, "", NO_JUSTIFICATION, 0, O_ACTIVE, COLOR_PAIR(Common::WHITE_BLACK_COLOR_PAIR) | A_BOLD);
	//
	memset(mSecurityListRowUsed, 0, sizeof(mSecurityListRowUsed));
	mSecurityListIsSelected = false;
	mSecurityListWasSelected = false;
	memset(mSecurityCode, 0, sizeof(mSecurityCode));
	mSecurityListSkipRows = 0;
	mSecurityListTableSelected = false;
	mLastSnapShot = 0;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------
ClientToolScreenSSESZSE::~ClientToolScreenSSESZSE()
{
	;
}
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::printTestFields(void)
{
	setFieldBuffer(SECURITY_LIST_SECURITY_CODE_ENTRY_0, "7");
	setFieldBuffer(SECURITY_LIST_SECURITY_CODE_ENTRY_1, "2026");
	setFieldBuffer(SECURITY_LIST_SECURITY_CODE_ENTRY_2, "2233");
	setFieldBuffer(SECURITY_LIST_SECURITY_CODE_ENTRY_3, "2594");
	setFieldBuffer(SECURITY_LIST_SECURITY_CODE_ENTRY_4, "2604");
	setFieldBuffer(SECURITY_LIST_SECURITY_CODE_ENTRY_5, "300283");
	setFieldBuffer(SECURITY_LIST_SECURITY_CODE_ENTRY_6, "300284");
	setFieldBuffer(SECURITY_LIST_SECURITY_CODE_ENTRY_7, "300285");
	setFieldBuffer(SECURITY_LIST_SECURITY_CODE_ENTRY_8, "300286");
	setFieldBuffer(SECURITY_LIST_SECURITY_CODE_ENTRY_9, "300287");
	setFieldBuffer(SECURITY_LIST_SECURITY_CODE_ENTRY_10, "300288");

	setFieldBuffer(SECURITY_LIST_SHORT_NAME_ENTRY_0, "ZERO-SEVEN");
	setFieldBuffer(SECURITY_LIST_SHORT_NAME_ENTRY_1, "SHANDONG WEIDA");
	setFieldBuffer(SECURITY_LIST_SHORT_NAME_ENTRY_2, "TAPAI GROUP");
	setFieldBuffer(SECURITY_LIST_SHORT_NAME_ENTRY_3, "BYD");
	setFieldBuffer(SECURITY_LIST_SHORT_NAME_ENTRY_4, "LONGLIVE BIO");
	setFieldBuffer(SECURITY_LIST_SHORT_NAME_ENTRY_5, "WENZHOU HONGFENG");
	setFieldBuffer(SECURITY_LIST_SHORT_NAME_ENTRY_6, "JSTI");
	setFieldBuffer(SECURITY_LIST_SHORT_NAME_ENTRY_7, "SINOCERA MATERIAL");
	setFieldBuffer(SECURITY_LIST_SHORT_NAME_ENTRY_8, "ACREL");
	setFieldBuffer(SECURITY_LIST_SHORT_NAME_ENTRY_9, "PHLX");
	setFieldBuffer(SECURITY_LIST_SHORT_NAME_ENTRY_10, "LONGMASTER INFO-TECH");

	for (int i=0; i<11; i++)
	{
		setFieldBuffer(SECURITY_LIST_MARKET_CODE_ENTRY_0+i, "ASZR");
		setFieldBuffer(SECURITY_LIST_INSTRUMENT_TYPE_ENTRY_0+i, "EQTY");
		mSecurityListRowUsed[i] = true;
	}

	setFieldBack(SECURITY_LIST_SECURITY_CODE_ENTRY_3, A_REVERSE);
	setFieldBack(SECURITY_LIST_SHORT_NAME_ENTRY_3, A_REVERSE); 
	setFieldBack(SECURITY_LIST_MARKET_CODE_ENTRY_3, A_REVERSE); 
	setFieldBack(SECURITY_LIST_INSTRUMENT_TYPE_ENTRY_3, A_REVERSE); 

	setFieldBuffer(MARKET_DEFINITION_MARKETCODE_ENTRY, "ASZR");
	setFieldBuffer(MARKET_DEFINITION_MARKETNAME_ENTRY, "XSHG A-SHARES SEGMENT    ");  
	setFieldBuffer(MARKET_DEFINITION_CURRENCYCODE_ENTRY, "CNY");
	setFieldBuffer(MARKET_DEFINITION_NUMBER_OF_SECURITIES_ENTRY, "111");
	setFieldBuffer(SECURITY_DEFINITION_ISIN_CODE_ENTRY, "123456789012");
	setFieldBuffer(SECURITY_DEFINITION_INSTRUMENT_TYPE_ENTRY, "EQTY");
	//  setFieldBuffer(SECURITY_DEFINITION_SPREAD_TABLE_CODE_ENTRY, "01");
	setFieldBuffer(SECURITY_DEFINITION_SECURITY_CURRENCY_CODE_ENTRY, "CNY");  
	setFieldBuffer(SECURITY_DEFINITION_LOT_SIZE_ENTRY, "100");
	setFieldBuffer(SECURITY_DEFINITION_PREVIOUS_CLOSING_PRICE_ENTRY, "$63.580");
	setFieldBuffer(SECURITY_DEFINITION_LISTING_DATE_ENTRY, "2015-01-01");
	setFieldBuffer(SECURITY_DEFINITION_DELISTING_DATE_ENTRY, "N/A");
	setFieldBuffer(SECURITY_DEFINITION_SECURITY_CODE_ENTRY, " 2594");
	setFieldBuffer(SECURITY_DEFINITION_SECURITY_SHORT_NAME_ENTRY, "BYD Co. Ltd.");
	setFieldBuffer(SECURITY_DEFINITION_SHORT_SELL_FLAG_ENTRY, "N");

	char inbuf[60];
	memset(inbuf, 0x00, 60);
	inbuf[0] = 0xD4;
	inbuf[1] = 0x6B;
	inbuf[3] = 0x4E;
	inbuf[2] = 0x9A;
	inbuf[5] = 0x8F;
	inbuf[4] = 0xEA;
	inbuf[7] = 0x80;
	inbuf[6] = 0xA1;
	inbuf[9] = 0x4E;
	inbuf[8] = 0xFD;
	inbuf[11] = 0x67;
	inbuf[10] = 0x09;
	inbuf[13] = 0x96;
	inbuf[12] = 0x50;
	inbuf[15] = 0x51;
	inbuf[14] = 0x6C;
	inbuf[17] = 0x53;
	inbuf[16] = 0xF8;
	size_t inbytesleft = 60;
	char*  outbuf;
	char*  pIn = inbuf;

	char cTmp[30];
	memset(cTmp, 0x00, sizeof(cTmp));

        char* utf8 = Common::UTF16LE_to_UTF8(mLogger, &pIn, inbytesleft);
	memcpy(cTmp, utf8, 30);
	delete[] utf8;

	setFieldBuffer(SECURITY_DEFINITION_SECURITY_NAME_GB_ENTRY, cTmp);
	setFieldBuffer(SECURITY_DEFINITION_SECURITY_NAME_GCCS_ENTRY, cTmp);

	setFieldBuffer(TRADING_STATUS_ENTRY, "2 (Trading Halt)");
	setFieldBuffer(TOP_BID_PRICE_ENTRY, "$59.120");
	setFieldBuffer(TOP_ASK_PRICE_ENTRY, "$59.130");
	setFieldBuffer(TOP_AGGREGATE_BID_QTY_ENTRY, "28,000");
	setFieldBuffer(TOP_AGGREGATE_ASK_QTY_ENTRY, "28,000");
	setFieldBuffer(STATISTICS_SHARES_TRADED_ENTRY, "30,000");
	setFieldBuffer(STATISTICS_TURNOVER_ENTRY, "$778,200");
	setFieldBuffer(STATISTICS_HIGH_PRICE_ENTRY, "$60.110");
	setFieldBuffer(STATISTICS_LOW_PRICE_ENTRY, "$58.900");  
	setFieldBuffer(STATISTICS_LAST_PRICE_ENTRY, "$59.100");
	setFieldBuffer(STATISTICS_OPENING_PRICE_ENTRY, "$57.500");
}
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::createForms()
{
	int formIndex = 0;

	FORM* pForm = mpNcursesWrapper->new_form(gpGlobal->mpField[mScreen][formIndex]);
	gpGlobal->mpForm[mScreen][formIndex] = pForm;

	WINDOW* pFormWin = mpNcursesWrapper->newwin(MAX_FORM_ROWS, MAX_FORM_COLS, MAX_HEADER_ROWS+MAX_MENU_ROWS, 0);
	gpGlobal->mpFormWin[mScreen][formIndex] = pFormWin;
	set_form_win(pForm, pFormWin);

	WINDOW* pFormSub = mpNcursesWrapper->derwin(pFormWin, MAX_FORM_ROWS, MAX_FORM_COLS, 0, 0);
	gpGlobal->mpFormSub[mScreen][formIndex] = pFormSub;
	set_form_sub(pForm, pFormSub);

	mpFormSub[formIndex] = pFormSub;
	mpNcursesWrapper->post_form(pForm);
}
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::printFieldLabels()
{
	WINDOW* pFormSub = mpFormSub[0];

	wborder(pFormSub, COLOR_PAIR(mThemeColor_) | A_BOLD | ACS_VLINE,
			COLOR_PAIR(mThemeColor_) | A_BOLD | ACS_VLINE,
			COLOR_PAIR(mThemeColor_) | A_BOLD | ACS_HLINE,
			COLOR_PAIR(mThemeColor_) | A_BOLD | ACS_HLINE,
			COLOR_PAIR(mThemeColor_) | A_BOLD | ACS_ULCORNER,
			COLOR_PAIR(mThemeColor_) | A_BOLD | ACS_URCORNER,
			COLOR_PAIR(mThemeColor_) | A_BOLD | ACS_LLCORNER,
			COLOR_PAIR(mThemeColor_) | A_BOLD | ACS_LRCORNER);

	set_menu_fore(gpGlobal->mpMenu, COLOR_PAIR(Common::BLACK_BLUE_COLOR_PAIR) | A_BOLD);
	post_menu(gpGlobal->mpMenu);
	wrefresh(gpGlobal->mpMenuWin);

	mvwvline(pFormSub, 27, 14, COLOR_PAIR(mThemeColor_) | A_BOLD | ACS_VLINE, 16);
	mvwvline(pFormSub, 27, 55, COLOR_PAIR(mThemeColor_) | A_BOLD | ACS_VLINE, 16);
	mvwvline(pFormSub, 27, 67, COLOR_PAIR(mThemeColor_) | A_BOLD | ACS_VLINE, 16);  
	mvwvline(pFormSub, 27, 83, COLOR_PAIR(mThemeColor_) | A_BOLD | ACS_VLINE, 16);

	updateSecurityListRecord();
}
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::clearFieldData(int fieldIndex)
{
	int formIndex = 0;
	FIELD* pField = gpGlobal->mpField[mScreen][formIndex][fieldIndex];
	mpNcursesWrapper->set_field_buffer(pField, 0, "");
}
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::clearScr(uint16_t msgType, uint8_t side)
{
	WINDOW* pFormSub = mpFormSub[0];

	switch (msgType)
	{
		case Common::SSESZSE_SECURITY_LIST_SESSION:
			{
				for (int i=0; i<MAX_SECURITY_LIST_ROWS; i++)
				{
					clearFieldData(SECURITY_LIST_SECURITY_CODE_ENTRY_0 + i);
					clearFieldData(SECURITY_LIST_SHORT_NAME_ENTRY_0 + i);
					clearFieldData(SECURITY_LIST_MARKET_CODE_ENTRY_0 + i);
					clearFieldData(SECURITY_LIST_INSTRUMENT_TYPE_ENTRY_0 + i);
					setFieldBack(SECURITY_LIST_SECURITY_CODE_ENTRY_0 + i, A_NORMAL);
					setFieldBack(SECURITY_LIST_SHORT_NAME_ENTRY_0 + i, A_NORMAL);
					setFieldBack(SECURITY_LIST_MARKET_CODE_ENTRY_0 + i, A_NORMAL);
					setFieldBack(SECURITY_LIST_INSTRUMENT_TYPE_ENTRY_0 + i, A_NORMAL);
				}
				break;
			}
		case Common::SSESZSE_MARKET_DEFINITION_SESSION:
			{
				clearFieldData(MARKET_DEFINITION_MARKETCODE_ENTRY);
				clearFieldData(MARKET_DEFINITION_MARKETNAME_ENTRY);
				clearFieldData(MARKET_DEFINITION_CURRENCYCODE_ENTRY);
				clearFieldData(MARKET_DEFINITION_NUMBER_OF_SECURITIES_ENTRY);
				break;
			}							
		case Common::SSESZSE_SECURITY_DEFINITION_SESSION:
			{
				clearFieldData(SECURITY_DEFINITION_ISIN_CODE_ENTRY);
				clearFieldData(SECURITY_DEFINITION_INSTRUMENT_TYPE_ENTRY);
				//        clearFieldData(SECURITY_DEFINITION_SPREAD_TABLE_CODE_ENTRY);
				clearFieldData(SECURITY_DEFINITION_SECURITY_CURRENCY_CODE_ENTRY);
				clearFieldData(SECURITY_DEFINITION_LOT_SIZE_ENTRY);
				clearFieldData(SECURITY_DEFINITION_PREVIOUS_CLOSING_PRICE_ENTRY);
				clearFieldData(SECURITY_DEFINITION_LISTING_DATE_ENTRY);
				clearFieldData(SECURITY_DEFINITION_DELISTING_DATE_ENTRY);
				clearFieldData(SECURITY_DEFINITION_SHORT_SELL_FLAG_ENTRY);
				clearFieldData(SECURITY_DEFINITION_SECURITY_SHORT_NAME_ENTRY);
				clearFieldData(SECURITY_DEFINITION_SECURITY_NAME_GCCS_ENTRY);
				clearFieldData(SECURITY_DEFINITION_SECURITY_NAME_GB_ENTRY);
				clearFieldData(SECURITY_DEFINITION_SECURITY_CODE_ENTRY);
				break;
			}
		case Common::SSESZSE_STATUS_TOB_STATISTICS_SESSION:
			{
				clearFieldData(TRADING_STATUS_ENTRY);
				clearFieldData(TOP_BID_PRICE_ENTRY);
				clearFieldData(TOP_ASK_PRICE_ENTRY);
				clearFieldData(TOP_AGGREGATE_BID_QTY_ENTRY);
				clearFieldData(TOP_AGGREGATE_ASK_QTY_ENTRY);
				clearFieldData(STATISTICS_SHARES_TRADED_ENTRY);
				clearFieldData(STATISTICS_TURNOVER_ENTRY);
				clearFieldData(STATISTICS_HIGH_PRICE_ENTRY);
				clearFieldData(STATISTICS_LOW_PRICE_ENTRY);
				clearFieldData(STATISTICS_LAST_PRICE_ENTRY);
				clearFieldData(STATISTICS_OPENING_PRICE_ENTRY);
				clearFieldData(CIRCUIT_BREAKER_STATE_ENTRY);
				break;
			}
		default:
			break;
	} // switch
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::printSecurityListFields(uint32_t securityCode, uint32_t* pSecurityListSkipRows)
{
	if (*pSecurityListSkipRows)
	{
		(*pSecurityListSkipRows)--;
		return;
	}//if

	const MultiIndexContainer::OMDCC_SecurityDefinition_SecurityCode& securityDefinition_SecurityCode 
		= gpMultiIndexContainer->mOMDCC_SecurityDefinitionContainer.get<MultiIndexContainer::omdcc_securityDefinition_SecurityCode>();

	MultiIndexContainer::OMDCC_SecurityDefinition_SecurityCode::iterator it
		= securityDefinition_SecurityCode.find(securityCode);

	char    shortName[41];
	char    marketCode[5];
	char    instrType[5];
	shortName[40] = 0x00;
	marketCode[4] = 0x00;
	instrType[4] = 0x00;

	int i = 0;
	while (mSecurityListRowUsed[i])
	{
		i++;
	}//while

	while (it!=securityDefinition_SecurityCode.end() && i<MAX_SECURITY_LIST_ROWS)
	{
		MultiIndexContainer::OMDCC_SecurityDefinition omdcc_securitydefinition = *it;
		if (securityCode != omdcc_securitydefinition.mSecurityCode)
			break;
		mSecurityListRowUsed[i] = true;
		mSecurityCode[i] = omdcc_securitydefinition.mSecurityCode;

		if (mSecurityListIsSelected && mSecurityCodeSelected==omdcc_securitydefinition.mSecurityCode)
		{               
			setFieldBack(SECURITY_LIST_SECURITY_CODE_ENTRY_0+i, A_REVERSE);
			setFieldBack(SECURITY_LIST_SHORT_NAME_ENTRY_0+i, A_REVERSE);
			setFieldBack(SECURITY_LIST_MARKET_CODE_ENTRY_0+i, A_REVERSE);
			setFieldBack(SECURITY_LIST_INSTRUMENT_TYPE_ENTRY_0+i, A_REVERSE);
		} 
		setFieldBuffer(SECURITY_LIST_SECURITY_CODE_ENTRY_0+i, omdcc_securitydefinition.mSecurityCode);

		memcpy(shortName, omdcc_securitydefinition.mSecurityShortName.c_str(), 40);
		setFieldBuffer(SECURITY_LIST_SHORT_NAME_ENTRY_0+i, shortName);

		memcpy(marketCode, omdcc_securitydefinition.mMarketCode.c_str(), 4);
		setFieldBuffer(SECURITY_LIST_MARKET_CODE_ENTRY_0+i,  marketCode);

		memcpy(instrType, omdcc_securitydefinition.mInstrumentType.c_str(), 4);
		setFieldBuffer(SECURITY_LIST_INSTRUMENT_TYPE_ENTRY_0+i, instrType);
		it++;
		i++; 
	}//while   
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::printFilteredFields(void)
{
	clearScr(Common::SSESZSE_SECURITY_LIST_SESSION);
	memset(mSecurityListRowUsed, 0, sizeof(mSecurityListRowUsed));
	mNoOfSecurity = 0;

	for (int i=0; i<MAX_SECURITY_LIST_ROWS; i++)
	{ 
		setFieldBack(SECURITY_LIST_SECURITY_CODE_ENTRY_0+i, A_NORMAL);
		setFieldBack(SECURITY_LIST_SHORT_NAME_ENTRY_0+i, A_NORMAL);
		setFieldBack(SECURITY_LIST_MARKET_CODE_ENTRY_0+i, A_NORMAL);
		setFieldBack(SECURITY_LIST_INSTRUMENT_TYPE_ENTRY_0+i, A_NORMAL);
	}
	bool        bSecurityExist = false;
	bool        bMarketExist = false;
	bool        bSearchSecurity = (gpGlobal->mOMDCC_SecurityCode_CFFExGpID[0]!=' ');
	bool        bSearchMarket = (gpGlobal->mOMDCC_MarketCode_CFFExID[0]!=' ');
	gpGlobal->mOMDCC_MarketCode_CFFExID[4] = 0x00;
	string      marketcode(gpGlobal->mOMDCC_MarketCode_CFFExID);
	uint32_t    securitycode=atoi(gpGlobal->mOMDCC_SecurityCode_CFFExGpID);
	uint32_t    securityListSkipRows = mSecurityListSkipRows;

	//    if (bSearchSecurity || bSearchMarket)
	//    {
	//        LOG4_DEBUG(mLogger, "ClientToolScreenSSESZSE::printFilteredFields marketcode [" << marketcode
	//                        << "] securitycode [" << securitycode << "] securityListSkipRows [" << securityListSkipRows << "]");
	//    }

	//Search Security Code  
	const MultiIndexContainer::OMDCC_SecurityDefinition_SecurityCode& securityDefinition_SecurityCode
		= gpMultiIndexContainer->mOMDCC_SecurityDefinitionContainer.get<MultiIndexContainer::omdcc_securityDefinition_SecurityCode>();
	//-------------------------------------------------------------------------------------------------------------
	/*
	   LOG4_DEBUG(mLogger, ">>>>>>>>>>>>> Loop security code: ");

	   for ( mpClientToolScreenHeader->mOMDCC_SecurityDefinition_SecurityCode_iterator = securityDefinition_SecurityCode.begin();
	   mpClientToolScreenHeader->mOMDCC_SecurityDefinition_SecurityCode_iterator!= securityDefinition_SecurityCode.end();
	   mpClientToolScreenHeader->mOMDCC_SecurityDefinition_SecurityCode_iterator++ )
	   {
	   LOG4_DEBUG(mLogger, "Security Code: " << mpClientToolScreenHeader->mOMDCC_SecurityDefinition_SecurityCode_iterator->mSecurityCode);
	   }
	   LOG4_DEBUG(mLogger, ">>>>>>>>>>>>> Loop security code: <<<<<<<<<<<<<<<");
	   */
	//-------------------------------------------------------------------------------------------------------------
	if (bSearchSecurity)
	{
		mpClientToolScreenHeader->mOMDCC_SecurityDefinition_SecurityCode_iterator = securityDefinition_SecurityCode.find(securitycode);
		bSecurityExist = (mpClientToolScreenHeader->mOMDCC_SecurityDefinition_SecurityCode_iterator!=securityDefinition_SecurityCode.end());
		//LOG4_DEBUG(mLogger, "bSecurityExist = " << bSecurityExist);
	}
	//Search Market Code
	const MultiIndexContainer::OMDCC_SecurityDefinition_MarketCode& securityDefinition_MarketCode
		= gpMultiIndexContainer->mOMDCC_SecurityDefinitionContainer.get<MultiIndexContainer::omdcc_securityDefinition_MarketCode>();
	const MultiIndexContainer::OMDCC_MarketDefinition_MarketCode& marketDefinition_MarketCode
		= gpMultiIndexContainer->mOMDCC_MarketDefinitionContainer.get<MultiIndexContainer::omdcc_marketDefinition_MarketCode>();
	if (bSearchMarket)
	{

		//-------------------------------------------------------------------------------------------------------------
		/*
		   LOG4_DEBUG(mLogger, ">>>>>>>>>>>>> Loop market code: ");

		   for ( mpClientToolScreenHeader->mOMDCC_MarketDefinition_MarketCode_iterator = marketDefinition_MarketCode.begin();
		   mpClientToolScreenHeader->mOMDCC_MarketDefinition_MarketCode_iterator != marketDefinition_MarketCode.end();
		   mpClientToolScreenHeader->mOMDCC_MarketDefinition_MarketCode_iterator++ )
		   {
		   LOG4_DEBUG(mLogger, "Market Code: " << mpClientToolScreenHeader->mOMDCC_MarketDefinition_MarketCode_iterator->mMarketCode);
		   }
		   LOG4_DEBUG(mLogger, ">>>>>>>>>>>>> Loop market code: <<<<<<<<<<<<<<<");
		   */
		//-------------------------------------------------------------------------------------------------------------

		//mpClientToolScreenHeader->mOMDCC_SecurityDefinition_MarketCode_iterator = securityDefinition_MarketCode.find(marketcode);
		//bMarketExist = (mpClientToolScreenHeader->mOMDCC_SecurityDefinition_MarketCode_iterator!=securityDefinition_MarketCode.end());
		mpClientToolScreenHeader->mOMDCC_MarketDefinition_MarketCode_iterator = marketDefinition_MarketCode.find(marketcode);
		bMarketExist = (mpClientToolScreenHeader->mOMDCC_MarketDefinition_MarketCode_iterator!=marketDefinition_MarketCode.end());
		//LOG4_DEBUG(mLogger, "bMarketExist = " << bMarketExist);
	}
	// 
	if (bSearchSecurity && bSecurityExist && !bSearchMarket) //security code (market code not exist)
	{
		mNoOfSecurity++;
		printSecurityListFields(securitycode, &securityListSkipRows); 
	}
	else if (bSearchMarket && bMarketExist && !bSearchSecurity) //market code (security code not exist)
	{
		MultiIndexContainer::OMDCC_SecurityDefinition_MarketCode::iterator iter;
		for (iter=securityDefinition_MarketCode.begin(); iter!=securityDefinition_MarketCode.end(); iter++)
		{
			if (!marketcode.compare(0, 4, iter->mMarketCode, 0, 4))
			{
				mNoOfSecurity++;
				printMarketDefinitionFileds();
				printSecurityListFields(iter->mSecurityCode, &securityListSkipRows);
			}
		}
	}
	else if (bSearchSecurity && bSecurityExist && bSearchMarket && bMarketExist) //both
	{
		if (!marketcode.compare(0, 4, mpClientToolScreenHeader->mOMDCC_SecurityDefinition_SecurityCode_iterator->mMarketCode, 0, 4))
		{
			mNoOfSecurity++;
			printSecurityListFields(securitycode, &securityListSkipRows);;
		}
	}
	//auto select the first series
	if (mSecurityListRowUsed[0] && !mSecurityListIsSelected)
	{
		selectSecurityList(mSecurityCode[0]);
	}
	//printStatusTOBStatisticsFields();    
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::refresh()
{
	Common::Source source=Common::CACHE_SOURCE;

	//Reload data agaiin
	uint64_t currentTime = Common::getUint64Time(mLogger);

	if ((currentTime - mLastSnapShot)/1000000 >= (gpGlobal->mSnapshotInterval))
	{
		mLastSnapShot = currentTime;

		if (!((gpGlobal->mOMDCC_MarketCode_CFFExID[0]==0x00 || gpGlobal->mOMDCC_MarketCode_CFFExID[0]==0x20) && (gpGlobal->mOMDCC_SecurityCode_CFFExGpID[0]==0x00 || gpGlobal->mOMDCC_SecurityCode_CFFExGpID[0]==0x20)))
		{
			sendRequest();
		}
	}

	updateScr(0, Common::SSESZSE_SECURITY_LIST_SESSION, 0, source);
	updateScr(0, Common::SSESZSE_MARKET_DEFINITION_SESSION, 0, source);
	updateScr(0, Common::SSESZSE_SECURITY_DEFINITION_SESSION, 0, source);
	updateScr(0, Common::SSESZSE_STATUS_TOB_STATISTICS_SESSION, 0, source);
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::deselectSecurityList()
{
	mSecurityListIsSelected = false;
	clearScr(Common::SSESZSE_SECURITY_LIST_SESSION);
	clearScr(Common::SSESZSE_MARKET_DEFINITION_SESSION);
	clearScr(Common::SSESZSE_SECURITY_DEFINITION_SESSION);
	clearScr(Common::SSESZSE_STATUS_TOB_STATISTICS_SESSION);
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::updateSecurityListRecord()
{
	setFieldBuffer(SECURITY_LIST_RECORD_ENTRY, mSecurityListSkipRows);
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::handleFilterCriteriaChange()
{
	mSecurityListIsSelected = false;
	mSecurityListWasSelected = false;
	deselectSecurityList();
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::selectSecurityList(uint32_t securityCode)
{
	mSecurityListIsSelected = true;
	mSecurityListWasSelected = true;
	mSecurityCodeSelected = securityCode;

	mSecuritySnapShotReq_.mSize = sizeof(mSecuritySnapShotReq_); 
	mSecuritySnapShotReq_.mInfoType = CT_OMDCC_SECURITY_SNAPSHOT_REQUEST;
	mSecuritySnapShotReq_.mCTType = gpGlobal->mProductIndex;
	mSecuritySnapShotReq_.mSecurityCode = securityCode;

	((ClientToolP4*)mClientToolP4_)->sendSecuritySnapShotRequest(mSecuritySnapShotReq_);
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::setClientToolPtr(void* ptr)
{
	mClientToolP4_ = ptr;
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
int ClientToolScreenSSESZSE::getSelectedField(int y, int x)
{
	int formIndex = 0;
	int fieldIndex;
	FIELD* pField;
	int rows, cols, frow, fcol, nrow, nbuf;
	/*
	   fieldIndex = SECURITY_LIST_LABEL;
	   pField = gpGlobal->mpField[mScreen][formIndex][fieldIndex];
	   field_info(pField, &rows, &cols, &frow, &fcol, &nrow, &nbuf);
	   if (y == frow && fcol <= x && x <= fcol+cols-1) {
	   return fieldIndex;
	   }
	   */
	int frowFirstField;
	int rowFirstField;

	fieldIndex = SECURITY_LIST_SECURITY_CODE_ENTRY_0;
	pField = gpGlobal->mpField[mScreen][formIndex][fieldIndex];
	field_info(pField, &rowFirstField, &cols, &frowFirstField, &fcol, &nrow, &nbuf);

	/*
	   LOG4_DEBUG(mLogger, "x = " << x << " y = " << y 
	   << " frowFirstField = " << frowFirstField
	   << " rowFirstField = " << rowFirstField 
	   << " SECURITY_LIST_SECURITY_CODE_ENTRY_0 = " << SECURITY_LIST_SECURITY_CODE_ENTRY_0);
	   */
	if ((34 <= y && y <= 48) && (1 <= x && x <= 82) && (x!=14 && x!=55 && x!=67))
	{
		return SECURITY_LIST_SECURITY_CODE_ENTRY_0 + y - 34;
	}

	/*
	   for (fieldIndex = SECURITY_LIST_SECURITY_CODE_ENTRY_0;
	   fieldIndex <= SECURITY_LIST_INSTRUMENT_TYPE_ENTRY_14; fieldIndex++)
	   {
	   pField = gpGlobal->mpField[mScreen][formIndex][fieldIndex];
	   field_info(pField, &rows, &cols, &frow, &fcol, &nrow, &nbuf);

	   LOG4_DEBUG(mLogger, "frow = " << frow << " fcol = " << fcol);

	   if (y == frow && fcol <= x && x <= fcol+cols-1)
	   {
	//return SECURITY_LIST_SECURITY_CODE_ENTRY_0 + y - frowFirstField;
	return SECURITY_LIST_SECURITY_CODE_ENTRY_0 + y - 34;//rowFirstField; //34
	}
	}
	*/
	/*
	   for (fieldIndex = BEGIN_FIELD; fieldIndex < END_FIELD; fieldIndex++)
	   {
	   pField = gpGlobal->mpField[mScreen][formIndex][fieldIndex];
	   field_info(pField, &rows, &cols, &frow, &fcol, &nrow, &nbuf);
	   if (y == frow && fcol <= x && x <= fcol+cols-1) {
	   return fieldIndex;
	   }
	   }
	   */
	return INVALID_FIELD;
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::processChar(int ch)
{
	printFieldLabels();

	MEVENT event;

	enum Common::Screen screen = Common::HEADER_SCREEN;
	int formIndex = 0;
	FORM*& pForm = gpGlobal->mpForm[screen][formIndex];

	switch (ch)
	{
		case KEY_BACKSPACE:
			{
				FIELD* pCurrentField = mpNcursesWrapper->current_field(pForm);
				char* buffer = field_buffer(pCurrentField, 0);
				FIELD** ppField = gpGlobal->mpField[screen][formIndex];

				int bufferLen = -1;
				if (pCurrentField == ppField[ClientToolScreenHeader::OMDCC_MKTCODE_CFFEXID_ENTRY])
				{
					bufferLen = sizeof(gpGlobal->mOMDCC_MarketCode_CFFExID)-1;
				}
				else if (pCurrentField == ppField[ClientToolScreenHeader::OMDCC_SECCODE_FFXGPID_ENTRY])
				{
					bufferLen = sizeof(gpGlobal->mOMDCC_SecurityCode_CFFExGpID)-1;
				}

				if (bufferLen != -1)
				{
					if (buffer[bufferLen-1] == ' ')
					{
						mpNcursesWrapper->form_driver(pForm, REQ_DEL_PREV);
					}
					else
					{
						mpNcursesWrapper->form_driver(pForm, REQ_DEL_CHAR);
					}
					mpNcursesWrapper->form_driver(pForm, REQ_END_FIELD);
				}
				break;
			}
		case 9:// TAB
			{
				mpNcursesWrapper->form_driver(pForm, REQ_NEXT_FIELD);
				mpNcursesWrapper->form_driver(pForm, REQ_END_FIELD);
				break;
			}
		case KEY_BTAB:
			{
				mpNcursesWrapper->form_driver(pForm, REQ_PREV_FIELD);
				mpNcursesWrapper->form_driver(pForm, REQ_END_FIELD);
				break;
			}
		case KEY_LEFT:
		case KEY_RIGHT:
			{
				break;
			}

		case KEY_UP:
			{
				if (mSecurityListTableSelected && (mSecurityListSkipRows > 0))
				{
					mSecurityListSkipRows--;
				}
				break;
			}
		case KEY_DOWN:
			{
				if (mSecurityListTableSelected)
				{
					mSecurityListSkipRows++;
					updateSecurityListRecord();
				}
				//printTestFields();
				break;
			}
		case KEY_PPAGE:
			{
				if (mSecurityListTableSelected && (mSecurityListSkipRows > 0))
				{
					if (mSecurityListSkipRows > MAX_SECURITY_LIST_ROWS)
					{
						mSecurityListSkipRows -= MAX_SECURITY_LIST_ROWS;
					}
					else
					{
						mSecurityListSkipRows = 0;
					}
					updateSecurityListRecord();
				}
				break;
			}
		case KEY_NPAGE:
			{
				if (mSecurityListTableSelected)
				{
					mSecurityListSkipRows += MAX_SECURITY_LIST_ROWS;
					updateSecurityListRecord();
				}
				break;
			}
		case KEY_HOME:
			{
				if (mSecurityListTableSelected && (mSecurityListSkipRows > 0))
				{
					mSecurityListSkipRows = 0;
					updateSecurityListRecord();
				}
				break;
			}
		case KEY_END:
			{
				//if (mSecurityListTableSelected && (mNoOfSecurity > MAX_SECURITY_LIST_ROWS))
				if (mSecurityListTableSelected)
				{     
					mSecurityListSkipRows = ((mNoOfSecurity - MAX_SECURITY_LIST_ROWS)<=0)?0:(mNoOfSecurity - MAX_SECURITY_LIST_ROWS);
					//mSecurityListSkipRows = mNoOfSecurity - MAX_SECURITY_LIST_ROWS;
					updateSecurityListRecord();
				}
				break;
			}
		case KEY_MOUSE:
			{
				if(getmouse(&event) == OK)
				{
					// When the user clicks left mouse button
					if(event.bstate & BUTTON1_CLICKED || event.bstate & BUTTON1_DOUBLE_CLICKED || event.bstate & BUTTON1_TRIPLE_CLICKED)
					{
						//int fieldIndex = getSelectedField(event.y-(MAX_HEADER_ROWS+MAX_MENU_ROWS), event.x);
						int fieldIndex = getSelectedField(event.y, event.x);

						if (fieldIndex != INVALID_FIELD)
						{
							//if (SECURITY_LIST_SECURITY_CODE_ENTRY_0 <= fieldIndex && fieldIndex <= SECURITY_LIST_INSTRUMENT_TYPE_ENTRY_18)
							//if (SECURITY_LIST_SECURITY_CODE_ENTRY_0 <= fieldIndex && fieldIndex <= (SECURITY_LIST_SECURITY_CODE_ENTRY_0+MAX_SERIES_DEFINITION_ROWS-1))
							if (SECURITY_LIST_SECURITY_CODE_ENTRY_0 <= fieldIndex && fieldIndex <= SECURITY_LIST_INSTRUMENT_TYPE_ENTRY_14)
							{
								int rowSelected = fieldIndex - SECURITY_LIST_SECURITY_CODE_ENTRY_0 - 1;

								if (mSecurityListRowUsed[rowSelected])
								{
									uint32_t securityCode= mSecurityCode[rowSelected];
									selectSecurityList(securityCode);
								}
								mSecurityListTableSelected= true;
							}
						}
					}
				}
				break;
			}
		case KEY_ENTER: //"Enter" key in NumPad
		case 10: //"Enter" key above "Shift" key
			{
				sendRequest();
				break;
			}
		default:
			{
				//FIELD* pCurrentField = mpNcursesWrapper->current_field(pForm);
				//if (pCurrentField != gpGlobal->mpField[screen][0][ClientToolScreenHeader::SYMBOL_ENTRY]) {
				//    if (ch < '0' || '9' < ch)
				//    {
				//      return;
				//    }
				//}
				int retVal;
				if (ch == ' ')
				{
					retVal = form_driver(pForm, REQ_RIGHT_CHAR);
				}
				else
				{
					retVal = form_driver(pForm, ch);
					mpNcursesWrapper->form_driver(pForm, REQ_END_FIELD);
				}
				if (retVal == E_REQUEST_DENIED) {
					// Do nothing
				}
				break;
			} // default
	} // switch

	bool bFilterCriteriaChanged = false;
	char* buffer;

	buffer = field_buffer(gpGlobal->mpField[screen][0][ClientToolScreenHeader::OMDCC_MKTCODE_CFFEXID_ENTRY], 0);
	if (memcmp(gpGlobal->mOMDCC_MarketCode_CFFExID, buffer, sizeof(mSecuritySearchReq_.mMarketCode)))
	{
		bFilterCriteriaChanged = true;    
		strcpy(gpGlobal->mOMDCC_MarketCode_CFFExID, buffer);
	}

	buffer = field_buffer(gpGlobal->mpField[screen][0][ClientToolScreenHeader::OMDCC_SECCODE_FFXGPID_ENTRY], 0);
	if (memcmp(gpGlobal->mOMDCC_SecurityCode_CFFExGpID, buffer, 6))
	{
		bFilterCriteriaChanged = true;
		strcpy(gpGlobal->mOMDCC_SecurityCode_CFFExGpID, buffer);
	}

	if (bFilterCriteriaChanged)
	{
		handleFilterCriteriaChange();
	}
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::updateScr(uint16_t msgSize, uint16_t msgType, char* pMsgData, Common::Source source)
{
	switch (msgType)
	{
		case Common::SSESZSE_SECURITY_LIST_SESSION:
			{
				//            clearScr(Common::SSESZSE_SECURITY_LIST_SESSION);
				//            memset(mSecurityListRowUsed, 0, sizeof(mSecurityListRowUsed));
				//            for (int i=0; i<MAX_SECURITY_LIST_ROWS; i++)
				//            {
				//                setFieldBack(SECURITY_LIST_SECURITY_CODE_ENTRY_0 + i, A_NORMAL);
				//                setFieldBack(SECURITY_LIST_SHORT_NAME_ENTRY_0 + i, A_NORMAL);                
				//                setFieldBack(SECURITY_LIST_MARKET_CODE_ENTRY_0+ i, A_NORMAL);
				//                setFieldBack(SECURITY_LIST_INSTRUMENT_TYPE_ENTRY_0+ i, A_NORMAL);
				//            }
				printFilteredFields();
				break;
			}
		case Common::SSESZSE_MARKET_DEFINITION_SESSION:
			{            
				printMarketDefinitionFileds();
				break;
			}
		case Common::SSESZSE_SECURITY_DEFINITION_SESSION:
			{
				printSecurityDefinitionFields();
				break;
			}
		case Common::SSESZSE_STATUS_TOB_STATISTICS_SESSION:
			{
				printStatusTOBStatisticsFields();
				break;
			}
		default:
			break;
	}
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::printMarketDefinitionFileds(void)
{
	clearScr(Common::SSESZSE_MARKET_DEFINITION_SESSION);

	if (!mSecurityListIsSelected)
		return;

	// Find market code from security code
	const MultiIndexContainer::OMDCC_SecurityDefinition_SecurityCode& secDef_secCode
		= gpMultiIndexContainer->mOMDCC_SecurityDefinitionContainer.get<MultiIndexContainer::omdcc_securityDefinition_SecurityCode>();

	//LOG4_DEBUG(mLogger, "printMarketDefinitionFileds mSecurityCodeSelected = " << mSecurityCodeSelected);
	mOMDCC_SecurityDefinition_SecurityCode_iter = secDef_secCode.find(mSecurityCodeSelected);

	if (mOMDCC_SecurityDefinition_SecurityCode_iter == secDef_secCode.end())
		return; 

	//LOG4_DEBUG(mLogger, "printMarketDefinitionFileds B");

	// Find market defintion from market code
	const MultiIndexContainer::OMDCC_MarketDefinition_MarketCode& mktDef_mktCode
		= gpMultiIndexContainer->mOMDCC_MarketDefinitionContainer.get<MultiIndexContainer::omdcc_marketDefinition_MarketCode>();

	mOMDCC_MarketDefinition_MarketCode_iter = mktDef_mktCode.find(mOMDCC_SecurityDefinition_SecurityCode_iter->mMarketCode.substr(0,4));

	//LOG4_DEBUG(mLogger, "printMarketDefinitionFileds C mMarketCode = " << mOMDCC_SecurityDefinition_SecurityCode_iter->mMarketCode.substr(0,4));

	if (mOMDCC_MarketDefinition_MarketCode_iter == mktDef_mktCode.end())
		return;

	//LOG4_DEBUG(mLogger, "printMarketDefinitionFileds D");

	setFieldBuffer(MARKET_DEFINITION_MARKETCODE_ENTRY, mOMDCC_MarketDefinition_MarketCode_iter->mMarketCode);
	setFieldBuffer(MARKET_DEFINITION_MARKETNAME_ENTRY, mOMDCC_MarketDefinition_MarketCode_iter->mMarketName);
	setFieldBuffer(MARKET_DEFINITION_CURRENCYCODE_ENTRY, mOMDCC_MarketDefinition_MarketCode_iter->mCurrencyCode);
	setFieldBuffer(MARKET_DEFINITION_NUMBER_OF_SECURITIES_ENTRY, FormatWithCommas(mOMDCC_MarketDefinition_MarketCode_iter->mNumberOfSecurities, 0, false)); 
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::printSecurityDefinitionFields(void)
{
	char        cBufA[8], cBufB[11];
	std::string sTmp;

	clearScr(Common::SSESZSE_SECURITY_DEFINITION_SESSION);

	if (!mSecurityListIsSelected)
		return;

	// Find security definition from security code
	const MultiIndexContainer::OMDCC_SecurityDefinition_SecurityCode& secDef_secCode
		= gpMultiIndexContainer->mOMDCC_SecurityDefinitionContainer.get<MultiIndexContainer::omdcc_securityDefinition_SecurityCode>();

	mOMDCC_SecurityDefinition_SecurityCode_iter = secDef_secCode.find(mSecurityCodeSelected);

	if (mOMDCC_SecurityDefinition_SecurityCode_iter == secDef_secCode.end())
		return;

	setFieldBuffer(SECURITY_DEFINITION_SECURITY_CODE_ENTRY, mOMDCC_SecurityDefinition_SecurityCode_iter->mSecurityCode);
	setFieldBuffer(SECURITY_DEFINITION_ISIN_CODE_ENTRY, mOMDCC_SecurityDefinition_SecurityCode_iter->mISINCode);
	setFieldBuffer(SECURITY_DEFINITION_INSTRUMENT_TYPE_ENTRY, mOMDCC_SecurityDefinition_SecurityCode_iter->mInstrumentType);
	//setFieldBuffer(SECURITY_DEFINITION_SPREAD_TABLE_CODE_ENTRY, mOMDCC_SecurityDefinition_SecurityCode_iter->mSpreadTableCode);
	setFieldBuffer(SECURITY_DEFINITION_SECURITY_CURRENCY_CODE_ENTRY, mOMDCC_SecurityDefinition_SecurityCode_iter->mCurrencyCode);
	setFieldBuffer(SECURITY_DEFINITION_LOT_SIZE_ENTRY, FormatWithCommas(mOMDCC_SecurityDefinition_SecurityCode_iter->mLotSize, 0, false));
	setFieldBuffer(SECURITY_DEFINITION_PREVIOUS_CLOSING_PRICE_ENTRY, FormatWithCommas(mOMDCC_SecurityDefinition_SecurityCode_iter->mPreviousClosingPrice, 3, true));

	if (mOMDCC_SecurityDefinition_SecurityCode_iter->mListingDate==19000101)
		setFieldBuffer(SECURITY_DEFINITION_LISTING_DATE_ENTRY, "1900-01-01 (Unknown)");
	else
	{        
		sprintf(cBufA, "%d", mOMDCC_SecurityDefinition_SecurityCode_iter->mListingDate);
		memcpy(cBufB, cBufA, 4);
		cBufB[4] = '-';
		memcpy(&cBufB[5], &cBufA[4], 2);
		cBufB[7] = '-';
		memcpy(&cBufB[8], &cBufA[6], 2);
		cBufB[10] = 0x00;
		setFieldBuffer(SECURITY_DEFINITION_LISTING_DATE_ENTRY, cBufB);
	}

	if (mOMDCC_SecurityDefinition_SecurityCode_iter->mDelistingDate==0)
		setFieldBuffer(SECURITY_DEFINITION_DELISTING_DATE_ENTRY, "0 (No Date Exists)");
	else
	{
		sprintf(cBufA, "%d", mOMDCC_SecurityDefinition_SecurityCode_iter->mDelistingDate);
		memcpy(cBufB, cBufA, 4);
		cBufB[4] = '-';
		memcpy(&cBufB[5], &cBufA[4], 2);
		cBufB[7] = '-';
		memcpy(&cBufB[8], &cBufA[6], 2);
		cBufB[10] = 0x00;
		setFieldBuffer(SECURITY_DEFINITION_DELISTING_DATE_ENTRY, cBufB);
	}

	//LOG4_DEBUG(mLogger, "mShortSellFlag: " << mOMDCC_SecurityDefinition_SecurityCode_iter->mShortSellFlag);
	//LOG4_DEBUG(mLogger, "mListingDate: " << mOMDCC_SecurityDefinition_SecurityCode_iter->mListingDate);

	setFieldBuffer(SECURITY_DEFINITION_SHORT_SELL_FLAG_ENTRY, mOMDCC_SecurityDefinition_SecurityCode_iter->mShortSellFlag);

	setFieldBuffer(SECURITY_DEFINITION_SECURITY_SHORT_NAME_ENTRY, mOMDCC_SecurityDefinition_SecurityCode_iter->mSecurityShortName);

	char    *inbuf;
	size_t  inbytesleft = 60;

	inbuf = (char*)mOMDCC_SecurityDefinition_SecurityCode_iter->mSecurityNameGB;
        char* utf8 = Common::UTF16LE_to_UTF8(mLogger, &inbuf, inbytesleft);
	setFieldBuffer(SECURITY_DEFINITION_SECURITY_NAME_GB_ENTRY, utf8);
	delete[] utf8;

	inbuf = (char*)mOMDCC_SecurityDefinition_SecurityCode_iter->mSecurityNameGCCS;
        utf8 = Common::UTF16LE_to_UTF8(mLogger, &inbuf, inbytesleft);
	setFieldBuffer(SECURITY_DEFINITION_SECURITY_NAME_GCCS_ENTRY, utf8);
	delete[] utf8;
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::printStatusTOBStatisticsFields(void)
{
	clearScr(Common::SSESZSE_STATUS_TOB_STATISTICS_SESSION);

	if (!mSecurityListIsSelected)
		return;

	// Find security status from security code
	const MultiIndexContainer::OMDCC_SecurityStatus_SecurityCode& secStatus_secCode
		= gpMultiIndexContainer->mOMDCC_SecurityStatusContainer.get<MultiIndexContainer::omdcc_securityStatus_SecurityCode>();

	mOMDCC_SecurityStatus_SecurityCode_iter = secStatus_secCode.find(mSecurityCodeSelected);

	if (mOMDCC_SecurityStatus_SecurityCode_iter != secStatus_secCode.end())
	{
		if (mOMDCC_SecurityStatus_SecurityCode_iter->mSecurityTradingStatus==2)
			setFieldBuffer(TRADING_STATUS_ENTRY, "2 (Trading Halt)");
		else if (mOMDCC_SecurityStatus_SecurityCode_iter->mSecurityTradingStatus==3)
			setFieldBuffer(TRADING_STATUS_ENTRY, "3 (Resume)");
		else
			setFieldBuffer(TRADING_STATUS_ENTRY, mOMDCC_SecurityStatus_SecurityCode_iter->mSecurityTradingStatus);

		//Circuit Breaker Trading State
		setFieldBuffer(CIRCUIT_BREAKER_STATE_ENTRY, mOMDCC_SecurityStatus_SecurityCode_iter->mCircuitBreakerTradingState);
	}

	// Find TOB from security code
	const MultiIndexContainer::OMDCC_TOB_SecurityCode& tob_secCode
		= gpMultiIndexContainer->mOMDCC_TopOfBookContainer.get<MultiIndexContainer::omdcc_TOB_SecurityCode>();

	mOMDCC_TOB_SecurityCode_iter = tob_secCode.find(mSecurityCodeSelected);

	if (mOMDCC_TOB_SecurityCode_iter != tob_secCode.end())
	{
		if (mOMDCC_TOB_SecurityCode_iter->mBidPrice==0)
		{
			setFieldBuffer(TOP_BID_PRICE_ENTRY, "N/A"); 
		}
		else
		{
			setFieldBuffer(TOP_BID_PRICE_ENTRY, FormatWithCommas(mOMDCC_TOB_SecurityCode_iter->mBidPrice, 3, true));
		}
		if (mOMDCC_TOB_SecurityCode_iter->mAskPrice==0)
		{
			setFieldBuffer(TOP_ASK_PRICE_ENTRY, "N/A");
		}
		else
		{
			setFieldBuffer(TOP_ASK_PRICE_ENTRY, FormatWithCommas(mOMDCC_TOB_SecurityCode_iter->mAskPrice, 3, true));
		}
		setFieldBuffer(TOP_AGGREGATE_BID_QTY_ENTRY, FormatWithCommas(mOMDCC_TOB_SecurityCode_iter->mAggregateBidQuantity, 0, false));
		setFieldBuffer(TOP_AGGREGATE_ASK_QTY_ENTRY, FormatWithCommas(mOMDCC_TOB_SecurityCode_iter->mAggregateAskQuantity, 0, false));
	}

	// Find statistics from security code
	const MultiIndexContainer::OMDCC_Statistics_SecurityCode& stat_secCode
		= gpMultiIndexContainer->mOMDCC_StatisticsContainer.get<MultiIndexContainer::omdcc_Statistics_SecurityCode>();

	mOMDCC_Statistics_SecurityCode_iter = stat_secCode.find(mSecurityCodeSelected);

	if (mOMDCC_Statistics_SecurityCode_iter != stat_secCode.end())
	{
		setFieldBuffer(STATISTICS_SHARES_TRADED_ENTRY, FormatWithCommas(mOMDCC_Statistics_SecurityCode_iter->mSharesTraded, 0, false));
		setFieldBuffer(STATISTICS_TURNOVER_ENTRY, FormatWithCommas(mOMDCC_Statistics_SecurityCode_iter->mTurnover, 3, true));
		setFieldBuffer(STATISTICS_HIGH_PRICE_ENTRY, FormatWithCommas(mOMDCC_Statistics_SecurityCode_iter->mHighPrice, 3, true));
		setFieldBuffer(STATISTICS_LOW_PRICE_ENTRY, FormatWithCommas(mOMDCC_Statistics_SecurityCode_iter->mLowPrice, 3, true));
		setFieldBuffer(STATISTICS_LAST_PRICE_ENTRY, FormatWithCommas(mOMDCC_Statistics_SecurityCode_iter->mLastPrice, 3, true));
		setFieldBuffer(STATISTICS_OPENING_PRICE_ENTRY, FormatWithCommas(mOMDCC_Statistics_SecurityCode_iter->mOpeningPrice, 3, true));
	}
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::sendDummyRequest(void)
{
	mSecuritySearchReq_.mSize = sizeof(mSecuritySearchReq_);
	mSecuritySearchReq_.mInfoType = CT_OMDCC_SECURITY_SEARCH_REQUEST;
	mSecuritySearchReq_.mCTType = 88;
	memcpy(mSecuritySearchReq_.mMarketCode, "ASHR", 4);
	mSecuritySearchReq_.mSecurityCode = 0;
	((ClientToolP4*)mClientToolP4_)->sendSecuritySearchRequest(mSecuritySearchReq_);
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
std::string ClientToolScreenSSESZSE::FormatWithCommas(int64_t value, uint32_t decimalPlace, bool dollarSign)
{
	double  dTmp;

	std::stringstream ss;
	ss.imbue(std::locale(""));

	dTmp = value / (pow(10, decimalPlace));

	if (value < 0)
	{
		ss << "-" << (dollarSign?"$":"") << std::fixed << std::setprecision(decimalPlace) << abs(dTmp);
	}
	else
	{    
		ss << (dollarSign?"$":"") << std::fixed << std::setprecision(decimalPlace) << dTmp;
	}

	return ss.str();
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
void ClientToolScreenSSESZSE::sendRequest(void)
{
	//Pack data struct
	mSecuritySearchReq_.mSize = sizeof(mSecuritySearchReq_);
	mSecuritySearchReq_.mInfoType = CT_OMDCC_SECURITY_SEARCH_REQUEST;
	mSecuritySearchReq_.mCTType = gpGlobal->mProductIndex;
	memset(mSecuritySearchReq_.mMarketCode, 0x20, sizeof(mSecuritySearchReq_.mMarketCode));//4

	if (mSecurityListIsSelected)
	{
		mSecuritySearchReq_.mSecurityCode = mSecurityCodeSelected;
	}
	else
	{
		memcpy(mSecuritySearchReq_.mMarketCode, gpGlobal->mOMDCC_MarketCode_CFFExID, min(sizeof(mSecuritySearchReq_.mMarketCode), strlen(gpGlobal->mOMDCC_MarketCode_CFFExID)));
		mSecuritySearchReq_.mSecurityCode = atoi(gpGlobal->mOMDCC_SecurityCode_CFFExGpID);

	}
	((ClientToolP4*)mClientToolP4_)->sendSecuritySearchRequest(mSecuritySearchReq_);
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
