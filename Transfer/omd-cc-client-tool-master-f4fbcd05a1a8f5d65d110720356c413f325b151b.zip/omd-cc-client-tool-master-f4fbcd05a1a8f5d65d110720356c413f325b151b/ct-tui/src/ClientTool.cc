#include <poll.h>

#include "ClientTool.h"
#include "MultiIndexContainer.h"
#include "Socket.h"

ClientTool* gpClientTool = 0;

using namespace std;

ClientTool::ClientTool(int argc, char** argv, Logger& logger, Logger& userlogger) : mLogger(logger), mUserLogger(userlogger) 
{
	gpGlobal->mMode = Common::REALTIME_MODE;
	mpNcursesWrapper = new NcursesWrapper(logger);
	mpostringstream = new ostringstream;

	mTimespecRefreshNcursesWindows.tv_sec = gpGlobal->mRefreshScreen / 10;
	mTimespecRefreshNcursesWindows.tv_nsec = (gpGlobal->mRefreshScreen % 10) * (100 * 1000 * 1000);

	Global::FeedHandlerMapType::iterator iter;
	iter = gpGlobal->mFeedHandlerMap.begin();

	while (iter != gpGlobal->mFeedHandlerMap.end()) 
	{
		iter->second->pPacketSpool = new PacketSpool(mLogger);
		iter++;
	}
}

ClientTool::~ClientTool() {
	delete mpNcursesWrapper;
}

void ClientTool::output(int row, int col, const char* pStr, bool lock) {
	if (lock) {
		Common::lock(mLogger, &mMutexOutput);
	}
	LOG4_ERR(mLogger
			, "output(int row, int col, char* pStr, bool lock) not implemented");
	if (lock) {
		Common::unlock(mLogger, &mMutexOutput);
	}
}

void ClientTool::output(const char* pStr, bool lock) {
	Common::lock(mLogger, &mMutexOutput);
	LOG4_ERR(mLogger, "output(char* pStr, bool lock) not implemented");
	Common::unlock(mLogger, &mMutexOutput);
}

void ClientTool::output(int row, int col, ostringstream& oss, bool lock) {
	if (lock) {
		Common::lock(mLogger, &mMutexOutput);
	}
	LOG4_ERR(mLogger, 
			"output(int row, int col, ostringstream oss, bool lock) not implemented");
	if (lock) {
		Common::unlock(mLogger, &mMutexOutput);
	}
}

void ClientTool::output(ostringstream& oss, bool lock) {
	if (lock) {
		Common::lock(mLogger, &mMutexOutput);
	}
	LOG4_ERR(mLogger, "output(ostringstream oss, bool lock) not implemented");
	if (lock) {
		Common::unlock(mLogger, &mMutexOutput);
	}
}

void ClientTool::processNcurses(pthread_cond_t& cond) {
	LOG4_ERR(mLogger, "processNcurses not implemented");
}

void ClientTool::refreshNcursesWindows() {
	LOG4_ERR(mLogger, "refreshNcursesWindows not implemented");
}

void ClientTool::startEventLoop() 
{
	ostringstream* mpostringstream = getostringstream();

	{
		pthread_t thread;
		if (pthread_create(&thread, NULL, &threadProcessNcurses, this) != 0) {
			LOG4_ERR(mLogger, "pthread_create threadProcessNcurses failed");
			Common::exit(1);
		}
	}

	mpTimerRefreshNcursesWindows = new Timer(mLogger, &refresh_ncurses_windows_cb, this, &mTimespecRefreshNcursesWindows, &mTimespecRefreshNcursesWindows);

	LOG4_INFO(mLogger, "ClientTool::startEventLoop()...");
}

void ClientTool::processMsg
(uint16_t channelID, uint64_t sendTime, uint16_t msgSize, uint16_t msgType
 , char* pMsgData) {
	LOG4_ERR(mLogger, "ClientTool::processMsg not implemented");
}

void ClientTool::refresh_ncurses_windows_cb(union sigval sigev_value) {
	struct Timer::Arg* pArg = (struct Timer::Arg*)sigev_value.sival_ptr;
	ClientTool* pClientTool = (ClientTool*)pArg->pArg;

	pClientTool->refreshNcursesWindows();
}

void ClientTool::sigHandler(int) {
	pthread_exit(0);
}

void* ClientTool::threadProcessNcurses(void *arg) {
	ClientTool* pClientTool = (ClientTool*)arg;
	pClientTool->processNcurses(pClientTool->mCond);
}

//By Louis 2013-07-15
string ClientTool::TrimLeadingSpace(char *src, int iLen)
{
	string 	res;
	int		i;

	res = "";

	for (i=0; i<iLen; i++)
	{
		if (src[i]!=' ')
			break;		
	}
	return string(&src[i], iLen-i);
}

string ClientTool::TrimTrailingSpace(char *src, int iLen)
{
	string	res;
	int		iTargetLen;

	res = "";
	iTargetLen = iLen;

	for (int i=iLen; i>0; i--)
	{
		if (src[i-1]!=' ')
			break;
		iTargetLen--;		
	}		
	return string(src, iTargetLen);
}

string ClientTool::FieldTranslation(uint16_t msgType, enum ClientTool::FieldType field, uint8_t value)
{
	string	res;	
	res = "";

	switch (msgType)
	{
		case 301: // Commodity Defintion
			switch (field)
			{
				case UNDERLYING_PRICE_UNIT:
					switch (value)
					{
						case 1:	res += "1(Price)";					break;
						case 2:	res += "2(Yield)";					break;
						case 3:	res += "3(Points)";					break;
						case 4:	res += "4(Yield Diff)";				break;
						case 5:	res += "5(IMM Index)";				break;
						case 6:	res += "6(Basis Points)";			break;
						case 7:	res += "7(Inverted Yield)";			break;
						case 8:	res += "8(Percentage of Nominal)";	break;
						case 9:	res += "9(Dirty Price)";			break;
					}
					break;			
				case UNDERLYING_TYPE:
					switch (value)
					{
						case 1:		res += "1(Stock)";					break;
						case 2:		res += "2(Currency)";				break;
						case 3:		res += "3(Interest rate)";			break;
						case 4:		res += "4(Energy)";					break;
						case 5:		res += "5(Soft and Agrics)";		break;
						case 6:		res += "6(Metal)";					break;
						case 7:		res += "7(Stock Index)";			break;
						case 8:		res += "8(Currency Index)";			break;
						case 9:		res += "9(Interest Rate Index)";	break;
						case 10:	res += "10(Energy Index)";			break;
						case 11:	res += "11(Softs and Agrics Index)";break;
						case 12:	res += "12(Metal Index)"; 			break; 
					}
					break;
				case EFFECTIVE_TOMORROW:
					switch (value)
					{
						case 0:		res += "0(False)";	break;
						case 1:		res += "1(True)";	break;
					}
					break;
			}
			break;
		case 302: //Class Definition
			switch (field)
			{
				case RANKING_TYPE:
					switch (value)
					{
						case 1:		res += "1(Price, Time)";										break;
						case 2: 	res += "2(Inverted Price, Time)";								break;
						case 3: 	res += "3(Price, Traders before MM, Time)";						break;
						case 4: 	res += "4(Inverted Price, Traders before MM, Time)";			break;
						case 5: 	res += "5(Price, MM before Traders, Time)";						break;
						case 6: 	res += "6(Inverted Price, MM before Traders, Time)";			break;
						case 7: 	res += "7(Price, Baits before Normal Orders, Time)";			break;
						case 8: 	res += "8(Inverted Price, Baits before Normal Orders, Time)";	break;
						case 11:	res += "11(Price, Own Orders, Time)";							break;
						case 12: 	res += "12(Inverted Price, Own Orders, Time)";					break;
					}
					break;
				case TRADABLE:
					break;
				case PREMIUM_UNIT_4_PRICE:
					break;
				case IS_FRACTIONS:
					break;
				case EFFECTIVE_TOMORROW:
					break;
			}
			break;
	}//switch (msgType)
	return res;
}

