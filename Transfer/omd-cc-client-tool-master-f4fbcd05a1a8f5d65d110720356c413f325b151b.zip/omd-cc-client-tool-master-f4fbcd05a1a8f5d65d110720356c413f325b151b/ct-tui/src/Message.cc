#include "Message.h"

using namespace std;

Message::Message(Logger& logger, uint16_t msgSize) : mMsgData(NULL)
{
	mMsgSize = (msgSize > MAX_PACKET_SIZE) ? MAX_PACKET_SIZE : msgSize;
	mMsgData = new char[mMsgSize];
}

Message::~Message()
{
	delete [] mMsgData;
}

uint16_t Message::getMsgSize() 
{
	return mMsgSize;
}

char* Message::getMsgData() 
{
	return mMsgData;
}
