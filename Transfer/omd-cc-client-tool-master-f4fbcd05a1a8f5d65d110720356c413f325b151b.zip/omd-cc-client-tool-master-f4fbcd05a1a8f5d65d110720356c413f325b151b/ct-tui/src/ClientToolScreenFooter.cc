#include "ClientToolScreenFooter.h"

ClientToolScreenFooter::ClientToolScreenFooter(Logger& logger)
  : ClientToolScreen(logger) {
  mScreen = Common::FOOTER_SCREEN;
  int formIndex = 0;
  int fieldIndex;

  int row = 0;
  int col;

  FIELD** ppField = gpGlobal->mpField[mScreen][formIndex];

  col = 0;
  fieldIndex = PROCESSED_MSGS;
  newField(ppField, fieldIndex, 1, 10, row, 0, 0, 0);
  col += 11;

  fieldIndex = LINE_STATUS_REALTIME_LABEL;
  newField(ppField, fieldIndex, 1, 4, row, col, 0, 0, "RT :");
  col += 5;

  int channelsPerLine = 20;//37;

  for (int i=0; i<MAX_PRODUCT_REALTIME_CHANNELS; i++) {
    if (i%channelsPerLine == 0) {
      col = 16;
    }
    fieldIndex = LINE_STATUS_REALTIME_ENTRY_0 + i;
    newField(ppField, fieldIndex, 1, 3, row + i/channelsPerLine, col
	     , 0, 0, "", NO_JUSTIFICATION
	     , 0, O_ACTIVE, COLOR_PAIR(Common::RED_BLACK_COLOR_PAIR));
    col += 4;
  }

  row += (MAX_PRODUCT_REALTIME_CHANNELS%channelsPerLine == 0
	  ?MAX_PRODUCT_REALTIME_CHANNELS/channelsPerLine
	  :MAX_PRODUCT_REALTIME_CHANNELS/channelsPerLine + 1);

  col = 0;
  fieldIndex = LINE_STATUS_RETRANS_ENTRY;
  newField(ppField, fieldIndex, 1, 6, row, col, 0, 0, "SERVER", NO_JUSTIFICATION
  	   , 0, O_ACTIVE, COLOR_PAIR(Common::RED_BLACK_COLOR_PAIR));

  col += 11;
  fieldIndex = LINE_STATUS_REFRESH_LABEL;
  newField(ppField, fieldIndex, 1, 4, row, col, 0, 0, "RFS:");
  col += 5;

  for (int i=0; i<MAX_PRODUCT_REFRESH_CHANNELS; i++) {
    if (i%channelsPerLine == 0) {
      col = 16;
    }
    fieldIndex = LINE_STATUS_REFRESH_ENTRY_0 + i;
    newField(ppField, fieldIndex, 1, 3, row + i/channelsPerLine, col
	     , 0, 0, "", NO_JUSTIFICATION
	     , 0, O_ACTIVE, COLOR_PAIR(Common::RED_BLACK_COLOR_PAIR));
    col += 4;
  }

  static wchar_t* rows[MAX_FORM_ROWS] = {
    0
  };

  for (int i=1; i<MAX_FORM_ROWS-1; i++) {
    if (rows[i-1]) {
      memcpy(&ch[i][1], rows[i-1], sizeof(wchar_t) * wcslen(rows[i-1]));
    }
  }

  mProcessedMsgs = 0;
}

ClientToolScreenFooter::~ClientToolScreenFooter() {
}

void ClientToolScreenFooter::createForms() {
  int formIndex;

  {
    formIndex = 0;

    FORM* pForm = mpNcursesWrapper->new_form(gpGlobal->mpField[mScreen][formIndex]);
    gpGlobal->mpForm[mScreen][formIndex] = pForm;

    WINDOW* pFormWin = mpNcursesWrapper->newwin
      (MAX_STATUS_ROWS, MAX_FORM_COLS, MAX_SCREEN_ROWS-MAX_STATUS_ROWS, 0);
    gpGlobal->mpFormWin[mScreen][formIndex] = pFormWin;
    set_form_win(pForm, pFormWin);

    WINDOW* pFormSub = mpNcursesWrapper->derwin
      (pFormWin, MAX_STATUS_ROWS, MAX_FORM_COLS, 0, 0);
    gpGlobal->mpFormSub[mScreen][formIndex] = pFormSub;
    set_form_sub(pForm, pFormSub);
    mpFormSub[0] = pFormSub;

    mpNcursesWrapper->post_form(pForm);
  }
}

void ClientToolScreenFooter::printFieldLabels() {
  WINDOW* pFormSub = mpFormSub[0];

  //box(pFormSub, 0, 0);
}

void ClientToolScreenFooter::clearScr(uint16_t msgType, uint16_t side) {}

void ClientToolScreenFooter::updateScr
(uint16_t msgSize, uint16_t msgType, char* pMsgData, Common::Source source) {
  if (source != Common::CACHE_SOURCE) {
    mProcessedMsgs++;
  }

  switch (msgType) {
  case Xdp::LINE_STATUS_TYPE: {
    setFieldBuffer(PROCESSED_MSGS, mProcessedMsgs);

    bool first = true;
    uint16_t channelID;
    char lineType;
    uint8_t status;
    int i;
    Global::ChannelSet::iterator iter;

    int formIndex = 0;
    int fieldIndex;

    const MultiIndexContainer::LineStatus_LineType_ChannelID&
      lineStatus_LineType_ChannelID
      = gpMultiIndexContainer->mLineStatusContainer
      .get<MultiIndexContainer::lineStatus_LineType_ChannelID>();
    MultiIndexContainer::LineStatus_LineType_ChannelID::iterator
      lineStatus_LineType_ChannelID_iterator;

    i=0;
    iter = gpGlobal->mRealTimeChannelSet.begin();
    while (iter != gpGlobal->mRealTimeChannelSet.end()) {
      channelID = *iter;

      lineStatus_LineType_ChannelID_iterator
	= lineStatus_LineType_ChannelID.find
	(boost::make_tuple(REALTIME_CHAR, channelID));
      if (lineStatus_LineType_ChannelID_iterator
	  != lineStatus_LineType_ChannelID.end()) {
	MultiIndexContainer::LineStatus lineStatus
	  = *lineStatus_LineType_ChannelID_iterator;
	status = lineStatus.mStatus;
	short pair = Common::getColorFromLineStatus(status);
	fieldIndex = LINE_STATUS_REALTIME_ENTRY_0 + i;
	FIELD* pField = gpGlobal->mpField[mScreen][formIndex][fieldIndex];
	set_field_fore(pField, COLOR_PAIR(pair));
	ostringstream oss;
	oss << setfill('0') << setw(3) << channelID;
	setFieldBuffer(fieldIndex, oss.str());
	i++;
      }
      iter++;
    }

    i=0;
    iter = gpGlobal->mRefreshChannelSet.begin();
    while (iter != gpGlobal->mRefreshChannelSet.end()) {
      channelID = *iter;

      lineStatus_LineType_ChannelID_iterator
	= lineStatus_LineType_ChannelID.find
	(boost::make_tuple(REFRESH_CHAR, channelID));
      if (lineStatus_LineType_ChannelID_iterator
	  != lineStatus_LineType_ChannelID.end()) {
	MultiIndexContainer::LineStatus lineStatus
	  = *lineStatus_LineType_ChannelID_iterator;
	status = lineStatus.mStatus;
	short pair = Common::getColorFromLineStatus(status);
	fieldIndex = LINE_STATUS_REFRESH_ENTRY_0 + i;
	FIELD* pField = gpGlobal->mpField[mScreen][formIndex][fieldIndex];
	set_field_fore(pField, COLOR_PAIR(pair));
	ostringstream oss;
	oss << setfill('0') << setw(3) << channelID;
	setFieldBuffer(fieldIndex, oss.str());
	i++;
      }
      iter++;
    }

    lineStatus_LineType_ChannelID_iterator
      = lineStatus_LineType_ChannelID.find
      (boost::make_tuple(RETRANS_CHAR, 0));
    if (lineStatus_LineType_ChannelID_iterator
	!= lineStatus_LineType_ChannelID.end()) {
      MultiIndexContainer::LineStatus lineStatus
	= *lineStatus_LineType_ChannelID_iterator;
      status = lineStatus.mStatus;
      short pair = Common::getColorFromLineStatus(status);
      fieldIndex = LINE_STATUS_RETRANS_ENTRY;
      FIELD* pField = gpGlobal->mpField[mScreen][formIndex][fieldIndex];
      set_field_fore(pField, COLOR_PAIR(pair));
    }
    break;
  }
  default:
    break;
  } // switch
}

void ClientToolScreenFooter::refresh() {
  Common::Source source=Common::CACHE_SOURCE;

  gpMultiIndexContainer->erase_LineStatus('T', 0);  
  gpMultiIndexContainer->mLineStatusContainer.insert(MultiIndexContainer::LineStatus("", 0, 8, Xdp::LINE_STATUS_TYPE, 'T', (gpGlobal->mServerConnected_?2:0)));

  uint16_t channelID;
  uint16_t channelIDRf;

  if (!gpGlobal->mServerConnected_)
  {
      Global::ChannelSet::iterator iter = gpGlobal->mRealTimeChannelSet.begin();
      Global::ChannelSet::iterator iterRf;
      while (iter != gpGlobal->mRealTimeChannelSet.end())
      {     
          channelID = *iter;
          gpMultiIndexContainer->erase_LineStatus('R', channelID);
          gpMultiIndexContainer->mLineStatusContainer.insert(MultiIndexContainer::LineStatus("", channelID, 8, Xdp::LINE_STATUS_TYPE, 'R', 0));
	  //refresh
	  iterRf = gpGlobal->mRefreshChannelSet.begin();
      	  while (iterRf != gpGlobal->mRefreshChannelSet.end())
	  {
	     channelIDRf = *iterRf;
             if (channelIDRf==channelID+500)
	     {
             	gpMultiIndexContainer->erase_LineStatus('F', channelIDRf);
             	gpMultiIndexContainer->mLineStatusContainer.insert(MultiIndexContainer::LineStatus("", channelIDRf, 8, Xdp::LINE_STATUS_TYPE, 'F', 0));
		//break;
	     }
	     iterRf++;
	  }
          iter++;
      } //while
  }

/* Testing

  gpMultiIndexContainer->erase_LineStatus('R', 102);
  gpMultiIndexContainer->mLineStatusContainer.insert(MultiIndexContainer::LineStatus("", 102, 8, Xdp::LINE_STATUS_TYPE, 'R', 1));

  gpMultiIndexContainer->erase_LineStatus('F', 601);
  gpMultiIndexContainer->mLineStatusContainer.insert(MultiIndexContainer::LineStatus("", 601, 8, Xdp::LINE_STATUS_TYPE, 'F', 2));

  gpMultiIndexContainer->erase_LineStatus('F', 602);
  gpMultiIndexContainer->mLineStatusContainer.insert(MultiIndexContainer::LineStatus("", 602, 8, Xdp::LINE_STATUS_TYPE, 'F', 1));

  gpMultiIndexContainer->erase_LineStatus('T', 0);
  gpMultiIndexContainer->mLineStatusContainer.insert(MultiIndexContainer::LineStatus("", 0, 8, Xdp::LINE_STATUS_TYPE, 'T', 2));

*/ 
  updateScr(0, Xdp::LINE_STATUS_TYPE, 0, source);
}
