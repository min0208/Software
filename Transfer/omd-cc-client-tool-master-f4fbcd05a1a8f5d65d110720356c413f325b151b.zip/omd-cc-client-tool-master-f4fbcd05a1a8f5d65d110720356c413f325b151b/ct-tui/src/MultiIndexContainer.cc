#include "MultiIndexContainer.h"

MultiIndexContainer* gpMultiIndexContainer = 0;

MultiIndexContainer::MultiIndexContainer(Logger& logger) : mLogger(logger) {
}

void MultiIndexContainer::erase_CommodityDefinition(uint16_t commodityCode) {
	MultiIndexContainer::CommodityDefinition_CommodityCode&
		commodityDefinition_CommodityCode
		= gpMultiIndexContainer->mCommodityDefinitionContainer
		.get<MultiIndexContainer::commodityDefinition_CommodityCode>();

	MultiIndexContainer::CommodityDefinition_CommodityCode::iterator
		commodityDefinition_CommodityCode_iterator
		= commodityDefinition_CommodityCode.find
		(commodityCode);

	if (commodityDefinition_CommodityCode_iterator
			!= commodityDefinition_CommodityCode.end()) {
		gpMultiIndexContainer->mCommodityDefinitionContainer.erase
			(commodityDefinition_CommodityCode_iterator);
	}
}

void MultiIndexContainer::erase_ClassDefinition(uint16_t commodityCode, uint8_t instrumentGroup) {
	MultiIndexContainer::ClassDefinition_CommodityCode_InstrumentGroup&
		classDefinition_CommodityCode_InstrumentGroup
		= gpMultiIndexContainer->mClassDefinitionContainer
		.get<MultiIndexContainer::classDefinition_CommodityCode_InstrumentGroup>();

	MultiIndexContainer::ClassDefinition_CommodityCode_InstrumentGroup::iterator
		classDefinition_CommodityCode_InstrumentGroup_iterator
		= classDefinition_CommodityCode_InstrumentGroup.find
		(boost::make_tuple(commodityCode, instrumentGroup));

	if (classDefinition_CommodityCode_InstrumentGroup_iterator
			!= classDefinition_CommodityCode_InstrumentGroup.end()) {
		gpMultiIndexContainer->mClassDefinitionContainer.erase
			(classDefinition_CommodityCode_InstrumentGroup_iterator);
	}
}

void MultiIndexContainer::erase_SeriesDefinitionBase(uint32_t orderBookID) {
	const MultiIndexContainer::SeriesDefinitionBase_OrderBookID_Symbol&
		seriesDefinitionBase_OrderBookID_Symbol
		= gpMultiIndexContainer->mSeriesDefinitionBaseContainer
		.get<MultiIndexContainer::seriesDefinitionBase_OrderBookID_Symbol>();

	MultiIndexContainer::SeriesDefinitionBase_OrderBookID_Symbol::iterator
		seriesDefinitionBase_OrderBookID_Symbol_iterator
		= seriesDefinitionBase_OrderBookID_Symbol.find(orderBookID);

	if (seriesDefinitionBase_OrderBookID_Symbol_iterator
			!= seriesDefinitionBase_OrderBookID_Symbol.end()) {
		gpMultiIndexContainer->mSeriesDefinitionBaseContainer.erase
			(seriesDefinitionBase_OrderBookID_Symbol_iterator);
	}
}

void MultiIndexContainer::erase_SeriesDefinitionExtended(string symbol) {
	const MultiIndexContainer::SeriesDefinitionExtended_Symbol&
		seriesDefinitionExtended_Symbol
		= gpMultiIndexContainer->mSeriesDefinitionExtendedContainer
		.get<MultiIndexContainer::seriesDefinitionExtended_Symbol>();

	MultiIndexContainer::SeriesDefinitionExtended_Symbol::iterator
		seriesDefinitionExtended_Symbol_iterator
		= seriesDefinitionExtended_Symbol.find
		(symbol);

	if (seriesDefinitionExtended_Symbol_iterator
			!= seriesDefinitionExtended_Symbol.end()) {
		gpMultiIndexContainer->mSeriesDefinitionExtendedContainer.erase
			(seriesDefinitionExtended_Symbol_iterator);
	}
}

void MultiIndexContainer::erase_CombinationDefinition(uint32_t comboOrderBookID, uint32_t legOrderBookID) {
	MultiIndexContainer::CombinationDefinition_ComboOrderBookID_LegOrderBookID&
		combinationDefinition_ComboOrderBookID_LegOrderBookID
		= gpMultiIndexContainer->mCombinationDefinitionContainer
		.get<MultiIndexContainer::combinationDefinition_ComboOrderBookID_LegOrderBookID>();

	MultiIndexContainer::CombinationDefinition_ComboOrderBookID_LegOrderBookID::iterator
		combinationDefinition_ComboOrderBookID_LegOrderBookID_iterator
		= combinationDefinition_ComboOrderBookID_LegOrderBookID.find
		(boost::make_tuple(comboOrderBookID, legOrderBookID));

	if (combinationDefinition_ComboOrderBookID_LegOrderBookID_iterator
			!= combinationDefinition_ComboOrderBookID_LegOrderBookID.end()) {
		gpMultiIndexContainer->mCombinationDefinitionContainer.erase
			(combinationDefinition_ComboOrderBookID_LegOrderBookID_iterator);
	}
}

void MultiIndexContainer::erase_MarketStatus(uint32_t orderBookID, uint16_t stateLevel) {
	MultiIndexContainer::MarketStatus_OrderBookID_StateLevel&
		marketStatus_OrderBookID_StateLevel
		= gpMultiIndexContainer->mMarketStatusContainer
		.get<MultiIndexContainer::marketStatus_OrderBookID_StateLevel>();

	MultiIndexContainer::MarketStatus_OrderBookID_StateLevel::iterator
		marketStatus_OrderBookID_StateLevel_iterator
		= marketStatus_OrderBookID_StateLevel.find
		(boost::make_tuple(orderBookID, stateLevel));

	if (marketStatus_OrderBookID_StateLevel_iterator
			!= marketStatus_OrderBookID_StateLevel.end()) {
		gpMultiIndexContainer->mMarketStatusContainer.erase
			(marketStatus_OrderBookID_StateLevel_iterator);
	}
}

void MultiIndexContainer::erase_SeriesStatus(uint32_t orderBookID) {
	MultiIndexContainer::SeriesStatus_OrderBookID&
		seriesStatus_OrderBookID
		= gpMultiIndexContainer->mSeriesStatusContainer
		.get<MultiIndexContainer::seriesStatus_OrderBookID>();

	MultiIndexContainer::SeriesStatus_OrderBookID::iterator
		seriesStatus_OrderBookID_iterator
		= seriesStatus_OrderBookID.find
		(orderBookID);

	if (seriesStatus_OrderBookID_iterator
			!= seriesStatus_OrderBookID.end()) {
		gpMultiIndexContainer->mSeriesStatusContainer.erase
			(seriesStatus_OrderBookID_iterator);
	}
}

void MultiIndexContainer::erase_CommodityStatus(uint16_t commodityCode) {
	MultiIndexContainer::CommodityStatus_CommodityCode&
		commodityStatus_CommodityCode
		= gpMultiIndexContainer->mCommodityStatusContainer
		.get<MultiIndexContainer::commodityStatus_CommodityCode>();

	MultiIndexContainer::CommodityStatus_CommodityCode::iterator
		commodityStatus_CommodityCode_iterator
		= commodityStatus_CommodityCode.find
		(commodityCode);

	if (commodityStatus_CommodityCode_iterator
			!= commodityStatus_CommodityCode.end()) {
		gpMultiIndexContainer->mCommodityStatusContainer.erase
			(commodityStatus_CommodityCode_iterator);
	}
}

void MultiIndexContainer::erase_FullOrderBookBid(uint32_t orderBookID, uint64_t orderID) {
	MultiIndexContainer::FullOrderBookBid_OrderBookID_OrderID&
		fullOrderBookBid_OrderBookID_OrderID
		= gpMultiIndexContainer->mFullOrderBookBidContainer
		.get<MultiIndexContainer::fullOrderBookBid_OrderBookID_OrderID>();

	MultiIndexContainer::FullOrderBookBid_OrderBookID_OrderID::iterator
		fullOrderBookBid_OrderBookID_OrderID_iterator
		= fullOrderBookBid_OrderBookID_OrderID.find
		(boost::make_tuple(orderBookID, orderID));

	if (fullOrderBookBid_OrderBookID_OrderID_iterator
			!= fullOrderBookBid_OrderBookID_OrderID.end()) {
		/*
		   gpMultiIndexContainer->mFullOrderBookBidContainer.erase
		   (fullOrderBookBid_OrderBookID_OrderID_iterator);
		   */

		LOG4_ERR(mLogger, "erase_FullOrderBookBid"
				<< " OrderBookID:" << orderBookID
				<< " , Side:" << (int)Common::BID_SIDE
				<< " , OrderID:" << orderID
				<< " Duplicate order");
	}
}

void MultiIndexContainer::erase_FullOrderBookAsk(uint32_t orderBookID, uint64_t orderID) {
	MultiIndexContainer::FullOrderBookAsk_OrderBookID_OrderID&
		fullOrderBookAsk_OrderBookID_OrderID
		= gpMultiIndexContainer->mFullOrderBookAskContainer
		.get<MultiIndexContainer::fullOrderBookAsk_OrderBookID_OrderID>();

	MultiIndexContainer::FullOrderBookAsk_OrderBookID_OrderID::iterator
		fullOrderBookAsk_OrderBookID_OrderID_iterator
		= fullOrderBookAsk_OrderBookID_OrderID.find
		(boost::make_tuple(orderBookID, orderID));

	if (fullOrderBookAsk_OrderBookID_OrderID_iterator
			!= fullOrderBookAsk_OrderBookID_OrderID.end()) {
		/*
		   gpMultiIndexContainer->mFullOrderBookAskContainer.erase
		   (fullOrderBookAsk_OrderBookID_OrderID_iterator);
		   */
		LOG4_ERR(mLogger, "erase_FullOrderBookAsk"
				<< " OrderBookID:" << orderBookID
				<< " , Side:" << (int)Common::OFFER_SIDE
				<< " , OrderID:" << orderID
				<< " Duplicate order");
	}
}

void MultiIndexContainer::erase_TopOfBook(uint32_t orderBookID) {
	MultiIndexContainer::TopOfBook_OrderBookID&
		topOfBook_OrderBookID
		= gpMultiIndexContainer->mTopOfBookContainer
		.get<MultiIndexContainer::topOfBook_OrderBookID>();

	MultiIndexContainer::TopOfBook_OrderBookID::iterator
		topOfBook_OrderBookID_iterator
		= topOfBook_OrderBookID.find
		(orderBookID);

	if (topOfBook_OrderBookID_iterator
			!= topOfBook_OrderBookID.end()) {
		gpMultiIndexContainer->mTopOfBookContainer.erase
			(topOfBook_OrderBookID_iterator);
	}
}

void MultiIndexContainer::erase_QuoteRequest(uint32_t orderBookID) {
	MultiIndexContainer::QuoteRequest_OrderBookID&
		quoteRequest_OrderBookID
		= gpMultiIndexContainer->mQuoteRequestContainer
		.get<MultiIndexContainer::quoteRequest_OrderBookID>();

	MultiIndexContainer::QuoteRequest_OrderBookID::iterator
		quoteRequest_OrderBookID_iterator
		= quoteRequest_OrderBookID.find
		(orderBookID);

	if (quoteRequest_OrderBookID_iterator
			!= quoteRequest_OrderBookID.end()) {
		gpMultiIndexContainer->mQuoteRequestContainer.erase
			(quoteRequest_OrderBookID_iterator);
	}
}

void MultiIndexContainer::erase_TradeWithAmendment
(uint64_t tradeID, uint32_t comboGroupID) {
	MultiIndexContainer::TradeWithAmendment_TradeID_ComboGroupID_TradeState&
		tradeWithAmendment_TradeID_ComboGroupID_TradeState
		= gpMultiIndexContainer->mTradeWithAmendmentContainer
		.get<MultiIndexContainer::tradeWithAmendment_TradeID_ComboGroupID_TradeState>();

	MultiIndexContainer::TradeWithAmendment_TradeID_ComboGroupID_TradeState::iterator
		tradeWithAmendment_TradeID_ComboGroupID_TradeState_iterator
		= tradeWithAmendment_TradeID_ComboGroupID_TradeState.find
		(boost::make_tuple(tradeID, comboGroupID));

	if (tradeWithAmendment_TradeID_ComboGroupID_TradeState_iterator
			!= tradeWithAmendment_TradeID_ComboGroupID_TradeState.end()) {
		gpMultiIndexContainer->mTradeWithAmendmentContainer.erase
			(tradeWithAmendment_TradeID_ComboGroupID_TradeState_iterator);
	}
}

void MultiIndexContainer::erase_TradeStatistics(uint32_t orderBookID) {
	MultiIndexContainer::TradeStatistics_OrderBookID&
		tradeStatistics_OrderBookID
		= gpMultiIndexContainer->mTradeStatisticsContainer
		.get<MultiIndexContainer::tradeStatistics_OrderBookID>();

	MultiIndexContainer::TradeStatistics_OrderBookID::iterator
		tradeStatistics_OrderBookID_iterator
		= tradeStatistics_OrderBookID.find
		(orderBookID);

	if (tradeStatistics_OrderBookID_iterator
			!= tradeStatistics_OrderBookID.end()) {
		gpMultiIndexContainer->mTradeStatisticsContainer.erase
			(tradeStatistics_OrderBookID_iterator);
	}
}

void MultiIndexContainer::erase_SeriesStatistics(uint32_t orderBookID) {
	MultiIndexContainer::SeriesStatistics_OrderBookID&
		seriesStatistics_OrderBookID
		= gpMultiIndexContainer->mSeriesStatisticsContainer
		.get<MultiIndexContainer::seriesStatistics_OrderBookID>();

	MultiIndexContainer::SeriesStatistics_OrderBookID::iterator
		seriesStatistics_OrderBookID_iterator
		= seriesStatistics_OrderBookID.find
		(orderBookID);

	if (seriesStatistics_OrderBookID_iterator
			!= seriesStatistics_OrderBookID.end()) {
		gpMultiIndexContainer->mSeriesStatisticsContainer.erase
			(seriesStatistics_OrderBookID_iterator);
	}
}

void MultiIndexContainer::erase_CalculatedOpeningPrice(uint32_t orderBookID) {
	MultiIndexContainer::CalculatedOpeningPrice_OrderBookID&
		calculatedOpeningPrice_OrderBookID
		= gpMultiIndexContainer->mCalculatedOpeningPriceContainer
		.get<MultiIndexContainer::calculatedOpeningPrice_OrderBookID>();

	MultiIndexContainer::CalculatedOpeningPrice_OrderBookID::iterator
		calculatedOpeningPrice_OrderBookID_iterator
		= calculatedOpeningPrice_OrderBookID.find
		(orderBookID);

	if (calculatedOpeningPrice_OrderBookID_iterator
			!= calculatedOpeningPrice_OrderBookID.end()) {
		gpMultiIndexContainer->mCalculatedOpeningPriceContainer.erase
			(calculatedOpeningPrice_OrderBookID_iterator);
	}
}

void MultiIndexContainer::erase_EstimatedAverageSettlementPrice(string instrumentCode) {
	MultiIndexContainer::EstimatedAverageSettlementPrice_InstrumentCode&
		estimatedAverageSettlementPrice_InstrumentCode
		= gpMultiIndexContainer->mEstimatedAverageSettlementPriceContainer
		.get<MultiIndexContainer::estimatedAverageSettlementPrice_InstrumentCode>();

	MultiIndexContainer::EstimatedAverageSettlementPrice_InstrumentCode::iterator
		estimatedAverageSettlementPrice_InstrumentCode_iterator
		= estimatedAverageSettlementPrice_InstrumentCode.find
		(instrumentCode);

	if (estimatedAverageSettlementPrice_InstrumentCode_iterator
			!= estimatedAverageSettlementPrice_InstrumentCode.end()) {
		gpMultiIndexContainer->mEstimatedAverageSettlementPriceContainer.erase
			(estimatedAverageSettlementPrice_InstrumentCode_iterator);
	}
}

void MultiIndexContainer::erase_OpenInterest(uint32_t orderBookID) {
	MultiIndexContainer::OpenInterest_OrderBookID&
		openInterest_OrderBookID
		= gpMultiIndexContainer->mOpenInterestContainer
		.get<MultiIndexContainer::openInterest_OrderBookID>();

	MultiIndexContainer::OpenInterest_OrderBookID::iterator
		openInterest_OrderBookID_iterator
		= openInterest_OrderBookID.find
		(orderBookID);

	if (openInterest_OrderBookID_iterator
			!= openInterest_OrderBookID.end()) {
		gpMultiIndexContainer->mOpenInterestContainer.erase
			(openInterest_OrderBookID_iterator);
	}
}

void MultiIndexContainer::erase_ImpliedVolatility(uint32_t orderBookID) {
	MultiIndexContainer::ImpliedVolatility_OrderBookID&
		impliedVolatility_OrderBookID
		= gpMultiIndexContainer->mImpliedVolatilityContainer
		.get<MultiIndexContainer::impliedVolatility_OrderBookID>();

	MultiIndexContainer::ImpliedVolatility_OrderBookID::iterator
		impliedVolatility_OrderBookID_iterator
		= impliedVolatility_OrderBookID.find
		(orderBookID);

	if (impliedVolatility_OrderBookID_iterator
			!= impliedVolatility_OrderBookID.end()) {
		gpMultiIndexContainer->mImpliedVolatilityContainer.erase
			(impliedVolatility_OrderBookID_iterator);
	}
}

void MultiIndexContainer::erase_MarketAlert(uint32_t seqNum) {
	MultiIndexContainer::MarketAlert_SeqNum&
		marketAlert_SeqNum
		= gpMultiIndexContainer->mMarketAlertContainer
		.get<MultiIndexContainer::marketAlert_SeqNum>();

	MultiIndexContainer::MarketAlert_SeqNum::iterator
		marketAlert_SeqNum_iterator
		= marketAlert_SeqNum.find
		(seqNum);

	if (marketAlert_SeqNum_iterator
			!= marketAlert_SeqNum.end()) {
		gpMultiIndexContainer->mMarketAlertContainer.erase
			(marketAlert_SeqNum_iterator);
	}
}

void MultiIndexContainer::erase_ChangeModeResponse(uint16_t channelID) {
	MultiIndexContainer::ChangeModeResponse_ChannelID&
		changeModeResponse_ChannelID
		= gpMultiIndexContainer->mChangeModeResponseContainer
		.get<MultiIndexContainer::changeModeResponse_ChannelID>();

	MultiIndexContainer::ChangeModeResponse_ChannelID::iterator
		changeModeResponse_ChannelID_iterator
		= changeModeResponse_ChannelID.find
		(channelID);

	if (changeModeResponse_ChannelID_iterator
			!= changeModeResponse_ChannelID.end()) {
		gpMultiIndexContainer->mChangeModeResponseContainer.erase
			(changeModeResponse_ChannelID_iterator);
	}
}

void MultiIndexContainer::erase_LineStatus(char lineType, uint16_t channelID) {
	const MultiIndexContainer::LineStatus_LineType_ChannelID&
		lineStatus_LineType_ChannelID
		= gpMultiIndexContainer->mLineStatusContainer
		.get<MultiIndexContainer::lineStatus_LineType_ChannelID>();

	MultiIndexContainer::LineStatus_LineType_ChannelID::iterator
		lineStatus_LineType_ChannelID_iterator
		= lineStatus_LineType_ChannelID.find
		(boost::make_tuple(lineType, channelID));

	if (lineStatus_LineType_ChannelID_iterator
			!= lineStatus_LineType_ChannelID.end()) {
		gpMultiIndexContainer->mLineStatusContainer.erase
			(lineStatus_LineType_ChannelID_iterator);
	}
}
//-----------------------------------------------------------------------
// For OMDCC
//-----------------------------------------------------------------------
void MultiIndexContainer::erase_OMDCC_MarketDefinition(string marketCode)
{
	MultiIndexContainer::OMDCC_MarketDefinition_MarketCode& mktDef_mktCode
		= gpMultiIndexContainer->mOMDCC_MarketDefinitionContainer.get<MultiIndexContainer::omdcc_marketDefinition_MarketCode>();

	MultiIndexContainer::OMDCC_MarketDefinition_MarketCode::iterator mktDef_Iter
		= mktDef_mktCode.find(marketCode);

	if (mktDef_Iter!=mktDef_mktCode.end())
	{
		gpMultiIndexContainer->mOMDCC_MarketDefinitionContainer.erase(mktDef_Iter);
	}
}
//-----------------------------------------------------------------------
void MultiIndexContainer::erase_OMDCC_SecurityDefinition(uint32_t securityCode)
{
	MultiIndexContainer::OMDCC_SecurityDefinition_SecurityCode& secDef_secCode
		= gpMultiIndexContainer->mOMDCC_SecurityDefinitionContainer.get<MultiIndexContainer::omdcc_securityDefinition_SecurityCode>();

	MultiIndexContainer::OMDCC_SecurityDefinition_SecurityCode::iterator secDef_Iter
		= secDef_secCode.find(securityCode);

	if (secDef_Iter!=secDef_secCode.end())
	{
		gpMultiIndexContainer->mOMDCC_SecurityDefinitionContainer.erase(secDef_Iter);
	}
}
//-----------------------------------------------------------------------
void MultiIndexContainer::erase_OMDCC_SecurityStatus(uint32_t securityCode)
{
	MultiIndexContainer::OMDCC_SecurityStatus_SecurityCode& secStatus_secCode
		= gpMultiIndexContainer->mOMDCC_SecurityStatusContainer.get<MultiIndexContainer::omdcc_securityStatus_SecurityCode>();

	MultiIndexContainer::OMDCC_SecurityStatus_SecurityCode::iterator secStatus_Iter
		= secStatus_secCode.find(securityCode);

	if (secStatus_Iter!=secStatus_secCode.end())
	{
		gpMultiIndexContainer->mOMDCC_SecurityStatusContainer.erase(secStatus_Iter);
	}
}
//-----------------------------------------------------------------------
void MultiIndexContainer::erase_OMDCC_TopOfBook(uint32_t securityCode)
{
	MultiIndexContainer::OMDCC_TOB_SecurityCode& tob_secCode
		= gpMultiIndexContainer->mOMDCC_TopOfBookContainer.get<MultiIndexContainer::omdcc_TOB_SecurityCode>();

	MultiIndexContainer::OMDCC_TOB_SecurityCode::iterator tob_Iter
		= tob_secCode.find(securityCode);

	if (tob_Iter!=tob_secCode.end())
	{
		gpMultiIndexContainer->mOMDCC_TopOfBookContainer.erase(securityCode);
	}    
}
//-----------------------------------------------------------------------
void MultiIndexContainer::erase_OMDCC_Statistics(uint32_t securityCode)
{
	MultiIndexContainer::OMDCC_Statistics_SecurityCode& statistics_secCode
		= gpMultiIndexContainer->mOMDCC_StatisticsContainer.get<MultiIndexContainer::omdcc_Statistics_SecurityCode>();

	MultiIndexContainer::OMDCC_Statistics_SecurityCode::iterator statistics_Iter
		= statistics_secCode.find(securityCode);

	if (statistics_Iter!=statistics_secCode.end())
	{
		gpMultiIndexContainer->mOMDCC_StatisticsContainer.erase(securityCode);
	}
}
//-----------------------------------------------------------------------
void MultiIndexContainer::ClearMktStatusNew(void)
{	
	memset(mktStatusNew, 0x00, sizeof(mktStatusNew));
	iMktStatusNewIdx = 0;
}

int MultiIndexContainer::GetMktStatus(MktStatusNew_Key_t key, MktStatusNew_Content_t *content)
{
	// LOG4_DEBUG(mLogger, "GetMktStatus " << "::"
	// << " M:" << (int)key.Market_u8 
	// << " I:" << (int)key.Instrument_u8
	// << " C:" << key.CommodityCode_u16
	// << " OBID:" << key.OrderBookID_u32);a

	for (int i=0; i<iMktStatusNewIdx; i++)
	{
		if (!memcmp(&mktStatusNew[i].key, &key, sizeof(MktStatusNew_Key_t)))
		{			
			memcpy(content, &mktStatusNew[i].content, sizeof(MktStatusNew_Content_t));
			//LOG4_DEBUG(mLogger, "GetMktStatus " << "OK");
			return 1;
		}
	}
	return 0;
}

void MultiIndexContainer::SetMktStatus(MktStatusNew_Key_t key, MktStatusNew_Content_t content)
{
	for (int i=0; i<iMktStatusNewIdx; i++)
	{
		if (!memcmp(&mktStatusNew[i].key, &key, sizeof(MktStatusNew_Key_t)))
		{
			//update;
			//check state level -> priority			
			memcpy(&mktStatusNew[i].content, &content, sizeof(MktStatusNew_Content_t));			
			return;
		}
	}
	if (iMktStatusNewIdx<MARKET_STATUS_MAX)
	{
		memcpy(&mktStatusNew[iMktStatusNewIdx].key, &key, sizeof(key));
		memcpy(&mktStatusNew[iMktStatusNewIdx].content, &content, sizeof(content));
		iMktStatusNewIdx++;
	}
}



