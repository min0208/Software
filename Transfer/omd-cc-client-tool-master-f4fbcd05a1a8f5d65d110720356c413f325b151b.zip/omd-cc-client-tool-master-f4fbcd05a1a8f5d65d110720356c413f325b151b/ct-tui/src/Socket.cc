#include "Socket.h"

Socket::Socket() {
}

Socket::~Socket() {
}

/*
 * Create an AF_INET stream socket
 */
int Socket::createTcp(Logger& logger) {
  int sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0) {
    ::ErrorHandler::print(logger, "socket()", true);
  }
  return sockfd;
}

/*
 * man 7 socket
 * Allow socket descriptor to be reuseable
 */
void Socket::setReuseAddr(Logger& logger, int sockfd) {
  int on = 1;
  if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR,
		 (char *)&on, sizeof(on)) < 0) {
    ::ErrorHandler::print(logger, "setsockopt()", true);
    close(sockfd);
  }
}

/*
 * man 2 ioctl, man 2 fcntl
 * Set socket to be non-blocking
 */
void Socket::setNonBlock(Logger& logger, int sockfd) {
  if (fcntl(sockfd, F_SETFL, O_NONBLOCK) < 0) {
    ::ErrorHandler::print(logger, "fcntl()", true);
    close(sockfd);
    exit(-1);
  }
}

/*
 * man 7 ip, man 2 bind
 * Bind the socket
 */
void Socket::bindAddr(Logger& logger, int sockfd, char* ipAddr, int port) {
  struct sockaddr_in addr;
  memset(&addr, 0, sizeof(addr));
  addr.sin_family      = AF_INET;
  addr.sin_port        = htons(port);
  addr.sin_addr.s_addr = inet_addr(ipAddr);
  if (bind(sockfd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
    ::ErrorHandler::print(logger, "bind()", true);
    close(sockfd);
    exit(-1);
  }
}

/*
 * Create listen socket
 */
int Socket::createListen(Logger& logger, char* ipAddr, int port) {
  int sockfd = createTcp(logger);
  setReuseAddr(logger, sockfd);
  setNonBlock(logger, sockfd);
  bindAddr(logger, sockfd, ipAddr, port);

  /*
   * Set the listen back log
   */
  if (listen(sockfd, 32) < 0) {
    ::ErrorHandler::print(logger, "listen()", true);
    close(sockfd);
    exit(-1);
  }

  return sockfd;
}

/*
 * man 2 accept
 */
int Socket::acceptConn(Logger& logger, int sockfd) {
  int sockfdNew = accept(sockfd, NULL, NULL);
  Socket::setNonBlock(logger, sockfdNew);
  return sockfdNew;
}

/*
 * Create an AF_INET datagram socket
 */
int Socket::createUdp(Logger& logger) {
  int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
  if (sockfd < 0) {
    ::ErrorHandler::print(logger, "socket()", true);
  }
  return sockfd;
}

void Socket::joinMcGroup
(Logger& logger, int sockfd, char* interface, char* multiaddr) {
  struct ip_mreq imreq;
  imreq.imr_multiaddr.s_addr = inet_addr(multiaddr);
  imreq.imr_interface.s_addr = inet_addr(interface);

  // man 7 ip
  if (setsockopt(sockfd, IPPROTO_IP, IP_ADD_MEMBERSHIP,
		 (const void*)&imreq, sizeof(struct ip_mreq)) < 0) {
    ::ErrorHandler::print(logger, "setsockopt(IP_ADD_MEMBERSHIP)", true);
    close(sockfd);
    exit(1);
  }
}

void Socket::leaveMcGroup
(Logger& logger, int sockfd, char* interface, char* multiaddr) {
  struct ip_mreq imreq;
  imreq.imr_multiaddr.s_addr = inet_addr(multiaddr);
  imreq.imr_interface.s_addr = inet_addr(interface);

  // man 7 ip
  if (setsockopt(sockfd, IPPROTO_IP, IP_DROP_MEMBERSHIP,
		 (const void*)&imreq, sizeof(struct ip_mreq)) < 0) {
    ::ErrorHandler::print(logger, "setsockopt(IP_DROP_MEMBERSHIP)", true);
    close(sockfd);
    exit(1);
  }
}

/*
 * Create multicast client socket
 */
int Socket::createMcClient
(Logger& logger, char* interface, char* multiaddr, uint32_t port) {
  int sockfd = createUdp(logger);
  setReuseAddr(logger, sockfd);
  setNonBlock(logger, sockfd);
  bindAddr(logger, sockfd, (char*)multiaddr, port);

  //
  int iBufferSize = 16777216;//1024 * 1024 * 10;
  if (setsockopt(sockfd, SOL_SOCKET, SO_RCVBUF, &iBufferSize, sizeof(iBufferSize))==-1)
  {
	LOG4_DEBUG(logger, "Cannot set sockopt.");
  }
  //

  int rcvBufBytes;
  socklen_t optlen = sizeof(rcvBufBytes);
  getsockopt(sockfd, SOL_SOCKET, SO_RCVBUF
	     , &rcvBufBytes, &optlen);
  LOG4_DEBUG(logger, "rcvBufBytes:" << rcvBufBytes);

  return sockfd;
}

/*
 * man 7 ip
 * Disable multicast packets loopback
 */
void Socket::disableMcLoopback(Logger& logger, int sockfd) {
  int off = 0;
  if (setsockopt(sockfd, IPPROTO_IP, IP_MULTICAST_LOOP,
		 (char*)&off, sizeof(off)) < 0) {
    ::ErrorHandler::print(logger, "setsockopt()", true);
    close(sockfd);
  }
}

/*
 * man 7 ip
 * Set multicast local interface
 */
void Socket::setMcLocalInterface(Logger& logger, int sockfd, char* interface) {
  struct in_addr localInterface;
  localInterface.s_addr = inet_addr(interface);
  if (setsockopt(sockfd, IPPROTO_IP, IP_MULTICAST_IF,
		 (char*)&localInterface, sizeof(localInterface)) < 0) {
    ::ErrorHandler::print(logger, "setting local interface", true);
  }
}
/*
 * Create multicast server socket
 */
int Socket::createMcServer
(Logger& logger, char* multiaddr, uint32_t port, char* interface
, struct sockaddr_in& sin) {
  int sockfd = createUdp(logger);
  disableMcLoopback(logger, sockfd);
  setNonBlock(logger, sockfd);
  setMcLocalInterface(logger, sockfd, interface);

  /*
   * Initialize the group sockaddr structure with a group address and port.
   */
  memset(&sin, 0, sizeof(sin));
  sin.sin_family = AF_INET;
  sin.sin_port = htons(port);
  sin.sin_addr.s_addr = inet_addr(multiaddr);

  return sockfd;
}

/*
 * man 2 connect
 * Connect the socket
 */
int Socket::connectAddr(Logger& logger, int sockfd, char* ipAddr, int port) {
  struct sockaddr_in addr;
  memset(&addr, 0, sizeof(addr));
  addr.sin_family      = AF_INET;
  addr.sin_port        = htons(port);
  addr.sin_addr.s_addr = inet_addr(ipAddr);
  int retVal = connect(sockfd, (struct sockaddr *)&addr, sizeof(addr));
  if (retVal < 0) {
    ::ErrorHandler::print(logger, "connect()", false);
    LOG4_ERR(logger, "ipAddr:" << ipAddr << ", port:" << port);
    close(sockfd);
  }
  return retVal;
}

/*
 * Create connect socket
 */
int Socket::createConnect(Logger& logger, char* ipAddr, int port) {
  int sockfd = createTcp(logger);
  if (connectAddr(logger, sockfd, ipAddr, port) < 0) {
    return -1;
  } else {
    return sockfd;
  }
}
