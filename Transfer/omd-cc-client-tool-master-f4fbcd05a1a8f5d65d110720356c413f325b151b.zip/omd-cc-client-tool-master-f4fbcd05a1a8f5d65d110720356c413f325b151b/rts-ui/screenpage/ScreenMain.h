#ifndef ScreenMainH
#define ScreenMainH 1

#include <list>

#include "ScreenPage.h"

#include "datamodules/securitydef.h"
#include "datamodules/aggregateobu.h"
#include "datamodules/brokerqueue.h"

using namespace std;

class ScreenMain : public ScreenPage
{
	public:
		ScreenMain();
		~ScreenMain();

		void refreshScr();
		void handleUserInput( int c );

	protected:
		virtual bool buildTextBox();

		virtual bool onInit();
		virtual bool onRedraw();
		virtual bool onRefresh();
		bool redrawOutline();
		bool validate();
		void sendRtsRequest();
		const char* getRtsStr( int nStatus );
/*
		bool showInstrumentData( int nInstrumentType, SecurityDef& oData );
		bool showSecurityDef( int nSecCode );
		bool showTradingSessionStatus( const char* sMarketCode );
		bool showIEP( int nSecCode );
		bool showStatistics( int nSecCode );
		bool showNominal( int nSecCode );
		bool showClosing( int nSecCode );
		bool showTrade( int nSecCode );
		bool showBrokerQ( int nSecCode );
		void showBrokerQ( BrokerQueue& oBQ, int nIDX, bool bBid );
		bool showOrder( int nSecCode );
		bool showOrderQueue( int nSecCode, int nOrderQueueType, int nBestPrice, list<AggregateOBU::ORDER>& oQueue, const char* sSpreadTableCode );
		void showSecInfo( int nSecCode );
		bool showVCM( int nSecCode );
		bool showReferencePrice( int nSecCode );
		bool showOrderImbalance( int nSecCode );
*/
		bool handleBackSpace( int c );
		bool handleArrowKey( int c );
		bool deleteChar( string& sStr );

	protected:
		int m_nInputFieldIndex;

		map<int,string> m_mInput;
};

#endif
