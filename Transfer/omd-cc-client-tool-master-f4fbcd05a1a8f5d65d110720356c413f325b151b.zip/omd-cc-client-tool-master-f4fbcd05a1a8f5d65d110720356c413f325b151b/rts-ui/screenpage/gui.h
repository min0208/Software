#ifndef GUI_H
#define GUI_H

#ifndef _XOPEN_SOURCE_EXTENDED
#define _XOPEN_SOURCE_EXTENDED
#endif

#ifdef __CYGWIN__
        #include <ncursesw/curses.h>
#else
        #include <curses.h>
#endif

#include <sstream>


#include "screenpage/ScreenMain.h"
#include "screenpage/ScreenQuit.h"
#include "screenpage/textbox.h"
#include "std/stdlogger.h"
#include <vector>
#include <map>

using namespace std;

class GUI
{
	public:
		GUI();
		virtual ~GUI();

	protected:
		enum LINE_STATUS
		{
			ALL_LINE_DOWN = 0,
			ONE_LINE_DOWN,
			ALL_LINE_UP
		};

                enum Screen
                {
                        MAIN_SCREEN,
                        QUIT_SCREEN,
                };

               enum FOOTNOTE_TEXTBOX_IDX
                {
                        FOOTNOTE_BEGIN,
                        FOOTNOTE_CT_INFO = FOOTNOTE_BEGIN,
                        FOOTNOTE_RT_HDR,
                        FOOTNOTE_RT_1,
                        FOOTNOTE_RFS_HDR = FOOTNOTE_RT_1 + NO_OF_CHANNEL,
                        FOOTNOTE_RFS_1,
                        FOOTNOTE_SERVER = FOOTNOTE_RFS_1 + NO_OF_CHANNEL,
                        FOOTNOTE_DATE_TIME,
                        FOOTNOTE_END
                };

	protected:
		bool pollingUserInput();

	protected:
		void initGUI();
		void setTitle( const char* sTitle );
		void setMarket( const vector<string>& vMarket );

		bool buildWindow();
		bool buildMenu();
		bool buildTextBox();
		bool buildScreenPage();

		bool redraw();
		bool redrawMenu();
		bool redrawOutline();
		bool redrawTextBox();
		bool redrawWindow( bool bLock=true );
		bool clearScr( bool bLock=true );
                bool refreshScr();
		bool resize();

		bool checkMenuOption( int nOption );
		int getMenuOption();

		int convertKeyToASC( bool bSpecial, int c );
		int getUserInput();
		bool clearUserInput();
                bool handleUserInput( int c );
                bool handleENTER( int c );
                bool handleNumeric( int c );
                bool handleBackSpace( int c );
                bool handleArrowKey( int c );
		bool deleteChar( string& sStr );

		bool showDateTime();
		bool showCTInfo();
		bool showCTSvrInfo();
		bool showChannelInfo();
		bool showUserInputSecCode();

		int getChannelStatusColor( int nStatus );
		int getCTSvrStatusColor( int nStatus );
		void rtsRequest();
	
	protected:
		WINDOW* m_pWin;
		WINDOW* m_pMenuWin;
		WINDOW* m_pFootNoteWin;

		MENU* m_pMenu;
		ITEM** m_pMenuItem;
		vector<string> m_vMenuItem;
		int m_nMenuOption;

		TextBox m_oTitleTextBox;
		TextBox m_oInSecHdrTextBox;
		TextBox m_oInSecDatTextBox;
		map<int,TextBox> m_mFootNote;

		ScreenMain *m_pScreenMain;
		ScreenQuit *m_pScreenQuit;

		STDMutex m_oCTMutex;

		string m_sTitle;
		vector<string> m_vMarket;

		string m_sUserInput;
		int m_nUserInSecCode;
		int m_nScreen;
		int m_nLastCOLS;
		int m_nLastLINES;

		int m_nCTSvrStatus;
                int m_nWaitForInput;
};

#endif
