//////////////////////////////////////////////////////////////////////////////////
//// Date	Ver	Name	Description
//// 20120520	r1	RC	Initial revision
//////////////////////////////////////////////////////////////////////////////////

#include "screenpage/textbox.h"
#include "std/stdmutexlocker.h"
#include "std/stdapp.h"

#include "main.h"

#define LOGC "|TextBox     | "

STDMutex TextBox::m_gTextBoxMutex;

TextBox::TextBox() :
	m_pWin(NULL),
	m_LEN(NULL),
	m_x(0),
	m_y(0),
	m_nColor(0),
	m_bHighlight(false)
{
}

TextBox::TextBox( WINDOW* pWin, int LEN, int x, int y ) :
	m_pWin(pWin),
	m_LEN(LEN),
	m_x(x),
	m_y(y)
{
}

TextBox::~TextBox()
{
}

bool TextBox::init( WINDOW* pWin, int LEN, int x, int y )
{
	m_pWin = pWin;
	m_LEN = LEN;
	m_x = x;
	m_y = y;

	return true;
}

bool TextBox::padSpace( const char* sInStr, char* sOutStr, int nFieldLen, int nAlign )
{
	int nInStrLen = strlen( sInStr );
	int nNeedSpace = nFieldLen - nInStrLen;

	if ( nNeedSpace < 0 ) 
	{
		// input string too long, truncate it to fit field length
		//strncpy( sOutStr, sInStr, nFieldLen );
		memcpy( sOutStr, sInStr, nFieldLen );
	}
	else
	{
		memset( sOutStr, ' ', nFieldLen );

		switch (nAlign)
		{
			case ALIGN_LEFT:
				{
					//strncpy( sOutStr, sInStr, nInStrLen );
					memcpy( sOutStr, sInStr, nInStrLen );
					break;
				}
			case ALIGN_RIGHT:
				{
					//strncpy( &sOutStr[ nNeedSpace], sInStr, nInStrLen );
					memcpy( &sOutStr[ nNeedSpace], sInStr, nInStrLen );
					break;
				}
			case ALIGN_CENTER:
				{
					//strncpy( &sOutStr[ nNeedSpace/2], sInStr, nInStrLen );
					memcpy( &sOutStr[ nNeedSpace/2], sInStr, nInStrLen );
					break;
				}
		}
	}

	sOutStr[ nFieldLen] = 0;

	return true;
}

bool TextBox::showSpecial( int nAlign, int nColor, bool bHighlight, const char* pFmt, ... )
{
	STDMutexLocker oLocker(m_gTextBoxMutex);

	m_nAlign = nAlign;
	m_nColor = nColor;
	m_bHighlight = bHighlight;

	if ( m_nColor != 0 )	wattron( m_pWin, COLOR_PAIR(m_nColor) | (m_bHighlight?A_REVERSE|A_BOLD:0) );

        // format the string
        char sText[ MAX_TEXT] = { 0 };
        va_list tArgList;
        va_start( tArgList, pFmt );
        vsnprintf( sText, sizeof(sText), pFmt, tArgList );
        va_end( tArgList );
        
	char sOut[ 1024];
	padSpace( sText, sOut, m_LEN, m_nAlign );
	m_sText = sOut;

	if ( m_pWin )
	{
		mvwprintw( m_pWin, m_y, m_x, m_sText.c_str() );
	}
	else
	{
		mvprintw( m_y, m_x, m_sText.c_str() );
	}

	if ( m_nColor != 0 )	wattroff( m_pWin, COLOR_PAIR(m_nColor) | (m_bHighlight?A_REVERSE|A_BOLD:0) );

	return true;
}

bool TextBox::show( const char* pFmt, ... )
{
	STDMutexLocker oLocker(m_gTextBoxMutex);
	/////////////////////////////
	// set normal display
	//
	m_nAlign = ALIGN_LEFT;
	m_nColor = 0;
	m_bHighlight = false;

        // format the string
        char sText[ MAX_TEXT] = { 0 };
        va_list tArgList;
        va_start( tArgList, pFmt );
        vsnprintf( sText, sizeof(sText), pFmt, tArgList );
        va_end( tArgList );
       
	char sOut[ 1024];
	padSpace( sText, sOut, m_LEN, m_nAlign );
	m_sText = sOut;

	if ( m_pWin )
	{
		mvwprintw( m_pWin, m_y, m_x, m_sText.c_str() );
	}
	else
	{
		mvprintw( m_y, m_x, m_sText.c_str() );
	}

	//ClientToolP3::logger()->log( 1, "%d %d %s", m_x, m_y, m_sText.c_str() );

	return true;
}

bool TextBox::show()
{
	STDMutexLocker oLocker(m_gTextBoxMutex);

	if ( m_nColor != 0 )	wattron( m_pWin, COLOR_PAIR(m_nColor) | (m_bHighlight?A_REVERSE|A_BOLD:0) );

	if ( m_pWin )
	{
		mvwprintw( m_pWin, m_y, m_x, m_sText.c_str() );
	}
	else
	{
		mvprintw( m_y, m_x, m_sText.c_str() );
	}

	if ( m_nColor != 0 )	wattroff( m_pWin, COLOR_PAIR(m_nColor) | (m_bHighlight?A_REVERSE|A_BOLD:0) );

	return true;
}

int TextBox::getX()
{
	return m_x;
}

int TextBox::getY()
{
	return m_y;
}

void TextBox::setX( int x )
{
	m_x = x;
}

void TextBox::setY( int y )
{
	m_y = y;
}

const char* TextBox::getText()
{
	return m_sText.c_str();
}

void TextBox::setText( const char* s )
{
	m_sText = s;
}

void TextBox::addChar( char c )
{
	m_sText += c;
}

