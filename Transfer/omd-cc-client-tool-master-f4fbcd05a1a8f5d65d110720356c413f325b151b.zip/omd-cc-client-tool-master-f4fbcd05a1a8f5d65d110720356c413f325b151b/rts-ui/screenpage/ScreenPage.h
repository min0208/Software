#ifndef ScreenPageH
#define ScreenPageH 1

#include <map>

#include "std/stdutil.h"
#include "std/stdmutexlocker.h"
#include "screenpage/textbox.h"

using namespace std;

class ScreenPage
{
	public:
		ScreenPage();
		virtual ~ScreenPage();

		virtual bool init();

	public:
		enum TEXTBOX_INDEX
		{
			TB_MAIN_BEGIN,
			TB_MAIN_HEADLINE = TB_MAIN_BEGIN,
			TB_MAIN_CHANNEL_ID,
			TB_MAIN_BEG_SEQNUM,
			TB_MAIN_END_SEQNUM,
			TB_MAIN_SEND,
			TB_MAIN_RESPONSE_STATUS,
			TB_MAIN_END,

			QUIT_BEGIN,
			QUIT_HDR = QUIT_BEGIN,
			QUIT_END,

			END_FIELD,
			INVALID_FIELD
		};

	public:
		virtual bool redraw();
		virtual void refreshScr() {};

	protected:
		int priceColor( int nInput, int nPrevious );

		virtual bool onInit();
		virtual bool buildWindow();
		virtual bool buildTextBox();

		virtual bool clearScr();
		virtual bool onRedraw(){};
		virtual bool onRefresh(){};
		virtual bool redrawWindow();
		virtual bool redrawTextBox();

	protected:
		WINDOW* m_pDataWin;
		map<int,TextBox> m_mDatTextBox;
		map<int,TextBox> m_mHdrTextBox;

		STDMutex m_oMutex;
};

#endif

