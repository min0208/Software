#include "gui.h"

#include "modules/imagecontrol.h"
#include "modules/spreadtable.h"
#include "include/common/ClientToolStructs.h"
#include "std/stdapp.h"
#include "main.h"

using namespace std;

#define LOGC "|GUI     | "

static const char *MENU_STR[] =
{
        "RTS",
        "Quit"
};

static const int NO_OF_MENU_ITEM = sizeof(MENU_STR)/sizeof(MENU_STR[0]);

GUI::GUI() :
	m_nUserInSecCode(0),
	m_nLastCOLS(0),
	m_nLastLINES(0),
        m_nScreen(MAIN_SCREEN),
        m_nWaitForInput(5)
{
}

GUI::~GUI()
{
        if ( m_pScreenMain ) delete m_pScreenMain;
        if ( m_pScreenQuit ) delete m_pScreenQuit;

	endwin();
}

void GUI::setTitle( const char* sTitle )
{
	m_sTitle = sTitle;
}

void GUI::initGUI()
{
	setlocale( LC_ALL, "" );

	if (initscr() == 0)
	{
		cout << "initscr failed:0" << endl;
		exit(1);
	}

	if (cbreak() == ERR)
	{
		endwin();
		cout << "cbreak failed:" << ERR << endl;
		exit(1);
	}

	if (noecho() == ERR)
	{
		endwin();
		cout << "noecho failed:" << ERR << endl;
		exit(1);
	};

	if (keypad(stdscr, TRUE) == ERR)
	{
		endwin();
		cout << "keypad failed:" << ERR << endl;
		exit(1);
	}

	start_color();

	init_pair( GUI_RED, COLOR_RED, COLOR_BLACK );
	init_pair( GUI_CYAN, COLOR_CYAN, COLOR_BLACK );
	init_pair( GUI_WHITE, COLOR_WHITE, COLOR_BLACK );
	init_pair( GUI_BLACK_BLUE, COLOR_BLACK, COLOR_BLUE );
	init_pair( GUI_YELLOW, COLOR_YELLOW, COLOR_BLACK );
	init_pair( GUI_MAGENTA, COLOR_MAGENTA, COLOR_BLACK );
	init_pair( GUI_GREEN, COLOR_GREEN, COLOR_BLACK );
	init_pair( GUI_BLUE, COLOR_BLUE, COLOR_BLACK );

	init_pair( GUI_GREEN_WHITE, COLOR_GREEN, COLOR_WHITE );
	init_pair( GUI_BLACK_MAGENTA, COLOR_BLACK, COLOR_MAGENTA );
	init_pair( GUI_WHITE_MAGENTA, COLOR_WHITE, COLOR_MAGENTA );
	init_pair( GUI_WHITE_RED, COLOR_WHITE, COLOR_RED );
	init_pair( GUI_WHITE_BLUE, COLOR_WHITE, COLOR_BLUE );
	init_pair( GUI_MAGENTA_WHITE, COLOR_MAGENTA, COLOR_WHITE );
	init_pair( GUI_MAGENTA_BLACK, COLOR_MAGENTA, COLOR_BLACK );
	init_pair( GUI_MAGENTA_BLUE, COLOR_MAGENTA, COLOR_BLUE );

	buildWindow();
	buildMenu();
	buildTextBox();
	buildScreenPage();
}

bool GUI::redrawWindow( bool bLock )
{
	if ( bLock )	m_oCTMutex.lock();

	wresize( m_pMenuWin, 2, COLS-2 );
	mvwin( m_pFootNoteWin, LINES-3, 1 );
	wresize( m_pFootNoteWin, 2, COLS-5 );

	if ( bLock )	m_oCTMutex.unlock();

	return true;
}

bool GUI::redrawMenu()
{
	post_menu( m_pMenu );

	switch ( m_nScreen )
	{
		case QUIT_SCREEN:
			{
				menu_driver( m_pMenu, REQ_LEFT_ITEM );
				menu_driver( m_pMenu, REQ_RIGHT_ITEM );
				break;
			}

		default:
			{
				menu_driver( m_pMenu, REQ_RIGHT_ITEM );
				menu_driver( m_pMenu, REQ_LEFT_ITEM );
				break;
			}
	}

	return true;
}

bool GUI::redrawTextBox()
{
	m_oTitleTextBox.show();

	switch ( m_nScreen )
	{
		case MAIN_SCREEN:
			{
				m_oInSecHdrTextBox.show();
				m_oInSecDatTextBox.show();
				break;
			}
	}

	map<int,TextBox>::iterator oItr = m_mFootNote.begin();

	while ( oItr != m_mFootNote.end() )
	{
		oItr->second.show();
		oItr++;
	};

	return true;
}

bool GUI::redraw()
{
	m_oCTMutex.lock();

	clearScr( false );
	redrawWindow( false );
	redrawMenu();
	redrawTextBox();

	m_oCTMutex.unlock();

	return true;
}

bool GUI::buildWindow()
{
	m_pWin = newwin( 0, 0, 0, 0 );
	m_pMenuWin = newwin( 1, COLS-2, 2, 1 );
	m_pFootNoteWin = newwin( 2, COLS-5, LINES-3, 1 );

	keypad( m_pMenuWin, TRUE );

	return true;
}

bool GUI::buildMenu()
{
	static const int LEN_10 = 10;
	char sText[ LEN_10+1];

	for ( unsigned int i=0; i<NO_OF_MENU_ITEM; i++ )
	{
		STDUtil::padSpace( MENU_STR[ i], sText, LEN_10 );
		m_vMenuItem.push_back( sText );
	}

	m_pMenuItem = (ITEM **)calloc( m_vMenuItem.size() + 1, sizeof(ITEM *) );

	for ( unsigned int i=0; i<m_vMenuItem.size(); i++ )
	{
		m_pMenuItem[ i] = new_item( m_vMenuItem[ i].c_str(), "" );
	}

	m_pMenuItem[ m_vMenuItem.size()] = (ITEM *)NULL;
	m_pMenu = new_menu( m_pMenuItem );

	set_menu_win( m_pMenu, m_pMenuWin );
	set_menu_sub( m_pMenu, derwin(m_pMenuWin, 1, COLS-3, 0, 0) );
	set_menu_mark( m_pMenu, "> " );
	set_menu_format( m_pMenu, 1, m_vMenuItem.size() + 1 );
	set_menu_fore( m_pMenu, COLOR_PAIR(GUI_YELLOW) | A_REVERSE );

	post_menu( m_pMenu );

	return true;
}

bool GUI::buildTextBox()
{
	TextBox oTextBox;

	/////////////////////////////////////////////////////
	// General Textbox
	//
	m_oTitleTextBox.init( m_pWin, TITLE_LEN, TITLE_X, TITLE_Y );
	m_oTitleTextBox.showSpecial( ALIGN_LEFT, GUI_WHITE_BLUE, false, m_sTitle.c_str() );

	oTextBox.init( m_pFootNoteWin, FOOTNOTE_1_LEN, FOOTNOTE_1_X, FOOTNOTE_1_Y );
	m_mFootNote[ FOOTNOTE_CT_INFO] = oTextBox;
	m_mFootNote[ FOOTNOTE_CT_INFO].show( " CT-SERVER" );

	oTextBox.init( m_pFootNoteWin, FOOTNOTE_SERVER_LEN, FOOTNOTE_SERVER_X, FOOTNOTE_SERVER_Y );
	m_mFootNote[ FOOTNOTE_SERVER] = oTextBox;

	oTextBox.init( m_pFootNoteWin, FOOTNOTE_N_LEN, FOOTNOTE_N_X, FOOTNOTE_N_Y );
	m_mFootNote[ FOOTNOTE_DATE_TIME] = oTextBox;
/*
	oTextBox.init( m_pFootNoteWin, FOOTNOTE_2_LEN, FOOTNOTE_2_X, FOOTNOTE_2_Y );
	m_mFootNote[ FOOTNOTE_RT_HDR] = oTextBox;
	m_mFootNote[ FOOTNOTE_RT_HDR].show( "RT" );

	oTextBox.init( m_pFootNoteWin, FOOTNOTE_2_LEN, (FOOTNOTE_2_X + FOOTNOTE_2_LEN + (FOOTNOTE_2_LEN * NO_OF_CHANNEL_PER_ROW)), FOOTNOTE_2_Y );
	m_mFootNote[ FOOTNOTE_RFS_HDR] = oTextBox;
	m_mFootNote[ FOOTNOTE_RFS_HDR].show( "RFS" );

	int Y = FOOTNOTE_2_Y - 1;
	int X_OFFSET = -NO_OF_CHANNEL_PER_ROW;

	for ( unsigned int i=0; i<NO_OF_CHANNEL; i++ )
	{
		if ( i % NO_OF_CHANNEL_PER_ROW == 0 )
		{
			Y++;
			X_OFFSET += NO_OF_CHANNEL_PER_ROW;
		}

		int TB_IDX = FOOTNOTE_RT_1 + i;
		int X = FOOTNOTE_2_X + FOOTNOTE_2_LEN + ( (i - X_OFFSET) * FOOTNOTE_2_LEN);

		oTextBox.init( m_pFootNoteWin, FOOTNOTE_2_LEN, X, Y );
		m_mFootNote[ TB_IDX] = oTextBox;

		TB_IDX = FOOTNOTE_RFS_1 + i;
		X = FOOTNOTE_2_X + FOOTNOTE_2_LEN + FOOTNOTE_2_LEN + ( (i - X_OFFSET) * FOOTNOTE_2_LEN) + (FOOTNOTE_2_LEN * NO_OF_CHANNEL_PER_ROW);

		oTextBox.init( m_pFootNoteWin, FOOTNOTE_2_LEN, X, Y );
		m_mFootNote[ TB_IDX] = oTextBox;
	}
*/
	return true;
}

bool GUI::buildScreenPage()
{
	////////////////////////////
	// init MAIN page
	//
	m_pScreenMain = new ScreenMain();
	m_pScreenMain->init();
	
	m_pScreenQuit = new ScreenQuit();
	m_pScreenQuit->init();

	return true;
}

bool GUI::refreshScr()
{
	bool bResize  = resize();

	if ( bResize )
	{
		redraw();
	}

	refresh();
	wrefresh( m_pWin );
	wrefresh( m_pFootNoteWin );

	switch ( m_nScreen )
	{
		case MAIN_SCREEN:
			{
				m_pScreenMain->refreshScr();
				break;
			}

		case QUIT_SCREEN:
			{
				m_pScreenQuit->refreshScr();
				break;
			}
	}

	showCTSvrInfo();
	showChannelInfo();
	showDateTime();

	wrefresh( m_pMenuWin );

	return true;
}

bool GUI::clearScr( bool bLock )
{
	if ( bLock )	m_oCTMutex.lock();

	wclear( m_pWin );
	wclear( m_pMenuWin );
	wclear( m_pFootNoteWin );

	if ( bLock )	m_oCTMutex.unlock();

	return true;
}

bool GUI::showDateTime()
{
	time_t t = time(NULL);
	struct tm tNow;
	localtime_r( &t, &tNow );

	m_mFootNote[ FOOTNOTE_DATE_TIME].showSpecial( ALIGN_LEFT, 0, false, "| %04d%02d%02d %02d:%02d:%02d", tNow.tm_year+1900, tNow.tm_mon+1, tNow.tm_mday, tNow.tm_hour, tNow.tm_min, tNow.tm_sec );

	return true;
}

bool GUI::showChannelInfo()
{
	// clean up channel status first
	for ( unsigned int i=0; i<NO_OF_CHANNEL; i++ )
	{
		m_mFootNote[ FOOTNOTE_RT_1+i].show( " " );
		m_mFootNote[ FOOTNOTE_RFS_1+i].show( " " );
	}

	ImageControl::MC_CHANNEL_MAP mMCChannel;
	ImageControl::inst()->getMCChannel( mMCChannel );

	ImageControl::MC_CHANNEL_MAP::iterator oItr = mMCChannel.begin(); 

	int RT_IDX = FOOTNOTE_RT_1;
	int RFS_IDX = FOOTNOTE_RFS_1;

	while ( oItr != mMCChannel.end() )
	{
		MCChannel& oMCChannel = oItr->second;
		if ( strncmp( oMCChannel.getType(), "R", 1 ) == 0 )
		{
			m_mFootNote[ RT_IDX++].showSpecial( ALIGN_LEFT, getChannelStatusColor(oMCChannel.getStatus()), false, oMCChannel.getChannelNum() );
		}
		else if ( strncmp( oMCChannel.getType(), "F", 1 ) == 0 )
		{
			m_mFootNote[ RFS_IDX++].showSpecial( ALIGN_LEFT, getChannelStatusColor(oMCChannel.getStatus()), false, oMCChannel.getChannelNum() );
		}
		oItr++;
	}
}

int GUI::getChannelStatusColor( int nStatus )
{
	switch ( nStatus )
	{
		case MCStatus::ALL_LINE_UP:		return GUI_GREEN;
		case MCStatus::ONE_LINE_DOWN:		return GUI_YELLOW;
	}

	return GUI_RED;
}

bool GUI::showCTSvrInfo()
{
	int nCTSvrStatus = ImageControl::inst()->getCTSvrStatus();
	m_mFootNote[ FOOTNOTE_CT_INFO].showSpecial( ALIGN_LEFT, getCTSvrStatusColor(nCTSvrStatus), false, " CT-SERVER" );

	return true;
}

int GUI::getCTSvrStatusColor( int nStatus )
{
	return (nStatus == CTStatus::CONNECT) ? GUI_GREEN : GUI_RED;
}

bool GUI::handleNumeric( int c )
{
	switch ( m_nScreen )
	{
		case MAIN_SCREEN:
			{
				if ( m_sUserInput.length() < 5 )
				{
					m_sUserInput += c;
					showUserInputSecCode();
				}
				break;
			}
	}

	return true;
}

bool GUI::handleArrowKey( int c )
{
	switch ( c )
	{
		///////////////////////////////////////////
		// ARROW KEY handling
		//
		case KEY_LEFT:
		case KEY_RIGHT:
			{
				menu_driver( m_pMenu, (c==KEY_LEFT)?REQ_LEFT_ITEM:REQ_RIGHT_ITEM );
				break;
			}
/*
		case KEY_DOWN:
			{
				if ( m_nScreen == NEWS_SCREEN )
				{
					m_pScreenNews->keyDown();
				}
				break;
			}
		case KEY_UP:
			{
				if ( m_nScreen == NEWS_SCREEN )
				{
					m_pScreenNews->keyUp();
				}
				break;
			}
		case 0x153: // PAGE_UP
			{
				if ( m_nScreen == NEWS_SCREEN )
				{
					m_pScreenNews->pageUp();
				}
				else if ( m_nScreen == MARKET_SCREEN )
				{
					m_pScreenMarket->pageUp();
				}
				break;
			}
		case 0x152: // PAGE_DOWN
			{
				if ( m_nScreen == NEWS_SCREEN )
				{
					m_pScreenNews->pageDown();
				}
				else if ( m_nScreen == MARKET_SCREEN )
				{
					m_pScreenMarket->pageDown();
				}
				break;
			}
*/
	}

	return true;
}

void GUI::rtsRequest()
{
	//ClientTool::inst()->setCTRequest( CT_OMDC_MKT_SNAPSHOT_REQUEST, PT_SECURITIES_STANDARD );
}

bool GUI::handleENTER( int c )
{
	if ( m_nScreen != getMenuOption() )
	{
		/////////////////////////////////////
		// Press ENTER for changing Menu Item
		//
		m_nScreen = getMenuOption();

		switch ( m_nScreen )
		{
			case MAIN_SCREEN:
				{
					//securityRequest( m_nUserInSecCode );
					break;
				}
		}

		redraw();
	}
	else
	{
		/////////////////////////////////////
		// PRESS ENTER at the same menu item
		//
		switch ( m_nScreen )
		{
			case MAIN_SCREEN:
				{
					if ( m_sUserInput.empty() )
					{
						// Press ENTER without input security code
						// Toggle MAIN/SECURITY screen
						//m_nMainSubOpt = (m_nMainSubOpt==MAIN_SCREEN)? SECURITY_SCREEN:MAIN_SCREEN;
					}
					else
					{
						m_nUserInSecCode = atoi( m_sUserInput.c_str() );
						//securityRequest( m_nUserInSecCode );
						clearUserInput();
					}

					break;
				}
		}
	}

	return true;
}

bool GUI::deleteChar( string& sStr )
{
	if ( sStr.length() > 0 )
	{
		sStr.erase( sStr.length()-1, 1 );
	}

	return true;
}

bool GUI::handleBackSpace( int c )
{
	deleteChar( m_sUserInput );
	showUserInputSecCode();

	return true;
}

bool GUI::clearUserInput()
{
	m_sUserInput.clear();
	showUserInputSecCode();

	return true;
}

bool GUI::showUserInputSecCode()
{
	//m_oInSecDatTextBox.show( m_sUserInput.c_str() );
	//wmove( m_pMenuWin, 1, m_oInSecDatTextBox.getX() + m_sUserInput.length() );

	return true;
}

bool GUI::resize()
{
	if ( (m_nLastCOLS != COLS) || ( m_nLastLINES != LINES ) )
	{
		STDGetLogger()->log( STDLOG_L7, "resize COLS|%d| LINES|%d|", COLS, LINES );
		m_nLastCOLS = COLS;
		m_nLastLINES = LINES;
		return true;
	}

	return false;
}

bool GUI::checkMenuOption( int nOption )
{
	return ( strncmp(item_name(current_item(m_pMenu)), MENU_STR[nOption], strlen(MENU_STR[nOption]) ) == 0 );
}

int GUI::getMenuOption()
{
	for ( unsigned int i=MAIN_SCREEN; i<=QUIT_SCREEN; i++ )
	{
		if ( checkMenuOption(i) )
		{
			return i;
		}
	}

	return -1;
}

int GUI::getUserInput()
{
	halfdelay( m_nWaitForInput );
	return getch();
}

int GUI::convertKeyToASC( bool bSpecial, int c )
{
	if ( !bSpecial )
	{
		if ( c == 0x157 )  // Num pad ENTER
		{
			return 0x0A;
		}
		else
		{
			return c;
		}
	}
	else if ( c >= 0x70 && c <= 0x79 ) // Num pad 0-9
	{
		return (c - 0x40);
	}

	return c;
}

bool GUI::pollingUserInput()
{
	bool bQuit = false;
	bool bPressedALT = false;
	bool bPressedNumKey = false;
	int c;

	//securityRequest( m_nUserInSecCode );

	while ( !bQuit && (STDGetApp()->getMsg()==STDApp::IDLE) )
	{
		c = getUserInput();

		switch ( c )
		{
			///////////////////////////////////////////
			// INPUT TIMEOUT
			//
			case -1:
				{
					break;
				}

			default:
				{
					if ( bPressedNumKey )
					{
						bQuit = !handleUserInput( convertKeyToASC(bPressedNumKey, c) );
						bPressedNumKey = false;
					}
					else if ( bPressedALT )
					{
						if ( c == 0x71 )        // ALT-Q
						{
							m_nScreen = QUIT_SCREEN;
						}
						else if ( c == 0x4F )
						{
							bPressedNumKey = true;
						}

						bPressedALT = false;
					}
					else if ( c == 0x1B )   // ALT
					{
						bPressedALT = true;
					}
					else
					{
						bQuit = !handleUserInput( convertKeyToASC(bPressedNumKey, c) );
					}
				}
		}

		refreshScr();
	};

	STDGetLogger()->log( STDLOG_L3, "exit GUI::pollingUserInput()" );

	return false;
}

bool GUI::handleUserInput( int c )
{
	//STDGetLogger()->log( STDLOG_L3, "GUI::handleUserInput() c|%d|", c );

	switch ( c )
	{
		case 0x157:
		case 0x0A:
			{
				return handleENTER( c );
			}
		case KEY_LEFT:
		case KEY_RIGHT:
		case 0x153: // PAGE_UP
		case 0x152: // PAGE_DOWN
			{
				return handleArrowKey( c );
			}
	}

	switch ( m_nScreen )
	{
		case MAIN_SCREEN:
			{
				m_pScreenMain->handleUserInput( c );
				break;
			}

		case QUIT_SCREEN:
			{
				if ( !m_pScreenQuit->userInput(c) )
				{
					return false;
				}
				else
				{
					m_nScreen = MAIN_SCREEN;
				}
				break;
			}
	}

	return true;
}

