#include "ScreenQuit.h"
#include "main.h"
#include "include/quitconstant.h"

ScreenQuit::ScreenQuit()
{
}

ScreenQuit::~ScreenQuit()
{
}

bool ScreenQuit::buildTextBox()
{
        TextBox oTextBox;

	oTextBox.init( m_pDataWin, QUIT_HDR_WIDTH, QUIT_HDR_X, QUIT_HDR_Y );
	m_mHdrTextBox[ QUIT_HDR] = oTextBox;
	m_mHdrTextBox[ QUIT_HDR].show( "Quit [Y]/[N]:" );

	return true;
}

bool ScreenQuit::userInput( int c )
{
	if ( c == 'Y' || c == 'y' )
	{
		return false;
	}
	else
	{
		return true;
	}

	return true;
}

void ScreenQuit::refreshScr()
{
	redraw();
}

