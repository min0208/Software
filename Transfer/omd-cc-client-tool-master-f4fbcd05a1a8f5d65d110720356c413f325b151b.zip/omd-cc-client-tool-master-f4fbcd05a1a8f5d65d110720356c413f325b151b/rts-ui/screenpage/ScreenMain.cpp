#include "ScreenMain.h"

#include "main.h"

#include "include/mainconstant.h"
#include "std/stdutil.h"
#include "std/stdmutexlocker.h"
#include "modules/imagecontrol.h"
#include "include/common/ClientToolStructs.h"

#define LOGC "|ScreenMain | "

static const char *HDR_NAME[] =
{
	"Channel ID:",
	"Begin Sequence Number:",
	"End Sequence Number:",
	"Send [Y]?",
	"EOF"
};

static const int NO_OF_HDR_ITEM = sizeof(HDR_NAME)/sizeof(HDR_NAME[0]) - 1;

ScreenMain::ScreenMain()
{
	m_nInputFieldIndex = TB_MAIN_CHANNEL_ID;
}

ScreenMain::~ScreenMain()
{

}

bool ScreenMain::onRedraw()
{
	redrawOutline();

	return true;
}

bool ScreenMain::onRefresh()
{
	return true;
}

bool ScreenMain::redrawOutline()
{
	STDMutexLocker oLocker(m_oMutex);

	static const int BLANK_LINE_DAT_LEN = TITLE_LEN;
	char sText[ BLANK_LINE_DAT_LEN+1];

	///////////////////////////
	// HEADER LINE
	//
	wattron( m_pDataWin, COLOR_PAIR(GUI_BLACK_MAGENTA) | A_REVERSE );
	STDUtil::padSpace( "Retransmission Request", sText, BLANK_LINE_DAT_LEN, ALIGN_LEFT );
	mvwprintw( m_pDataWin, 0, 0, sText );

	///////////////////////////
	// HEADER LINE
	//
	STDUtil::padSpace( "Retransmission Status", sText, BLANK_LINE_DAT_LEN, ALIGN_LEFT );
	mvwprintw( m_pDataWin, 7, 0, sText );
	wattroff( m_pDataWin, COLOR_PAIR(GUI_BLACK_MAGENTA) | A_REVERSE );

	return true;
}

bool ScreenMain::onInit()
{
	m_pDataWin = newwin( LINES-6, COLS-2, DATA_WIN_TOP, 1 );
	keypad( m_pDataWin, TRUE );


	return true;
}

bool ScreenMain::buildTextBox()
{
	TextBox oTextBox;

	/////////////////////////////
	// Data Field
	//
	for ( unsigned int i=TB_MAIN_CHANNEL_ID; i<TB_MAIN_RESPONSE_STATUS; i++ )
	{
		int HDR_TEXT_IDX = i - TB_MAIN_CHANNEL_ID;
		int HDR_X = TB_MAIN_CHANNEL_ID_HDR_X;
		int HDR_Y = TB_MAIN_CHANNEL_ID_HDR_Y + HDR_TEXT_IDX;
		int HDR_LEN = TB_MAIN_CHANNEL_ID_HDR_LEN;

		int DAT_X = TB_MAIN_CHANNEL_ID_DAT_X;
		int DAT_Y = HDR_Y;
		int DAT_LEN = TB_MAIN_CHANNEL_ID_DAT_LEN;

		oTextBox.init( m_pDataWin, HDR_LEN, HDR_X, HDR_Y );
		m_mHdrTextBox[ i] = oTextBox;
		m_mHdrTextBox[ i].show( HDR_NAME[ HDR_TEXT_IDX] );
		
		oTextBox.init( m_pDataWin, DAT_LEN, DAT_X, DAT_Y );
		m_mDatTextBox[ i] = oTextBox;
	}

	oTextBox.init( m_pDataWin, 80, 0, 8 );
	m_mDatTextBox[ TB_MAIN_RESPONSE_STATUS] = oTextBox;
	m_mDatTextBox[ m_nInputFieldIndex].showSpecial( ALIGN_RIGHT, GUI_WHITE, true, "" );

	return true;
}

const char* ScreenMain::getRtsStr( int nStatus )
{
	switch (nStatus)
	{
	case 0:		return "request accepted";
	case 1:		return "unknown/unauthorized channel ID";
	case 2:		return "messages not available";
	case 3:		return "invalid request rejected by client tool server";
	case 100:	return "exceeds maximum sequence range";
	case 101:	return "exceeds maximum requests in a day";
	}

	return "unknown";
}

void ScreenMain::refreshScr()
{
	redraw();

	int nRtsStatus = ImageControl::inst()->getRtsStatus();

	if ( nRtsStatus != -1 )
	{
		m_mDatTextBox[ TB_MAIN_RESPONSE_STATUS].show( "     (%d) - %s", nRtsStatus, getRtsStr(nRtsStatus) );
	}

//	wmove( m_pDataWin, TB_MAIN_CHANNEL_ID_DAT_Y, TB_MAIN_CHANNEL_ID_DAT_X );
}

bool ScreenMain::validate()
{
	int nLen = m_mInput[ m_nInputFieldIndex].length();
	int nMaxLen = 0;

	switch ( m_nInputFieldIndex )
	{
		case TB_MAIN_CHANNEL_ID:
			{
				nMaxLen = 3;
				break;
			}

		case TB_MAIN_BEG_SEQNUM:
			{
				nMaxLen = 9;
				break;
			}

		case TB_MAIN_END_SEQNUM:
			{
				nMaxLen = 9;
				break;
			}
	}

	return (nLen < nMaxLen);
}

void ScreenMain::sendRtsRequest()
{
	int nChannelId = atoi( m_mInput[ TB_MAIN_CHANNEL_ID].c_str() );
	int nBegSeqNum = atoi( m_mInput[ TB_MAIN_BEG_SEQNUM].c_str() );
	int nEndSeqNum = atoi( m_mInput[ TB_MAIN_END_SEQNUM].c_str() );

	if ( ClientTool::inst()->setCTRequest( true, CT_RETRANSMISSION_REQUEST, PT_NONE, nChannelId, nBegSeqNum, nEndSeqNum ) )
	{
		m_mDatTextBox[ TB_MAIN_RESPONSE_STATUS].show( "     Waiting for RTS response - channel|%d| seqeunce number|%d to %d|", nChannelId, nBegSeqNum, nEndSeqNum );
	}
	else
	{
		m_mDatTextBox[ TB_MAIN_RESPONSE_STATUS].showSpecial( ALIGN_LEFT, GUI_YELLOW, false, "     Failed to send RTS request - please confirm the CT server is running" );
	}
}

void ScreenMain::handleUserInput( int c )
{
	switch ( c )
	{
		case 0x09:	//TAB
		case KEY_UP:
		case KEY_DOWN:
			{
				handleArrowKey( c );
				break;
			}

		case 7:
		case 127:
		case 263:
			{
				handleBackSpace( c );
				break;
			}

		case 'Y':
		case 'y':
			{
				switch ( m_nInputFieldIndex )
				{
					case TB_MAIN_SEND:
						{
							sendRtsRequest();
							break;
						}
				}
				break;
			}
		case 0x30:
		case 0x31:
		case 0x32:
		case 0x33:
		case 0x34:
		case 0x35:
		case 0x36:
		case 0x37:
		case 0x38:
		case 0x39:
			{
				switch ( m_nInputFieldIndex )
				{
					case TB_MAIN_CHANNEL_ID:
					case TB_MAIN_BEG_SEQNUM:
					case TB_MAIN_END_SEQNUM:
						{
							if ( validate() )
							{
								m_mInput[ m_nInputFieldIndex] += c;
							}
							break;
						}
				}

				break;
			}

		default:
			{
				return;
			}
	}

	m_mDatTextBox[ m_nInputFieldIndex].showSpecial( ALIGN_RIGHT, GUI_WHITE, true,  m_mInput[ m_nInputFieldIndex].c_str() );
}

bool ScreenMain::handleBackSpace( int c )
{
	deleteChar( m_mInput[ m_nInputFieldIndex] );

	return true;
}

bool ScreenMain::deleteChar( string& sStr )
{
	if ( sStr.length() > 0 )
	{
		sStr.erase( sStr.length()-1, 1 );
	}

	return true;
}

bool ScreenMain::handleArrowKey( int c )
{
	switch ( c )
	{
		case KEY_UP:
			{
				if ( m_nInputFieldIndex > TB_MAIN_CHANNEL_ID )
				{
					m_mDatTextBox[ m_nInputFieldIndex].show( m_mInput[ m_nInputFieldIndex].c_str() );
					m_nInputFieldIndex--;
					m_mDatTextBox[ m_nInputFieldIndex].showSpecial( ALIGN_RIGHT, GUI_WHITE, true,  m_mInput[ m_nInputFieldIndex].c_str() );
				}
				else
				{
					m_mDatTextBox[ m_nInputFieldIndex].show( m_mInput[ m_nInputFieldIndex].c_str() );
					m_nInputFieldIndex = NO_OF_HDR_ITEM;
					m_mDatTextBox[ m_nInputFieldIndex].showSpecial( ALIGN_RIGHT, GUI_WHITE, true,  m_mInput[ m_nInputFieldIndex].c_str() );
				}

				break;
			}

		case 0x09:	// TAB
		case KEY_DOWN:
			{
				if ( m_nInputFieldIndex < NO_OF_HDR_ITEM )
				{
					m_mDatTextBox[ m_nInputFieldIndex].show( m_mInput[ m_nInputFieldIndex].c_str() );
					m_nInputFieldIndex++;
					m_mDatTextBox[ m_nInputFieldIndex].showSpecial( ALIGN_RIGHT, GUI_WHITE, true,  m_mInput[ m_nInputFieldIndex].c_str() );
				}
				else
				{
					m_mDatTextBox[ m_nInputFieldIndex].show( m_mInput[ m_nInputFieldIndex].c_str() );
					m_nInputFieldIndex = TB_MAIN_CHANNEL_ID;
					m_mDatTextBox[ m_nInputFieldIndex].showSpecial( ALIGN_RIGHT, GUI_WHITE, true,  m_mInput[ m_nInputFieldIndex].c_str() );
				}
				break;
			}
	}

	return true;
}

