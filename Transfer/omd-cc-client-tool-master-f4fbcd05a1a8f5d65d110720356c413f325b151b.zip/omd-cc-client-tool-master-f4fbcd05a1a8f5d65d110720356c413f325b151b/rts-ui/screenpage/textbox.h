#ifndef _TEXT_BOX_H
#define _TEXT_BOX_H

#include <menu.h>
#include <string>

#include "include/constant.h"
#include "std/stdmutex.h"

using namespace std;

class TextBox
{ 
	public:
		TextBox();
		TextBox( WINDOW* pWin, int LEN, int x, int y );

		~TextBox();

		bool init( WINDOW* pWin, int LEN, int x, int y );
		bool show();
		bool showSpecial( int nAlign, int nColor, bool bHightlight, const char* pFmt, ... );
		bool show( const char* pFmt, ... );
		int getX();
		int getY();
		const char* getText();
		void setX( int x );
		void setY( int y );
		void setText( const char* s );
		void addChar( char c );

	protected:
		bool padSpace( const char* sInStr, char* sOutStr, int nFieldLen, int nAlign=ALIGN_LEFT );

	protected:
		WINDOW *m_pWin;
		int m_LEN;
		int m_x;
		int m_y;
		string m_sText;
		int m_nAlign;
		int m_nColor;
		bool m_bHighlight;

		static STDMutex m_gTextBoxMutex;
};

#endif

