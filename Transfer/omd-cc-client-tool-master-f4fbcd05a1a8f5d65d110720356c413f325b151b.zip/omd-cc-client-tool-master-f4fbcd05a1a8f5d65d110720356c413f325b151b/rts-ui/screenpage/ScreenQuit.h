#ifndef ScreenQuitH
#define ScreenQuitH 1

#include "ScreenPage.h"

using namespace std;

class ScreenQuit : public ScreenPage
{
	public:
		ScreenQuit();
		~ScreenQuit();

		virtual void refreshScr();
		bool userInput( int c );

        protected:
                virtual bool buildTextBox();

	protected:
		int m_nState;
};

#endif
