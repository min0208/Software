#include "ScreenPage.h"

ScreenPage::ScreenPage()
{
}

ScreenPage::~ScreenPage()
{
}

bool ScreenPage::init()
{
        buildWindow();
	onInit();	
	buildTextBox();	
	wrefresh( m_pDataWin );

	return true;
}

bool ScreenPage::onInit()
{
	return true;
}

bool ScreenPage::buildTextBox()
{
	return true;
}

bool ScreenPage::buildWindow()
{
	m_pDataWin = newwin( LINES-DATA_WIN_Y_OFFSET, COLS-2, DATA_WIN_TOP, 1 );

	keypad( m_pDataWin, TRUE );

	return true;
}

bool ScreenPage::clearScr()
{
	STDMutexLocker oLocker(m_oMutex);

	wclear( m_pDataWin );

	return true;
}

bool ScreenPage::redraw()
{
	redrawWindow();
	onRedraw();
	redrawTextBox();
	wrefresh( m_pDataWin );
	onRefresh();

	return true;
}

bool ScreenPage::redrawWindow()
{
	STDMutexLocker oLocker(m_oMutex);

	wclear( m_pDataWin );
	wresize( m_pDataWin, LINES-DATA_WIN_Y_OFFSET, COLS-2 );

	return true;
}

bool ScreenPage::redrawTextBox()
{
	STDMutexLocker oLocker(m_oMutex);

	//////////////////////////////
	// redraw data
	//
	map<int,TextBox>::iterator oItr = m_mDatTextBox.begin();

	while ( oItr != m_mDatTextBox.end() )
	{
		oItr->second.show();
		oItr++;
	};

	oItr = m_mHdrTextBox.begin();

	while ( oItr != m_mHdrTextBox.end() )
	{
		oItr->second.show();
		oItr++;
	};

	return true;
}

int ScreenPage::priceColor( int nInput, int nPrevious )
{
	if ( nInput == 0 )              return GUI_WHITE;
	if ( nInput > nPrevious )       return GUI_GREEN;
	if ( nInput < nPrevious )       return GUI_RED;

	return GUI_WHITE;
}

