#ifndef IMAGE_CONTROL_H
#define IMAGE_CONTROL_H

#include "datamodules/security.h"
#include "datamodules/market.h"
#include "datamodules/currency.h"
#include "datamodules/news.h"
#include "datamodules/mcchannel.h"
#include "datamodules/ctstatus.h"

using namespace std;

class ImageControl
{
	public:
		typedef map<string,News>	NEWS_MAP;
		typedef map<string,NEWS_MAP>	NEWS_TYPE_MAP;
		typedef map<int,Security>	SECURITY_MAP;
		typedef map<string,Currency>	CURRENCY_MAP;
		typedef map<string,Market>	MARKET_MAP;
		typedef map<string,MCChannel>	MC_CHANNEL_MAP;

	public:
		ImageControl();
		~ImageControl();

		static ImageControl* inst();

		bool resetData();
		void resetSecurity( int nSecCode );
		void resetMarket();
		void resetCurrency();
		void resetNews();

		void setRtsStatus( int nStatus );

		//////////////////////////
		// Market
		//
		bool getMarket( MARKET_MAP& mData );
		bool getMarket( const char* sMarketCode, Market& oData );
		bool getMarketTurnover( const char* sMarketCode, Market::MKT_TURNOVER_MAP& mDataMap );

		//////////////////////////
		// News
		//
		bool getNews( const char* sNewsType, NEWS_MAP& mData );

		//////////////////////////
		// Currency
		//
		bool getCurrency( CURRENCY_MAP& mData );

		int getRtsStatus();

		//////////////////////////
		// Security
		//
		void setBidBrokerQueue( BrokerQueue& oData );
		void setAskBrokerQueue( BrokerQueue& oData );
		void setData( SecurityDef& oData );
		void setData( SecurityStatus& oData );
		void setData( IEP& oData );
		void setData( TradeTicker& oData );
		void setData( LiquidityProvider& oData );
		void setData( Yield& oData );
		void setData( AggregateOBU& oData );
		void setData( Nominal& oData );
		void setData( ClosingPrice& oData );
		void setData( Statistics& oData );
		void setData( VCMTrigger& oData );
		void setData( ReferencePrice& oData );
		void setData( OrderImbalance& oData );

		//////////////////////////////////////////
		// Get the latest N trade
		// if nNoOfTrade = 0, it means ALL
		//
		int getSecInstrumentType( int nSecCode );
		int getSecNominalPrice( int nSecCode );
		int getSecClosingPrice( int nSecCode );
		string getSecSpreadTableCode( int nSecCode );
		int getSecBidPrice( int nSecCode );
		int getSecAskPrice( int nSecCode );
		bool getSecBidQ( int nSecCode, list<AggregateOBU::ORDER>& oOrderQ );
		bool getSecAskQ( int nSecCode, list<AggregateOBU::ORDER>& oOrderQ );
		bool getSecBQBid( int nSecCode, BrokerQueue& oBQ );
		bool getSecBQAsk( int nSecCode, BrokerQueue& oBQ );
		bool getSecTradeTicker( int nSecCode, int nNoOfTrade, vector<TradeTicker>& vData );
		bool getSecurityDef( int nSecCode, SecurityDef& oData );
		bool getSecClosing( int nSecCode, ClosingPrice& oData );
		bool getSecLiquidityProvider( int nSecCode, LiquidityProvider& oData );
		bool getSecIEP( int nSecCode, IEP& oData );
		bool getSecSecurityStatus( int nSecCode, SecurityStatus& oData );
		bool getSecStatistics( int nSecCode, Statistics& oData );
		bool getSecYield( int nSecCode, Yield& oData );
		bool getSecNominal( int nSecCode, Nominal& oData );
		int getSecPrevClosingPrice( int nSecCode );
		int getSecHighPrice( int nSecCode );
		int getSecLowPrice( int nSecCode );
		int getSecLastPrice( int nSecCode );
		bool getSecReferencePrice( int nSecCode, ReferencePrice& oData );
		bool getSecOrderImbalance( int nSecCode, OrderImbalance& oData );
		bool getSecVCMTrigger( int nSecCode, VCMTrigger& oData );
		bool getOI( int nSecCode, OrderImbalance& oData );

		//////////////////////////
		// Market Data
		//
		void setData( MarketDef& oData );
		void setData( MarketTurnover& oData );
		void setData( TradingSessionStatus& oData );

		//////////////////////////
		// Currency Data
		//
		void setData( CurrencyRate& oData );

		//////////////////////////
		// News
		//
		void setData( News& oData );

		//////////////////////////
		// MC Channel
		//
		void setData( MCStatus& oData );
		bool getMCChannel( MC_CHANNEL_MAP& mData );

		//////////////////////////
		// CT Server Status
		//
		void setData( CTStatus& oData );
		int getCTSvrStatus();

	protected:

		STDMutex m_oMutex;

		static ImageControl* m_pImageControl;

		//////////////////////////
		// Security
		//
		SECURITY_MAP m_mSecurity;

		//////////////////////////
		// Market
		//
		MARKET_MAP m_mMarket;

		//////////////////////////
		// Currency
		//
		CURRENCY_MAP m_mCurrency;

		//////////////////////////
		// News
		//
		NEWS_TYPE_MAP m_mNewsType;

		//////////////////////////
		// Multicast Channel
		//
		MC_CHANNEL_MAP m_mMCChannel;

		int m_nCTSvrStatus;
		int m_nRtsStatus;
};

#endif

