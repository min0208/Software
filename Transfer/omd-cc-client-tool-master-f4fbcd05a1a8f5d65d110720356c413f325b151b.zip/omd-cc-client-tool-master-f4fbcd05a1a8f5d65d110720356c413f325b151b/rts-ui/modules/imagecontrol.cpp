#include "modules/imagecontrol.h"
#include "main.h"

#include "std/stdmutexlocker.h"
#include "std/stdutil.h"

#define LOGC "|ImageCon| "

ImageControl* ImageControl::m_pImageControl = NULL;

ImageControl::ImageControl() :
	m_nCTSvrStatus(CTStatus::DISCONNECT),
	m_nRtsStatus(-1)
{
}

ImageControl::~ImageControl()
{
}

void ImageControl::setBidBrokerQueue( BrokerQueue& oData )
{
    int nSecCode = oData.getSecCode();

    m_mSecurity[ nSecCode].setBidBrokerQueue( oData );
}

void ImageControl::setAskBrokerQueue( BrokerQueue& oData )
{
    int nSecCode = oData.getSecCode();

    m_mSecurity[ nSecCode].setAskBrokerQueue( oData );
}

void ImageControl::setRtsStatus( int nStatus )
{
	m_nRtsStatus = nStatus;
}

void ImageControl::setData( CTStatus& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_nCTSvrStatus = oData.getStatus();

	if ( m_nCTSvrStatus == CTStatus::DISCONNECT )
	{
		m_mMCChannel.clear();
	}
}

void ImageControl::setData( MCStatus& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	string sChannelNum = oData.getChannelNum();
	m_mMCChannel[ sChannelNum.c_str()].setData( oData );
}

void ImageControl::setData( CurrencyRate& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	string sCurrencyCode = oData.getCurrencyCode();
	m_mCurrency[ sCurrencyCode.c_str()].setData( oData );
}

void ImageControl::setData( TradeTicker& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	int nSecCode = oData.getSecCode();
	m_mSecurity[ nSecCode].setData( oData );
}

void ImageControl::setData( Statistics& oData )
{
        STDMutexLocker oLocker(m_oMutex);

        int nSecCode = oData.getSecCode();
        m_mSecurity[ nSecCode].setData( oData );
}

void ImageControl::setData( AggregateOBU& oData )
{
        STDMutexLocker oLocker(m_oMutex);

        int nSecCode = oData.getSecCode();
        m_mSecurity[ nSecCode].setData( oData );
}

void ImageControl::setData( ClosingPrice& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	int nSecCode = oData.getSecCode();
	m_mSecurity[ nSecCode].setData( oData );
}

void ImageControl::setData( Nominal& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	int nSecCode = oData.getSecCode();
	m_mSecurity[ nSecCode].setData( oData );
}

void ImageControl::setData( MarketTurnover& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	string sMarketCode = oData.getMarketCode();

	m_mMarket[ sMarketCode].setData( oData );
}

void ImageControl::setData( MarketDef& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	string sMarketCode = oData.getMarketCode();

	m_mMarket[ sMarketCode].setData( oData );
}

void ImageControl::setData( TradingSessionStatus& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	string sMarketCode = oData.getMarketCode();

	m_mMarket[ sMarketCode].setData( oData );
}

void ImageControl::setData( SecurityStatus& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	int nSecCode = oData.getSecCode();
	m_mSecurity[ nSecCode].setData( oData );
}

void ImageControl::setData( SecurityDef& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	int nSecCode = oData.getSecCode();
	m_mSecurity[ nSecCode].setData( oData );
}

void ImageControl::setData( IEP& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	int nSecCode = oData.getSecCode();
	m_mSecurity[ nSecCode].setData( oData );
}

void ImageControl::setData( Yield& oData )
{
        STDMutexLocker oLocker(m_oMutex);

        int nSecCode = oData.getSecCode();
        m_mSecurity[ nSecCode].setData( oData );
}

void ImageControl::setData( VCMTrigger& oData )
{
        STDMutexLocker oLocker(m_oMutex);

        int nSecCode = oData.getSecCode();
        m_mSecurity[ nSecCode].setData( oData );
}

void ImageControl::setData( OrderImbalance& oData )
{
        STDMutexLocker oLocker(m_oMutex);

        int nSecCode = oData.getSecCode();
        m_mSecurity[ nSecCode].setData( oData );
}

void ImageControl::setData( ReferencePrice& oData )
{
        STDMutexLocker oLocker(m_oMutex);

        int nSecCode = oData.getSecCode();
        m_mSecurity[ nSecCode].setData( oData );
}

void ImageControl::setData( News& oData )
{
        STDMutexLocker oLocker(m_oMutex);

        string sNewsType = oData.getNewsType();
        string sNewsId = oData.getNewsId();

	NEWS_MAP& mNews = m_mNewsType[ sNewsType];

	mNews[ sNewsId].setData( oData );
}

void ImageControl::setData( LiquidityProvider& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	int nSecCode = oData.getSecCode();
	m_mSecurity[ nSecCode].setData( oData );
}

bool ImageControl::getNews( const char* sNewsType, NEWS_MAP& mData )
{
	STDMutexLocker oLocker(m_oMutex);

	mData = m_mNewsType[ sNewsType];

	return true;
}

int ImageControl::getSecHighPrice( int nSecCode )
{
	STDMutexLocker oLocker(m_oMutex);

	return m_mSecurity[ nSecCode].getHighPrice();
}

int ImageControl::getSecNominalPrice( int nSecCode )
{
	STDMutexLocker oLocker(m_oMutex);

	return m_mSecurity[ nSecCode].getNominalPrice();
}

int ImageControl::getSecLastPrice( int nSecCode )
{
	STDMutexLocker oLocker(m_oMutex);

	return m_mSecurity[ nSecCode].getLastPrice();
}

int ImageControl::getSecLowPrice( int nSecCode )
{
	STDMutexLocker oLocker(m_oMutex);

	return m_mSecurity[ nSecCode].getLowPrice();
}

int ImageControl::getSecPrevClosingPrice( int nSecCode )
{
	STDMutexLocker oLocker(m_oMutex);

	return m_mSecurity[ nSecCode].getPrevClosingPrice();
}

int ImageControl::getCTSvrStatus()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_nCTSvrStatus;
}

bool ImageControl::getMarket( MARKET_MAP& mData )
{
	STDMutexLocker oLocker(m_oMutex);

	mData = m_mMarket;

	return true;
}

bool ImageControl::getMarket( const char* sMarketCode, Market& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	MARKET_MAP::iterator oItr = m_mMarket.find( sMarketCode );

	if ( oItr == m_mMarket.end() )	return false;

	oData = oItr->second;

	return true;
}

bool ImageControl::getMCChannel( MC_CHANNEL_MAP& mData )
{
	STDMutexLocker oLocker(m_oMutex);

	mData = m_mMCChannel;

	return true;
}

bool ImageControl::getCurrency( CURRENCY_MAP& mData )
{
	STDMutexLocker oLocker(m_oMutex);

	mData = m_mCurrency;

	return true;
}

void ImageControl::resetNews()
{
	STDMutexLocker oLocker(m_oMutex);

	m_mNewsType.clear();
}

void ImageControl::resetCurrency()
{
	STDMutexLocker oLocker(m_oMutex);

	m_mCurrency.clear();
}

void ImageControl::resetMarket()
{
	STDMutexLocker oLocker(m_oMutex);

	m_mMarket.clear();
}

void ImageControl::resetSecurity( int nSecCode )
{
	STDMutexLocker oLocker(m_oMutex);

	m_mSecurity[ nSecCode].reset();
}

bool ImageControl::resetData()
{
	STDMutexLocker oLocker(m_oMutex);

	m_mCurrency.clear();
	m_mSecurity.clear();
	m_mMarket.clear();

	NEWS_TYPE_MAP::iterator oItr = m_mNewsType.begin();

	while ( oItr != m_mNewsType.end() )
	{
		oItr->second.clear();
		oItr++;
	};

	m_mNewsType.clear();

	return true;
}

ImageControl* ImageControl::inst()
{
	if ( m_pImageControl == NULL )
	{
		m_pImageControl = new ImageControl;
	}

	return m_pImageControl;
}

bool ImageControl::getSecSecurityStatus( int nSecCode, SecurityStatus& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	oData = m_mSecurity[ nSecCode].getSecurityStatus();

	return true;
}

bool ImageControl::getSecStatistics( int nSecCode, Statistics& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	oData = m_mSecurity[ nSecCode].getStatistics();

	return true;
}

bool ImageControl::getSecYield( int nSecCode, Yield& oData )
{
        STDMutexLocker oLocker(m_oMutex);

	oData = m_mSecurity[ nSecCode].getYield();

	return true;
}

bool ImageControl::getSecVCMTrigger( int nSecCode, VCMTrigger& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	if ( !m_mSecurity[ nSecCode].isVCM() )
	{
		return false;
	}

	oData = m_mSecurity[ nSecCode].getVCMTrigger();

	return true;
}

bool ImageControl::getSecNominal( int nSecCode, Nominal& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	oData = m_mSecurity[ nSecCode].getNominal();

	return true;
}

bool ImageControl::getSecIEP( int nSecCode, IEP& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	oData = m_mSecurity[ nSecCode].getIEP();

	return true;
}

bool ImageControl::getSecTradeTicker( int nSecCode, int nNoOfTrade, vector<TradeTicker>& vData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_mSecurity[ nSecCode].getTradeTicker( nNoOfTrade, vData );

	return true;
}

bool ImageControl::getSecurityDef( int nSecCode, SecurityDef& oData )
{
	STDMutexLocker oLocker(m_oMutex);
	oData = m_mSecurity[ nSecCode].getSecurityDef();
	return true;
}

string ImageControl::getSecSpreadTableCode( int nSecCode )
{
	STDMutexLocker oLocker(m_oMutex);

	return m_mSecurity[ nSecCode].getSpreadTableCode();
}

int ImageControl::getSecBidPrice( int nSecCode )
{
	STDMutexLocker oLocker(m_oMutex);

	return m_mSecurity[ nSecCode].getBidPrice();
}

int ImageControl::getSecAskPrice( int nSecCode )
{
	STDMutexLocker oLocker(m_oMutex);

	return m_mSecurity[ nSecCode].getAskPrice();
}

bool ImageControl::getSecBQBid( int nSecCode, BrokerQueue& oBQ )
{
	STDMutexLocker oLocker(m_oMutex);

	return m_mSecurity[ nSecCode].getBQBid( oBQ );
}

bool ImageControl::getSecBQAsk( int nSecCode, BrokerQueue& oBQ )
{
	STDMutexLocker oLocker(m_oMutex);

	return m_mSecurity[ nSecCode].getBQAsk( oBQ );
}

bool ImageControl::getSecBidQ( int nSecCode, list<AggregateOBU::ORDER>& oOrderQ )
{
	STDMutexLocker oLocker(m_oMutex);

	return m_mSecurity[ nSecCode].getBidQ( oOrderQ );
}

bool ImageControl::getSecAskQ( int nSecCode, list<AggregateOBU::ORDER>& oOrderQ )
{
	STDMutexLocker oLocker(m_oMutex);

	return m_mSecurity[ nSecCode].getAskQ( oOrderQ );
}

bool ImageControl::getSecReferencePrice( int nSecCode, ReferencePrice& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	if ( !m_mSecurity[ nSecCode].isRefPrice() )
	{
		return false;
	}

	oData = m_mSecurity[ nSecCode].getReferencePrice();
	return true;
}

bool ImageControl::getSecOrderImbalance( int nSecCode, OrderImbalance& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	if ( !m_mSecurity[ nSecCode].isOI() )
	{
		return false;
	}

	oData = m_mSecurity[ nSecCode].getOrderImbalance();
	return true;
}

bool ImageControl::getSecClosing( int nSecCode, ClosingPrice& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	if ( !m_mSecurity[ nSecCode].isClosed() )
	{
		return false;
	}

	oData = m_mSecurity[ nSecCode].getClosing();

	return true;
}

bool ImageControl::getSecLiquidityProvider( int nSecCode, LiquidityProvider& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	oData = m_mSecurity[ nSecCode].getLiquidityProvider();

	return true;
}

int ImageControl::getSecInstrumentType( int nSecCode )
{
	STDMutexLocker oLocker(m_oMutex);

	return m_mSecurity[ nSecCode].getInstrumentType();
}

int ImageControl::getSecClosingPrice( int nSecCode )
{
	STDMutexLocker oLocker(m_oMutex);

	return m_mSecurity[ nSecCode].getClosingPrice();
}

bool ImageControl::getMarketTurnover( const char* sMarketCode, Market::MKT_TURNOVER_MAP& mDataMap )
{
	STDMutexLocker oLocker(m_oMutex);

	return m_mMarket[ sMarketCode].getMarketTurnover( mDataMap );
}

int ImageControl::getRtsStatus()
{
	return m_nRtsStatus;
}

