#ifndef _CT_SVR_CONNECTOR_H
#define _CT_SVR_CONNECTOR_H

#include "std/stdtcpclient.h"
#include "std/stdtimer.h"
#include "modules/msghandler.h"

using namespace std;
using namespace MSG_HANDLER;

class CTSvrConnector : public STDTCPClient //, public STDTimer 
{
	public:
		enum MODE
		{
			REALTIME = 1,
			REFRESH
		};

		enum STATUS
		{
			CONNECT,
			DISCONNECT
		};

	public:
		CTSvrConnector( MsgHandler* pMsgHandler, const char* sRemoteIP, int nRemotePort, const char* sLocalIP, int nLocalPort, int nHeartBeatInterval, int nIdleTimeout, int nReconnectAfterSec, int nRequestTime );
		~CTSvrConnector();

		int getState(); 

		bool setRequest( bool bOneOffRequest, int nInfoType, int nProductType, int nArg0, int nArg1, int nArg2, int nArg3 );
		void recvResponse( int nResponseCode );

	protected:
		virtual void onAppTimer( int nLineFD, short nEvent );
		virtual void onReceive( const char* pData, unsigned int nDataSize );
		virtual void onConnected( struct bufferevent* pEvent, void *pPtr );
		virtual void onClose( struct bufferevent* pEvent, void *pPtr );

		bool processMsg( const char* pMsg, unsigned int nMsgSize );

	protected:
		int m_nState;
		int m_nInfoType;
		int m_nProductType;
		int m_nArg0, m_nArg1, m_nArg2, m_nArg3;
		char m_aRcvBuf[ STD_TCP_BUF_SIZE];
		unsigned int m_nRcvDataSize;
		MsgHandler* m_pMsgHandler;

		int m_nRequestAttempt;
		bool m_bRequesting;
		bool m_bBlockRequest;
		bool m_bOneOffRequest;
		bool m_bRunning;

		STDMutex m_oRequestMutex;
};

#endif

