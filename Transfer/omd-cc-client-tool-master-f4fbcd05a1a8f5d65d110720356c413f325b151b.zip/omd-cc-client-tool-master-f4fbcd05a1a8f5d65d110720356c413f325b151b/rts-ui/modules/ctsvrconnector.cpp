//////////////////////////////////////////////////////////////////////////////////
//// Date	Ver	Name	Description
//// 20120430	r1	RC	Initial revision
//////////////////////////////////////////////////////////////////////////////////

#include "modules/ctsvrconnector.h"
#include "include/common/XdpStructs.h"
#include "include/common/ClientToolStructs.h"
#include "modules/imagecontrol.h"

#include "main.h"

#define LOGC "|CTSvrCon| "

CTSvrConnector::CTSvrConnector( MsgHandler* pMsgHandler, const char* sRemoteIP, int nRemotePort, const char* sLocalIP, int nLocalPort, int nHeartBeatInterval, int nIdleTimeout, int nReconnectAfterSec, int nSnapshotRequestTime ) : 
	STDTCPClient( 0, sLocalIP, nLocalPort, sRemoteIP, nRemotePort, nHeartBeatInterval, nIdleTimeout, nReconnectAfterSec, nSnapshotRequestTime ),
	m_pMsgHandler(pMsgHandler),
	m_nState(DISCONNECT),
	m_nRcvDataSize(0),
	m_nInfoType(CT_RETRANSMISSION_REQUEST),
	m_nProductType(PT_NONE),
	m_nArg0(0),
	m_nArg1(0),
	m_nArg2(0),
	m_nRequestAttempt(0),
	m_bRequesting(false),
	m_bBlockRequest(true),
	m_bOneOffRequest(false),
	m_bRunning(true)
{
}

CTSvrConnector::~CTSvrConnector()
{
	STDGetLogger()->log( STDLOG_L3, LOGC "~CTSvrConnector()" );

	m_bRunning = false;

        if ( m_pMsgHandler )
        {
                delete m_pMsgHandler;
                m_pMsgHandler = NULL;
        }
}

void CTSvrConnector::recvResponse( int nResponseCode )
{
	STDGetLogger()->log( STDLOG_L7, LOGC "recv response|%d|", nResponseCode );
	m_bRequesting = false;
}

bool CTSvrConnector::setRequest( bool bOneOffRequest, int nInfoType, int nProductType, int nArg0, int nArg1, int nArg2, int nArg3 )
{
	STDMutexLocker oLocker(m_oRequestMutex);

	switch ( nInfoType )
	{
		case CT_OMDC_SEC_SNAPSHOT_REQUEST:
		case CT_OMDC_MKT_SNAPSHOT_REQUEST:
		case CT_OMDC_NEWS_SNAPSHOT_REQUEST:
		case CT_OMDC_CUR_SNAPSHOT_REQUEST:
		case CT_RETRANSMISSION_REQUEST:
			{
				m_nInfoType = nInfoType;
				break;
			}

		default:
			{
				STDGetLogger()->log( STDLOG_L2, LOGC "invalid CT server request - nInfoType|%d| nProductType|%d| nArg0|%d| nArg1|%d| nArg2|%d| nArg3|%d|", nInfoType, nProductType, nArg0, nArg1, nArg2, nArg3 );
				return false;
			}
	}

	switch ( nProductType )
	{
	case PT_SECURITIES_STANDARD:
	case PT_SECURITIES_PREMIUM:
	case PT_SECURITIES_FULLTICK:
	case PT_INDEX:
	case PT_NONE:
		{
			m_nProductType = nProductType;
			break;
		}
	}

	STDGetLogger()->log( STDLOG_L3, LOGC "setRequest bOneOffRequest|%d| nInfoType|%d| nProductType|%d| nArg0|%d| nArg1|%d| nArg2|%d| nArg3|%d|", bOneOffRequest, nInfoType, nProductType, nArg0, nArg1, nArg2, nArg3 );

	ImageControl::inst()->setRtsStatus( -1 );

	m_bOneOffRequest = bOneOffRequest;
	m_bBlockRequest = false;
	m_nArg0 = nArg0;
	m_nArg1 = nArg1;
	m_nArg2 = nArg2;
	m_nArg3 = nArg3;

	return (m_nState == CONNECT);
}

void CTSvrConnector::onAppTimer( int nLineFD, short nEvent )
{
	static const int MAX_REQUEST_ATTEMPT = 5;

	m_nRequestAttempt++;

	if ( m_nState == CONNECT )
	{
		if ( !m_bBlockRequest )
		{
			if ( !m_bRequesting || (m_nRequestAttempt > MAX_REQUEST_ATTEMPT) )
			{
				m_bBlockRequest = (m_bOneOffRequest)?true:false;
				m_bRequesting = true;
				m_nRequestAttempt = 0;

				switch ( m_nInfoType )
				{
					case CT_OMDC_SEC_SNAPSHOT_REQUEST:
						{
							CTSecSnapShotRequest oRequest;
							memset( &oRequest, NULL, sizeof(oRequest) );
							oRequest.mSize = sizeof(CTSecSnapShotRequest);
							oRequest.mInfoType = m_nInfoType;
							oRequest.mCTType = m_nProductType;
							oRequest.mSecurityCode = m_nArg0;
							oRequest.mTradeStartRecord = m_nArg1;
							oRequest.mTradeCount = m_nArg2;
							oRequest.mOrderCount = m_nArg3;
							STDGetLogger()->log( STDLOG_L7, LOGC "send request|%d| product|%d| seccode|%d| trade start record|%d| trade count|%d| order count|%d|", oRequest.mInfoType, oRequest.mCTType, oRequest.mSecurityCode, oRequest.mTradeStartRecord, oRequest.mTradeCount, oRequest.mOrderCount );
							send( (const char *)&oRequest, oRequest.mSize );

							break;
						}

					case CT_OMDC_MKT_SNAPSHOT_REQUEST:
						{
							CTMktSnapShotRequest oMktRequest;
							memset( &oMktRequest, NULL, sizeof(oMktRequest) );
							oMktRequest.mSize = sizeof(CTMktSnapShotRequest);
							oMktRequest.mInfoType = CT_OMDC_MKT_SNAPSHOT_REQUEST;
							oMktRequest.mCTType = m_nProductType;
							memset( oMktRequest.mMarketCode, 0, sizeof(oMktRequest.mMarketCode) );
							STDGetLogger()->log( STDLOG_L7, LOGC "send request|%d| product|%d|", oMktRequest.mInfoType, oMktRequest.mCTType );
							send( (const char *)&oMktRequest, oMktRequest.mSize );
							break;
						}

					case CT_OMDC_NEWS_SNAPSHOT_REQUEST:
						{
							CTNewsRequest oRequest;
							memset( &oRequest, NULL, sizeof(oRequest) );
							oRequest.mSize = sizeof(CTNewsRequest);
							oRequest.mInfoType = CT_OMDC_NEWS_SNAPSHOT_REQUEST;
							oRequest.mCTType = m_nProductType;
							STDGetLogger()->log( STDLOG_L7, LOGC "send request|%d|", oRequest.mInfoType );
							send( (const char *)&oRequest, oRequest.mSize );
							break;
						}

					case CT_OMDC_CUR_SNAPSHOT_REQUEST:
						{
							CTCurSnapShotRequest oRequest;
							memset( &oRequest, NULL, sizeof(oRequest) );
							oRequest.mSize = sizeof(CTCurSnapShotRequest);
							oRequest.mInfoType = CT_OMDC_CUR_SNAPSHOT_REQUEST;
							oRequest.mCTType = m_nProductType;
							STDGetLogger()->log( STDLOG_L7, LOGC "send request|%d|", oRequest.mInfoType );
							send( (const char *)&oRequest, oRequest.mSize );
							break;
						}

					case CT_RETRANSMISSION_REQUEST:
						{
							ImageControl::inst()->setRtsStatus( -1 );

							CTRetransRequest oRequest;
							memset( &oRequest, NULL, sizeof(oRequest) );
							oRequest.mSize = sizeof(CTRetransRequest);
							oRequest.mInfoType = m_nInfoType;
							oRequest.mCTType = m_nProductType;
							oRequest.mChannelId = m_nArg0;
							oRequest.mBeginSeqNum = m_nArg1;
							oRequest.mEndSeqNum = m_nArg2;
							send( (const char *)&oRequest, oRequest.mSize );

							STDGetLogger()->log( STDLOG_L3, LOGC "send CT request type|%d| channel|%d| seqnum|%d-%d|", m_nInfoType, oRequest.mChannelId, oRequest.mBeginSeqNum, oRequest.mEndSeqNum );
							break;
						}

					default:
						{
							STDGetLogger()->log( STDLOG_L2, LOGC "invalid CT request type|%d|", m_nInfoType );
							break;
						}
				}
			}
			else
			{
				STDGetLogger()->log( STDLOG_L7, LOGC "requesting %d", m_nRequestAttempt );
			}
		}
	}
}

void CTSvrConnector::onConnected( struct bufferevent* pEvent, void *pPtr )
{
	m_nState = CONNECT;

	char* pPacket = new char[ 256];
	char* pOffset = pPacket;

	Xdp::PacketHeader* pPktHdr = (Xdp::PacketHeader*) pOffset;
	pPktHdr->mPktSize = sizeof(Xdp::PacketHeader) + sizeof(Xdp::CTSvrStatus);
	pPktHdr->mMsgCount = 1;
	pOffset += sizeof(Xdp::PacketHeader);

	Xdp::CTSvrStatus* pCTSvrStatus = (Xdp::CTSvrStatus*) pOffset;
	pCTSvrStatus->mMsgSize = sizeof(Xdp::CTSvrStatus);
	pCTSvrStatus->mMsgType = Xdp::CT_SERVER_STATUS_TYPE;
	pCTSvrStatus->mStatus = CONNECT;

	//STDGetLogger()->log( STDLOG_L7, LOGC "post data nMsgSize|%d| CT_SERVER_STATUS_TYPE mStatus|%c| ", pCTSvrStatus->mMsgSize, pCTSvrStatus->mStatus );

	if ( m_bRunning )
		m_pMsgHandler->postData( pPacket );
}

void CTSvrConnector::onClose( struct bufferevent* pEvent, void* pPtr )
{
	m_nState = DISCONNECT;

	char* pPacket = new char[ 256];
	char* pOffset = pPacket;

	Xdp::PacketHeader* pPktHdr = (Xdp::PacketHeader*) pOffset;
	pPktHdr->mPktSize = sizeof(Xdp::PacketHeader) + sizeof(Xdp::CTSvrStatus);
	pPktHdr->mMsgCount = 1;
	pOffset += sizeof(Xdp::PacketHeader);

	Xdp::CTSvrStatus* pCTSvrStatus = (Xdp::CTSvrStatus*) pOffset;
	pCTSvrStatus->mMsgSize = sizeof(Xdp::CTSvrStatus);
	pCTSvrStatus->mMsgType = Xdp::CT_SERVER_STATUS_TYPE;
	pCTSvrStatus->mStatus = DISCONNECT;

	//STDGetLogger()->log( STDLOG_L7, LOGC "post data nMsgSize|%d| CT_SERVER_STATUS_TYPE mStatus|%d| ", pCTSvrStatus->mMsgSize, pCTSvrStatus->mStatus );

	if ( m_bRunning )
		m_pMsgHandler->postData( pPacket );
}

bool CTSvrConnector::processMsg( const char* pMsg, unsigned int nMsgSize )
{
	char* pPacket = new char[ nMsgSize];

	STDGetLogger()->log( STDLOG_L7, LOGC "post data nMsgSize|%d|", nMsgSize );

	memcpy( pPacket, pMsg, nMsgSize );

	if ( m_bRunning )
		m_pMsgHandler->postData( pPacket );

	return true;
}

void CTSvrConnector::onReceive( const char* pData, unsigned int nDataSize )
{
	static const int PKT_LEN_SIZE = 2;

	memcpy( &m_aRcvBuf[ m_nRcvDataSize], pData, nDataSize );
	m_nRcvDataSize += nDataSize;

	while ( m_nRcvDataSize > 0 )	
	{
		///////////////////////
		// packet length
		//
		if ( m_nRcvDataSize < PKT_LEN_SIZE )
		{
			break;
		}

		Xdp::PacketHeader* pPktHdr = (Xdp::PacketHeader*) m_aRcvBuf;

		if ( pPktHdr->mPktSize <= m_nRcvDataSize )
		{
			processMsg( m_aRcvBuf, pPktHdr->mPktSize );

			m_nRcvDataSize -= pPktHdr->mPktSize;
			memmove( m_aRcvBuf, &m_aRcvBuf[ pPktHdr->mPktSize], m_nRcvDataSize );
		}
		else
		{
			break;
		}
	};
}

