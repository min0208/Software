#ifndef SPREAD_TABLE_H
#define SPREAD_TABLE_H

#include <string>
#include <map>
#include <vector>

using namespace std;

class SpreadTable
{
	public:
		SpreadTable();
		~SpreadTable();

		struct SPREAD
		{
			int from;
			int to;
			int spread;
		};

		enum TYPE
		{
			BID,
			ASK
		};

		static SpreadTable* inst();

		bool getSpreadValue( const char* sSpreadTableCode, int nType, int nPrice, int& nSpread );
		bool getSpreadStr( const char* sSpreadTableCode, int nBidPrice, int nAskPrice, string& sOutStr );

		// input price, request # of tick price, BID/ASK 
		bool getTickTable( int nPrice, const char* sSpreadTableCode, int nNoOfTick, int nType, vector<unsigned int>& vTickTable );

	protected:
		bool loadSpreadTable();
		bool buildFullTickTable();
		bool dumpFullTickTable();
		bool search( int nType, vector<SPREAD>::iterator oFirst, vector<SPREAD>::iterator oLast, int nValue, int& nResult );

	protected:

		map< string,vector<SPREAD> > m_mSpreadTable;
		map< string, vector<unsigned int> > m_mFullTickTable;

		static SpreadTable* m_gSpreadTable;
};

#endif

