/////////////////////////////////////////////////////////////////////////////////
//// Date	Ver	Name	Description
//// 20120430	r1	RC	Initial revision
//////////////////////////////////////////////////////////////////////////////////

#include "modules/msghandler.h"
#include "include/common/XdpStructs.h"
#include "include/common/ClientToolStructs.h"

#include "datamodules/ctsecrespond.h"
#include "datamodules/ctrtsrespond.h"
#include "datamodules/ctmktrespond.h"
#include "datamodules/ctnewsrespond.h"
#include "datamodules/ctcurrespond.h"
#include "datamodules/ctstatus.h"
#include "datamodules/mcstatus.h"
#include "datamodules/security.h"
#include "datamodules/market.h"
#include "datamodules/currency.h"
#include "datamodules/news.h"
#include "datamodules/refreshcomplete.h"
#include "std/stdutil.h"
#include "main.h"

#define LOGC "|MsgHandl| "

MsgHandler* MsgHandler::g_pMsgHandler = NULL;

MsgHandler::MsgHandler() :
	m_bQuit(false),
	m_nMsgCnt(0)
{
}

MsgHandler::~MsgHandler()
{
	m_bQuit = true;
	STDGetLogger()->log( STDLOG_L3, LOGC "~MsgHandler()" );
}

void MsgHandler::onMsg()
{
	lockFifo();

	if ( m_oFifo.empty() )
	{
		unlockFifo();
		STDGetLogger()->log( STDLOG_L7, LOGC "empty queue" );
		return;
	}

	char* pPacket = m_oFifo.front();
	m_oFifo.pop_front();
	unlockFifo();

	processMsg( pPacket );

	delete pPacket;
}

MsgHandler* MsgHandler::inst()
{
	if ( !g_pMsgHandler )
	{
		g_pMsgHandler = new MsgHandler;
		g_pMsgHandler->run();
	}

	return g_pMsgHandler;
}

void MsgHandler::processMsg( const char* pPacket )
{
	Xdp::PacketHeader* pPacketHeader = (Xdp::PacketHeader*) pPacket;
	pPacket += Xdp::gPacketHeaderSize;

	for ( unsigned int i=0; i<pPacketHeader->mMsgCount; i++ )
	{
		Xdp::MsgHeader* pMsgHeader = (Xdp::MsgHeader*)pPacket;

		STDGetLogger()->log( STDLOG_L7, LOGC "processMsg mMsgSize|%d| mMsgType|%d|", pMsgHeader->mMsgSize, pMsgHeader->mMsgType );

		switch ( pMsgHeader->mMsgType )
		{
			case CT_RETRANSMISSION_RESPOND:
				{
					CTRtsRespond oCTRtsRespond( (CTRetransRespond*)(pMsgHeader) );
					break;
				}
			case CT_OMDC_NEWS_SNAPSHOT_RESPOND:
				{
					CTSvrNewsRespond oCTNewsRespond( (CTNewsRespond*)(pMsgHeader) );
					break;
				}
			case CT_OMDC_SEC_SNAPSHOT_RESPOND:
				{
					CTSecRespond oCTSecRespond( (CTSecSnapShotRespond*)(pMsgHeader) );
					break;
				}
			case CT_OMDC_CUR_SNAPSHOT_RESPOND:
				{
					CTSvrCurRespond oCTCurRespond( (CTCurSnapShotRespond*)(pMsgHeader) );
					break;
				}
			case CT_OMDC_MKT_SNAPSHOT_RESPOND:
				{
					CTMktRespond oCTMktRespond( (CTMktSnapShotRespond*)(pMsgHeader) );
					break;
				}
			case Xdp::CURRENCY_RATE_TYPE:
				{
					CurrencyRate oData( (Xdp::CurrencyRate*)(pMsgHeader) );
					break;
				}
			case Xdp::YIELD_TYPE:
				{
					Yield oData( (Xdp::Yield*)(pMsgHeader) );
					break;
				}
			case Xdp::LIQUIDITY_PROVIDER_TYPE:
				{
					LiquidityProvider oData( (Xdp::LiquidityProvider*)(pMsgHeader) );
					break;
				}
			case Xdp::ORDER_IMBALANCE_TYPE:
				{
					OrderImbalance oData( (Xdp::OrderImbalance*)(pMsgHeader) );
					break;
				}
			case Xdp::BROKER_QUEUE_TYPE:
				{
					BrokerQueue oData( (Xdp::BrokerQueue*)(pMsgHeader) );
					break;
				}
			case Xdp::TENBBOS_TYPE:
				{
					AggregateOBU oData( (Xdp::TenBBOs*)(pMsgHeader) );
					break;
				}
			case Xdp::SECURITY_STATIC_TYPE:
				{
					SecurityDef oSecurityDef( (Xdp::SecurityStatic*)(pMsgHeader) );
					break;
				}
			case Xdp::SECURITY_STATUS_TYPE:
				{
					SecurityStatus oSecurityStatus( (Xdp::SecurityStatus*)(pMsgHeader) );
					break;
				}
			case Xdp::STATISTICS_TYPE:
				{
					Statistics oStatistics( (Xdp::Statistics*)(pMsgHeader) );
					break;
				}
			case Xdp::TRADING_SESSION_STATUS_TYPE:
				{
					TradingSessionStatus oData( (Xdp::TradingSessionStatus*)(pMsgHeader) );
					break;
				}
			case Xdp::NOMINAL_TYPE:
				{
					Nominal oNominal( (Xdp::Nominal*)(pMsgHeader) );
					break;
				}
			case Xdp::IEP_TYPE:
				{
					IEP oIEP( (Xdp::IEP*)(pMsgHeader) );
					break;
				}
			case Xdp::VCM_TRIGGER_TYPE:
				{
					VCMTrigger oData( (Xdp::VCMTrigger*)(pMsgHeader) );
					break;
				}
			case Xdp::CLOSING_PRICE_TYPE:
				{
					ClosingPrice oData( (Xdp::ClosingPrice*)(pMsgHeader) );
					break;
				}
			case Xdp::MARKET_STATIC_TYPE:
				{
					MarketDef oData( (Xdp::MarketStatic*)(pMsgHeader) );
					break;
				}
			case Xdp::MARKET_TURNOVER_TYPE:
				{
					MarketTurnover oData( (Xdp::MarketTurnover*)(pMsgHeader) );
					break;
				}
			case Xdp::TRADE_TICKER_TYPE:
				{
					TradeTicker oData( (Xdp::TradeTicker*)(pMsgHeader) );
					break;
				}
			case Xdp::REFERENCE_PRICE_TYPE:
				{
					ReferencePrice oData( (Xdp::ReferencePrice*)(pMsgHeader) );
					break;
				}
			case Xdp::NEWS_TYPE:
				{
					News oData( (Xdp::News*)(pMsgHeader) );
					break;
				}
			case Xdp::REFRESH_COMPLETE_TYPE:
				{
					RefreshComplete oData( (Xdp::RefreshComplete*)(pMsgHeader) );
					break;
				}
			case Xdp::CT_SERVER_STATUS_TYPE:
				{
					CTStatus oCTStatus( (Xdp::CTSvrStatus*)(pMsgHeader) );
					break;
				}
			case Xdp::LINE_STATUS_TYPE:
				{
					MCStatus oMCStatus( (Xdp::LineStatus*)(pMsgHeader) );
					break;
				}
			default:
				{
					STDGetLogger()->log( STDLOG_L2, LOGC "unexpected mMsgType|%d|", pMsgHeader->mMsgType );
					break;
				}
		}
		pPacket += pMsgHeader->mMsgSize;
	}
}

int MsgHandler::getMsgCnt()
{
	return m_nMsgCnt;
}

