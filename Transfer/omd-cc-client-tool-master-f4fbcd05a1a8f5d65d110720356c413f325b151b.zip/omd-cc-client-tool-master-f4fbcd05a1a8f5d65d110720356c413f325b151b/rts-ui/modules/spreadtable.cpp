#include "modules/spreadtable.h"
#include "include/constant.h"
#include "std/stdutil.h"
#include "main.h"

#include <iterator>
#include <algorithm>

using namespace std;

#define LOGC "|SpreadTa| "

SpreadTable* SpreadTable::m_gSpreadTable = NULL;

const char MAIN_TABLE[] 	= "01";
const char DEBT_TABLE[] 	= "02";
const char OPTION_TABLE[] 	= "03";
const int FACTOR = 1000;

SpreadTable::SpreadTable()
{
	loadSpreadTable();
	buildFullTickTable();
//	dumpFullTickTable();
}

SpreadTable::~SpreadTable()
{
}

bool SpreadTable::getSpreadValue( const char* sSpreadTableCode, int nType, int nPrice, int& nSpread )
{
	vector<SPREAD>& vSpreadTable = m_mSpreadTable[ sSpreadTableCode];

	return search( nType, vSpreadTable.begin(), vSpreadTable.end(), nPrice, nSpread );
}

SpreadTable* SpreadTable::inst()
{
	if ( m_gSpreadTable == NULL )
	{
		m_gSpreadTable = new SpreadTable;
	}

	return m_gSpreadTable;
}

bool SpreadTable::getTickTable( int nPrice, const char* sSpreadTableCode, int nNoOfTick, int nType, vector<unsigned int>& vTickTable )
{
	map< string, vector<unsigned int> >::iterator oMapItr = m_mFullTickTable.find( sSpreadTableCode );

	if ( oMapItr == m_mFullTickTable.end() )
	{
		//STDGetLogger()->log( STDLOGGER_LEVEL_OPERATION, LOGC "false 1" );
		return false;
	}

	vector<unsigned int>& vFullTickTable = oMapItr->second;
	vector<unsigned int>::iterator oItr = find( vFullTickTable.begin(), vFullTickTable.end(), nPrice );

	if ( oItr == vFullTickTable.end() )
	{
		//STDGetLogger()->log( STDLOGGER_LEVEL_OPERATION, LOGC "false 2" );
		return false;
	}

	if ( nType == BID )
	{
		for ( int i=0; i<nNoOfTick; i++ )
		{
			//STDGetLogger()->log( STDLOGGER_LEVEL_OPERATION, LOGC "add %d", *oItr );
			vTickTable.push_back( *oItr );	

			oItr--;

			if ( oItr < vFullTickTable.begin() )
			{
				break;
			}
		}

		//STDGetLogger()->log( STDLOGGER_LEVEL_OPERATION, LOGC "%d", (int)vTickTable.size() );
	}
	else
	{
		for ( int i=0; i<nNoOfTick; i++ )
		{
			//STDGetLogger()->log( STDLOGGER_LEVEL_OPERATION, LOGC "add %d", *oItr );
			vTickTable.push_back( *oItr );	

			oItr++;

			if ( oItr >= vFullTickTable.end() )
			{
				break;
			}
		}

		//STDGetLogger()->log( STDLOGGER_LEVEL_OPERATION, LOGC "%d", (int)vTickTable.size() );
	}
	
	return true;
}

bool SpreadTable::dumpFullTickTable()
{
	map< string, vector<unsigned int> >::iterator oItr = m_mFullTickTable.begin();

	while ( oItr != m_mFullTickTable.end() )
	{
		//STDGetLogger()->log( STDLOGGER_LEVEL_OPERATION, LOGC "FULL TICK TABLE|%s|", oItr->first.c_str() );

		vector<unsigned int> vFullTickTable = oItr->second;

		for ( unsigned int i=0; i<vFullTickTable.size(); i++ )
		{
			//STDGetLogger()->log( STDLOGGER_LEVEL_OPERATION, LOGC "%d.%03d", vFullTickTable[ i] / 1000, vFullTickTable[ i] % 1000 );
		}

		oItr++;
	}

	return true;
}

bool SpreadTable::buildFullTickTable()
{
	map< string, vector<SPREAD> >::iterator oItr = m_mSpreadTable.begin();

	while ( oItr != m_mSpreadTable.end() )
	{
		vector<unsigned int> vFullTickTable;
		vector<SPREAD>& vSpreadTable = oItr->second;

		for ( unsigned int i=0; i<vSpreadTable.size(); i++ )
		{
			int nPrice = vSpreadTable[ i].from;

			while ( nPrice < vSpreadTable[ i].to )
			{
				nPrice += vSpreadTable[ i].spread;	
				vFullTickTable.push_back( nPrice );
			};
		}

		m_mFullTickTable[ oItr->first] = vFullTickTable;
		oItr++;
	}

	return true;
}

bool SpreadTable::loadSpreadTable()
{
	SPREAD tSpread;
	vector<SPREAD> vSpreadTable;

	tSpread.from = 0.009 * FACTOR;
	tSpread.to = 0.25 * FACTOR;
	tSpread.spread = 0.001 * FACTOR;
	vSpreadTable.push_back( tSpread );

	tSpread.from = 0.25 * FACTOR;
	tSpread.to = 0.50 * FACTOR;
	tSpread.spread = 0.005 * FACTOR;
	vSpreadTable.push_back( tSpread );

	tSpread.from = 0.50 * FACTOR; 
	tSpread.to = 10.00 * FACTOR;
	tSpread.spread = 0.01 * FACTOR;
	vSpreadTable.push_back( tSpread );

	tSpread.from = 10.00 * FACTOR; 
	tSpread.to = 20.00 * FACTOR;
	tSpread.spread = 0.02 * FACTOR;
	vSpreadTable.push_back( tSpread );

	tSpread.from = 20.00 * FACTOR;
	tSpread.to = 100.00 * FACTOR;
	tSpread.spread = 0.05 * FACTOR;
	vSpreadTable.push_back( tSpread );

	tSpread.from = 100.00 * FACTOR;
	tSpread.to = 200.00 * FACTOR;
	tSpread.spread = 0.1 * FACTOR;
	vSpreadTable.push_back( tSpread );

	tSpread.from = 200.00 * FACTOR;
	tSpread.to = 500.00 * FACTOR;
	tSpread.spread = 0.2 * FACTOR;
	vSpreadTable.push_back( tSpread );

	tSpread.from = 500.00 * FACTOR;
	tSpread.to = 1000.00 * FACTOR;
	tSpread.spread = 0.5 * FACTOR;
	vSpreadTable.push_back( tSpread );

	tSpread.from = 1000.00 * FACTOR;
	tSpread.to = 2000.00 * FACTOR;
	tSpread.spread = 1.0 * FACTOR;
	vSpreadTable.push_back( tSpread );

	tSpread.from = 2000.00 * FACTOR;
	tSpread.to = 5000.00 * FACTOR;
	tSpread.spread = 2.0 * FACTOR;
	vSpreadTable.push_back( tSpread );

	tSpread.from = 5000.00 * FACTOR;
	tSpread.to = 9995.00 * FACTOR;
	tSpread.spread = 5.0 * FACTOR;
	vSpreadTable.push_back( tSpread );

	m_mSpreadTable[ MAIN_TABLE] = vSpreadTable; 

	//////////////////////////////
	// Debt Spread Table
	//
	vSpreadTable.clear();
	tSpread.from = 0.45 * FACTOR;
	tSpread.to = 9999.95 * FACTOR;
	tSpread.spread = 0.05 * FACTOR;
	vSpreadTable.push_back( tSpread );

	m_mSpreadTable[ DEBT_TABLE] = vSpreadTable; 

	//////////////////////////////
	// Option Spread Table
	//
	vSpreadTable.clear();
	tSpread.from = 0.45 * FACTOR;
	tSpread.to = 9999.95 * FACTOR;
	tSpread.spread = 0.05 * FACTOR;
	vSpreadTable.push_back( tSpread );

	m_mSpreadTable[ OPTION_TABLE] = vSpreadTable; 

	return true;
}

bool SpreadTable::search( int nType, vector<SPREAD>::iterator oFirst, vector<SPREAD>::iterator oLast, int nValue, int& nResult )
{
	vector<SPREAD>::iterator oItr = oFirst;

	while ( oItr != oLast )
	{
		SPREAD& oSpread = *oItr;

		if  ( nType == ASK )
		{
			if ( nValue >= oSpread.from && nValue < oSpread.to )
			{
				nResult = oSpread.spread;
				return true;
			}
		}
		else
		{
			if ( nValue > oSpread.from && nValue <= oSpread.to )
			{
				nResult = oSpread.spread;
				return true;
			}
		}

		oItr++;	
	}

	nResult = 0.0;

	return false;
}

bool SpreadTable::getSpreadStr( const char* sSpreadTableCode, int nBidPrice, int nAskPrice, string& sOutStr )
{
	char sText[ MAX_TEXT];
	string sBidPrice;
	string sAskPrice;
	int nBidSpread = 0;
	int nAskSpread = 0;

	if ( nBidPrice == 0 )
	{
		sBidPrice = "     ";
	}
	else
	{
		getSpreadValue( sSpreadTableCode, BID, nBidPrice, nBidSpread );
		STDUtil::convertIntToStr( nBidSpread, STDUtil::INTEGER_3_DP, sBidPrice );
	}

	if ( nAskPrice == 0 )
	{
		sAskPrice = "     ";
	}
	else
	{
		getSpreadValue( sSpreadTableCode, ASK, nAskPrice, nAskSpread );
		STDUtil::convertIntToStr( nAskSpread, STDUtil::INTEGER_3_DP, sAskPrice );
	}

	sprintf( sText, "%02s (%s/%s)", sSpreadTableCode, sBidPrice.c_str(), sAskPrice.c_str() );
	sOutStr = sText;
}

