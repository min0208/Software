#ifndef _MSG_HANDLER_H
#define _MSG_HANDLER_H

#include "std/stdqthread.h"

//#include "datamodules/struct.h"

namespace MSG_HANDLER
{
	class MsgHandler : public CQueueThrd <char*>
	{ 
		public:
			MsgHandler();
			~MsgHandler();

			static MsgHandler* inst();
			static MsgHandler* g_pMsgHandler;

			int getMsgCnt();
			/*
			   bool init( key_t nDataQKey, const char* sPath, int nProjectId, int nSequenceResetGracePeriod );


			   protected:
			   bool processSequenceReset();
			   bool processLineStatus( const Msg& tMsg );
			   void setMsg( Msg& tMsg, char* pMsgData, int nMsgSize );

*/

		protected:
			virtual void onMsg();

			void processMsg( const char* pPacket );

			bool m_bQuit;
			int m_nMsgCnt;
	};

}

#endif

