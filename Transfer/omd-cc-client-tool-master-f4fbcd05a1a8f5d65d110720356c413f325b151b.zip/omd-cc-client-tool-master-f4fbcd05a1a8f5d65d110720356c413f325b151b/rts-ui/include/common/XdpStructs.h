// $Id: XdpStructs.h 63886 2012-04-04 16:51:57Z alenug $

#ifndef XdpStructsH
#define XdpStructsH

#include "WombatTypes.h"

namespace Xdp
{
	// === Basic enumerations ====

	// Maximum packet length
	static const w_u32_t MAX_PACKET_LEN = 1500;
	// Maximum message length
	static const w_u32_t MAX_MESSAGE_LEN = 1500;
	// Maximum MaxCacheSize
	static const w_i32_t MAX_CACHE_SIZE = 2000000;
	// Maximum Packet Buffer Size for publishing
	static const w_i32_t MAX_PACKET_BUFFER_SIZE = 10000;
	// Maximum value of SecurityCode
	static const w_u32_t MAX_SECURITY_CODE = 100000;
	// Maximum value of PriceLevel
	static const w_u32_t MAX_PRICE_LEVEL = 10;
	// Maximum type of messages (excluding control messages)
	static const w_u32_t MAX_MESSAGE_TYPE = 100;

	enum StaticFileType
	{
		SECURITY,
		MARKET,
		REGISTERED_TRADER,
		CURRENCY,
		SPREAD_TABLE
	};

	enum XdpMessageTypes
	{
		MARKET_STATIC_TYPE = 10,
		SECURITY_STATIC_TYPE = 11,
		LIQUIDITY_PROVIDER_TYPE = 13,
		CURRENCY_RATE_TYPE = 14,
		SPREAD_TABLE_TYPE = 15,
		TRADING_SESSION_STATUS_TYPE = 20,
		SECURITY_STATUS_TYPE = 21,
		NEWS_TYPE = 22,
		VCM_TRIGGER_TYPE = 23,
		ADD_ORDER_TYPE = 30,
		MODIFY_ORDER_TYPE = 31,
		DELETE_ORDER_TYPE = 32,
		ADD_ODDLOT_ORDER_TYPE = 33,
		DELETE_ODDLOT_ORDER_TYPE = 34,
		NOMINAL_TYPE = 40,
		IEP_TYPE = 41,
		EAS_TYPE = 42,
		REFERENCE_PRICE_TYPE = 43,
		YIELD_TYPE = 44,
		TRADE_TYPE = 50,
		TRADE_CANCEL_TYPE = 51,
		TRADE_TICKER_TYPE = 52,
		TENBBOS_TYPE = 53,
		BROKER_QUEUE_TYPE = 54,
		BBO_TYPE = 55,
		ORDER_IMBALANCE_TYPE = 56,
		STATISTICS_TYPE = 60,
		MARKET_TURNOVER_TYPE = 61,
		CLOSING_PRICE_TYPE = 62,
		INDEX_DEFINITION_TYPE = 70,
		INDEX_DATA_TYPE = 71,
		SEQUENCE_RESET_TYPE = 100,
		LOGON_TYPE = 101,
		LOGON_RESPONSE_TYPE = 102,
		RETRANS_REQUEST_TYPE = 201,
		RETRANS_RESPONSE_TYPE = 202,
		REFRESH_COMPLETE_TYPE = 203,

		CHANGE_MODE_REQUEST_TYPE = 301,
		CHANGE_MODE_RESPONSE_TYPE = 302,
		REFRESH_START_TYPE = 303,
		REFRESH_END_TYPE = 304,
		LINE_STATUS_TYPE = 405,
		CT_SERVER_STATUS_TYPE = 3000,
		END_MSG_TYPE
	};

	enum TradingStatus
	{
		TRADING_HALT = 2,
		RESUME = 3
	};

	enum SessionStatus
	{
		SESSION_ACTIVE    = 0,
		INVALID_USERNAME  = 1,
		USER_ALREADY_CONNECTED = 2
	};

	enum RetransStatus
	{
		REQUEST_ACCEPTED    = 0,
		UNKNOWN_CHANNEL_ID  = 1,
		MESSAGES_NOT_AVAILABLE = 2,
		EXCEEDS_MAXIMUM_SEQUENCE_RANGE = 3,
		EXCEEDS_MAXIMUM_REQUESTS_PER_DAY = 4
	};

	enum InternalStatus
	{
		INTERNAL_OK        = 0,
		INTERNAL_ERROR     = 99,
		ILLEGAL_CONNECTION = 100,
		BAD_CLIENT_BEHAVIOUR = 101,
		ILLEGAL_LENGTH = 102,
		ILLEGAL_MSG_TYPE = 103,
		UNKNOWN_USERID = 104,
		SEQNUM_TOO_SMALL = 105
	};

#pragma pack(1) // prevents compiler padding (structs not aligned).

	// ==== Administration ====

	struct PacketHeader
	{
		w_u16_t mPktSize;
		w_u8_t  mMsgCount;
		w_u8_t  mPossResend;
		w_u32_t mSeqNum;
		w_u64_t mSendTime;
		//w_u32_t mInternalID;
	};
	//const w_size_t gPacketHeaderSize = 20;
	const w_size_t gPacketHeaderSize = 16;

	struct MsgHeader
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		// The item below does not count into the header size
		w_u32_t mSecurityCode;
	};
	const w_size_t gMsgHeaderSize = 4;

	struct SequenceReset
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mNewSeqNo;
	};

	struct Logon
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		char    mUsername[12];
	};
	const w_size_t gMsgLogonSize = 16;

	struct LogonResponse
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u8_t  mSessionStatus;
		char    mFiller[3];
	};
	const w_size_t gMsgLogonResponseSize = 8;

	// ==== Retrans ====

	struct RetransRequest
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u16_t mChannelId;
		char    mFiller[2];
		w_u32_t mBeginSeqNum;
		w_u32_t mEndSeqNum;
	};
	const w_size_t gMsgRetransRequestSize = 16;

	struct RetransResponse
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u16_t mChannelId;
		w_u8_t  mRetransStatus;
		char    mFiller;
		w_u32_t mBeginSeqNum;
		w_u32_t mEndSeqNum;
	};
	const w_size_t gMsgRetransResponseSize = 16;

	// ==== Refresh ====

	struct RefreshComplete
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mLastSeqNum;
	};
	const w_size_t gMsgRefreshCompleteSize = 8;

	// ==== Static ====

	struct MarketStatic
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		char    mMarketCode[4];
		char    mMarketName[25];
		char    mCurrencyCode[3];
		w_u32_t mNumberOfSecurities;
	};

	struct SubMarketStatic
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		char    mSubMarketCode[4];
		char    mSubMarketName[50];
		char    mMarketCode[4];
		char    mFiller[2];
	};

	struct SecurityStaticRepeatGrp
	{
		w_u32_t mUnderlyingSecurityCode;
		w_u32_t mUnderlyingSecurityWeight;
	};

	struct SecurityStatic
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		char    mMarketCode[4];
		char    mISINCode[12];
		char    mInstrumentType[4];
		char	mFiller[2];
		char    mSpreadTableCode[2];
		char    mSecurityShortName[40];
		char    mCurrencyCode[3];
		char    mSecurityNameGCCS[60];
		char    mSecurityNameGB[60];
		w_u32_t mLotSize;
		char	mFiller2[4];
		w_i32_t mPreviousClosingPrice;
		char    mVCMFlag;
		char    mShortSellFlag;
		char    mCASFlag;
		char    mCCASSFlag;
		char    mDummySecurityFlag;
		char    mTestSecurityFlag;
		char    mStampDutyFlag;
		char    mFiller3;
		w_u32_t mListingDate;
		w_u32_t mDelistingDate;
		char    mFreeText[38];
		char	mFiller4[82];
		char    mEFNFlag;
		w_u32_t mAccruedInterest;
		w_u32_t mCouponRate;
		char	mFiller5[42];
		w_u32_t mConversionRatio;
		w_i32_t mStrikePrice;
		char	mFiller6[4];
		w_u32_t mMaturityDate;
		char    mCallPutFlag;
		char    mStyle;
		char	mFiller7[50];
		w_u16_t mNoUnderlyingSecurities;
		SecurityStaticRepeatGrp mSecurityStaticRepeatGrp;
	};

	struct LiquidityProviderRepeatGrp
	{
		w_u16_t mLPBrokerNumber;
	};

	struct LiquidityProvider
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_u16_t mNoLiquidityProviders;
		LiquidityProviderRepeatGrp mLiquidityProviderRepeatGrp;
	};

	struct CurrencyRate
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		char    mCurrencyCode[3];
		char    mFiller;
		w_u16_t mCurrencyFactor;
		char    mFiller2[2];
		w_u32_t mCurrencyRate;
	};

	struct SpreadTableRepeatGrp
	{
		w_u32_t mCeilingPrice;
		w_u32_t mSpreadPrice;
	};

	struct SpreadTable
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		char    mTableID[2];
		char    mFiller[2];
		w_u32_t mFloorPrice;
		char    mFiller2[2];
		w_u16_t mNoEntries;
		SpreadTableRepeatGrp mSpreadTableRepeatGrp;
	};

	// ==== Status and News ====

	struct TradingSessionStatus
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		char    mMarketCode[4];
		w_u8_t  mTradingSessionID;
		w_u8_t  mTradingSessionSubID;
		w_u8_t  mTradingSesStatus;
		char    mTradingSesControlFlag;
		char    mFiller[4];
		w_u64_t mStartTime;
		w_u64_t mEndTime;
	};

	struct SecurityStatus
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_u8_t  mSecurityTradingStatus;
		char    mFiller[3];
	};

	struct MarketCodesRepeatGrp
	{
		char    mMarketCode[4];
	};

	struct SecurityCodesRepeatGrp
	{
		w_u32_t mSecurityCode;
	};

	struct NewsLinesRepeatGrp
	{
		char    mNewsLine[160];
	};

	struct NewsNbMarketCodesSubMsg
	{
		w_u16_t mNoMarketCodes;
	};

	struct NewsNbSecurityCodesSubMsg
	{
		w_u16_t mNoSecurityCodes;
	};

	struct NewsNbNewsLinesSubMsg
	{
		w_u16_t mNoNewsLines;
	};

	struct News
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		char    mNewsType[3];
		char    mNewsID[3];
		char    mHeadline[320];
		char    mCancelFlag;
		char    mLastFragment;
		char    mFiller[4];
		w_u64_t mReleaseTime;
		char    mFiller2[2];
		w_u16_t mNoMarketCodes;
	};

	// ==== Orders ====

	struct AddOrder
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_u64_t mOrderID;
		w_i32_t mPrice;
		w_u32_t mQuantity;
		w_u16_t mSide;
		char    mOrderType;
		char    mFiller2;
		w_i32_t mOrderBookPosition;
		w_u64_t mSendTime;	// added for sending packet header send time to CT P3
	};

	struct ModifyOrder
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_u64_t mOrderID;
		w_u32_t mQuantity;
		w_u16_t mSide;
		char    mOrderType;
		char    mFiller;
		w_i32_t mOrderBookPosition;
		w_u64_t mSendTime;	// added for sending packet header send time to CT P3
	};

	struct DeleteOrder
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_u64_t mOrderID;
		w_u16_t mSide;
		w_u64_t mSendTime;	// added for sending packet header send time to CT P3
	};

	struct AddOddLotOrder
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_u64_t mOrderID;
		w_i32_t mPrice;
		w_u32_t mQuantity;
		w_u16_t mBrokerID;
		w_u16_t mSide;
		w_u64_t mSendTime;	// added for sending packet header send time to CT P3
	};

	struct DeleteOddLotOrder
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_u64_t mOrderID;
		w_u16_t mBrokerID;
		w_u16_t mSide;
		w_u64_t mSendTime;	// added for sending packet header send time to CT P3
	};

	// ==== Trades ====

	struct Trade
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_u32_t mTradeID;
		w_i32_t mPrice;
		w_u32_t mQuantity;
		w_u16_t mTrdType;
		char    mFiller[2];
		w_u64_t mTradeTime;
	};

	struct TradeCancel
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_u32_t mTradeID;
	};

	struct TradeTicker
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_u32_t mTickerID;
		w_i32_t mPrice;
		w_u64_t mAggregateQuantity;
		w_u64_t mTradeTime;
		w_u16_t mTrdType;
		char    mTrdCancelFlag;
		char    mFiller;
	};

	// ==== Quotes ====

	struct TenBBOsRepeatGrp
	{
		w_u64_t mAggregateQuantity;
		w_i32_t mPrice;
		w_u32_t mNumberOfOrders;
		w_u16_t mSide;
		w_u8_t  mPriceLevel;
		w_u8_t  mUpdateAction;
		char    mFiller[4];
	};

	struct TenBBOs
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		char    mFiller[3];
		w_u8_t  mNoEntries;
		TenBBOsRepeatGrp mTenBBOsRepeatGrp;
	};

	struct BBO
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_u64_t mAggregateBidQuantity;
		w_u64_t mAggregateAskQuantity;
		w_i32_t mBidPrice;
		w_i32_t mAskPrice;
		w_u32_t mNumberBidOrders;
		w_u32_t mNumberAskOrders;
		char    mFiller[3];
	};

	struct BrokerQueueRepeatGrp
	{
		w_u16_t mItem;
		char    mType;
		char    mFiller;
	};

	struct BrokerQueue
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_u8_t mItemCount;
		w_u16_t mSide;
		char    mBQMoreFlag;
		BrokerQueueRepeatGrp mBrokerQueueRepeatGrp;
	};

	// ==== Other ====

	struct IEP
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_i32_t mPrice;
		w_u64_t mAggregateQuantity;
	};

	struct Nominal
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_i32_t mNominalPrice;
	};

	struct Yield
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_i32_t mYield;
	};

	struct Statistics
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_u64_t mSharesTraded;
		w_i64_t mTurnover;
		w_i32_t mHighPrice;
		w_i32_t mLowPrice;
		w_i32_t mLastPrice;
		w_i32_t mVWAP;
		w_u32_t mShortSellSharesTraded;
		w_i64_t mShortSellTurnover;
	};

	struct MarketTurnover
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		char    mMarketCode[4];
		char    mCurrencyCode[3];
		char    mFiller;
		w_i64_t mTurnover;
	};

	struct ClosingPrice
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_i32_t mClosingPrice;
		w_u32_t mNumberOfTrades;
	};

	struct EAS
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		w_u32_t mSecurityCode;
		w_i32_t mEASPrice;
	};

	// ==== Index ====

	struct IndexDefinition
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		char    mIndexCode[11];
		char    mIndexSource;
		char    mCurrencyCode[3];
		char    mFiller;
	};

	struct IndexData
	{
		w_u16_t mMsgSize;
		w_u16_t mMsgType;
		char    mIndexCode[11];
		char    mIndexStatus;
		w_u64_t mIndexTime;
		w_i64_t mIndexValue;
		w_i64_t mNetChgPrevDay;
		w_i64_t mIndexHigh;
		w_i64_t mIndexLow;
		w_i64_t mEASValue;
		w_i64_t mIndexTurnover;
		w_i64_t mOpeningValue;
		w_i64_t mClosingValue;
		w_i64_t mPreviousSesClose;
		w_i64_t mIndexVolume;
		w_i32_t mNetChgPrevDayPct;
		char    mException;
		char    mFiller[3];
	};

	struct ChangeModeRequest
	{
		uint16_t mMsgSize;
		uint16_t mMsgType;
		uint8_t  mMode; // 0 = real time, 1 = refresh
		char     mFiller;
	};

	struct ChangeModeResponse
	{
		uint16_t mMsgSize;
		uint16_t mMsgType;
		uint8_t  mMode; // 0 = real time, 1 = refresh
		uint8_t  mStatus; // 0 = success, 1 = fail
	};

	struct RefreshStartEnd
	{
		uint16_t mMsgSize;
		uint16_t mMsgType;
	};

	// VCM
	struct VCMTrigger
	{
		uint16_t mMsgSize;
		uint16_t mMsgType;
		uint32_t mSecurityCode;
		uint64_t mVCMStartTime;
		uint64_t mVCMEndTime;
		int32_t  mVCMRefPrice;
		int32_t  mVCMLowPrice;
		int32_t  mVCMHighPrice;
	};

	// CAS
	struct OrderImbalance
	{
		uint16_t mMsgSize;
		uint16_t mMsgType;
		uint32_t mSecurityCode;
		char	 mOrderImbalanceDir;
		char	 mFiller;
		uint64_t mOrderImbalanceQty;
		char	 mFiller2[2];
	};

	struct ReferencePrice
	{
		uint16_t mMsgSize;
		uint16_t mMsgType;
		uint32_t mSecurityCode;
		int32_t  mReferencePrice;
		int32_t  mReferenceLowPrice;
		int32_t  mReferenceHighPrice;
	};

	struct CTSvrStatus 
	{
		uint16_t mMsgSize;
		uint16_t mMsgType;
		// 0 = CONNECT
		// 1 = DISCONNECT
		uint8_t mStatus;
	};

	struct LineStatus 
	{
		uint16_t mMsgSize;
		uint16_t mMsgType;
		uint16_t mChannelID;
		char mLineType; // R=real-time, F=refresh, T=retransmission
		// 3 = both lines are down
		// 2 = one of the lines is up
		// 1 = both lines are up
		uint8_t mStatus;
	};

#pragma pack()

} // namespace Xdp

#endif // XdpStructsH
