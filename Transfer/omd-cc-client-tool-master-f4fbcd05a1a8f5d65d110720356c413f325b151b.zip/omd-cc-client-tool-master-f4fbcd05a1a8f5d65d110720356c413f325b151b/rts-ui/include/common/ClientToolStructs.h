#ifndef ClientToolStructsH
#define ClientToolStructsH

#pragma pack(1) // prevents compiler padding (structs not aligned).

#include "WombatTypes.h"

//***********************************************************
// Message protocal between ClientTool Server and Client
//***********************************************************

// Recognize correct connection between server and client [Client -> Server]
enum CTProductType
{
        PT_NONE = 0,
	PT_SECURITIES_STANDARD = 1,
	PT_SECURITIES_PREMIUM = 2,
	PT_SECURITIES_FULLTICK = 3,
	PT_DERIVATIVES_STANDARD = 4,
	PT_DERIVATIVES_PREMIUM = 5,
	PT_INDEX = 6,
	PT_DERIVATIVES_FULLTICK = 11,
};

// Information types [Client <-> Server]
enum CTInfoType
{
	// change the starting value from 18 to 9000 where the original range 18-25 is clashed with XDP message type
	//CT_SERIES_SEARCH_REQUEST = 18,
	CT_SERIES_SEARCH_REQUEST = 9000,
	CT_SERIES_SEARCH_RESPOND,
	CT_SNAPSHOT_REQUEST,
	CT_SNAPSHOT_RESPOND,
	CT_RETRANSMISSION_REQUEST,
	CT_RETRANSMISSION_RESPOND,
        CT_NEWS_REQUEST,
        CT_NEWS_REQUEST_RESPOND,
        CT_OMDC_SEC_SNAPSHOT_REQUEST,
        CT_OMDC_SEC_SNAPSHOT_RESPOND,
        CT_OMDC_MKT_SNAPSHOT_REQUEST,
        CT_OMDC_MKT_SNAPSHOT_RESPOND,
        CT_OMDC_NEWS_SNAPSHOT_REQUEST,
        CT_OMDC_NEWS_SNAPSHOT_RESPOND,
        CT_OMDC_CUR_SNAPSHOT_REQUEST,
        CT_OMDC_CUR_SNAPSHOT_RESPOND,
        CT_OMDC_IDX_SNAPSHOT_REQUEST,
        CT_OMDC_IDX_SNAPSHOT_RESPOND
};

// Respond code [Server -> Client]
enum CTRespondCode
{
	CT_SUCCESS = 0,
	ERR_NOTFOUND,
	ERR_INVALID_CTTYPE,
        ERR_INVALID_REQUEST,
	//...
};

// Request header [Client -> Server]
struct CTRequestHeader
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
	w_u16_t			mCTType;			//ClientTool Product Type, refer to "enum CTProductType"
};

// Series search criteria [Client -> Server]
struct CTSeriesSearchRequest
{
	//CTRequestHeader	mHeader;
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mCTType;                        //ClientTool Product Type, refer to "enum CTProductType"

	w_u16_t			mCommodityCode;
	w_u8_t			mMarketCode;
	w_u8_t			mInstrumentGroup;
	w_u32_t			mOrderBookID;
	char			mSymbol[32];
};

// Snapshot criteria [Client -> Server]
struct CTSnapShotRequest
{
	//CTRequestHeader	mHeader;
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mCTType;                        //ClientTool Product Type, refer to "enum CTProductType"

	w_u32_t			mOrderBookID;
	w_u32_t			mTradeCount;
	w_u32_t			mTradeOffset;
	w_u32_t			mCommodityKey;
	w_u32_t			mClassKey;
	w_u32_t			mStatisticsKey;
	w_u32_t			mOpenInterestKey;
	char			mInstrumentCode[20];
};

// Retransmission criteria [Client -> Server]
struct CTRetransRequest
{
	//CTRequestHeader	mHeader;
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mCTType;                        //ClientTool Product Type, refer to "enum CTProductType"

	w_u16_t 		mChannelId;
	w_u32_t	 		mBeginSeqNum;
	w_u32_t 		mEndSeqNum;
};

struct CTNewsRequest
{
        //CTRequestHeader mHeader;
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mCTType;                        //ClientTool Product Type, refer to "enum CTProductType"
};

// Respond header [Server -> Client]
struct CTRespondHeader
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
	w_u16_t			mRespondCode;	//refer to "enum CTRespondCode"
};

// Series search respond [Server -> Client]
struct CTSeriesSearchRespond
{
//	CTRespondHeader	mHeader;
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mRespondCode;   //refer to "enum CTRespondCode"
	
};

// Snapshot respond [Server -> Client]
struct CTSnapShotRespond
{
//	CTRespondHeader	mHeader;
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mRespondCode;   //refer to "enum CTRespondCode"
	
};

// Retransmission respond [Server -> Client]
struct CTRetransRespond
{
//	CTRespondHeader	mHeader;
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mRespondCode;   //refer to "enum CTRespondCode"
	
	w_u16_t 		mChannelId;
	w_u32_t	 		mBeginSeqNum;
	w_u32_t 		mEndSeqNum;
	// + list of messages
};

struct CTNewsRespond
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mRespondCode;   //refer to "enum CTRespondCode"        
};

// OMDC Snapshot criteria [Client -> Server]
struct CTSecSnapShotRequest
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mCTType;                        //ClientTool Product Type, refer to "enum CTProductType"
	w_u32_t			mSecurityCode;
	w_i32_t			mTradeStartRecord;		// -1 = last n records
	w_u32_t			mTradeCount;
	w_u32_t			mOrderCount;
};

// Snapshot respond [Server -> Client]
struct CTSecSnapShotRespond
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mRespondCode;   //refer to "enum CTRespondCode"
	w_u32_t			mSecurityCode;
};

static const int MAX_MARKET_CODE_LEN=4;

// Market Snapshot criteria [Client -> Server]
struct CTMktSnapShotRequest
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mCTType;                        //ClientTool Product Type, refer to "enum CTProductType"
	char			mMarketCode[MAX_MARKET_CODE_LEN];
};

// Market respond [Server -> Client]
struct CTMktSnapShotRespond
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mRespondCode;   //refer to "enum CTRespondCode"        
	char			mMarketCode[MAX_MARKET_CODE_LEN];
};

// Currency Snapshot criteria [Client -> Server]
struct CTCurSnapShotRequest
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mCTType;                        //ClientTool Product Type, refer to "enum CTProductType"
};

// Currency respond [Server -> Client]
struct CTCurSnapShotRespond
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mRespondCode;   //refer to "enum CTRespondCode"        
};

// Index Snapshot criteria [Client -> Server]
struct CTIdxSnapShotRequest
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mCTType;                        //ClientTool Product Type, refer to "enum CTProductType"
};

// Index respond [Server -> Client]
struct CTIdxSnapShotRespond
{
        w_u16_t                 mSize;
        w_u16_t                 mInfoType;                      //Information type, refer to "enum CTInfoType"
        w_u16_t                 mRespondCode;   //refer to "enum CTRespondCode"        
};

#pragma pack()

#endif //ClientToolStructsH

