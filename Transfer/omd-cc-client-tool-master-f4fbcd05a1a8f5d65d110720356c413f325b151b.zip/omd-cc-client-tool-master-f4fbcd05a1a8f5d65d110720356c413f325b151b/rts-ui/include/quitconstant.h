#ifndef _QUIT_CONSTANT_H
#define _QUIT_CONSTANT_H

static const int QUIT_HDR_X = 1;
static const int QUIT_HDR_Y = 1;
static const int QUIT_HDR_WIDTH = 20;

#endif

