// Hey, Emacs! This is -*-C++-*- code.
//----------------------------------------------------------------------------
// $Id: WombatTypes.h 63321 2012-01-27 16:26:42Z ciarang $
//
// Copyright (c) 1999-2003 Wombat Consulting, Inc., of Incline Village, NV.
// All rights reserved.
// 
// This software and documentation constitute an unpublished work and
// contain valuable trade secrets and proprietary information belonging
// to Wombat.  None of this material may be copied, duplicated or
// disclosed without the express written permission of Wombat.  
// 
// WOMBAT EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES CONCERNING THIS
// SOFTWARE AND DOCUMENTATION, INCLUDING ANY WARRANTIES OF
// MERCHANTABILITY AND/OR FITNESS FOR ANY PARTICULAR PURPOSE, AND
// WARRANTIES OF PERFORMANCE, AND ANY WARRANTY THAT MIGHT OTHERWISE ARISE
// FROM COURSE OF DEALING OR USAGE OF TRADE. NO WARRANTY IS EITHER
// EXPRESS OR IMPLIED WITH RESPECT TO THE USE OF THE SOFTWARE OR
// DOCUMENTATION.  
// 
// Under no circumstances shall Wombat be liable for incidental, special,
// indirect, direct or consequential damages or loss of profits,
// interruption of business, or related expenses which may arise from use
// of software or documentation, including but not limited to those
// resulting from defects in software and/or documentation, or loss or
// inaccuracy of data of any kind.
//
//----------------------------------------------------------------------------

#ifndef WombatTypesH
#define WombatTypesH

#include <sys/types.h>
#include <inttypes.h>

typedef int8_t            w_i8_t;
typedef int16_t           w_i16_t;
typedef int32_t           w_i32_t;
typedef int64_t           w_i64_t;
typedef uint8_t           w_u8_t;
typedef uint16_t          w_u16_t;
typedef uint32_t          w_u32_t;
typedef uint64_t          w_u64_t;

typedef float             w_f32_t;
typedef double            w_f64_t;

typedef w_u32_t           w_seqnum_t;
typedef w_u32_t           w_size_t;
typedef w_u64_t           w_volume_t;

#ifndef QUANTITIES_AS_DOUBLES
typedef w_u64_t           w_quantity_t;
typedef w_i64_t           w_squantity_t;
#else
typedef w_f64_t           w_quantity_t;
typedef w_f64_t           w_squantity_t;
#endif

#ifndef _TIME_T
#define	_TIME_T
typedef	long              time_t;    /* time of day in seconds */
#endif	/* _TIME_T */


#endif // WombatTypesH
