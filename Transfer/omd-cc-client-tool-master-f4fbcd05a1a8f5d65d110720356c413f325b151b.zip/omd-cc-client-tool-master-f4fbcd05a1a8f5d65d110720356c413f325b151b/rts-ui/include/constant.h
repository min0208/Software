#ifndef _CONSTANT_H
#define _CONSTANT_H

#define VERSION_DATE    __DATE__

static const char* PROGRAM_NAME = "OMD RTS Client Tool";

enum GUI_COLOR
{
        GUI_RED = 1,
        GUI_CYAN,
        GUI_WHITE_RED,
        GUI_WHITE,
        GUI_BLACK_BLUE,
        GUI_YELLOW,
        GUI_MAGENTA,
        GUI_GREEN,
        GUI_BLUE,
        GUI_WHITE_MAGENTA,
        GUI_WHITE_BLUE,
        GUI_BLACK_MAGENTA,
        GUI_MAGENTA_WHITE,
	GUI_MAGENTA_BLACK,
	GUI_MAGENTA_BLUE,
	GUI_GREEN_WHITE
};

enum RESULT
{
	SUCCESS,
	UNKNOWN_MSG_TYPE,
	UNKNOWN_CT,
	FAIL
};

enum ALIGN
{
	ALIGN_LEFT,
	ALIGN_RIGHT,
	ALIGN_CENTER
};

enum LAYOUT_TYPE
{
        TYPE_EQTY,
        TYPE_BOND,
        TYPE_WRNT,
        TYPE_BWRT,
        TYPE_TRST,
        TYPE_OPEN,
        TYPE_CLOSE
};

enum SECURITY_DATA_IDX
{
        SEC_CODE,
        SEC_FLAG,
        SEC_MARKET,
        SEC_NAME,
        SEC_GCCS_NAME,
        SEC_GB_NAME,
        SEC_HIGH,
        SEC_LOW,
        SEC_PREVIOUS_CLOSING_PRICE,
        SEC_NOMINAL,
        SEC_SHARES_TRADED,
        SEC_TURNOVER,
        SEC_VWAP,
        SEC_NUMBEROFTRADES,
        SEC_SPREAD_VALUE,
        SEC_LOT_SIZE,
        SEC_CURRENCY_CODE,
        SEC_FREE_TEXT_1,
        SEC_FREE_TEXT_2,
        SEC_BID,
        SEC_ASK,
        SEC_BIDQ,
        SEC_ASKQ,
        SEC_IEP,
        SEC_IEV,
        SEC_SS_SHARES_TRADED,
        SEC_SS_TURNOVER,
        SEC_CONVERSION_RATIO,
        SEC_STRIKE_PRICE,
        SEC_UNDERLYING_SEC,
        SEC_MATURITY_DATE,
        SEC_COUPON_RATE,
        SEC_ACCRUED_INTEREST,
        SEC_LAST,
        SEC_CLOSING_PRICE,
        SEC_TOP_MSG_BOX,
        SEC_TRADE_ID,
        SEC_TRADE_PRICE,
        SEC_TRADE_QUANTITY,
        SEC_TRADE_TYPE,
        SEC_TRADE_TIME,
        SEC_TRADE,
        SEC_SPREAD_TABLE_CODE,
        SEC_TRADE_STATUS,
	SEC_VCM_FLAG,
	SEC_SHORT_SELL_FLAG,
	SEC_CAS_FLAG,
	SEC_CCASS_FLAG,
	SEC_DUMMY_FLAG,
	SEC_TEST_FLAG,
	SEC_STAMP_DUTY_FLAG,
	SEC_CALL_PUT_FLAG,
	SEC_EFN_FLAG,
	SEC_STYLE,
	SEC_ALL_UNDERLYING_SEC_1,
	SEC_ALL_UNDERLYING_SEC_2,
	SEC_ALL_UNDERLYING_SEC_3,
	SEC_ALL_UNDERLYING_SEC_4,
	//SEC_ALL_UNDERLYING_SEC_WEIGHT,
	SEC_ALL_LIQUIDITY_PROVIDER_1,
	SEC_ALL_LIQUIDITY_PROVIDER_2,
	SEC_ALL_LIQUIDITY_PROVIDER_3,
	SEC_ALL_LIQUIDITY_PROVIDER_4,
	SEC_ALL_LIQUIDITY_PROVIDER_5,
	SEC_ISIN_CODE,
	SEC_INSTRUMENT_TYPE,
	SEC_LISTING_DATE,
	SEC_DELISTING_DATE,
	SEC_YIELD,
	SEC_ORDER_IMBALANCE_DIR,
	SEC_ORDER_IMBALANCE_QTY,
	SEC_VCM_START_TIME,
	SEC_VCM_END_TIME,
	SEC_REFERENCE_PRICE_REF_PRICE, // also for VCM reference price
	SEC_REFERENCE_PRICE_LOW_PRICE,	// also for VCM reference low price
	SEC_REFERENCE_PRICE_HIGH_PRICE,	// also for VCM reference high price
        SEC_EOF
};

enum MC_CHANNEL_IDX
{
	MC_NUM,
	MC_TYPE,
	MC_STATUS
};

enum CURRENCY_DATA_IDX
{
	CUR_CODE,
	CUR_FACTOR,
	CUR_RATE
};

enum MARKET_DATA_IDX
{
	MKT_CODE,
	MKT_NAME,
	MKT_CURRENCY,
	MKT_NUM_OF_SEC,
	MKT_TRADE_SES_ID,
	MKT_TRADE_SES_SUB_ID,
	MKT_TRADE_SES_STATUS,
	MKT_TRADE_SES_CTRL_FLAG,
	MKT_START_TIME,
	MKT_END_TIME,
	MKT_TURNOVER,
	MKT_TURNOVER_SHORT_FORM
};

static const int TRADE_NO_OF_TRADE_SHOW = 126;
//static const int MAIN_NO_OF_TRADE_SHOW 	= 16;
static const int MAIN_NO_OF_ORDER_SHOW 	= 10;
static const int ORDER_NO_OF_LINE_SHOW 	= 35;
static const int NO_OF_CURRENCY_SHOW 	= 20;
static const int NO_OF_NEWS_LINE	= 50;
static const int MAX_UNDERLYING_SEC 	= 20;
static const int MAX_NO_OF_MKT_CURRENCY = 9;

static const int MAX_ORDER_DEPTH 	= 10;
static const int MAX_BQ_DEPTH 		= 41;
static const int MAX_MARKET_DISPLAY 	= 4;
static const int MAX_TRADE_DISPLAY 	= 16;
static const int MAX_TRADE_TICKER_DISPLAY = 4;

static const int MAX_LIQUIDITY_PROVIDER = 50;
static const int MAX_TEXT = 128;
static const int NO_OF_CHANNEL = 14;
static const int NO_OF_CHANNEL_PER_ROW = 7;
static const int NO_OF_SETTING_NOTE = 4;

static const int DATA_WIN_LEFT		= 1;
static const int DATA_WIN_TOP		= 4;
static const int DATA_WIN_Y_OFFSET	= 7;

static const int FIELD_X_OFFSET = 3;
static const int FIELD_X_BIDQ	= 30;

static const int TITLE_LEN = 139;
static const int TITLE_X = 1;
static const int TITLE_Y = 1;

static const int FOOTNOTE_1_LEN = 25;
static const int FOOTNOTE_1_X = 0;
static const int FOOTNOTE_1_Y = 0;

static const int FOOTNOTE_2_LEN = 4;
static const int FOOTNOTE_2_X = FOOTNOTE_1_X + FOOTNOTE_1_LEN;
static const int FOOTNOTE_2_Y = FOOTNOTE_1_Y;

static const int FOOTNOTE_SERVER_LEN = 4;
static const int FOOTNOTE_SERVER_X = FOOTNOTE_2_X + FOOTNOTE_2_LEN + (FOOTNOTE_2_LEN * (NO_OF_CHANNEL+1));
static const int FOOTNOTE_SERVER_Y = FOOTNOTE_2_Y;

static const int LAST_FOOTNOTE = ( (NO_OF_CHANNEL + 1) * 2) + 1;
static const int FOOTNOTE_N_LEN = 25;
static const int FOOTNOTE_N_X = FOOTNOTE_SERVER_X + FOOTNOTE_SERVER_LEN;
static const int FOOTNOTE_N_Y = FOOTNOTE_SERVER_Y;

static const int IN_SEC_CODE_HDR_LEN = 21;
static const int IN_SEC_CODE_HDR_X = 2;
static const int IN_SEC_CODE_HDR_Y = 1;
static const int IN_SEC_CODE_LEN = 5;
static const int IN_SEC_CODE_X = IN_SEC_CODE_HDR_X + IN_SEC_CODE_HDR_LEN + 1;
static const int IN_SEC_CODE_Y = IN_SEC_CODE_HDR_Y;

static const int TOP_MSG_BOX_HDR_LEN = 30;
static const int TOP_MSG_BOX_HDR_X = IN_SEC_CODE_X + IN_SEC_CODE_LEN + FIELD_X_OFFSET;
static const int TOP_MSG_BOX_HDR_Y = IN_SEC_CODE_Y;

#endif

