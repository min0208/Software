#ifndef ClientToolH
#define ClientToolH

#include "screenpage/gui.h"
#include "modules/ctsvrconnector.h"
#include "modules/msghandler.h"

#include "std/stdapp.h"

using namespace std;
using namespace MSG_HANDLER;

class ClientTool : public STDApp, public GUI
{
	public:
		ClientTool();
		~ClientTool();

		static ClientTool* inst();
		static STDLogger* logger();
		bool setCTRequest( bool bOneOffRequest, int nInfoType, int nProductType, int nArg0=0, int nArg1=0, int nArg2=0, int nArg3=0 );
		void recvCTSvrResponse( int nResponseCode );
		void recvRefreshComplete();

	protected:
		bool initInstance();
		bool exitInstance();

		bool init();
		bool initServerSocket();

	protected:
		static ClientTool* m_gClientTool;
		CTSvrConnector			*m_pCTSvrConnector;
		MsgHandler			*m_pMsgHandler;
};

#endif

