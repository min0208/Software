#include "datamodules/closingprice.h"
#include "modules/imagecontrol.h"
#include "std/stdapp.h"

ClosingPrice::ClosingPrice()
{
}

ClosingPrice::ClosingPrice( Xdp::ClosingPrice* pMsg ) :
	m_nClosingPrice(0)
{
	process( pMsg );
}

ClosingPrice::~ClosingPrice()
{
}

int ClosingPrice::process( Xdp::ClosingPrice* pMsg )
{
	m_nSecCode = pMsg->mSecurityCode;
	m_nClosingPrice = pMsg->mClosingPrice;

	setDataInt( SEC_CODE, m_nSecCode, STDUtil::INTEGER_5_DIGIT );
	setDataInt( SEC_CLOSING_PRICE, pMsg->mClosingPrice, STDUtil::INTEGER_3_DP );
	setDataInt( SEC_NUMBEROFTRADES, pMsg->mNumberOfTrades, STDUtil::INTEGER_NORMAL );

	STDGetLogger()->log( STDLOG_L6, "seccode|%05d| closing price|%d| # of trades|%d|", m_nSecCode, m_nClosingPrice, pMsg->mNumberOfTrades );
	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

int ClosingPrice::getClosingPrice()
{
	return m_nClosingPrice;
}

