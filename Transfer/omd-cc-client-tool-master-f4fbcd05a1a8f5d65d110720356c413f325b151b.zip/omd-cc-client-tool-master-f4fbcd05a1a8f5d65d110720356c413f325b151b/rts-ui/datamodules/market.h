#ifndef MARKET_H
#define MARKET_H

#include "datamodules/marketdef.h"
#include "datamodules/marketturnover.h"
#include "datamodules/tradingsessionstatus.h"

using namespace std;

class Market
{
	public:
		typedef map<string,MarketTurnover> MKT_TURNOVER_MAP;

	public:
		Market();
		~Market();
		const char* getMarketCode();

		void setData( MarketDef& oData );
		void setData( TradingSessionStatus& oData );
		void setData( MarketTurnover& oData );

		MarketDef getMarketDef();
		TradingSessionStatus getTradingSessionStatus();
		bool getMarketTurnover( MKT_TURNOVER_MAP& mDataMap );
		MarketTurnover getMarketTurnover( const char* sCurrencyCode="" );

	protected:
		string m_sMarketCode;

		MarketDef m_oMarketDef;
		TradingSessionStatus m_oTradingSessionStatus;
		MKT_TURNOVER_MAP m_mMarketTurnover;   // 1st key is CURRENCY CODE. value = "" means the total of all traded currencies

		STDMutex m_oMutex;
};

#endif

