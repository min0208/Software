#ifndef CT_CUR_RESPOND_H 
#define CT_CUR_RESPOND_H

#include "datamodules/ctrespond.h"

#include "include/common/ClientToolStructs.h"

class CTSvrCurRespond : public CTRespond
{
	public:
		CTSvrCurRespond();
		CTSvrCurRespond( CTCurSnapShotRespond* pMsg );
		~CTSvrCurRespond();

	protected:
		int process( CTCurSnapShotRespond* pMsg );
};

#endif
