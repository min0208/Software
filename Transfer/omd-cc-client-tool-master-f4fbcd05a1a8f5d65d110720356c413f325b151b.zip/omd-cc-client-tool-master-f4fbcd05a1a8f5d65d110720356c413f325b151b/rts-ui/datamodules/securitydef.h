#ifndef SECURITY_DEF_H
#define SECURITY_DEF_H

#include "datamodules/secmsgbase.h"

#include "include/common/XdpStructs.h"

#include <vector>

class SecurityDef : public SecMsgBase
{
	public:
		SecurityDef();
		SecurityDef( Xdp::SecurityStatic* pMsg );
		~SecurityDef();

		int getInstrumentType() const;
		int getPrevClosing();
		const char* getSpreadTableCode();

	protected:
		int process( Xdp::SecurityStatic* pMsg );

	protected:

		int m_nInstrumentType;
		int m_nPrevClosing;
};

#endif
