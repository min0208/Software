#ifndef BrokerQueue_H
#define BrokerQueue_H

#include "datamodules/secmsgbase.h"

#include "include/common/XdpStructs.h"

#include <deque>
#include <vector>

using namespace std;

class BrokerQueue : public SecMsgBase
{
	public:
		enum ORDER_SIDE
		{
			BID = 1,
			ASK
		};

		struct BROKER
		{
			unsigned short nItem;
			char cType;
		};

	public:
		BrokerQueue();
		BrokerQueue( Xdp::BrokerQueue *pMsg );
		~BrokerQueue();

		int process( Xdp::BrokerQueue *pMsg );
		vector<BROKER> getBroker();
		unsigned int getSide();
		bool getMoreFlag();

		void reset();

	protected:
		vector<BROKER> m_vBroker;
		unsigned int m_nSide;
		bool m_bMoreFlag;
};

#endif
