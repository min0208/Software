#ifndef CT_STATUS_H 
#define CT_STATUS_H

#include "datamodules/msgbase.h"

#include "include/common/XdpStructs.h"

class CTStatus : public MsgBase
{
	public:
		CTStatus();
		CTStatus( Xdp::CTSvrStatus* pMsg );
		~CTStatus();

		enum LINE_STATUS 
		{
			CONNECT,
			DISCONNECT
		};

	public:
		int getStatus();

	protected:
		int process( Xdp::CTSvrStatus* pMsg );

	protected:
		int m_nStatus;
};

#endif
