#include "datamodules/ctsecrespond.h"
#include "modules/imagecontrol.h"
#include "main.h"

#define LOGC "|CTSecRes| "

CTSecRespond::CTSecRespond()
{
}

CTSecRespond::CTSecRespond( CTSecSnapShotRespond* pMsg ) :
	CTRespond( (CTSnapShotRespond*)pMsg )
{
	process( pMsg );
}

CTSecRespond::~CTSecRespond()
{
}

int CTSecRespond::process( CTSecSnapShotRespond* pMsg )
{
	if ( pMsg->mRespondCode != CT_SUCCESS )
	{
		STDGetLogger()->log( STDLOG_L3, LOGC "receive CT server negative response code|%d|", pMsg->mRespondCode );
	}

	STDGetLogger()->log( STDLOG_L7, LOGC "CTSecSnapShotRespond seccode|%d| rsp code|%d|", pMsg->mSecurityCode, pMsg->mRespondCode );

	ImageControl::inst()->resetSecurity( pMsg->mSecurityCode );
	
	return SUCCESS;
}
