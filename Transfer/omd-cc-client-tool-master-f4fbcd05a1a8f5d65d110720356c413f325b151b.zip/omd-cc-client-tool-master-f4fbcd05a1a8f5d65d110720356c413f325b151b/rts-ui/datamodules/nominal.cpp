#include "datamodules/nominal.h"
#include "modules/imagecontrol.h"

Nominal::Nominal()
{
}

Nominal::Nominal( Xdp::Nominal* pMsg )
{
	process( pMsg );
}

Nominal::~Nominal()
{
}

int Nominal::process( Xdp::Nominal* pMsg )
{
	m_nSecCode = pMsg->mSecurityCode;
	m_nNominal =  pMsg->mNominalPrice;
	setDataInt( SEC_CODE, m_nSecCode, STDUtil::INTEGER_5_DIGIT );
	setDataInt( SEC_NOMINAL, pMsg->mNominalPrice, STDUtil::INTEGER_3_DP );

	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

int Nominal::getNominal()
{
	return m_nNominal;
}

