#include "datamodules/market.h"
#include "std/stdmutexlocker.h"
#include "std/stdapp.h"

Market::Market()
{
}

Market::~Market()
{
}

void Market::setData( MarketDef& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sMarketCode = oData.getMarketCode();
	m_oMarketDef = oData;

	//STDGetLogger()->log( STDLOG_L5, "market code|%s|", m_sMarketCode.c_str() );
}

void Market::setData( MarketTurnover& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sMarketCode = oData.getMarketCode();
	m_mMarketTurnover[ oData.getCurrencyCode()] = oData;
}

void Market::setData( TradingSessionStatus& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sMarketCode = oData.getMarketCode();
	m_oTradingSessionStatus = oData;
}

MarketDef Market::getMarketDef() 
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oMarketDef;
}

MarketTurnover Market::getMarketTurnover( const char* sCurrencyCode )
{
	STDMutexLocker oLocker(m_oMutex);

	return m_mMarketTurnover[ sCurrencyCode];
}

TradingSessionStatus Market::getTradingSessionStatus()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oTradingSessionStatus;
}

const char* Market::getMarketCode()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_sMarketCode.c_str();
}

bool Market::getMarketTurnover( MKT_TURNOVER_MAP& mDataMap )
{
	STDMutexLocker oLocker(m_oMutex);

	mDataMap = m_mMarketTurnover;

	return true;
}

