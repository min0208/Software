#include "datamodules/msgbase.h"
#include "std/stdutil.h"
#include "std/stdapp.h"

#include <iconv.h>

#define LOGC "|MsgBase | "

MsgBase::MsgBase()
{
}

MsgBase::~MsgBase()
{
}

bool MsgBase::getStr( const char* pInBuf, int nInBufSize, char* pOutBuf, int nOutBufSize )
{
	if ( nInBufSize >= nOutBufSize ) 
	{
		STDGetLogger()->log( STDLOG_L2, LOGC "getStr() not enough space. nInBufSize|%d| nOutBufSize|%d|", nInBufSize, nOutBufSize );
		return false;	// out buffer needs in buffer + 1 for null terminate string
	}

	memcpy( pOutBuf, pInBuf, nInBufSize );
	pOutBuf[ nInBufSize] = 0;

	return true;
}

bool MsgBase::convertUnicode( const char* sInEncode, char* sInStr, int nInStrLen, const char* sOutEncode, char* sOutStr, int nOutBufLen )
{
	iconv_t tIconv = iconv_open( sOutEncode, sInEncode );

	if ( tIconv == 0 )
	{
		STDGetLogger()->log( STDLOG_L2, LOGC "convertUnicode() iconv_open failed|%d|", tIconv );
		return false;
	}

	char* pInStr = sInStr;
	char* pOutStr = sOutStr;
	size_t i = nInStrLen;
	size_t j = nOutBufLen;
	size_t nChar = iconv( tIconv, &pInStr, &i, &pOutStr, &j );
	iconv_close( tIconv );

	STDGetLogger()->log( STDLOG_L2, LOGC "convertUnicode() nChar|%d| str|%s| errno|%d|", nChar, sOutStr, errno );

	return ( ((int)nChar) == 0 );
}

int MsgBase::setDataUnicode( int nField, const char* pInBuf, int nInBufSize )
{
	char sText[ MAX_TEXT];
	memset( sText, 0, sizeof(sText) );

	if ( getStr( pInBuf, nInBufSize, sText, MAX_TEXT ) )
	{
		int nTextLen = sizeof(sText);
		int nUTF8Size = MAX_TEXT;
		char sUTF8[ nUTF8Size];
		memset( sUTF8, 0, nUTF8Size );

		if ( convertUnicode("UTF-16", sText, nTextLen, "UTF-8", sUTF8, nUTF8Size) )
		{
			m_mField[ nField] = sUTF8;
			return SUCCESS;
		}
		else
		{
			m_mField[ nField] = "";
		}
	}
	else
	{
		m_mField[ nField] = "";
	}

	return FAIL;
}

int MsgBase::setDataStr( int nField, const char* sInBuf, int nInBufSize )
{
	char sText[ MAX_TEXT];

	if ( getStr(sInBuf, nInBufSize, sText, MAX_TEXT) )
	{
		m_mField[ nField] = sText;
	}

	return SUCCESS;
}

int MsgBase::setDataTime64( int nField, long long nData, int nFormat )
{
	string sText;

	STDUtil::convertInt64ToTimeStr( nData, nFormat, sText );
	m_mField[ nField] = sText;

	return SUCCESS;
}

int MsgBase::setDataInt64( int nField, unsigned long long nData, int nFormat )
{
	string sText;

	STDUtil::convertInt64ToStr( nData, nFormat, sText );
	m_mField[ nField] = sText;

	return SUCCESS;
}

int MsgBase::setDataDate( int nField, int nData )
{
	string sText;

	if ( nData != 0 )
	{
		STDUtil::convertIntToStr( nData, STDUtil::DATE_ONLY, sText );
		m_mField[ nField] = sText;
	}

	return SUCCESS;
}

int MsgBase::setDataInt( int nField, unsigned int nData, int nFormat )
{
	string sText;

	STDUtil::convertIntToStr( nData, nFormat, sText );
	m_mField[ nField] = sText;

	return SUCCESS;
}

int MsgBase::setDataChar( int nField, char cData )
{
	char sText[ MAX_TEXT];

	sprintf( sText, "%c", cData );	// the integer is in YYYYMMDD format

	m_mField[ nField] = sText;

	return SUCCESS;
}

int MsgBase::setData( int nField, const char* sData )
{
	m_mField[ nField] = sData;

	return SUCCESS;
}

const char* MsgBase::getData( int nField ) 
{
	return m_mField[ nField].c_str();
}

bool MsgBase::validateStr( const char* sData, const char** vValidStr, int nSize )
{
	int nDataLen = strlen(sData);

	for ( unsigned int i=0; i<nSize; i++ )
	{
		int nDataLen = strlen(vValidStr[i]);	// using valid string length instead of sData length. to disregard the space 

		if ( strncmp(sData, vValidStr[i], nDataLen) == 0 )
		{
			return true;
		}
	}

	return false;
}

bool MsgBase::validateChar( char cData, const char* vValidChar, int nSize )
{
	for ( unsigned int i=0; i<nSize; i++ )
	{
		if ( cData == vValidChar[i] )
		{
			return true;
		}
	}

	return false;
}

