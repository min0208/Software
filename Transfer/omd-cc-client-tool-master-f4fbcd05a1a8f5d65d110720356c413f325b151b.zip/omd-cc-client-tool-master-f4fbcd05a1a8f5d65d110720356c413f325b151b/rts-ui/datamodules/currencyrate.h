#ifndef CURRENCY_RATE_H 
#define CURRENCY_RATE_H

#include "datamodules/mktmsgbase.h"
#include "include/common/XdpStructs.h"

class CurrencyRate : public MsgBase
{
	public:
		CurrencyRate();
		CurrencyRate( Xdp::CurrencyRate* pMsg );
		~CurrencyRate();

		int process( Xdp::CurrencyRate* pMsg );

		const char* getCurrencyCode();

	protected:
		string m_sCurrencyCode;
};

#endif
