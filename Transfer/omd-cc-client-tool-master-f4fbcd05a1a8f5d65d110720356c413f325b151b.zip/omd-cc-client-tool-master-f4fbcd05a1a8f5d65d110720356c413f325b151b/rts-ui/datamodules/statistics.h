#ifndef STATISTICS_H
#define STATISTICS_H

#include "datamodules/secmsgbase.h"
#include "include/common/XdpStructs.h"

class Statistics : public SecMsgBase
{
	public:
		Statistics();
		Statistics( Xdp::Statistics* pMsg );
		~Statistics();

		int process( Xdp::Statistics* pMsg );
		int getHigh();
		int getLow();
		int getLast();

	protected:
		int m_nHigh;
		int m_nLow;
		int m_nLast;
};

#endif
