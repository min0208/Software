#ifndef CLOSING_PRICE_H 
#define CLOSING_PRICE_H

#include "datamodules/secmsgbase.h"

#include "include/common/XdpStructs.h"

class ClosingPrice : public SecMsgBase
{
	public:
		ClosingPrice();
		ClosingPrice( Xdp::ClosingPrice* pMsg );
		~ClosingPrice();

		int process( Xdp::ClosingPrice* pMsg );
		int getClosingPrice();

	protected:
		int m_nClosingPrice;
};

#endif
