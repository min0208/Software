#ifndef MKT_MSG_BASE_H
#define MKT_MSG_BASE_H

#include "datamodules/msgbase.h"

class MktMsgBase : public MsgBase
{
	public:
		MktMsgBase();
		~MktMsgBase();

		const char* getMarketCode();
		bool setMarketCode( const char* sMarketCode );

	public:
		virtual bool checkMarketCode( const char* MSG_CLASS, const char* sData );
		virtual bool checkTradingSesId( const char* MSG_CLASS, int nData );
		virtual bool checkTradingSesSubId( const char* MSG_CLASS, int nData );
		virtual bool checkTradingSesStatus( const char* MSG_CLASS, int nData );
		virtual bool checkTradingSesCtrlFlag( const char* MSG_CLASS, char cData );

	protected:
		string m_sMarketCode;
};

#endif

