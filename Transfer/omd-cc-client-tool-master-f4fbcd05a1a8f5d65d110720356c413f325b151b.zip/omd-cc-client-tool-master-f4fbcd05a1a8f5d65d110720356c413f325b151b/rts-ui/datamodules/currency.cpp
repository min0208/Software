#include "datamodules/currency.h"
#include "std/stdmutexlocker.h"

Currency::Currency()
{
}

Currency::~Currency()
{
}

void Currency::setData( CurrencyRate& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sCurrencyCode = oData.getCurrencyCode();
	m_oCurrencyRate = oData;
}

CurrencyRate Currency::getCurrencyRate() 
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oCurrencyRate;
}

const char* Currency::getCurrencyCode()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_sCurrencyCode.c_str();
}


