#include "datamodules/securitystatus.h"
#include "modules/imagecontrol.h"
#include "std/stdapp.h"

#define LOGC "|SecStatu| "

SecurityStatus::SecurityStatus() :
	m_nStatus(0)
{
}

SecurityStatus::SecurityStatus( Xdp::SecurityStatus* pMsg ) :
	m_nStatus(0)
{
	process( pMsg );
}

SecurityStatus::~SecurityStatus()
{
}

int SecurityStatus::process( Xdp::SecurityStatus* pMsg )
{
	m_nSecCode = pMsg->mSecurityCode;

	setDataInt( SEC_CODE, m_nSecCode, STDUtil::INTEGER_5_DIGIT );
	setDataInt( SEC_TRADE_STATUS, pMsg->mSecurityTradingStatus, STDUtil::INTEGER_NORMAL );
	m_nStatus = pMsg->mSecurityTradingStatus;

	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

int SecurityStatus::getStatus()
{
	return m_nStatus;
}

const char* SecurityStatus::getStatusStr()
{
	static const char* STATUS[] = {
		"ACTIVE",
		"N/A",
		"SUSPEND",
		"ACTIVE"
	};
	static const int NO_OF_STATUS = 4;

	char sText[ MAX_TEXT];

	if ( m_nStatus >= 0 && m_nStatus < NO_OF_STATUS )
	{
		return STATUS[ m_nStatus];
	}

	return "Unknown";
}

