#include "datamodules/tradingsessionstatus.h"
#include "modules/imagecontrol.h"
#include "std/stdapp.h"

#define LOGC "|TradSesS| "

TradingSessionStatus::TradingSessionStatus() :
	m_nSubId(-1),
	m_nStatus(0),
	m_cCtrlFlag(0)
{
}

TradingSessionStatus::TradingSessionStatus( Xdp::TradingSessionStatus* pMsg )
{
	process( pMsg );
}

TradingSessionStatus::~TradingSessionStatus()
{
}

int TradingSessionStatus::process( Xdp::TradingSessionStatus* pMsg )
{
	setDataStr( MKT_CODE, pMsg->mMarketCode, sizeof(pMsg->mMarketCode) );
	setDataInt( MKT_TRADE_SES_ID, pMsg->mTradingSessionID, STDUtil::INTEGER_NORMAL );
	setDataInt( MKT_TRADE_SES_SUB_ID, pMsg->mTradingSessionSubID, STDUtil::INTEGER_NORMAL );
	setDataInt( MKT_TRADE_SES_STATUS, pMsg->mTradingSesStatus, STDUtil::INTEGER_NORMAL );
	setDataChar( MKT_TRADE_SES_CTRL_FLAG, pMsg->mTradingSesControlFlag );

	( pMsg->mStartTime == 0 ) ?
		setData( MKT_START_TIME, " " ) :
		setDataTime64( MKT_START_TIME, pMsg->mStartTime );

	( pMsg->mEndTime == 0 ) ?
		setData( MKT_END_TIME, " " ) :
		setDataTime64( MKT_END_TIME, pMsg->mEndTime );

	m_nSubId = pMsg->mTradingSessionSubID;
	m_nStatus = pMsg->mTradingSesStatus;
	m_cCtrlFlag = pMsg->mTradingSesControlFlag;

	char sTmpStr[ 128];
	char sMarketCode[ 128];
	strcpy( sTmpStr, getData(MKT_CODE) );
	STDUtil::trimRight( sTmpStr, sMarketCode, ' ' );
	m_sMarketCode = sMarketCode;
	setData( MKT_CODE, sMarketCode );

	STDGetLogger()->log( STDLOG_L6, LOGC "market|%s| subid|%03d| status|%03d| ctrl flag|%c| start time|%llu| end time|%llu|", getData(MKT_CODE), pMsg->mTradingSessionSubID, pMsg->mTradingSesStatus, pMsg->mTradingSesControlFlag, pMsg->mStartTime, pMsg->mEndTime );

	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

bool TradingSessionStatus::setSubId( int nSubId )
{
	m_nSubId = nSubId;
	return true;
}

bool TradingSessionStatus::setStatus( int nStatus )
{
	m_nStatus = nStatus;
	return true;
}

bool TradingSessionStatus::setCtrlFlag( char cCtrlFlag )
{
	m_cCtrlFlag = cCtrlFlag;
	return true;
}

int TradingSessionStatus::getSubId()
{
	return m_nSubId;
}

int TradingSessionStatus::getStatus()
{
	return m_nStatus;
}

char TradingSessionStatus::getCtrlFlag()
{
	return m_cCtrlFlag;
}

const char* TradingSessionStatus::getSubIdStr()
{
	switch ( m_nSubId )
	{
		case 0:		return "Day Close-DC";
		case 1:		return "Pre-trading-OI";
		case 2:		return "Opening/Opening Auction-MA";
		case 3:		return "Continuous Trading-CT";
		case 4:		return "Closing/Closing Auction";
		case 5:		return "Post-trading";
		case 7:		return "Quiescent-BL";
		case 100:	return "Not Yet Open-NO";
		case 101:	return "No Cancel/Modification-NC";
		case 102:	return "Exchange Intervention-EI";
		case 103:	return "Close-CL";
		case 104:	return "Order Cancel-OC";
		case 105:	return "Reference Price Fixing";
		case 106:	return "No Cancellation";
		case 107:	return "Random Close";
	}

	return "Unknown";
}

const char* TradingSessionStatus::getSubIdLongStr()
{
	switch ( m_nStatus )
	{
		case 1:
			{
				switch ( m_nSubId )
				{
					case 7:         return "BLOCKING";
					case 102:       return "EXCHANGE INTERVENTION";
				}

				break;
			}

		case 2:
			{
				switch ( m_nSubId )
				{
					case 1:         return "ORDER INPUT";
					case 2:         return "MATCHING";
					case 3:         return "CONTINUOUS TRADING";
					case 101:       return "NO ORDER CANCEL";
					case 104:       return "ORDER CANCEL";
				}

				break;
			}

		case 3:
			{
				switch ( m_nSubId )
				{
					case 100:       return "NOT YET OPEN";
					case 103:       return "CLOSE";
				}

				break;
			}

		case 5:
			{
				switch ( m_nSubId )
				{
					case 4:       return "MATCHING";
					case 5:       return "ORDER INPUT";
					case 105:       return "REF PRICE FIXING";
					case 106:       return "NO CANCELLATION";
					case 107:       return "RANDOM CLOSE";
				}

				break;
			}

		case 100:
			{
				return "DAY CLOSE";
			}
	}

	return "Unknown";
}

const char* TradingSessionStatus::getSubIdShortStr()
{
	switch ( m_nSubId )
	{
		case 0:         return "Day Close";
		case 1:         return "Pre-trading";
		case 2:         return "Opening/Opening Auction";
		case 3:         return "Continuous Trading";
		case 4:		return "Closing/Closing Auction";
		case 5:		return "Post-trading";
		case 7:         return "Quiescent";
		case 100:       return "Not Yet Open";
		case 101:       return "No Cancel/Modification";
		case 102:       return "Exchange Intervention";
		case 103:       return "Close";
		case 104:       return "Order Cancel";
		case 105:	return "Reference Price Fixing";
		case 106:	return "No Cancellation";
		case 107:	return "Random Close";

				/*
				   case 0:         return "DC";
				   case 1:         return "OI";
				   case 2:         return "MA";
				   case 3:         return "CT";
				   case 7:         return "BL";
				   case 100:       return "NO";
				   case 101:       return "NC";
				   case 102:       return "EI";
				   case 103:       return "CL";
				   case 104:       return "OC";
				   */
	}

	return "Unknown";
}

const char* TradingSessionStatus::getStatusStr()
{
	switch ( m_nStatus )
	{
		case 0:		return "Unknown";
		case 1:		return "Halted";
		case 2:		return "Open";
		case 3:		return "Closed";
		case 5:		return "Pre-Close";
		case 100:	return "Day Closed";
	}

	return "Unknown";
}

const char* TradingSessionStatus::getCtrlFlagStr()
{
	switch ( m_cCtrlFlag )
	{
		case '0':	return "Automatic";
		case '1':	return "Manual";
	}

	return "Unknown";
}

bool TradingSessionStatus::inCAS(const char* marketCode, int* status)
{
	bool rtn=false;
	if (marketCode)
	{
		Market oMarket;
		if ( ImageControl::inst()->getMarket(marketCode, oMarket) )
		{
			TradingSessionStatus oData = oMarket.getTradingSessionStatus();
			*status=oData.getStatus();
			rtn=(*status==5);
		} else
			*status=-2;
	} else
		*status=-1;
	return rtn;
}
