#ifndef NOMINAL_H 
#define NOMINAL_H

#include "datamodules/secmsgbase.h"
#include "include/common/XdpStructs.h"

class Nominal : public SecMsgBase
{
	public:
		Nominal();
		Nominal( Xdp::Nominal* pMsg );
		~Nominal();

		int process( Xdp::Nominal* pMsg );
		int getNominal();

	protected:
		int m_nNominal;
};

#endif
