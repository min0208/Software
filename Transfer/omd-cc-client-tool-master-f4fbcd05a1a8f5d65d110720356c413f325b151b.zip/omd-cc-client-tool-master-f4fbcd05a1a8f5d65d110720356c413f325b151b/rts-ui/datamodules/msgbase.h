#ifndef MSG_BASE_H
#define MSG_BASE_H

#include <string>
#include <map>
#include <vector>

#include "std/stdmutex.h"
#include "std/stdutil.h"
#include "include/constant.h"

using namespace std;

class MsgBase
{
	public:
		MsgBase();
		~MsgBase();

		const char* getData( int nField );

		int setData( int nField, const char* sData );
		int setDataChar( int nField, char cData );
                int setDataInt64( int nField, unsigned long long nData, int nFormat=STDUtil::INTEGER_NORMAL );
                int setDataInt( int nField, unsigned int nData, int nFormat );
                int setDataStr( int nField, const char* sInBuf, int nInBufSize );
                int setDataUnicode( int nField, const char* pInBuf, int nInBufSize );
                int setDataTime64( int nField, long long nData, int nFormat=STDUtil::TIME_SEC );
                int setDataDate( int nField, int nData );

	protected:
		int dumpGeneralInfo( const char* sMSG );

		bool getStr( const char* pInBuf, int nInBufSize, char* pOutBuf, int nOutBufSize );
		bool validateStr( const char* sData, const char** vValidStr, int nSize );
		bool validateChar( char cData, const char* vValidChar, int nSize );
		bool convertUnicode( const char* sInEncode, char* sInStr, int nInStrLen, const char* sOutEncode, char* sOutStr, int nOutBufLen );

	protected:
		//Msg m_tMsg;

		map<int,string> m_mField;	// the map for storing security, market, index, news data
};

#endif

