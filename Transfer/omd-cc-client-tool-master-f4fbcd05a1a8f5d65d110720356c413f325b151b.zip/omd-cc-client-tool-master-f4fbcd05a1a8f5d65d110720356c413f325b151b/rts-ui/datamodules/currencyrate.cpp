#include "datamodules/currencyrate.h"
#include "modules/imagecontrol.h"

CurrencyRate::CurrencyRate()
{
}

CurrencyRate::CurrencyRate( Xdp::CurrencyRate* pMsg )
{
	process( pMsg );
}

CurrencyRate::~CurrencyRate()
{
}

int CurrencyRate::process( Xdp::CurrencyRate* pMsg )
{
	setDataStr( CUR_CODE, pMsg->mCurrencyCode, sizeof(pMsg->mCurrencyCode) );
	setDataInt( CUR_FACTOR, pMsg->mCurrencyFactor, STDUtil::INTEGER_NORMAL );
	setDataInt( CUR_RATE, pMsg->mCurrencyRate, STDUtil::INTEGER_4_DP );

	// trim space 
	char sTmpStr[ 128];
	char sCurCode[ 128];
        strcpy( sTmpStr, getData(CUR_CODE) );
        STDUtil::trimRight( sTmpStr, sCurCode, ' ' );
	setData( CUR_CODE, sCurCode );
        m_sCurrencyCode = sCurCode;

	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

const char* CurrencyRate::getCurrencyCode()
{
	return m_sCurrencyCode.c_str();
}

