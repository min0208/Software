#include "datamodules/ctrtsrespond.h"
#include "modules/imagecontrol.h"
#include "main.h"

#define LOGC "|CTRtsRes| "

CTRtsRespond::CTRtsRespond()
{
}

CTRtsRespond::CTRtsRespond( CTRetransRespond* pMsg ) :
	CTRespond( (CTSnapShotRespond*)pMsg )
{
	process( pMsg );
}

CTRtsRespond::~CTRtsRespond()
{
}

int CTRtsRespond::process( CTRetransRespond* pMsg )
{
	if ( pMsg->mRespondCode != CT_SUCCESS )
	{
		STDGetLogger()->log( STDLOG_L3, LOGC "receive CT server negative response code|%d|", pMsg->mRespondCode );
	}

	STDGetLogger()->log( STDLOG_L7, LOGC "CTRtsRespond rsp code|%d|", pMsg->mRespondCode );

	ImageControl::inst()->setRtsStatus( pMsg->mRespondCode );
	
	return SUCCESS;
}
