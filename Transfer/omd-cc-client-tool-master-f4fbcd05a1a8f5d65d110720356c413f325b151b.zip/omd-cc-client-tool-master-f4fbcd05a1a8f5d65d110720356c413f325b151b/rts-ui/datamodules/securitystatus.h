#ifndef SECURITY_STATUS_H
#define SECURITY_STATUS_H

#include "datamodules/secmsgbase.h"

#include "include/common/XdpStructs.h"

#include <vector>

class SecurityStatus : public SecMsgBase
{
	public:
		SecurityStatus();
		SecurityStatus( Xdp::SecurityStatus* pMsg );
		~SecurityStatus();

		int getStatus();
		const char* getStatusStr();

	protected:
		int process( Xdp::SecurityStatus* pMsg );

	protected:
		int m_nStatus;
};

#endif
