#include "datamodules/secmsgbase.h"
#include "std/stdapp.h"
#include <vector>
#include <string>

using namespace std;

static const char* MARKET[] = { "MAIN", "GEM", "ETS", "NASD" };
static const int NO_OF_MARKET = sizeof(MARKET)/sizeof(MARKET[0]);

static const char* INSTRUMENT[] = { "EQTY", "WRNT", "BWRT", "TRST", "BOND" };
static const int NO_OF_INSTRUMENT = sizeof(INSTRUMENT)/sizeof(INSTRUMENT[0]);

static const char* SPREAD_CODE[] = { "01", "03" };
static const int NO_OF_SPREAD_CODE= sizeof(SPREAD_CODE)/sizeof(SPREAD_CODE[0]);

static const char YN[] = { 'Y', 'N' };
static const int NO_OF_YN = sizeof(YN)/sizeof(YN[0]);

static const char CALL_PUT[] = { 'C', 'P' };
static const int NO_OF_CALL_PUT = sizeof(CALL_PUT)/sizeof(CALL_PUT[0]);

static const char STYLE[] = { 'A', 'E', ' ' };
static const int NO_OF_STYLE = sizeof(STYLE)/sizeof(STYLE[0]);

static const char ORDER_TYPE[] = { '1', '2' };
static const int NO_OF_ORDER_TYPE = sizeof(ORDER_TYPE)/sizeof(ORDER_TYPE[0]);

static const char BROKER_TYPE[] = { 'B', 'S' };
static const int NO_OF_BROKER_TYPE = sizeof(BROKER_TYPE)/sizeof(BROKER_TYPE[0]);

static const char ORDER_IMBALANCE_DIR_TYPE[] = { 'N', 'B', 'S', ' ' };
static const int NO_OF_ORDER_IMBALANCE_DIR_TYPE = sizeof(ORDER_IMBALANCE_DIR_TYPE)/sizeof(ORDER_IMBALANCE_DIR_TYPE[0]);

SecMsgBase::SecMsgBase()
{
}

SecMsgBase::~SecMsgBase()
{
}

int SecMsgBase::getSecCode()
{
	return m_nSecCode;
}

bool SecMsgBase::checkSecCode( const char* MSG_CLASS, int nData )
{
	if ( nData < 1 || nData > 99999 )
	{
		STDGetLogger()->log( STDLOG_L2, "%s invalid security code|%d|", MSG_CLASS, nData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkMarketCode( const char* MSG_CLASS, const char* sData )
{
	if ( !validateStr(sData, MARKET, NO_OF_MARKET) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid market code|%s|", MSG_CLASS, m_nSecCode, sData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkInstrumentType( const char* MSG_CLASS, const char* sData )
{
	if ( !validateStr(sData, INSTRUMENT, NO_OF_INSTRUMENT) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid instrument type|%s|", MSG_CLASS, m_nSecCode, sData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkSpreadTableCode( const char* MSG_CLASS, const char* sData )
{
	if ( !validateStr(sData, SPREAD_CODE, NO_OF_SPREAD_CODE) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid spread code|%s|", MSG_CLASS, m_nSecCode, sData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkShortSellFlag( const char* MSG_CLASS, char cData )
{
	if ( !validateChar(cData, YN, NO_OF_YN) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid short sell flag|%c %d|", MSG_CLASS, m_nSecCode, cData, cData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkVCMFlag( const char* MSG_CLASS, char cData )
{
	if ( !validateChar(cData, YN, NO_OF_YN) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid VCM flag|%c %d|", MSG_CLASS, m_nSecCode, cData, cData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkCASFlag( const char* MSG_CLASS, char cData )
{
	if ( !validateChar(cData, YN, NO_OF_YN) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid CAS flag|%c %d|", MSG_CLASS, m_nSecCode, cData, cData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkCCASSFlag( const char* MSG_CLASS, char cData )
{
	if ( !validateChar(cData, YN, NO_OF_YN) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid CCASS flag|%c %d|", MSG_CLASS, m_nSecCode, cData, cData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkDummySecurityFlag( const char* MSG_CLASS, char cData )
{
	if ( !validateChar(cData, YN, NO_OF_YN) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid dummy security flag|%c %d|", MSG_CLASS, m_nSecCode, cData, cData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkTestSecurityFlag( const char* MSG_CLASS, char cData )
{
	if ( !validateChar(cData, YN, NO_OF_YN) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid test security flag|%c %d|", MSG_CLASS, m_nSecCode, cData, cData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkStampDutyFlag( const char* MSG_CLASS, char cData )
{
	if ( !validateChar(cData, YN, NO_OF_YN) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid stamp duty flag|%c %d|", MSG_CLASS, m_nSecCode, cData, cData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkEFNFlag( const char* MSG_CLASS, char cData )
{
	if ( !validateChar(cData, YN, NO_OF_YN) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid EFN flag|%c %d|", MSG_CLASS, m_nSecCode, cData, cData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkCallPutFlag( const char* MSG_CLASS, char cData )
{
	if ( !validateChar(cData, CALL_PUT, NO_OF_CALL_PUT) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid call put flag|%c %d|", MSG_CLASS, m_nSecCode, cData, cData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkStyle( const char* MSG_CLASS, char cData )
{
	if ( !validateChar(cData, STYLE, NO_OF_STYLE) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid style|%d|", MSG_CLASS, m_nSecCode, cData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkNoOfUnderlyingSecWRNT( const char* MSG_CLASS, int nData )
{
	if ( nData > 1 )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid wrnt no of underlying sec|%d|", MSG_CLASS, m_nSecCode, nData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkNoOfUnderlyingSecBWRT( const char* MSG_CLASS, int nData )
{
	if ( nData < 0 || nData > 20 )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid bwrt no of underlying sec|%d|", MSG_CLASS, m_nSecCode, nData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkNoOfLiquidityProvider( const char* MSG_CLASS, int nData )
{
        if ( nData < 1 || nData > 50 )
        {
                STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid no of liquidity provider|%d|", MSG_CLASS, m_nSecCode, nData );
                return false;
        }

        return true;
}


bool SecMsgBase::checkSecTradingStaus( const char* MSG_CLASS, int nData )
{
        switch ( nData )
        {
		case 2:
		case 3:
			{
				return true;
			}
        }

	STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid security trading status|%d|", MSG_CLASS, m_nSecCode, nData );
	return false;
}

bool SecMsgBase::checkOrderSide( const char* MSG_CLASS, int nData )
{
        switch ( nData )
        {
                case 0:
                case 1:
                        {
                                return true;
                        }
        }

        STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid order side|%d|", MSG_CLASS, m_nSecCode, nData );
        return false;
}

bool SecMsgBase::checkOrderType( const char* MSG_CLASS, char cData )
{
        if ( !validateChar(cData, ORDER_TYPE, NO_OF_ORDER_TYPE) )
        {
                STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid order type|%c %d|", MSG_CLASS, m_nSecCode, cData, cData );
                return false;
        }

        return true;
}

bool SecMsgBase::checkOrderImbalanceDirType( const char* MSG_CLASS, char cData )
{
        if ( !validateChar(cData, ORDER_IMBALANCE_DIR_TYPE, NO_OF_ORDER_IMBALANCE_DIR_TYPE) )
        {
                STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid order imbalanace dir type|%c %d|", MSG_CLASS, m_nSecCode, cData, cData );
                return false;
        }

        return true;
}

bool SecMsgBase::checkOrderUpdateAction( const char* MSG_CLASS, int nData )
{
        switch ( nData )
        {
                case 0:
                case 1:
                case 2:
                case 74:
                        {
                                return true;
                        }
        }

        STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid aggregate order update action|%d|", MSG_CLASS, m_nSecCode, nData );
        return false;
}

bool SecMsgBase::checkBQItemCnt( const char* MSG_CLASS, int nData )
{
        if ( nData < 0 || nData > 40 )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid broker item count|%d|", MSG_CLASS, m_nSecCode, nData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkBQMoreFlag( const char* MSG_CLASS, char cData )
{
	if ( !validateChar(cData, YN, NO_OF_YN) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid BQ more flag|%c %d|", MSG_CLASS, m_nSecCode, cData, cData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkBQType( const char* MSG_CLASS, char cData )
{
	if ( !validateChar(cData, BROKER_TYPE, NO_OF_BROKER_TYPE) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid broker type|%c %d|", MSG_CLASS, m_nSecCode, cData, cData );
		return false;
	}

	return true;
}

bool SecMsgBase::checkTradeType( const char* MSG_CLASS, int nData )
{
        switch (nData)
        {
	case 0:
	case 4:
	case 22:
	case 99:
	case 100:
	case 101:
	case 102:
	case 103:
	case 104:
		return true;
	}

	STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid trade type|%d|", MSG_CLASS, m_nSecCode, nData );
	return false;
}

bool SecMsgBase::checkTradeCancelFlag( const char* MSG_CLASS, char cData )
{
	if ( !validateChar(cData, YN, NO_OF_YN) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s security code|%d| invalid trade cancel flag|%c %d|", MSG_CLASS, m_nSecCode, cData, cData );
		return false;
	}

	return true;
}

