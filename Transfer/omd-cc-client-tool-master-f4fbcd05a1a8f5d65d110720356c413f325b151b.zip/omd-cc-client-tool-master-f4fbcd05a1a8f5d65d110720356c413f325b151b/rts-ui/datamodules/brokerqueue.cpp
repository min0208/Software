#include "datamodules/brokerqueue.h"

#include "modules/imagecontrol.h"
#include "std/stdapp.h"

#define LOGC "|BrokerQ | "

BrokerQueue::BrokerQueue() :
	m_bMoreFlag(false)
{
}

BrokerQueue::BrokerQueue( Xdp::BrokerQueue* pMsg ) :
	m_bMoreFlag(false)
{
	process( pMsg );
}

BrokerQueue::~BrokerQueue()
{
}

int BrokerQueue::process( Xdp::BrokerQueue* pMsg )
{
	char* pOffset = (char *)&(pMsg->mBrokerQueueRepeatGrp);

	m_nSecCode = pMsg->mSecurityCode;
	m_nSide = pMsg->mSide;
	m_bMoreFlag = (pMsg->mBQMoreFlag == 'Y');

	for ( unsigned int i=0; i<pMsg->mItemCount; i++ )
	{
		BROKER tBroker;

		Xdp::BrokerQueueRepeatGrp* pSubXdpMsg = (Xdp::BrokerQueueRepeatGrp*) pOffset;
		tBroker.nItem = pSubXdpMsg->mItem;
		tBroker.cType = pSubXdpMsg->mType;

		m_vBroker.push_back( tBroker );

		pOffset += sizeof(Xdp::BrokerQueueRepeatGrp);
	}

	if ( m_nSide == BID )
	{
		ImageControl::inst()->setBidBrokerQueue( *this );
	}
	else
	{
		ImageControl::inst()->setAskBrokerQueue( *this );
	}

	return SUCCESS;
}

vector<BrokerQueue::BROKER> BrokerQueue::getBroker()
{
	return m_vBroker;
}

unsigned int BrokerQueue::getSide()
{
	return m_nSide;
}

bool BrokerQueue::getMoreFlag()
{
	return m_bMoreFlag;
}

void BrokerQueue::reset()
{
	m_vBroker.clear();
}

