#include "datamodules/tradeticker.h"
#include "modules/imagecontrol.h"
#include "std/stdapp.h"

#define LOGC "|TradeTic| "

TradeTicker::TradeTicker()
{
}

TradeTicker::TradeTicker( Xdp::TradeTicker* pMsg ) :
	m_nPrice(0),
	m_nTickerID(0)
{
	process( pMsg );
}

TradeTicker::~TradeTicker()
{
}

const char* TradeTicker::getTradeTickerType( char cType )
{
	switch ( cType )
	{
	case 0:		return " ";
	case 4:		return "P";
	case 22:	return "M";
	case 100:	return "Y";
	case 101:	return "X";
	case 102:	return "D";
	case 103:	return "U";
	case 104:	return "V";
	case 99:	return " *";
	}

	return " ";
}

int TradeTicker::process( Xdp::TradeTicker* pMsg )
{
	m_nSecCode = pMsg->mSecurityCode;
	m_nTickerID = pMsg->mTickerID;
	m_nPrice = pMsg->mPrice;

	if ( pMsg->mTrdCancelFlag == 'Y' )
	{
		pMsg->mTrdType = 99;	// set trade type = 99 if trade cancel for client tool processing
		setData( SEC_TRADE_TIME, " " );
		//setData( SEC_TRADE_TIME, "CANCEL" );
		//setDataInt( SEC_TRADE_PRICE, pMsg->mTickerID, STDUtil::INTEGER_NORMAL );
		//setData( SEC_TRADE_QUANTITY, "TRADE ID" );
	}
	else
	{
		setDataTime64( SEC_TRADE_TIME, pMsg->mTradeTime );
	}

	m_nType = pMsg->mTrdType;

	setDataInt( SEC_TRADE_PRICE, pMsg->mPrice, STDUtil::INTEGER_3_DP );
	setDataInt( SEC_TRADE_QUANTITY, pMsg->mAggregateQuantity, STDUtil::INTEGER_NORMAL );
	setDataInt( SEC_CODE, m_nSecCode, STDUtil::INTEGER_5_DIGIT );
	setDataInt( SEC_TRADE_ID, pMsg->mTickerID, STDUtil::INTEGER_NORMAL );
	setDataStr( SEC_TRADE_TYPE, getTradeTickerType(pMsg->mTrdType), 2 );

	STDGetLogger()->log( STDLOG_L6, LOGC "seccode|%05d| ticker id|%d| price|%d| qty|%d| type|%d| time|%llu|", pMsg->mSecurityCode, pMsg->mTickerID, pMsg->mPrice, pMsg->mAggregateQuantity, pMsg->mTrdType, pMsg->mTradeTime );

	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

int TradeTicker::getPrice()
{
	return m_nPrice;
}

int TradeTicker::getTickerID()
{
	return m_nTickerID;
}

int TradeTicker::getType()
{
	return m_nType;
}

