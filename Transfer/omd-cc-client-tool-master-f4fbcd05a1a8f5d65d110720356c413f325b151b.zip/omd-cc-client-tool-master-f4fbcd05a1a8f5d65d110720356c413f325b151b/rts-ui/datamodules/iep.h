#ifndef IEP_H 
#define IEP_H

#include "datamodules/secmsgbase.h"
#include "include/common/XdpStructs.h"

class IEP : public SecMsgBase
{
	public:
		IEP();
		IEP( Xdp::IEP* pMsg );
		~IEP();

		int process( Xdp::IEP* pMsg );

	protected:
};

#endif
