#include "datamodules/ctmktrespond.h"
#include "modules/imagecontrol.h"
#include "main.h"

#define LOGC "|CTMktRes| "

CTMktRespond::CTMktRespond()
{
}

CTMktRespond::CTMktRespond( CTMktSnapShotRespond* pMsg ) :
	CTRespond( (CTSnapShotRespond*)pMsg )
{
	process( pMsg );
}

CTMktRespond::~CTMktRespond()
{
}

int CTMktRespond::process( CTMktSnapShotRespond* pMsg )
{
	if ( pMsg->mRespondCode != CT_SUCCESS )
	{
		STDGetLogger()->log( STDLOG_L3, LOGC "receive CT server negative response code|%d|", pMsg->mRespondCode );
	}

	STDGetLogger()->log( STDLOG_L7, LOGC "CTMktSnapShotRespond rsp code|%d|", pMsg->mRespondCode );

	ImageControl::inst()->resetMarket();
	
	return SUCCESS;
}
