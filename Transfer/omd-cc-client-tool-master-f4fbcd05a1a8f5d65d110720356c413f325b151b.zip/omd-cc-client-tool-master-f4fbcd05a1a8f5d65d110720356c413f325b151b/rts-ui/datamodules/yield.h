#ifndef YIELD_H 
#define YIELD_H

#include "datamodules/secmsgbase.h"
#include "include/common/XdpStructs.h"

class Yield : public SecMsgBase
{
	public:
		Yield();
		Yield( Xdp::Yield* pMsg );
		~Yield();

		int process( Xdp::Yield* pMsg );
};

#endif
