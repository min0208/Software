#ifndef SEC_MSG_BASE_H
#define SEC_MSG_BASE_H

#include "datamodules/msgbase.h"

class SecMsgBase : public MsgBase
{
	public:
		SecMsgBase();
		~SecMsgBase();

		int getSecCode();

	public:
		virtual bool checkSecCode( const char* MSG_CLASS, int nData );
		virtual bool checkMarketCode( const char* MSG_CLASS, const char* sData );
		virtual bool checkInstrumentType( const char* MSG_CLASS, const char* sData );
		virtual bool checkSpreadTableCode( const char* MSG_CLASS, const char* sData );
		virtual bool checkShortSellFlag( const char* MSG_CLASS, char cData );
		virtual bool checkVCMFlag( const char* MSG_CLASS, char cData );
		virtual bool checkCASFlag( const char* MSG_CLASS, char cData );
		virtual bool checkCCASSFlag( const char* MSG_CLASS, char cData );
		virtual bool checkDummySecurityFlag( const char* MSG_CLASS, char cData );
		virtual bool checkTestSecurityFlag( const char* MSG_CLASS, char cData );
		virtual bool checkStampDutyFlag( const char* MSG_CLASS, char cData );
		virtual bool checkEFNFlag( const char* MSG_CLASS, char cData );
		virtual bool checkCallPutFlag( const char* MSG_CLASS, char cData );
		virtual bool checkStyle( const char* MSG_CLASS, char cData );
		virtual bool checkNoOfUnderlyingSecWRNT( const char* MSG_CLASS, int nData );
		virtual bool checkNoOfUnderlyingSecBWRT( const char* MSG_CLASS, int nData );
		virtual bool checkNoOfLiquidityProvider( const char* MSG_CLASS, int nData );
		virtual bool checkSecTradingStaus( const char* MSG_CLASS, int nData );
		virtual bool checkOrderSide( const char* MSG_CLASS, int nData );
		virtual bool checkOrderType( const char* MSG_CLASS, char cData );
		virtual bool checkOrderUpdateAction( const char* MSG_CLASS, int nData );
		virtual bool checkBQItemCnt( const char* MSG_CLASS, int nData );
		virtual bool checkBQMoreFlag( const char* MSG_CLASS, char cData );
		virtual bool checkBQType( const char* MSG_CLASS, char cData );
		virtual bool checkTradeType( const char* MSG_CLASS, int nData );
		virtual bool checkTradeCancelFlag( const char* MSG_CLASS, char cData );
		virtual bool checkOrderImbalanceDirType( const char* MSG_CLASS, char cData );

	protected:
		int m_nSecCode;
};

#endif

