#ifndef MARKET_TURNOVER_H
#define MARKET_TURNOVER_H

#include "datamodules/mktmsgbase.h"

#include "include/common/XdpStructs.h"

#include <vector>

class MarketTurnover : public MktMsgBase
{
	public:
		MarketTurnover();
		MarketTurnover( Xdp::MarketTurnover* pMsg );
		~MarketTurnover();

		int process( Xdp::MarketTurnover* pMsg );
		const char* getCurrencyCode();
		bool setCurrencyCode( const char* sCurrencyCode );

	protected:

		string m_sCurrencyCode;
};

#endif
