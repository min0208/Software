#ifndef MC_CHANNEL_H
#define MC_CHANNEL_H

#include <string>

#include "datamodules/mcstatus.h"

using namespace std;

class MCChannel
{
	public:
		MCChannel();
		~MCChannel();

		void setData( MCStatus& oData );
		
		const char* getChannelNum();
		const char* getType();
		int getStatus();

	protected:

		MCStatus m_oMCStatus;

		STDMutex m_oMutex;
};

#endif

