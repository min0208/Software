#ifndef VCM_TRIGGER_H
#define VCM_TRIGGER_H

#include "datamodules/secmsgbase.h"

#include "include/common/XdpStructs.h"

class VCMTrigger : public SecMsgBase
{
	public:
		VCMTrigger();
		VCMTrigger( Xdp::VCMTrigger* pMsg );
		~VCMTrigger();

		int process( Xdp::VCMTrigger* pMsg );

		uint64_t getStartTime();
		uint64_t getEndTime();

	protected:
		uint64_t m_nVCMStartTime;
		uint64_t m_nVCMEndTime;
};

#endif
