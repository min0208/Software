#include "datamodules/mktmsgbase.h"
#include "std/stdapp.h"

static const char* MARKET[] = { "MAIN", "GEM", "ETS", "NASD" };
static const int NO_OF_MARKET = sizeof(MARKET)/sizeof(MARKET[0]);

MktMsgBase::MktMsgBase()
{
}

MktMsgBase::~MktMsgBase()
{
}

const char* MktMsgBase::getMarketCode()
{
	return m_sMarketCode.c_str();
}

bool MktMsgBase::setMarketCode( const char* sMarketCode )
{
	m_sMarketCode = sMarketCode;

	return true;
}

bool MktMsgBase::checkMarketCode( const char* MSG_CLASS, const char* sData )
{
	if ( !validateStr(sData, MARKET, NO_OF_MARKET) )
	{
		STDGetLogger()->log( STDLOG_L2, "%s invalid market code|%s|", MSG_CLASS, sData );
		return false;
	}

	return true;
}

bool MktMsgBase::checkTradingSesId( const char* MSG_CLASS, int nData )
{
	if ( nData != 1 )
	{
		STDGetLogger()->log( STDLOG_L2, "%s market code|%s| invalid trading session id|%d|", MSG_CLASS, m_sMarketCode.c_str(), nData );
		return false;
	}

	return true;
}

bool MktMsgBase::checkTradingSesSubId( const char* MSG_CLASS, int nData )
{
	switch ( nData )
	{
		case 0:
		case 1:
		case 2:
		case 3:
		case 7:
		case 100:
		case 101:
		case 102:
		case 103:
		case 104:
			{
				return true;
			}
	}

	STDGetLogger()->log( STDLOG_L2, "%s market code|%s| invalid trading session id|%d|", MSG_CLASS, m_sMarketCode.c_str(), nData );

	return false;
}

bool MktMsgBase::checkTradingSesStatus( const char* MSG_CLASS, int nData )
{
	switch ( nData )
	{
		case 0:
		case 1:
		case 2:
		case 3:
		case 100:
			{
				return true;
			}
	}

	STDGetLogger()->log( STDLOG_L2, "%s market code|%s| invalid trading session id|%d|", MSG_CLASS, m_sMarketCode.c_str(), nData );

	return false;
}

bool MktMsgBase::checkTradingSesCtrlFlag( const char* MSG_CLASS, char cData )
{
        switch ( cData )
        {
                case '0':
                case '1':
                        {
                                return true;
                        }
        }

        STDGetLogger()->log( STDLOG_L2, "%s market code|%s| invalid trading session control flag|%c|", MSG_CLASS, m_sMarketCode.c_str(), cData );

        return false;
}

