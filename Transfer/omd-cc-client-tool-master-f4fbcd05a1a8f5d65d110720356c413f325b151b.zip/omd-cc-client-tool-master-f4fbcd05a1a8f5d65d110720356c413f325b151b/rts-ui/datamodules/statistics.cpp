#include "datamodules/statistics.h"
#include "modules/imagecontrol.h"
#include "std/stdapp.h"

Statistics::Statistics() :
	m_nHigh(0),
	m_nLow(0),
	m_nLast(0)
{
}

Statistics::Statistics( Xdp::Statistics* pMsg )
{
	process( pMsg );
}

Statistics::~Statistics()
{
}

int Statistics::process(  Xdp::Statistics* pMsg )
{
	m_nSecCode = pMsg->mSecurityCode;
	m_nHigh = pMsg->mHighPrice;
	m_nLow = pMsg->mLowPrice;
	m_nLast = pMsg->mLastPrice;
	setDataInt( SEC_CODE, m_nSecCode, STDUtil::INTEGER_5_DIGIT );
	setDataInt( SEC_HIGH, pMsg->mHighPrice, STDUtil::INTEGER_3_DP );
	setDataInt( SEC_LOW, pMsg->mLowPrice, STDUtil::INTEGER_3_DP );
	setDataInt( SEC_LAST, pMsg->mLastPrice, STDUtil::INTEGER_3_DP );
	setDataInt64( SEC_SHARES_TRADED, (long long)pMsg->mSharesTraded, STDUtil::INTEGER_MILLION_SHORT_FORM );
	setDataInt64( SEC_TURNOVER, (long long)pMsg->mTurnover, STDUtil::INTEGER_3_DP_SHORT_FORM_2_DP );
	setDataInt( SEC_VWAP, pMsg->mVWAP, STDUtil::INTEGER_3_DP );
	setDataInt( SEC_SS_SHARES_TRADED, pMsg->mShortSellSharesTraded, STDUtil::INTEGER_NORMAL );
	setDataInt64( SEC_SS_TURNOVER, (long long)pMsg->mShortSellTurnover );

	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

int Statistics::getHigh()
{
	return m_nHigh;
}

int Statistics::getLow()
{
	return m_nLow;
}

int Statistics::getLast()
{
	return m_nLast;
}

