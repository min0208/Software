#ifndef AGGREGATE_OBU_H
#define AGGREGATE_OBU_H

#include "datamodules/secmsgbase.h"

#include "include/common/XdpStructs.h"

#include <deque>

class AggregateOBU : public SecMsgBase
{
	public:
		enum ORDER_SIDE
		{
			BID = 0,
			ASK
		};

		enum ORDER_ACTION 
		{
			NEW,
			CHANGE,
			DELETE,
			CLEAR = 74
		};

		struct ORDER
		{
			unsigned int nSide;
			unsigned int nPriceLevel;
			unsigned long long nQty;
			unsigned int nPrice;
			unsigned int nNoOfOrder;
			unsigned int nUpdateAction;

			bool operator <= ( ORDER& t )
			{
				return ( nPrice <= t.nPrice );
			};

			bool operator >= ( ORDER& t )
			{
				return ( nPrice >= t.nPrice );
			};

			bool operator == ( ORDER& t )
			{
				return ( nPrice == t.nPrice );
			};
		};

	public:
		AggregateOBU();
		AggregateOBU( Xdp::TenBBOs* pMsg );
		~AggregateOBU();

		int process( Xdp::TenBBOs* pMsg );
		vector<ORDER>* getOrderUpdate();

	protected:
		vector<ORDER> m_vOrderUpdate;
};

#endif
