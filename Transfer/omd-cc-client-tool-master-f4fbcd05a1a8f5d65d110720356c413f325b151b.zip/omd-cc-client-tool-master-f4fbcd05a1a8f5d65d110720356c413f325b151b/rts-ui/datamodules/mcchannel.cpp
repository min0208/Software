#include "datamodules/mcchannel.h"

#include "std/stdmutexlocker.h"

MCChannel::MCChannel()
{
}

MCChannel::~MCChannel()
{
}

void MCChannel::setData( MCStatus& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_oMCStatus = oData;
}

int MCChannel::getStatus() 
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oMCStatus.getStatus();
}

const char* MCChannel::getChannelNum()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oMCStatus.getChannelNum();
}

const char* MCChannel::getType()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oMCStatus.getType();
}


