#ifndef MARKET_DEF_H 
#define MARKET_DEF_H

#include "datamodules/mktmsgbase.h"
#include "include/common/XdpStructs.h"

class MarketDef : public MktMsgBase
{
	public:
		MarketDef();
		MarketDef( Xdp::MarketStatic* pMsg );
		~MarketDef();

		int process( Xdp::MarketStatic* pMsg );

	protected:
};

#endif
