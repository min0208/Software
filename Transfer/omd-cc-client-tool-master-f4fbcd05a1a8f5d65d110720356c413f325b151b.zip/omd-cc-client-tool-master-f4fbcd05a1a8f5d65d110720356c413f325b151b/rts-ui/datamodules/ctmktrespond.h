#ifndef CT_MKT_RESPOND_H 
#define CT_MKT_RESPOND_H

#include "datamodules/ctrespond.h"

#include "include/common/ClientToolStructs.h"

class CTMktRespond : public CTRespond
{
	public:
		CTMktRespond();
		CTMktRespond( CTMktSnapShotRespond* pMsg );
		~CTMktRespond();

	protected:
		int process( CTMktSnapShotRespond* pMsg );
};

#endif
