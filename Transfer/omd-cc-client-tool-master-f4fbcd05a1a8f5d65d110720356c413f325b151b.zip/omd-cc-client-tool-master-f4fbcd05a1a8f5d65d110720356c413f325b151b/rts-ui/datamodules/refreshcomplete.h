#ifndef REFRESH_COMPLETE_H 
#define REFRESH_COMPLETE_H

#include "include/common/XdpStructs.h"

class RefreshComplete
{
	public:
		RefreshComplete();
		RefreshComplete( Xdp::RefreshComplete* pMsg );
		~RefreshComplete();
};

#endif
