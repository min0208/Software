#ifndef REFERENCE_PRICE_H
#define REFERENCE_PRICE_H

#include "datamodules/secmsgbase.h"

#include "include/common/XdpStructs.h"

class ReferencePrice : public SecMsgBase
{
	public:
		ReferencePrice();
		ReferencePrice( Xdp::ReferencePrice* pMsg );
		~ReferencePrice();

		int process( Xdp::ReferencePrice* pMsg );
	protected:

};

#endif
