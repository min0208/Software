#include "datamodules/ctcurrespond.h"
#include "modules/imagecontrol.h"
#include "main.h"

#define LOGC "|CTSvrCur| "

CTSvrCurRespond::CTSvrCurRespond()
{
}

CTSvrCurRespond::CTSvrCurRespond( CTCurSnapShotRespond* pMsg ) :
	CTRespond( (CTSnapShotRespond*)pMsg )
{
	process( pMsg );
}

CTSvrCurRespond::~CTSvrCurRespond()
{
}

int CTSvrCurRespond::process( CTCurSnapShotRespond* pMsg )
{
	if ( pMsg->mRespondCode != CT_SUCCESS )
	{
		STDGetLogger()->log( STDLOG_L3, LOGC "receive CT server negative response code|%d|", pMsg->mRespondCode );
	}

	STDGetLogger()->log( STDLOG_L7, LOGC "CTSvrCurRespond rsp code|%d|", pMsg->mRespondCode );

	ImageControl::inst()->resetCurrency();
	
	return SUCCESS;
}
