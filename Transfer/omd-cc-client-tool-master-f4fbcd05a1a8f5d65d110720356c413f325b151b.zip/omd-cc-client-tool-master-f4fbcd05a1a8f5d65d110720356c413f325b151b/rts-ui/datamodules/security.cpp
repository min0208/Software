#include "datamodules/security.h"
#include "std/stdmutexlocker.h"
#include "std/stdapp.h"

#include <algorithm>


#define LOGC "|Security| "

Security::Security() :
	m_nBidPrice(0),
	m_nAskPrice(0),
	m_sSpreadTableCode("01"),
	m_bClosing(false),
	m_bOI(false),
	m_bRefPrice(false),
	m_bVCM(false)
{
}

Security::~Security()
{
}

bool Security::insertOrUpdateAskQ( int nAction, AggregateOBU::ORDER& tOrder )
{
	list<AggregateOBU::ORDER>::iterator oItr = m_qAsk.begin();
	bool bUpdate = false;

	//STDGetLogger()->log( STDLOG_L2, LOGC "seccode|%s| AggregateOBU insert. new price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel );

	while ( oItr != m_qAsk.end() )
	{
		if ( tOrder.nPrice > 0 )
		{
			if ( tOrder <= *oItr )
			{
				if ( tOrder == *oItr )
				{
					if ( nAction == AggregateOBU::NEW )
					{
						STDGetLogger()->log( STDLOG_L2, LOGC "seccode|%s| AggregateOBU insert error. ask order already exists. old price|%d| order|%d| qty|%d| level|%d|. new price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), oItr->nPrice, oItr->nNoOfOrder, oItr->nQty, oItr->nPriceLevel, tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel );
					}
					else
					{
						STDGetLogger()->log( STDLOG_L6, LOGC "seccode|%s| AggregateOBU ask update. old price|%d| order|%d| qty|%d| level|%d|. new price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), oItr->nPrice, oItr->nNoOfOrder, oItr->nQty, oItr->nPriceLevel, tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel );
					}

					*oItr = tOrder;         // update
				}
				else
				{
					if ( nAction == AggregateOBU::CHANGE )
					{
						STDGetLogger()->log( STDLOG_L2, LOGC "seccode|%s| AggregateOBU update error. ask order not found. price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel );
					}
					else
					{
						STDGetLogger()->log( STDLOG_L6, LOGC "seccode|%s| AggregateOBU ask insert. new price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel );
					}

					m_qAsk.insert( oItr, tOrder );  // insert
				}

				bUpdate = true;
				break;
			}
		}

		oItr++;
	};

	if ( !bUpdate )
	{
		if ( nAction == AggregateOBU::CHANGE )
		{
			STDGetLogger()->log( STDLOG_L2, LOGC "seccode|%s| AggregateOBU update error. ask order not found. price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel );
		}
		else
		{
			STDGetLogger()->log( STDLOG_L6, LOGC "seccode|%s| AggregateOBU ask insert. price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel );
		}

		m_qAsk.push_back( tOrder );
	}

	reorderPriceLevel( m_qAsk );

	if ( m_qAsk.size() > MAX_ORDER_DEPTH )
	{
		m_qAsk.resize( MAX_ORDER_DEPTH );
	}

	m_nAskPrice = (m_qAsk.size() > 0) ? m_qAsk.begin()->nPrice : 0;

	return true;
}

bool Security::insertOrUpdateBidQ( int nAction, AggregateOBU::ORDER& tOrder )
{
	list<AggregateOBU::ORDER>::iterator oItr = m_qBid.begin();
	bool bUpdate = false;

	while ( oItr != m_qBid.end() )
	{
		if ( tOrder.nPrice > 0 )
		{
			if ( tOrder >= *oItr )
			{
				if ( tOrder == *oItr )
				{
					if ( nAction == AggregateOBU::NEW )
					{
						STDGetLogger()->log( STDLOG_L2, LOGC "seccode|%s| AggregateOBU insert error. bid order already exists. old price|%d| order|%d| qty|%d| level|%d|. new price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), oItr->nPrice, oItr->nNoOfOrder, oItr->nQty, oItr->nPriceLevel, tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel );
					}
					else
					{
						STDGetLogger()->log( STDLOG_L6, LOGC "seccode|%s| AggregateOBU bid update. old price|%d| order|%d| qty|%d| level|%d|. new price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), oItr->nPrice, oItr->nNoOfOrder, oItr->nQty, oItr->nPriceLevel, tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel );
					}

					*oItr = tOrder;		// update
				}
				else
				{
					if ( nAction == AggregateOBU::CHANGE )
					{
						STDGetLogger()->log( STDLOG_L2, LOGC "seccode|%s| AggregateOBU update error. bid order not found. price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel );
					}
					else
					{
						STDGetLogger()->log( STDLOG_L6, LOGC "seccode|%s| AggregateOBU bid insert. price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel );
					}

					m_qBid.insert( oItr, tOrder );	// insert
				}

				bUpdate = true;
				break;
			}
		}

		oItr++;
	};

	if ( !bUpdate )
	{
		if ( nAction == AggregateOBU::CHANGE )
		{
			STDGetLogger()->log( STDLOG_L2, LOGC "seccode|%s| AggregateOBU update error. bid order not found. price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel );
		}
		else
		{
			STDGetLogger()->log( STDLOG_L6, LOGC "seccode|%s| AggregateOBU bid insert. new price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel );
		}

		m_qBid.push_back( tOrder );
	}

	reorderPriceLevel( m_qBid );

	if ( m_qBid.size() > MAX_ORDER_DEPTH )
	{
		m_qBid.resize( MAX_ORDER_DEPTH );
	}

	// set BEST BID price = 1st item
	m_nBidPrice = (m_qBid.size() > 0) ? m_qBid.begin()->nPrice : 0;

	//dumpQ();

	return true;
}

bool Security::deleteBidQ( AggregateOBU::ORDER& tOrder )
{
	list<AggregateOBU::ORDER>::iterator oItr = m_qBid.begin();
	bool bDelete = false;

	while ( oItr != m_qBid.end() )
	{
		if ( tOrder.nPrice > 0 )
		{
			if ( tOrder == *oItr )
			{
				if ( tOrder.nQty != oItr->nQty )
				{
					STDGetLogger()->log( STDLOG_L2, LOGC "seccode|%s| AggregateOBU delete error. bid order - qty not match. new msg price|%d| order|%d| qty|%d| level|%d|. memory price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel, oItr->nPrice, oItr->nNoOfOrder, oItr->nQty, oItr->nPriceLevel );
				}

				m_qBid.erase( oItr );
				bDelete = true;
				break;
			}
		}
		oItr++;
	};

	if ( bDelete )
	{
		reorderPriceLevel( m_qBid );

		if ( m_qBid.size() > MAX_ORDER_DEPTH )
		{
			m_qBid.resize( MAX_ORDER_DEPTH );
		}

		// set BEST BID price = 1st item
		m_nBidPrice = (m_qBid.size() > 0) ? m_qBid.begin()->nPrice : 0;
	}
	else
	{
		STDGetLogger()->log( STDLOG_L2, LOGC "seccode|%s| AggregateOBU delete error. bid order not found. price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel );
	}

	return true;
}

bool Security::deleteAskQ( AggregateOBU::ORDER& tOrder )
{
	list<AggregateOBU::ORDER>::iterator oItr = m_qAsk.begin();
	bool bDelete = false;

	while ( oItr != m_qAsk.end() )
	{
		if ( tOrder.nPrice > 0 )
		{
			if ( tOrder == *oItr )
			{
				if ( tOrder.nQty != oItr->nQty )
				{
					STDGetLogger()->log( STDLOG_L2, LOGC "seccode|%s| AggregateOBU delete error. ask order - qty not match. new msg price|%d| order|%d| qty|%d| level|%d|. memory price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel, oItr->nPrice, oItr->nNoOfOrder, oItr->nQty, oItr->nPriceLevel );
				}

				m_qAsk.erase( oItr );
				bDelete = true;
				break;
			}
		}
		oItr++;
	};

	if ( bDelete )
	{
		reorderPriceLevel( m_qAsk );

		if ( m_qAsk.size() > MAX_ORDER_DEPTH )
		{
			m_qAsk.resize( MAX_ORDER_DEPTH );
		}

		// set the BEST ASK price = 1st item
		m_nAskPrice = (m_qAsk.size() > 0) ? m_qAsk.begin()->nPrice : 0;
	}
	else
	{
		STDGetLogger()->log( STDLOG_L2, LOGC "seccode|%s| AggregateOBU delete error. ask order not found. price|%d| order|%d| qty|%d| level|%d|", m_sSecCode.c_str(), tOrder.nPrice, tOrder.nNoOfOrder, tOrder.nQty, tOrder.nPriceLevel );
	}

	return true;
}

bool Security::clearAskQ()
{
	m_qAsk.clear();
	return true;
}

bool Security::clearBidQ()
{
	m_qBid.clear();
	return true;
}

bool Security::reorderPriceLevel( list<AggregateOBU::ORDER>& qQueue )
{
	list<AggregateOBU::ORDER>::iterator oItr = qQueue.begin();

	int nPriceLevel = 1;

	while ( oItr != qQueue.end() )
	{
		(*oItr).nPriceLevel = nPriceLevel++;
		oItr++;
	};

	return true;
}

void Security::dumpQ()
{
	list<AggregateOBU::ORDER>::iterator oItr = m_qAsk.begin();

	string sLogMsg;

	sLogMsg = "ASK Q\n";

	while ( oItr != m_qAsk.end() )
	{
		char sText[ MAX_TEXT];
		sprintf( sText, "seccode|%s| L|%d| price|%d| qty|%llu| order|%d|\n", m_sSecCode.c_str(), (*oItr).nPriceLevel, (*oItr).nPrice, (*oItr).nQty, (*oItr).nNoOfOrder );
		sLogMsg += sText;
		oItr++;
	}

	STDGetLogger()->log( 6, LOGC "%s", sLogMsg.c_str() );

	oItr = m_qBid.begin();
	sLogMsg = "BID Q\n";

	while ( oItr != m_qBid.end() )
	{
		char sText[ MAX_TEXT];
		sprintf( sText, "seccode|%s| L|%d| price|%d| qty|%llu| order|%d|\n", m_sSecCode.c_str(), (*oItr).nPriceLevel, (*oItr).nPrice, (*oItr).nQty, (*oItr).nNoOfOrder );
		sLogMsg += sText;
		oItr++;
	}

	STDGetLogger()->log( 6, LOGC "%s", sLogMsg.c_str() );
}

void Security::setData( AggregateOBU& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sSecCode = oData.getData( SEC_CODE );

	vector<AggregateOBU::ORDER>* pOrderUpdate = oData.getOrderUpdate();

	//STDGetLogger()->log( 1, "AggregateOBU size|%d|", pOrderUpdate->size() );

	for ( unsigned int i=0; i<pOrderUpdate->size(); i++ )
	{
		AggregateOBU::ORDER& tOrder = (*pOrderUpdate)[ i];

		switch ( tOrder.nUpdateAction )
		{
			case AggregateOBU::NEW:
			case AggregateOBU::CHANGE:
				{
					( tOrder.nSide == AggregateOBU::BID ) ? insertOrUpdateBidQ(tOrder.nUpdateAction, tOrder) : insertOrUpdateAskQ(tOrder.nUpdateAction, tOrder);
					break;
				}
			case AggregateOBU::DELETE:
				{
					( tOrder.nSide == AggregateOBU::BID ) ? deleteBidQ(tOrder) : deleteAskQ(tOrder);
					break;
				}
			case AggregateOBU::CLEAR:
				{
					( tOrder.nSide == AggregateOBU::BID ) ? clearBidQ() : clearAskQ();
					break;
				}
		}
	}
}

void Security::setData( SecurityDef& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sSecCode = oData.getData( SEC_CODE );
	m_sSpreadTableCode = oData.getData( SEC_SPREAD_TABLE_CODE );
	m_oSecurityDef = oData;
}

void Security::setData( Yield& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sSecCode = oData.getData( SEC_CODE );
	m_oYield= oData;
}

void Security::setData( VCMTrigger& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sSecCode = oData.getData( SEC_CODE );
	m_oVCMTrigger= oData;
	m_bVCM = true;
}

void Security::setData( OrderImbalance& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sSecCode = oData.getData( SEC_CODE );
	m_oOrderImbalance = oData;
	m_bOI = true;
}

void Security::setData( ReferencePrice& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sSecCode = oData.getData( SEC_CODE );
	m_oReferencePrice = oData;
	m_bRefPrice = true;
}

void Security::setData( SecurityStatus& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sSecCode = oData.getData( SEC_CODE );
	m_oSecurityStatus = oData;
}

void Security::setData( TradeTicker& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sSecCode = oData.getData( SEC_CODE );

	if ( m_vTradeTicker.size() > MAX_TRADE_TICKER_DISPLAY )
	{
		m_vTradeTicker.pop_front();
	}

	m_vTradeTicker.push_back( oData );
}

void Security::setData( Statistics& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sSecCode = oData.getData( SEC_CODE );
	m_oStatistics = oData;
}

void Security::setData( Nominal& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sSecCode = oData.getData( SEC_CODE );
	m_oNominal = oData;
}

void Security::setData( ClosingPrice& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sSecCode = oData.getData( SEC_CODE );
	m_oClosingPrice = oData;
	m_bClosing = true;
}

void Security::setData( IEP& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sSecCode = oData.getData( SEC_CODE );
	m_oIEP = oData;
}

void Security::setData( LiquidityProvider& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sSecCode = oData.getData( SEC_CODE );
	m_oLiquidityProvider = oData;
}

SecurityDef Security::getSecurityDef()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oSecurityDef;
}

Statistics Security::getStatistics()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oStatistics;
}

LiquidityProvider Security::getLiquidityProvider()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oLiquidityProvider;
}

Nominal Security::getNominal()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oNominal;
}

ClosingPrice Security::getClosing()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oClosingPrice;
}

SecurityStatus Security::getSecurityStatus()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oSecurityStatus;
}

Yield Security::getYield()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oYield;
}

VCMTrigger Security::getVCMTrigger()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oVCMTrigger;
}

OrderImbalance Security::getOrderImbalance()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oOrderImbalance;
}

ReferencePrice Security::getReferencePrice()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oReferencePrice;
}

IEP Security::getIEP()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oIEP;
}

bool Security::getTradeTicker( unsigned int nRecordNum, TradeTicker& oTradeTicker )
{
	STDMutexLocker oLocker(m_oMutex);

	if ( (nRecordNum < 0) || (nRecordNum >= m_vTradeTicker.size()) )	return false;

	oTradeTicker = m_vTradeTicker[ nRecordNum];

	return true;
}

bool Security::getBidQ( list<AggregateOBU::ORDER>& oOrderQ )
{
	STDMutexLocker oLocker(m_oMutex);

	oOrderQ = m_qBid;

	return true;
}

bool Security::getAskQ( list<AggregateOBU::ORDER>& oOrderQ )
{
	STDMutexLocker oLocker(m_oMutex);

	oOrderQ = m_qAsk;

	return true;
}

bool Security::getBQBid( BrokerQueue& oBQ )
{
	STDMutexLocker oLocker(m_oMutex);

	oBQ = m_oBidBrokerQueue;

	return true;
}

bool Security::getBQAsk( BrokerQueue& oBQ )
{
	STDMutexLocker oLocker(m_oMutex);

	oBQ = m_oAskBrokerQueue;

	return true;
}

const char* Security::getSecCode()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_sSecCode.c_str();
}

int Security::getBidPrice()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_nBidPrice;
}

int Security::getAskPrice()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_nAskPrice;
}

const char* Security::getSpreadTableCode()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_sSpreadTableCode.c_str();
}

int Security::getInstrumentType()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oSecurityDef.getInstrumentType();
}

int Security::getPrevClosingPrice()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oSecurityDef.getPrevClosing();
}

int Security::getNominalPrice()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oNominal.getNominal();
}

int Security::getClosingPrice()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oClosingPrice.getClosingPrice();
}

int Security::getHighPrice()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oStatistics.getHigh();
}

int Security::getLowPrice()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oStatistics.getLow();
}

int Security::getLastPrice()
{
	STDMutexLocker oLocker(m_oMutex);

	return m_oStatistics.getLast();
}

bool Security::isOI()
{
	return m_bOI;
}

bool Security::isClosed()
{
	return m_bClosing;
}

bool Security::isRefPrice()
{
	return m_bRefPrice;
}

bool Security::isVCM()
{
	return m_bVCM;
}

bool Security::getTradeTicker( int nNoOfTrade, vector<TradeTicker>& vData )
{
        vData.clear();

        STDMutexLocker oLocker(m_oMutex);

        if ( nNoOfTrade == 0 )
        {
                ////////////////////////////////////////
                // return all trade if nNoOfTrade = 0
                //
                std::copy( m_vTradeTicker.begin(), m_vTradeTicker.end(), std::back_inserter(vData) );

                return true;
        }

        deque<TradeTicker>::iterator oItr = m_vTradeTicker.end();
        oItr -= nNoOfTrade;

        if ( oItr >= m_vTradeTicker.begin() )
        {
                std::copy( oItr, m_vTradeTicker.end(), std::back_inserter(vData) );
        }
        else
        {
                std::copy( m_vTradeTicker.begin(), m_vTradeTicker.end(), std::back_inserter(vData) );
        }

        return true;
}

void Security::setBidBrokerQueue( BrokerQueue& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_oBidBrokerQueue = oData;
}

void Security::setAskBrokerQueue( BrokerQueue& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_oAskBrokerQueue = oData;
}

void Security::reset()
{
	STDMutexLocker oLocker(m_oMutex);

	m_oBidBrokerQueue.reset();
	m_oAskBrokerQueue.reset();

	m_vTradeTicker.clear();
	m_qBid.clear();
	m_qAsk.clear();
	m_bClosing = false;
	m_bOI = false;
	m_bRefPrice = false;
}

