#include "datamodules/refreshcomplete.h"

#include "std/stdapp.h"

#define LOGC "|RefreshC| "

RefreshComplete::RefreshComplete()
{
}

RefreshComplete::RefreshComplete( Xdp::RefreshComplete* pMsg )
{
        STDGetLogger()->log( STDLOG_L6, LOGC "last seqnum|%d|", pMsg->mLastSeqNum );
}

RefreshComplete::~RefreshComplete()
{
}

