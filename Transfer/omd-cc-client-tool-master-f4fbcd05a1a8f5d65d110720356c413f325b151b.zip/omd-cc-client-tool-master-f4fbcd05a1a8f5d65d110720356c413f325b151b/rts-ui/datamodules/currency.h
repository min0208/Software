#ifndef CURRENCY_H
#define CURRENCY_H

#include <string>

#include "datamodules/currencyrate.h"

using namespace std;

class Currency
{
	public:
		Currency();
		~Currency();

		const char* getCurrencyCode();

		void setData( CurrencyRate& oData );
		
		CurrencyRate getCurrencyRate();

	protected:
		string m_sCurrencyCode;

		CurrencyRate m_oCurrencyRate;

		STDMutex m_oMutex;
};

#endif

