#ifndef SECURITY_H
#define SECURITY_H

#include <string>
#include <list>
#include <deque>

#include "datamodules/securitydef.h"
#include "datamodules/securitystatus.h"
#include "datamodules/statistics.h"
#include "datamodules/nominal.h"
#include "datamodules/closingprice.h"
#include "datamodules/aggregateobu.h"
#include "datamodules/liquidityprovider.h"
#include "datamodules/iep.h"
#include "datamodules/tradeticker.h"
#include "datamodules/yield.h"
#include "datamodules/vcmtrigger.h"
#include "datamodules/orderimbalance.h"
#include "datamodules/referenceprice.h"
#include "datamodules/brokerqueue.h"

using namespace std;

class Security
{
	public:
		Security();
		~Security();

		const char* getSecCode();
		int getBidPrice();
		int getAskPrice();
		int getNominalPrice();
		int getClosingPrice();
		int getHighPrice();
		int getLowPrice();
		int getLastPrice();
		int getPrevClosingPrice();
		int getTradePrice( unsigned int nRecordNum );
		const char* getSpreadTableCode();
		int getInstrumentType();
		bool isClosed();
		bool isOI();
		bool isRefPrice();
		bool isVCM();

		void reset();

		void setData( SecurityDef& oData );
		void setData( SecurityStatus& oData );
		void setData( Statistics& oData );
		void setData( Nominal& oData );
		void setData( ClosingPrice& oData );
		void setData( IEP& oData );
		void setData( AggregateOBU& oData );
		void setData( TradeTicker& oData );
		void setData( LiquidityProvider& oData );
		void setData( Yield& oData );
		void setData( VCMTrigger& oData );
		void setData( ReferencePrice& oData );
		void setData( OrderImbalance& oData );
		void setData( BrokerQueue& oData );
		void setBidBrokerQueue( BrokerQueue& oData );
		void setAskBrokerQueue( BrokerQueue& oData );

		SecurityDef getSecurityDef();
		LiquidityProvider getLiquidityProvider();
		Statistics getStatistics();
		SecurityStatus getSecurityStatus();
		Nominal getNominal();
		ClosingPrice getClosing();
		IEP getIEP();
		Yield getYield();
		VCMTrigger getVCMTrigger();
		ReferencePrice getReferencePrice();
		OrderImbalance getOrderImbalance();

		bool getTradeTicker( int nNoOfTrade, vector<TradeTicker>& vData );
		bool getTradeTicker( unsigned int nRecordNum, TradeTicker& oTradeTicker );
		bool getBidQ( list<AggregateOBU::ORDER>& oOrderQ );
		bool getAskQ( list<AggregateOBU::ORDER>& oOrderQ );
		bool getBQBid( BrokerQueue& oBQ );
		bool getBQAsk( BrokerQueue& oBQ );

	protected:
		bool insertOrUpdateBidQ( int nAction, AggregateOBU::ORDER& tOrder );
		bool insertOrUpdateAskQ( int nAction, AggregateOBU::ORDER& tOrder );
		bool deleteAskQ( AggregateOBU::ORDER& tOrder );
		bool deleteBidQ( AggregateOBU::ORDER& tOrder );
		bool clearAskQ();
		bool clearBidQ();
		bool reorderPriceLevel( list<AggregateOBU::ORDER>& qQueue );

		void dumpQ();

	protected:
		BrokerQueue m_oBidBrokerQueue;
		BrokerQueue m_oAskBrokerQueue;

		string m_sSecCode;
		string m_sSpreadTableCode;
		int m_nBidPrice;
		int m_nAskPrice;
		bool m_bClosing;
		bool m_bOI;
		bool m_bRefPrice;
		bool m_bVCM;

		SecurityDef m_oSecurityDef;
		SecurityStatus m_oSecurityStatus;
		Statistics m_oStatistics;
		Nominal m_oNominal;
		ClosingPrice m_oClosingPrice;
		IEP m_oIEP;
		Yield m_oYield;
		LiquidityProvider m_oLiquidityProvider;
		OrderImbalance m_oOrderImbalance;
		VCMTrigger m_oVCMTrigger;
		ReferencePrice m_oReferencePrice;

		deque<TradeTicker> m_vTradeTicker;	// keep the last 4 trade ticker for each security
		list<AggregateOBU::ORDER> m_qBid;
		list<AggregateOBU::ORDER> m_qAsk;

		STDMutex m_oMutex;
};

#endif

