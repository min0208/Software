#include "datamodules/liquidityprovider.h"
#include "modules/imagecontrol.h"
#include "std/stdapp.h"

#define LOGC "|LqProvid| "

LiquidityProvider::LiquidityProvider()
{
}

LiquidityProvider::LiquidityProvider( Xdp::LiquidityProvider* pMsg )
{
	process( pMsg );
}

LiquidityProvider::~LiquidityProvider()
{
}

int LiquidityProvider::process( Xdp::LiquidityProvider* pMsg )
{
	char* pOffset = (char *)&pMsg->mLiquidityProviderRepeatGrp;

	m_nSecCode = pMsg->mSecurityCode;
	setDataInt( SEC_CODE, m_nSecCode, STDUtil::INTEGER_5_DIGIT );

	int nFieldIndex = SEC_ALL_LIQUIDITY_PROVIDER_1;

	string sLiquidityProviderBuf;

	for ( unsigned int i=0; i<pMsg->mNoLiquidityProviders; i++ )
	{
		Xdp::LiquidityProviderRepeatGrp* pSubXdpMsg = (Xdp::LiquidityProviderRepeatGrp*) pOffset;

		if ( i >= MAX_LIQUIDITY_PROVIDER )
		{
			break;
		}

		char sText[ MAX_TEXT];

		sprintf( sText, "%04d ", pSubXdpMsg->mLPBrokerNumber );
		sLiquidityProviderBuf += sText;

		pOffset += sizeof(Xdp::LiquidityProviderRepeatGrp);

		if ( i % 10 == 9 )	// 10 underlying security per row
		{
			setDataStr( nFieldIndex++, sLiquidityProviderBuf.c_str(), sLiquidityProviderBuf.length() );
			sLiquidityProviderBuf.clear();
		}
	}

	setDataStr( nFieldIndex, sLiquidityProviderBuf.c_str(), sLiquidityProviderBuf.length() );

	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

