#include "datamodules/referenceprice.h"
#include "modules/imagecontrol.h"
#include "std/stdapp.h"

#define LOGC "|RefPrice| "

ReferencePrice::ReferencePrice()
{
}

ReferencePrice::ReferencePrice( Xdp::ReferencePrice* pMsg )
{
	process( pMsg );
}

ReferencePrice::~ReferencePrice()
{
}

int ReferencePrice::process( Xdp::ReferencePrice* pMsg )
{
	m_nSecCode = pMsg->mSecurityCode;
	setDataInt( SEC_CODE, m_nSecCode, STDUtil::INTEGER_5_DIGIT );
	setDataInt(SEC_REFERENCE_PRICE_REF_PRICE, pMsg->mReferencePrice, STDUtil::INTEGER_3_DP );
	setDataInt(SEC_REFERENCE_PRICE_LOW_PRICE, pMsg->mReferenceLowPrice, STDUtil::INTEGER_3_DP );
	setDataInt(SEC_REFERENCE_PRICE_HIGH_PRICE, pMsg->mReferenceHighPrice, STDUtil::INTEGER_3_DP );

	STDGetLogger()->log( STDLOG_L6, LOGC "seccode|%d| ref price |%d| low |%d| high |%d|", m_nSecCode, pMsg->mReferencePrice, pMsg->mReferenceLowPrice, pMsg->mReferenceHighPrice);

	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

