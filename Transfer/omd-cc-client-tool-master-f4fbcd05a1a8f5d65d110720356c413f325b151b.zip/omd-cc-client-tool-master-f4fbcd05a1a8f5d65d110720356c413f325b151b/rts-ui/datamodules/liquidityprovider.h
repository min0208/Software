#ifndef LIQUIDITY_PROVIDER_H
#define LIQUIDITY_PROVIDER_H

#include "datamodules/secmsgbase.h"
#include "include/common/XdpStructs.h"

class LiquidityProvider : public SecMsgBase
{
	public:
		LiquidityProvider();
		LiquidityProvider( Xdp::LiquidityProvider* pMsg );
		~LiquidityProvider();

		int process( Xdp::LiquidityProvider* pMsg );

	protected:
};

#endif
