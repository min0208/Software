#include "datamodules/iep.h"
#include "modules/imagecontrol.h"

IEP::IEP()
{
}

IEP::IEP( Xdp::IEP* pMsg )
{
	process( pMsg );
}

IEP::~IEP()
{
}

int IEP::process( Xdp::IEP* pMsg )
{
	m_nSecCode = pMsg->mSecurityCode;
	setDataInt( SEC_CODE, m_nSecCode, STDUtil::INTEGER_5_DIGIT );
	setDataInt( SEC_IEP, pMsg->mPrice, STDUtil::INTEGER_3_DP );
	setDataInt64( SEC_IEV, (long long)pMsg->mAggregateQuantity );

	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

