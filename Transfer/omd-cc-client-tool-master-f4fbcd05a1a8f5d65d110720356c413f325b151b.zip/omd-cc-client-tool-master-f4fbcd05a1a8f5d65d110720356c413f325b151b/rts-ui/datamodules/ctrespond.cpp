#include "datamodules/ctrespond.h"

#include "main.h"

#define LOGC "|CTRespon| "

CTRespond::CTRespond()
{
}

CTRespond::CTRespond( CTSnapShotRespond* pMsg )
{
	process( pMsg );
}

CTRespond::~CTRespond()
{
}

int CTRespond::process( CTSnapShotRespond* pMsg )
{
	if ( pMsg->mRespondCode != CT_SUCCESS )
	{
		STDGetLogger()->log( STDLOG_L3, LOGC "receive negative respond code|%d| for request|%d|", pMsg->mRespondCode, pMsg->mInfoType );
	}

	ClientTool::inst()->recvCTSvrResponse( pMsg->mRespondCode );

	return SUCCESS;
}

