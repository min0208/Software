#ifndef NEWS_H 
#define NEWS_H

#include "datamodules/msgbase.h"
#include "std/stdmutex.h"
#include "include/common/XdpStructs.h"

class News : public MsgBase
{
	public:
		News();
		News( Xdp::News* pMsg );
		~News();

		int process( Xdp::News* pMsg );
		void setData( News& oData );

		const char* getNewsId();
		const char* getNewsType();
		const char* getHeadline();
		char getLastFragment();
		char getCancelFlag();
		const char* getReleaseTime();
		const char* getMarketCodeStr();
		const char* getSecCodeStr();
		vector<string> getMarketCode();
		vector<int> getSecCode();
		vector<string> getNewsLine();

		void setNewsId( const char* sNewsId );
		void setNewsType( const char* sNewsType );
		void setHeadline( const char* sHeadline );
		void setLastFragment( char cLastFragment );
		void setCancelFlag( char cCancelFlag );
		void setReleaseTime( const char* sReleaseTime );
		void setMarketCodeStr( const char* sMarketCodeStr );
		void setSecCodeStr( const char* sSecCodeStr );
		void setNewsLine( vector<string>& vNewsLine );

	protected:
		string m_sNewsType;
		string m_sNewsId;
		string m_sHeadline;
		char m_cCancelFlag;
		char m_cLastFragment;
		string m_sReleaseTime;
		vector<string> m_vMarketCode;
		vector<int> m_vSecCode;
		vector<string> m_vNewsLine;
		string m_sMarketCode;
		string m_sSecCode;

		STDMutex m_oMutex;
};

#endif
