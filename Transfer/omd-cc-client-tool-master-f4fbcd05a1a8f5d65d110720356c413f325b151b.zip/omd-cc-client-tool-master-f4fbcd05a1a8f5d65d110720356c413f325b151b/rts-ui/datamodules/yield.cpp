#include "datamodules/yield.h"
#include "modules/imagecontrol.h"
#include "std/stdapp.h"

#define LOGC "|Yield   | "

Yield::Yield()
{
}

Yield::Yield( Xdp::Yield* pMsg )
{
	process( pMsg );
}

Yield::~Yield()
{
}

int Yield::process( Xdp::Yield* pMsg )
{
	m_nSecCode = pMsg->mSecurityCode;
	setDataInt( SEC_CODE, m_nSecCode, STDUtil::INTEGER_5_DIGIT );

	if ( pMsg->mYield > 0 )
	{
		setDataInt( SEC_YIELD, pMsg->mYield, STDUtil::INTEGER_3_DP );
	}
	else
	{
		setData( SEC_YIELD, " " );
	}

	STDGetLogger()->log( STDLOG_L6, "seccode|%d| yield|%d|", m_nSecCode, pMsg->mYield );

	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

