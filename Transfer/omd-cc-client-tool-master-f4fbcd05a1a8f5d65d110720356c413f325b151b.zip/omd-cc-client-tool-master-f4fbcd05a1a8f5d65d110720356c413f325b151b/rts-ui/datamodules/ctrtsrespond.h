#ifndef CT_RTS_RESPOND_H 
#define CT_RTS_RESPOND_H

#include "datamodules/ctrespond.h"

#include "include/common/ClientToolStructs.h"

class CTRtsRespond : public CTRespond
{
	public:
		CTRtsRespond();
		CTRtsRespond( CTRetransRespond* pMsg );
		~CTRtsRespond();

	protected:
		int process( CTRetransRespond* pMsg );
};

#endif
