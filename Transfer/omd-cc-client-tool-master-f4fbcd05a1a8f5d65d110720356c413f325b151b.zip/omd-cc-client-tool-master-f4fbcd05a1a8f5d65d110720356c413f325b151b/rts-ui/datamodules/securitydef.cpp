#include "datamodules/securitydef.h"
#include "modules/imagecontrol.h"
#include "std/stdapp.h"

#define LOGC "|SecDef  | "

SecurityDef::SecurityDef()
{
}

SecurityDef::SecurityDef( Xdp::SecurityStatic* pMsg )
{
	process( pMsg );
}

SecurityDef::~SecurityDef()
{
}

int SecurityDef::process( Xdp::SecurityStatic* pMsg )
{
	char* pOffset = (char*) &pMsg->mSecurityStaticRepeatGrp;

	m_nSecCode = pMsg->mSecurityCode;
	m_nPrevClosing = pMsg->mPreviousClosingPrice;

	setDataInt( SEC_CODE, m_nSecCode, STDUtil::INTEGER_5_DIGIT );
	setDataStr( SEC_MARKET, pMsg->mMarketCode, sizeof(pMsg->mMarketCode) );
	setDataStr( SEC_ISIN_CODE, pMsg->mISINCode, sizeof(pMsg->mISINCode) );
	setDataStr( SEC_INSTRUMENT_TYPE, pMsg->mInstrumentType, sizeof(pMsg->mInstrumentType) );
	setDataStr( SEC_SPREAD_TABLE_CODE, pMsg->mSpreadTableCode, sizeof(pMsg->mSpreadTableCode) );
	setDataStr( SEC_NAME, pMsg->mSecurityShortName, sizeof(pMsg->mSecurityShortName) );
	setDataStr( SEC_CURRENCY_CODE, pMsg->mCurrencyCode, sizeof(pMsg->mCurrencyCode) );
	setDataUnicode( SEC_GCCS_NAME, pMsg->mSecurityNameGCCS, sizeof(pMsg->mSecurityNameGCCS) );
	setDataUnicode( SEC_GB_NAME, pMsg->mSecurityNameGB, sizeof(pMsg->mSecurityNameGB) );
	setDataInt( SEC_LOT_SIZE, pMsg->mLotSize, STDUtil::INTEGER_NORMAL );
	setDataInt( SEC_PREVIOUS_CLOSING_PRICE, pMsg->mPreviousClosingPrice, STDUtil::INTEGER_3_DP );
	setDataChar( SEC_VCM_FLAG, pMsg->mVCMFlag );
	setDataChar( SEC_SHORT_SELL_FLAG, pMsg->mShortSellFlag );
	setDataChar( SEC_CAS_FLAG, pMsg->mCASFlag );
	setDataChar( SEC_CCASS_FLAG, pMsg->mCCASSFlag );
	setDataChar( SEC_DUMMY_FLAG, pMsg->mDummySecurityFlag );
	setDataChar( SEC_TEST_FLAG, pMsg->mTestSecurityFlag );
	setDataChar( SEC_STAMP_DUTY_FLAG, pMsg->mStampDutyFlag );
	setDataDate( SEC_LISTING_DATE, pMsg->mListingDate );
	setDataDate( SEC_DELISTING_DATE, pMsg->mDelistingDate );
	int nFreeTextLen = sizeof(pMsg->mFreeText) / 2;	// break the free text to 2 rows
	setDataStr( SEC_FREE_TEXT_1, pMsg->mFreeText, nFreeTextLen );
	setDataStr( SEC_FREE_TEXT_2, &pMsg->mFreeText[ nFreeTextLen], nFreeTextLen );

	char sTmpStr[ 128];
	char sMarketCode[ 128];
	strcpy( sTmpStr, getData(SEC_MARKET) );
	STDUtil::trimRight( sTmpStr, sMarketCode, ' ' );
	setData( SEC_MARKET, sMarketCode );
/*
	///////////////////////////
	// data validation
	//
	checkSecCode( LOGC, m_nSecCode );
	checkMarketCode( LOGC, getData(SEC_MARKET) );
	checkInstrumentType( LOGC, getData(SEC_INSTRUMENT_TYPE) );
	checkSpreadTableCode( LOGC, getData(SEC_SPREAD_TABLE_CODE) );
	checkShortSellFlag( LOGC, pMsg->mShortSellFlag );
	checkVCMFlag( LOGC, pMsg->mVCMFlag );
	checkCASFlag( LOGC, pMsg->mCASFlag );
	checkCCASSFlag( LOGC, pMsg->mCCASSFlag );
	checkDummySecurityFlag( LOGC, pMsg->mDummySecurityFlag );
	checkTestSecurityFlag( LOGC, pMsg->mTestSecurityFlag );
	checkStampDutyFlag( LOGC, pMsg->mStampDutyFlag );
*/
	char sFlag[ MAX_TEXT];
	memset( sFlag, 0, sizeof(sFlag) );

	if ( strncmp(pMsg->mInstrumentType, "EQTY", 4) == 0 )
	{
		m_nInstrumentType = TYPE_EQTY;

		sprintf( sFlag, "%c%c%c%c%c%c%c",
				(pMsg->mShortSellFlag=='Y')?'H':' ',
				(pMsg->mStampDutyFlag=='Y')?'S':' ',
				(pMsg->mCCASSFlag=='Y')?'#':' ',
				(pMsg->mTestSecurityFlag=='Y')?'T':(pMsg->mDummySecurityFlag=='Y'?'D':' '),
				' ', 
				(pMsg->mCASFlag=='Y')?'C':' ',
				(pMsg->mVCMFlag=='Y')?'V':' '
			);
	}
	else if ( (strncmp(pMsg->mInstrumentType, "WRNT", 4) == 0) || (strncmp(pMsg->mInstrumentType, "BWRT", 4) == 0) )
	{
		m_nInstrumentType = (strncmp(pMsg->mInstrumentType, "WRNT", 4) == 0) ? TYPE_WRNT : TYPE_BWRT;

		char sTmp[ MAX_TEXT];
		memset( sTmp, 0, MAX_TEXT );
		strncpy( sTmp, pMsg->mInstrumentType, 4 );

		setDataInt( SEC_CONVERSION_RATIO, pMsg->mConversionRatio, STDUtil::INTEGER_3_DP );
		setDataInt( SEC_STRIKE_PRICE, pMsg->mStrikePrice, STDUtil::INTEGER_3_DP );
		setDataDate( SEC_MATURITY_DATE, pMsg->mMaturityDate );
		setDataChar( SEC_CALL_PUT_FLAG, pMsg->mCallPutFlag );
		setDataChar( SEC_STYLE, pMsg->mStyle );

		sprintf( sFlag, "%c%c%c%c%c%c%c",
				(pMsg->mCallPutFlag=='C')?'C':'P',
				(pMsg->mStampDutyFlag=='Y')?'S':' ',
				(pMsg->mCCASSFlag=='Y')?'#':' ',
				(pMsg->mTestSecurityFlag=='Y')?'T':(pMsg->mDummySecurityFlag=='Y'?'D':' '),
				(pMsg->mStyle=='A')?'A':'E',
				(pMsg->mCASFlag=='Y')?'C':' ',
				(pMsg->mVCMFlag=='Y')?'V':' '
		       );

		Xdp::SecurityStaticRepeatGrp* pSubXdpMsg = (Xdp::SecurityStaticRepeatGrp*) pOffset;

		if ( pMsg->mNoUnderlyingSecurities > 0 )
		{
			// only retrieve the first underlying security code according to requirement
			setDataInt( SEC_UNDERLYING_SEC, pSubXdpMsg->mUnderlyingSecurityCode, STDUtil::INTEGER_5_DIGIT );
		}

		string sUnderSecBuf;
		int nFieldIndex = SEC_ALL_UNDERLYING_SEC_1;

		for ( unsigned int i=0; i<pMsg->mNoUnderlyingSecurities; i++ )
		{
			pSubXdpMsg = (Xdp::SecurityStaticRepeatGrp*) pOffset;

			if ( i >= MAX_UNDERLYING_SEC )
			{
				break;
			}

			char sText[ MAX_TEXT];
			sprintf( sText, "%05d(%d) ", pSubXdpMsg->mUnderlyingSecurityCode, pSubXdpMsg->mUnderlyingSecurityWeight );
			sUnderSecBuf += sText;
			pOffset += sizeof(Xdp::SecurityStaticRepeatGrp);

			if ( i % 5 == 4 )	// 5 underlying security per row
			{
				setDataStr( nFieldIndex++, sUnderSecBuf.c_str(), sUnderSecBuf.length() );
				sUnderSecBuf.clear();
			}
		}

		setDataStr( nFieldIndex, sUnderSecBuf.c_str(), sUnderSecBuf.length() );
/*
		checkCallPutFlag( LOGC, pMsg->mCallPutFlag );

		if ( m_nInstrumentType == TYPE_WRNT )
		{
			checkNoOfUnderlyingSecWRNT(LOGC, pMsg->mNoUnderlyingSecurities);
		}
		else
		{
			checkStyle( LOGC, pMsg->mStyle );
			checkNoOfUnderlyingSecBWRT(LOGC, pMsg->mNoUnderlyingSecurities);
		}
*/
	}
	else if ( strncmp(pMsg->mInstrumentType, "TRST", 4) == 0 )
	{
		m_nInstrumentType = TYPE_TRST;

		sprintf( sFlag, "%c%c%c%c%c%c%c",
				(pMsg->mShortSellFlag=='Y')?'H':' ',
				(pMsg->mStampDutyFlag=='Y')?'S':' ',
				(pMsg->mCCASSFlag=='Y')?'#':' ',
				(pMsg->mTestSecurityFlag=='Y')?'T':(pMsg->mDummySecurityFlag=='Y'?'D':' '),
				' ',
				(pMsg->mCASFlag=='Y')?'C':' ',
				(pMsg->mVCMFlag=='Y')?'V':' '
		       );
	}
	else if ( strncmp(pMsg->mInstrumentType, "BOND", 4) == 0 )
	{
		m_nInstrumentType = TYPE_BOND;

		setDataInt( SEC_COUPON_RATE, pMsg->mCouponRate, STDUtil::INTEGER_3_DP );
		setDataInt( SEC_ACCRUED_INTEREST, pMsg->mAccruedInterest, STDUtil::INTEGER_3_DP );
		setDataChar( SEC_EFN_FLAG, pMsg->mEFNFlag );

		sprintf( sFlag, "%c%c%c%c%c%c%c",
				(pMsg->mEFNFlag=='Y')?'F':' ',
				(pMsg->mStampDutyFlag=='Y')?'S':' ',
				(pMsg->mCCASSFlag=='Y')?'#':' ',
				(pMsg->mTestSecurityFlag=='Y')?'T':(pMsg->mDummySecurityFlag=='Y'?'D':' '),
				' ',
				(pMsg->mCASFlag=='Y')?'C':' ',
				(pMsg->mVCMFlag=='Y')?'V':' '
		       );

		//checkEFNFlag( LOGC, pMsg->mEFNFlag );
	}

	setData( SEC_FLAG, sFlag );
//	m_mField[ SEC_FLAG] = sFlag;

	STDGetLogger()->log( STDLOG_L6, LOGC "seccode|%d| name|%s| cname|%s| type|%s| market|%s| flag|%s|", m_nSecCode, getData(SEC_NAME), getData(SEC_GCCS_NAME), getData(SEC_INSTRUMENT_TYPE), getData(SEC_MARKET), getData(SEC_FLAG) );

	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

int SecurityDef::getInstrumentType() const
{
	return m_nInstrumentType;
}

int SecurityDef::getPrevClosing()
{
	return m_nPrevClosing;
}

const char* SecurityDef::getSpreadTableCode()
{
	return getData( SEC_SPREAD_TABLE_CODE );
}

