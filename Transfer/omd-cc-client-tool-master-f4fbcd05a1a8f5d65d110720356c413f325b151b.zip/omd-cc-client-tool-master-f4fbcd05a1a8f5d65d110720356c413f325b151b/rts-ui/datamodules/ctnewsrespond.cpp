#include "datamodules/ctnewsrespond.h"
#include "modules/imagecontrol.h"
#include "main.h"

#define LOGC "|CTSvrNew| "

CTSvrNewsRespond::CTSvrNewsRespond()
{
}

CTSvrNewsRespond::CTSvrNewsRespond( CTNewsRespond* pMsg ) :
	CTRespond( (CTSnapShotRespond*)pMsg )
{
	process( pMsg );
}

CTSvrNewsRespond::~CTSvrNewsRespond()
{
}

int CTSvrNewsRespond::process( CTNewsRespond* pMsg )
{
	if ( pMsg->mRespondCode != CT_SUCCESS )
	{
		STDGetLogger()->log( STDLOG_L3, LOGC "receive CT server negative response code|%d|", pMsg->mRespondCode );
	}

	STDGetLogger()->log( STDLOG_L7, LOGC "CTSvrNewsRespond rsp code|%d|", pMsg->mRespondCode );

	ImageControl::inst()->resetNews();
	
	return SUCCESS;
}
