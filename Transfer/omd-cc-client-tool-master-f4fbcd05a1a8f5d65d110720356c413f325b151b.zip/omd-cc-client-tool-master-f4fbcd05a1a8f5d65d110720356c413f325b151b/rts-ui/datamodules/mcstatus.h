#ifndef MC_STATUS_H 
#define MC_STATUS_H

#include "datamodules/msgbase.h"

#include "include/common/XdpStructs.h"

class MCStatus : public MsgBase
{
	public:
		MCStatus();
		MCStatus( Xdp::LineStatus* pMsg );
		~MCStatus();

		enum LINE_STATUS 
		{
			ALL_LINE_UP = 1,
			ONE_LINE_DOWN,
			ALL_LINE_DOWN
		};

	public:
		const char* getChannelNum();
		const char* getType();
		int getStatus();

	protected:
		int process( Xdp::LineStatus* pMsg );

	protected:
		int m_nStatus;
};

#endif
