#include "datamodules/mcstatus.h"

#include "modules/imagecontrol.h"
#include "main.h"

#define LOGC "|MCStatus| "

MCStatus::MCStatus() :
	m_nStatus(ALL_LINE_DOWN)
{
}

MCStatus::MCStatus( Xdp::LineStatus* pMsg )
{
	process( pMsg );
}

MCStatus::~MCStatus()
{
}

const char* MCStatus::getChannelNum()
{
	return getData( MC_NUM );
}

const char* MCStatus::getType()
{
	return getData( MC_TYPE );
}

int MCStatus::getStatus()
{
	return m_nStatus;
}

int MCStatus::process( Xdp::LineStatus* pMsg )
{
	STDGetLogger()->log( STDLOG_L6, LOGC "mc%03d type|%c| status|%d|", pMsg->mChannelID, pMsg->mLineType, pMsg->mStatus );

	setDataInt( MC_NUM, pMsg->mChannelID, STDUtil::INTEGER_3_DIGIT );
	setDataChar( MC_TYPE, pMsg->mLineType );
	m_nStatus = pMsg->mStatus;

	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

