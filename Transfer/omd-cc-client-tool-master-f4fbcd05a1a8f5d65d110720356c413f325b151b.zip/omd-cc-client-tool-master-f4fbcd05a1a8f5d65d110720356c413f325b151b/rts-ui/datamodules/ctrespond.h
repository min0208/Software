#ifndef CT_RESPOND_H 
#define CT_RESPOND_H

#include "datamodules/msgbase.h"

#include "include/common/ClientToolStructs.h"

class CTRespond: public MsgBase
{
	public:
		CTRespond();
		CTRespond( CTSnapShotRespond* pMsg );
		~CTRespond();

	protected:
		virtual int process( CTSnapShotRespond* pMsg );
};

#endif
