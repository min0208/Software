#include "datamodules/vcmtrigger.h"
#include "modules/imagecontrol.h"
#include "std/stdapp.h"
#include <time.h>

#define LOGC "|VCMTrigg| "

VCMTrigger::VCMTrigger() : m_nVCMStartTime(0), m_nVCMEndTime(0)
{
}

VCMTrigger::VCMTrigger( Xdp::VCMTrigger* pMsg )
{
	process( pMsg );
}

VCMTrigger::~VCMTrigger()
{
}

int VCMTrigger::process( Xdp::VCMTrigger* pMsg )
{
	m_nSecCode = pMsg->mSecurityCode;
	m_nVCMStartTime=pMsg->mVCMStartTime;
	m_nVCMEndTime=pMsg->mVCMEndTime;

	setDataInt( SEC_CODE, m_nSecCode, STDUtil::INTEGER_5_DIGIT );
	setDataTime64(SEC_VCM_START_TIME, pMsg->mVCMStartTime, STDUtil::TIME_SEC);
	setDataTime64(SEC_VCM_END_TIME, pMsg->mVCMEndTime, STDUtil::TIME_SEC);
	setDataInt(SEC_REFERENCE_PRICE_REF_PRICE, pMsg->mVCMRefPrice, STDUtil::INTEGER_3_DP );
	setDataInt(SEC_REFERENCE_PRICE_LOW_PRICE, pMsg->mVCMLowPrice, STDUtil::INTEGER_3_DP );
	setDataInt(SEC_REFERENCE_PRICE_HIGH_PRICE, pMsg->mVCMHighPrice, STDUtil::INTEGER_3_DP );

	STDGetLogger()->log( STDLOG_L6, LOGC "seccode|%d| start|%s| end|%s| ref price|%d| low|%d| high|%d|", m_nSecCode, getData(SEC_VCM_START_TIME), getData(SEC_VCM_END_TIME), pMsg->mVCMRefPrice, pMsg->mVCMLowPrice, pMsg->mVCMHighPrice);
	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

uint64_t VCMTrigger::getStartTime() 
{ 
	return m_nVCMStartTime;
}

uint64_t VCMTrigger::getEndTime() 
{ 
	return m_nVCMEndTime;
}

