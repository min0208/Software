#include "datamodules/marketdef.h"
#include "modules/imagecontrol.h"
//#include "datamodules/marketturnover.h"
//#include "datamodules/tradingsessionstatus.h"
#include "std/stdapp.h"

#define LOGC "|MktDef  | "

MarketDef::MarketDef()
{
}

MarketDef::MarketDef( Xdp::MarketStatic* pMsg )
{
	process( pMsg );
}

MarketDef::~MarketDef()
{
}

int MarketDef::process( Xdp::MarketStatic* pMsg )
{
	setDataStr( MKT_CODE, pMsg->mMarketCode, sizeof(pMsg->mMarketCode) );
	setDataStr( MKT_NAME, pMsg->mMarketName, sizeof(pMsg->mMarketName) );
	setDataStr( MKT_CURRENCY, pMsg->mCurrencyCode, sizeof(pMsg->mCurrencyCode) );
	setDataInt( MKT_NUM_OF_SEC, pMsg->mNumberOfSecurities, STDUtil::INTEGER_NORMAL );

	char sTmpStr[ 128];
	char sMarketCode[ 128];
	strcpy( sTmpStr, getData(MKT_CODE) );
	STDUtil::trimRight( sTmpStr, sMarketCode, ' ' );

	m_sMarketCode = sMarketCode;
	setData( MKT_CODE, sMarketCode );

	STDGetLogger()->log( STDLOG_L6, LOGC "market code|%s| name|%s| currency|%s| num|%s|", getData(MKT_CODE), getData(MKT_NAME), getData(MKT_CURRENCY), getData(MKT_NUM_OF_SEC) );

	ImageControl::inst()->setData( *this );

/*
	/////////////////////////
	// debug only
	//
	//
	News oNewsData;

	static int ID = 1;

	char sText[ MAX_TEXT];

	sprintf( sText, "%03d", ID++ );
	oNewsData.setNewsId( sText );
	oNewsData.setNewsType( "EXN" );
	oNewsData.setHeadline( "Hello" );
	oNewsData.setLastFragment( 'Y' );
	oNewsData.setCancelFlag( 'N' );
	oNewsData.setReleaseTime( "02/04/2012 12:37:00" );
	oNewsData.setMarketCodeStr( "All" );
	oNewsData.setSecCodeStr( "0005" );

	vector<string> vNewsLine;

	for ( unsigned int i=0; i<10; i++ )
	{
		vNewsLine.push_back( "TEST" );
	}

	oNewsData.setNewsLine( vNewsLine );

	ImageControl::inst()->setData( oNewsData );

	/////////////////////////
	// debug only
	//
	TradingSessionStatus oStatusData;

	oStatusData.setMarketCode( sMarketCode );
	oStatusData.setData( MKT_CODE, sMarketCode );
	oStatusData.setData( MKT_TRADE_SES_ID, "1" );
	oStatusData.setData( MKT_TRADE_SES_SUB_ID, "3" );
	oStatusData.setData( MKT_TRADE_SES_STATUS, "1" );
	oStatusData.setData( MKT_TRADE_SES_CTRL_FLAG, "0" );
	oStatusData.setData( MKT_START_TIME, "07/07/2012 09:00" );
	oStatusData.setData( MKT_END_TIME, "07/07/2012 16:00" );
	oStatusData.setSubId( 3 );
	oStatusData.setStatus( 2 );
	oStatusData.setCtrlFlag( '0' );
	ImageControl::inst()->setData( oStatusData );
	
	/////////////////////////
	// debug only
	//
	MarketTurnover oData;

	oData.setMarketCode( sMarketCode );
	oData.setCurrencyCode( "HKD" );
	oData.setData( MKT_CODE, sMarketCode );
	oData.setData( MKT_CURRENCY, "HKD" );
	oData.setData( MKT_TURNOVER, "12345678" );
	oData.setData( MKT_TURNOVER_SHORT_FORM, "1.23M" );
	ImageControl::inst()->setData( oData );

	oData.setCurrencyCode( "CAD" );
	oData.setData( MKT_CURRENCY, "CAD" );
	oData.setData( MKT_TURNOVER, "28000000000" );
	oData.setData( MKT_TURNOVER_SHORT_FORM, "280M" );
	ImageControl::inst()->setData( oData );

	oData.setCurrencyCode( "" );
	oData.setData( MKT_CURRENCY, "" );
	oData.setData( MKT_TURNOVER, "999000000000" );
	oData.setData( MKT_TURNOVER_SHORT_FORM, "999B" );
	ImageControl::inst()->setData( oData );

	oData.setCurrencyCode( "GBP" );
	oData.setData( MKT_CURRENCY, "GBP" );
	oData.setData( MKT_TURNOVER, "999" );
	oData.setData( MKT_TURNOVER_SHORT_FORM, "999" );
	ImageControl::inst()->setData( oData );

	oData.setCurrencyCode( "USD" );
	oData.setData( MKT_CURRENCY, "USD" );
	oData.setData( MKT_TURNOVER, "888" );
	oData.setData( MKT_TURNOVER_SHORT_FORM, "888" );
	ImageControl::inst()->setData( oData );

	oData.setCurrencyCode( "XXX" );
	oData.setData( MKT_CURRENCY, "XXX" );
	oData.setData( MKT_TURNOVER, "0" );
	oData.setData( MKT_TURNOVER_SHORT_FORM, "0" );
	ImageControl::inst()->setData( oData );
	*/

	return SUCCESS;
}

