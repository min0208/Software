#ifndef TRADING_SESSION_STATUS_H
#define TRADING_SESSION_STATUS_H

#include "datamodules/mktmsgbase.h"

#include "include/common/XdpStructs.h"

#include <vector>

class TradingSessionStatus : public MktMsgBase
{
	public:
		TradingSessionStatus();
		TradingSessionStatus( Xdp::TradingSessionStatus* pMsg );
		~TradingSessionStatus();

		int process( Xdp::TradingSessionStatus* pMsg );

		int getSubId();
		const char* getSubIdStr();
		const char* getSubIdLongStr();
		const char* getSubIdShortStr();

		bool setSubId( int nSubId );
		bool setStatus( int nStatus );
		bool setCtrlFlag( char cCtrlFlag );

		int getStatus();
		const char* getStatusStr();

		char getCtrlFlag();
		const char* getCtrlFlagStr();

		static bool inCAS(const char* marketCode, int* status);

	protected:
		int m_nSubId;
		int m_nStatus;
		char m_cCtrlFlag;
};

#endif
