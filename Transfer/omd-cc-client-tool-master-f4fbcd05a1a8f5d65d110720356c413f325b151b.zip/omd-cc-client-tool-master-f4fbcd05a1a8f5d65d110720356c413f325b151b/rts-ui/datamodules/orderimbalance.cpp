#include "datamodules/orderimbalance.h"

#include "modules/imagecontrol.h"
#include "std/stdapp.h"

#define LOGC "|OrderImb| "

OrderImbalance::OrderImbalance()
{
}

OrderImbalance::OrderImbalance( Xdp::OrderImbalance* pMsg )
{
	process( pMsg );
}

OrderImbalance::~OrderImbalance()
{
}

int OrderImbalance::process( Xdp::OrderImbalance* pMsg )
{
	m_nSecCode = pMsg->mSecurityCode;
	setDataInt( SEC_CODE, m_nSecCode, STDUtil::INTEGER_5_DIGIT );
	setDataChar(SEC_ORDER_IMBALANCE_DIR, pMsg->mOrderImbalanceDir );
	setDataInt(SEC_ORDER_IMBALANCE_QTY, pMsg->mOrderImbalanceQty, STDUtil::INTEGER_NORMAL );
	checkOrderImbalanceDirType(LOGC, pMsg->mOrderImbalanceDir);
	STDGetLogger()->log( STDLOG_L6, LOGC "seccode|%d| direction|%c| qty|%d|", m_nSecCode, pMsg->mOrderImbalanceDir, pMsg->mOrderImbalanceQty );

	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

