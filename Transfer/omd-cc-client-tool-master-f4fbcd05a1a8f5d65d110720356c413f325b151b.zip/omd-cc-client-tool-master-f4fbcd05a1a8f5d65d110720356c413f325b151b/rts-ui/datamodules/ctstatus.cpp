#include "datamodules/ctstatus.h"

#include "modules/imagecontrol.h"
#include "main.h"

#define LOGC "|CTStatus| "

CTStatus::CTStatus() :
	m_nStatus(DISCONNECT)
{
}

CTStatus::CTStatus( Xdp::CTSvrStatus* pMsg )
{
	process( pMsg );
}

CTStatus::~CTStatus()
{
}

int CTStatus::getStatus()
{
	return m_nStatus;
}

int CTStatus::process( Xdp::CTSvrStatus* pMsg )
{
	m_nStatus = pMsg->mStatus;

        STDGetLogger()->log( STDLOG_L6, LOGC "status|%d|", m_nStatus );

	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

