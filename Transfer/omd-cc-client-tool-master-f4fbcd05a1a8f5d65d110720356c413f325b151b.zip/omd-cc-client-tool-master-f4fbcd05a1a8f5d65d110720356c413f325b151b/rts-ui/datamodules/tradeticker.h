#ifndef TRADE_TICKER_H 
#define TRADE_TICKER_H

#include "datamodules/secmsgbase.h"
#include "include/common/XdpStructs.h"

class TradeTicker : public SecMsgBase
{
	public:
		TradeTicker();
		TradeTicker( Xdp::TradeTicker* pMsg );
		~TradeTicker();

		int process( Xdp::TradeTicker* pMsg );
		int getPrice();
		int getTickerID();
		int getType();

	protected:
		const char* getTradeTickerType( char cType );

	protected:
		int m_nPrice;
		int m_nTickerID;
		int m_nType;
};

#endif
