#include "datamodules/aggregateobu.h"
#include "modules/imagecontrol.h"
#include "std/stdapp.h"

#define LOGC "|Aggregat| "

AggregateOBU::AggregateOBU()
{
}

AggregateOBU::AggregateOBU( Xdp::TenBBOs* pMsg )
{
	process( pMsg );
}

AggregateOBU::~AggregateOBU()
{
}

int AggregateOBU::process( Xdp::TenBBOs* pMsg )
{
	char* pOffset = (char *)&(pMsg->mTenBBOsRepeatGrp);

	m_nSecCode = pMsg->mSecurityCode;
	setDataInt( SEC_CODE, m_nSecCode, STDUtil::INTEGER_5_DIGIT );

	string sLogMsg;

	for ( unsigned int i=0; i<pMsg->mNoEntries; i++ )
	{
		ORDER tOrder;

		Xdp::TenBBOsRepeatGrp* pSubXdpMsg = (Xdp::TenBBOsRepeatGrp*) pOffset;
		tOrder.nQty = pSubXdpMsg->mAggregateQuantity;
		tOrder.nPrice = pSubXdpMsg->mPrice;
		tOrder.nNoOfOrder = pSubXdpMsg->mNumberOfOrders;
		tOrder.nSide = pSubXdpMsg->mSide;
		tOrder.nPriceLevel = pSubXdpMsg->mPriceLevel;
		tOrder.nUpdateAction = pSubXdpMsg->mUpdateAction;

		if ( (tOrder.nPrice != 0) && (tOrder.nPrice != 2147483647) )
		{
			m_vOrderUpdate.push_back( tOrder );
		}
/*
		char sText[ MAX_TEXT];
		sprintf( sText, "seccode|%d| update|%d| side|%d| price|%d| qty|%llu| order|%d| L|%d|\n", m_nSecCode, pSubXdpMsg->mUpdateAction, pSubXdpMsg->mSide, pSubXdpMsg->mPrice, (unsigned long long)pSubXdpMsg->mAggregateQuantity, pSubXdpMsg->mNumberOfOrders, pSubXdpMsg->mPriceLevel );
		sLogMsg += sText;
		STDGetLogger()->log( STDLOG_L5, "%s", sLogMsg.c_str() );
*/
		pOffset += sizeof(Xdp::TenBBOsRepeatGrp);
	}

	if ( m_vOrderUpdate.size() > 0 )
		ImageControl::inst()->setData( *this );

	return SUCCESS;
}

vector<AggregateOBU::ORDER>* AggregateOBU::getOrderUpdate()
{
	return &m_vOrderUpdate;
}

