#ifndef CT_NEWS_RESPOND_H 
#define CT_NEWS_RESPOND_H

#include "datamodules/ctrespond.h"

#include "include/common/ClientToolStructs.h"

class CTSvrNewsRespond : public CTRespond
{
	public:
		CTSvrNewsRespond();
		CTSvrNewsRespond( CTNewsRespond* pMsg );
		~CTSvrNewsRespond();

	protected:
		int process( CTNewsRespond* pMsg );
};

#endif
