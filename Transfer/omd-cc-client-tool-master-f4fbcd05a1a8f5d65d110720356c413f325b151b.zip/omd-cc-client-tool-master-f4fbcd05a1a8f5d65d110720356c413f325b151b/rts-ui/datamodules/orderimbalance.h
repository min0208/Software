#ifndef ORDER_IMBALANCE_H
#define ORDER_IMBALANCE_H

#include "datamodules/secmsgbase.h"

#include "include/common/XdpStructs.h"

class OrderImbalance : public SecMsgBase
{
	public:
		OrderImbalance();
		OrderImbalance( Xdp::OrderImbalance* pMsg );
		~OrderImbalance();

		int process( Xdp::OrderImbalance* pMsg );
};

#endif
