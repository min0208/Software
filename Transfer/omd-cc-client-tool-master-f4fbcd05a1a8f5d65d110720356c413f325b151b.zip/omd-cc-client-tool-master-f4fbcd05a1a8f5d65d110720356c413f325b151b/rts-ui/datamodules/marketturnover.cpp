#include "datamodules/marketturnover.h"
#include "modules/imagecontrol.h"
#include "std/stdapp.h"

#define LOGC "|MktTurno| "

MarketTurnover::MarketTurnover()
{
}

MarketTurnover::MarketTurnover( Xdp::MarketTurnover* pMsg )
{
	process( pMsg );
}

MarketTurnover::~MarketTurnover()
{
}

int MarketTurnover::process( Xdp::MarketTurnover* pMsg )
{
	char sTmpStr[ 128];

	setDataStr( MKT_CODE, pMsg->mMarketCode, sizeof(pMsg->mMarketCode) );
	setDataStr( MKT_CURRENCY, pMsg->mCurrencyCode, sizeof(pMsg->mCurrencyCode) );
	setDataInt64( MKT_TURNOVER, pMsg->mTurnover, STDUtil::INTEGER_3_DP );
	setDataInt64( MKT_TURNOVER_SHORT_FORM, pMsg->mTurnover, STDUtil::INTEGER_3_DP_SHORT_FORM_3_DP );

	char sMarketCode[ 128];
	strcpy( sTmpStr, getData(MKT_CODE) );
	STDUtil::trimRight( sTmpStr, sMarketCode, ' ' );
	m_sMarketCode = sMarketCode;
	setData( MKT_CODE, sMarketCode );

	char sCurCode[ 128];
	strcpy( sTmpStr, getData(MKT_CURRENCY) );
	STDUtil::trimRight( sTmpStr, sCurCode, ' ' );
	m_sCurrencyCode = sCurCode;
	setData( MKT_CURRENCY, sCurCode );

	STDGetLogger()->log( STDLOG_L6, LOGC "market code|%4s| currency|%3s| turnover|%llu|%s|", m_sMarketCode.c_str(), sCurCode, pMsg->mTurnover, getData(MKT_TURNOVER_SHORT_FORM) );
	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

bool MarketTurnover::setCurrencyCode( const char* sCurrencyCode )
{
	m_sCurrencyCode = sCurrencyCode;

	return true;
}

const char* MarketTurnover::getCurrencyCode()
{
	return m_sCurrencyCode.c_str();
}

