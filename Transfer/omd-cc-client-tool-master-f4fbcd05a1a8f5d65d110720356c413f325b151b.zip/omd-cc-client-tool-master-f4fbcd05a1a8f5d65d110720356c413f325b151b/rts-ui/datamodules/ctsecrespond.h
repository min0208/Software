#ifndef CT_SEC_RESPOND_H 
#define CT_SEC_RESPOND_H

#include "datamodules/ctrespond.h"

#include "include/common/ClientToolStructs.h"

class CTSecRespond : public CTRespond
{
	public:
		CTSecRespond();
		CTSecRespond( CTSecSnapShotRespond* pMsg );
		~CTSecRespond();

	protected:
		int process( CTSecSnapShotRespond* pMsg );
};

#endif
