#include "datamodules/news.h"
#include "modules/imagecontrol.h"
#include "std/stdmutexlocker.h"
#include "std/stdapp.h"

#define LOGC "|News      | "

static const char* NEWS_TYPE[] = { "EXN", "EXC" };
static const int NO_OF_NEWS_TYPE= sizeof(NEWS_TYPE)/sizeof(NEWS_TYPE[0]);

static const char* MARKET[] = { "MAIN", "GEM", "ETS", "NASD" };
static const int NO_OF_MARKET = sizeof(MARKET)/sizeof(MARKET[0]);

static const char YN[] = { 'Y', 'N' };
static const int NO_OF_YN = sizeof(YN)/sizeof(YN[0]);

News::News()
{
}

News::News( Xdp::News* pMsg )
{
	process( pMsg );
}

News::~News()
{
}

int News::process( Xdp::News* pMsg )
{
	char *pOffset = (char*)pMsg;

	STDUtil::charArrayToStr( pMsg->mNewsType, sizeof(pMsg->mNewsType), m_sNewsType );
	STDUtil::charArrayToStr( pMsg->mNewsID, sizeof(pMsg->mNewsID), m_sNewsId );
	m_cCancelFlag = pMsg->mCancelFlag;
	m_cLastFragment = pMsg->mLastFragment;
	STDUtil::convertInt64ToTimeStr( pMsg->mReleaseTime, STDUtil::DATE_TIME_SEC, m_sReleaseTime );

	if ( m_sNewsType == "EXC" )
	{
		STDUtil::convertUTF16toUTF8( pMsg->mHeadline, sizeof(pMsg->mHeadline), m_sHeadline );
	}
	else
	{
		STDUtil::charArrayToStr( pMsg->mHeadline, sizeof(pMsg->mHeadline), m_sHeadline );
	}

	pOffset += sizeof(Xdp::News);

	/////////////////////////////
	// data validation
	//
	m_sMarketCode.clear();
	m_sSecCode.clear();

	for ( unsigned int i=0; i<pMsg->mNoMarketCodes; i++ )
	{
		string sMarketCode;
		STDUtil::charArrayToStr( pOffset, sizeof(Xdp::MarketCodesRepeatGrp), sMarketCode );
		m_vMarketCode.push_back( sMarketCode );

		m_sMarketCode += sMarketCode;
		m_sMarketCode += " ";

		pOffset += sizeof(Xdp::MarketCodesRepeatGrp);
	}

	pOffset += 2;

	Xdp::NewsNbSecurityCodesSubMsg* pNbSecCode = (Xdp::NewsNbSecurityCodesSubMsg*) pOffset;
	pOffset += sizeof(Xdp::NewsNbSecurityCodesSubMsg);

	for ( unsigned int i=0; i<pNbSecCode->mNoSecurityCodes; i++ )
	{
		Xdp::SecurityCodesRepeatGrp* pSecCode = (Xdp::SecurityCodesRepeatGrp*) pOffset;
		m_vSecCode.push_back( pSecCode->mSecurityCode );

		char sText[ MAX_TEXT];

		sprintf( sText, "%05d ", pSecCode->mSecurityCode );
		m_sSecCode += sText;

		pOffset += sizeof(Xdp::SecurityCodesRepeatGrp);
	}

	//////////////////////////////////////////////
	// set market & sec code str if count = 0
	//
	if ( pMsg->mNoMarketCodes == 0 && pNbSecCode->mNoSecurityCodes == 0 )
	{
		m_sMarketCode = "All";
		m_sSecCode = "N/A";
	}

	pOffset += 2;

	Xdp::NewsNbNewsLinesSubMsg* pNbNewsLine = (Xdp::NewsNbNewsLinesSubMsg*) pOffset;
	pOffset += sizeof(Xdp::NewsNbNewsLinesSubMsg);

	for ( unsigned int i=0; i<pNbNewsLine->mNoNewsLines; i++ )
	{
		string sNewsLine;

		if ( m_sNewsType == "EXC" )
		{
			STDUtil::convertUTF16toUTF8( pOffset, sizeof(Xdp::NewsLinesRepeatGrp), sNewsLine );
		}
		else
		{
			STDUtil::charArrayToStr( pOffset, sizeof(Xdp::NewsLinesRepeatGrp), sNewsLine );
		}

		STDGetLogger()->log( STDLOG_L6, LOGC "news type|%s| id|%s| content|%s|", m_sNewsType.c_str(), m_sNewsId.c_str(), sNewsLine.c_str() );

		m_vNewsLine.push_back( sNewsLine );

		pOffset += sizeof(Xdp::NewsLinesRepeatGrp);
	}

	ImageControl::inst()->setData( *this );

	return SUCCESS;
}

void News::setData( News& oData )
{
	STDMutexLocker oLocker(m_oMutex);

	m_sNewsId = oData.getNewsId();

	if ( m_sHeadline.empty() )
	{
		m_sHeadline = oData.getHeadline();
	}

	m_cCancelFlag = oData.getCancelFlag();
	m_cLastFragment = oData.getLastFragment();
	m_sReleaseTime = oData.getReleaseTime();
	m_vMarketCode = oData.getMarketCode();
	m_sMarketCode = oData.getMarketCodeStr();
	m_vSecCode = oData.getSecCode();
	m_sSecCode = oData.getSecCodeStr();

	vector<string> vNewsLine = oData.getNewsLine();
	m_vNewsLine.insert( m_vNewsLine.end(), vNewsLine.begin(), vNewsLine.end() );
}

const char* News::getNewsId()
{
	return m_sNewsId.c_str();
}

const char* News::getNewsType()
{
	return m_sNewsType.c_str();
}

const char* News::getHeadline()
{
	return m_sHeadline.c_str();
}

char News::getCancelFlag()
{
	return m_cCancelFlag;
}

char News::getLastFragment()
{
	return m_cLastFragment;
}

const char* News::getReleaseTime()
{
	return m_sReleaseTime.c_str();
}

const char* News::getMarketCodeStr()
{
	return m_sMarketCode.c_str();
}

vector<string> News::getMarketCode()
{
	return m_vMarketCode;
}

const char* News::getSecCodeStr()
{
	return m_sSecCode.c_str();
}

vector<int> News::getSecCode()
{
	return m_vSecCode;
}

vector<string> News::getNewsLine()
{
	return m_vNewsLine;
}

void News::setNewsId( const char* sNewsId )
{
	m_sNewsId = sNewsId;
}

void News::setNewsType( const char* sNewsType )
{
	m_sNewsType = sNewsType;
}

void News::setHeadline( const char* sHeadline )
{
	m_sHeadline = sHeadline;
}

void News::setLastFragment( char cLastFragment )
{
	m_cLastFragment = cLastFragment;
}

void News::setCancelFlag( char cCancelFlag )
{
	m_cCancelFlag = cCancelFlag;
}

void News::setReleaseTime( const char* sReleaseTime )
{
	m_sReleaseTime = sReleaseTime;
}

void News::setMarketCodeStr( const char* sMarketCodeStr )
{
	m_sMarketCode = sMarketCodeStr;
}

void News::setSecCodeStr( const char* sSecCodeStr )
{
	m_sSecCode = sSecCodeStr;
}

void News::setNewsLine( vector<string>& vNewsLine )
{
	m_vNewsLine = vNewsLine;
}

