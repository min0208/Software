#include <stdio.h>
#include <string.h>
#include <errno.h>
#include "std/stdmsgq.h"

STDMsgQ::STDMsgQ()
{
}

STDMsgQ::~STDMsgQ()
{
}

bool STDMsgQ::init( key_t nKey, int nFlag )
{
	m_nMsgQId = msgget( (key_t) nKey, nFlag );	

	if ( m_nMsgQId == -1 )
	{
		fprintf( stderr, "STDMsgQ error - msgget failed with error|%d|\n", errno );
		return false;
	}

	return true;
}

bool STDMsgQ::init( const char* sPath, int nProjectId, int nFlag )
{

	key_t nKey = ftok( sPath, nProjectId );

	if ( nKey == -1 ) 
	{
		fprintf( stderr, "STDMsgQ error - ftok failed with error|%d|\n", errno );
	}

	m_nMsgQId = msgget( (key_t) nKey, nFlag );	

	if ( m_nMsgQId == -1 )
	{
		fprintf( stderr, "STDMsgQ error - msgget failed with error|%d|\n", errno );
		return false;
	}

	return true;
}

bool STDMsgQ::post( int nMsgType, void* pData, int nDataSize, int nFlag )
{
	if ( nDataSize > MSGQ_BUFSIZE ) return false;

	struct MSGQ_T tMsgQ;
	tMsgQ.nMsgType = nMsgType;
	memcpy( tMsgQ.aData, pData, nDataSize );

	return ( msgsnd(m_nMsgQId, (void*)&tMsgQ, nDataSize, nFlag) == 0 );
}

bool STDMsgQ::recv( void* pBuf, int& nBufSize, long& nMsgType, int nFlag )
{
	struct MSGQ_T tMsgQ;
	nBufSize = msgrcv( m_nMsgQId, (void*)&tMsgQ, nBufSize, nMsgType, nFlag );

	if ( nBufSize <= 0 ) return false;

	nMsgType = tMsgQ.nMsgType;
	memcpy( pBuf, tMsgQ.aData, nBufSize );
	
	return true;
}

