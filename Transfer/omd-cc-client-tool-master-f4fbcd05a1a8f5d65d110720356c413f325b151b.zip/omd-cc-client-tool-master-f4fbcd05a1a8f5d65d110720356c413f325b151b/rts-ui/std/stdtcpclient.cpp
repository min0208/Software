//////////////////////////////////////////////////////////////////////////////////
//// Date	Ver	Name	Description
//// 20120430	r1	RC	Initial revision
//////////////////////////////////////////////////////////////////////////////////

#include "std/stdtcpclient.h"
#include "std/stdapp.h"
#include "std/stdmutexlocker.h"

#define LOGC "|STDTCPCl| "

STDTCPClient::STDTCPClient( int nId, const char* sLocalIP, int nLocalPort, const char* sRemoteIP, int nRemotePort, int nHeartBeatInterval, int nIdleTimeout, int nReconnectAfterSec, int nAppTimer ) : 
	STDSocketBase(nAppTimer),
	m_nId(nId),
	m_sLocalIP(sLocalIP),
	m_nLocalPort(nLocalPort),
	m_sRemoteIP(sRemoteIP),
	m_nRemotePort(nRemotePort),
	HEARTBEAT_INTERVAL(nHeartBeatInterval),
	IDLE_TIMEOUT(nIdleTimeout),
	RECONNECT_INTERVAL(nReconnectAfterSec),
	m_nHeartBeatIntervalCnt(0),
	m_nIdleTimeoutCnt(0),
	m_nReconnectAfterSecCnt(nReconnectAfterSec),
	m_bConnected(false),
	m_pTCPEv(NULL)
{
}

STDTCPClient::~STDTCPClient()
{
	if ( m_pTCPEv )	closeConnection(false);
}

bool STDTCPClient::send( const char* pData, unsigned int nDataSize )
{
	STDMutexLocker oLocker(m_oSendMutex);

	if ( m_bConnected )
	{
		int nResult = bufferevent_write( m_pTCPEv, (const char*) pData, nDataSize  );

		STDGetLogger()->log( STDLOG_L7, LOGC "send data to id|%d| ip|%s:%d| bytes|%d| result|%d|", m_nId, m_sRemoteIP.c_str(), m_nRemotePort, nDataSize, nResult );
	}

	return true;
}

void STDTCPClient::onHealthCheck( int nLineFD, short nEvent )
{
	////////////////////////////////////////////
	// auto reconnect if reconnect interval > 0
	//
	if ( RECONNECT_INTERVAL > 0 )
	{
		if ( !m_bConnected )
		{
			if ( RECONNECT_INTERVAL <= m_nReconnectAfterSecCnt++ )
			{
				m_nReconnectAfterSecCnt = 0;
				reconnect();
			}
			else
			{
				//STDGetLogger()->log( STDLOG_L5, LOGC "onHealthCheck() reconnect interval|%d/%d|", m_nReconnectAfterSecCnt, RECONNECT_INTERVAL );
			}
		}
	}

	if ( IDLE_TIMEOUT > 0 )
	{
		if ( m_bConnected )
		{
			if ( IDLE_TIMEOUT <= m_nIdleTimeoutCnt++ )
			{
				m_nIdleTimeoutCnt = 0;
				closeConnection();
			}
			else
			{
				//STDGetLogger()->log( STDLOG_L5, LOGC "onHealthCheck() idle interval|%d/%d|", m_nIdleTimeoutCnt, IDLE_TIMEOUT );
			}
		}
	}

        if ( HEARTBEAT_INTERVAL > 0 )
        {
                if ( m_bConnected )
                {
                        if ( HEARTBEAT_INTERVAL <= m_nHeartBeatIntervalCnt++ )
                        {
                                m_nHeartBeatIntervalCnt = 0;
                                onSendHeartBeat();
                        }
                        else
                        {
                                //STDGetLogger()->log( STDLOG_L5, LOGC "onHealthCheck() heartbeat interval|%d/%d|", m_nHeartBeatIntervalCnt, IDLE_TIMEOUT );
                        }
                }
        }

	onTimerCheck();
}

void STDTCPClient::onEventCB( struct bufferevent* pEvent, short nEvents, void* pPtr )
{
	((STDTCPClient*)pPtr)->onEvent( pEvent, nEvents, pPtr );
}

void STDTCPClient::onReceiveCB( struct bufferevent* pEvent, void* pPtr )
{
	((STDTCPClient*)pPtr)->onReceive( pEvent, pPtr );
}

void STDTCPClient::onSendCB( struct bufferevent* pEvent, void* pPtr )
{
	((STDTCPClient*)pPtr)->onSend( pEvent, pPtr );
}

void STDTCPClient::onEvent( struct bufferevent* pEvent, short nEvents, void* pPtr )
{
	STDGetLogger()->log( STDLOG_L7, LOGC "onEvent event|0x%02X|", nEvents );

	if ( nEvents & BEV_EVENT_CONNECTED )
	{
		STDGetLogger()->log( STDLOG_L3, LOGC "connected to id|%d| ip|%s:%d|", m_nId, m_sRemoteIP.c_str(), m_nRemotePort );
		m_bConnected = true;
		onConnected( pEvent, pPtr );
	}

	if ( nEvents & BEV_EVENT_ERROR )
	{
		STDGetLogger()->log( STDLOG_L2, LOGC "socket error id|%d| ip|%s:%d|", m_nId, m_sRemoteIP.c_str(), m_nRemotePort );
		m_bConnected = false;
		onClose( pEvent, pPtr );
	}

	if ( nEvents & (BEV_EVENT_ERROR || BEV_EVENT_READING) )
	{
		STDGetLogger()->log( STDLOG_L2, LOGC "connection closed by id|%d| ip|%s:%d| reason|BEV_EVENT_ERROR|", m_nId, m_sRemoteIP.c_str(), m_nRemotePort );
		m_bConnected = false;
		onClose( pEvent, pPtr );
	}

	if ( nEvents & (BEV_EVENT_EOF || BEV_EVENT_READING) )
	{
		STDGetLogger()->log( STDLOG_L2, LOGC "connection closed by id|%d| ip|%s:%d| reason|BEV_EVENT_EOF|", m_nId, m_sRemoteIP.c_str(), m_nRemotePort );
		m_bConnected = false;
		onClose( pEvent, pPtr );
	}
}

bool STDTCPClient::closeConnection( bool bLock )
{
	if ( bLock )	m_oSendMutex.lock();

	if ( m_pTCPEv )
	{
		bufferevent_free( m_pTCPEv );
		m_pTCPEv = NULL;

		STDGetLogger()->log( STDLOG_L3, LOGC "close connection id|%d| ip|%s:%d|", m_nId, m_sRemoteIP.c_str(), m_nRemotePort );
	}

	m_bConnected = false;

	if ( bLock )	m_oSendMutex.unlock();

	return true;
}

bool STDTCPClient::reconnect()
{
	STDMutexLocker oLocker(m_oSendMutex);

	if ( m_bConnected )
	{
		return true;
	}

	STDGetLogger()->log( STDLOG_L3, LOGC "connecting to id|%d| ip|%s:%d|", m_nId, m_sRemoteIP.c_str(), m_nRemotePort );

	// clear old connection
	closeConnection( false );

	// set callback event
	m_pTCPEv = bufferevent_socket_new( m_tBase, -1, BEV_OPT_CLOSE_ON_FREE );
	bufferevent_setcb( m_pTCPEv, onReceiveCB, onSendCB, onEventCB, this );

	// set socket info
	struct sockaddr_in sin;
	memset( &sin, 0, sizeof(sin) );
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = inet_addr( m_sRemoteIP.c_str() );
	sin.sin_port = htons( m_nRemotePort );

	// connect
	if ( bufferevent_socket_connect( m_pTCPEv, (struct sockaddr*)&sin, sizeof(sin) ) < 0 )
	{
		closeConnection( false );
		return false;
	}

	bufferevent_enable( m_pTCPEv, EV_READ | EV_WRITE );

	return true;
}

bool STDTCPClient::isConnected()
{
	return m_bConnected;
}

void STDTCPClient::onReceive( struct bufferevent* pEvent, void *pPtr )
{
	char aRcvDataBuf[ STD_TCP_BUF_SIZE];

	/////////////////////////////////////////////////////////
	// receive data from socket 
	//
	struct evbuffer* pEvBuf = bufferevent_get_input( pEvent );
	unsigned int nRcvDataSize = evbuffer_remove( pEvBuf, aRcvDataBuf, STD_TCP_BUF_SIZE );

	if ( nRcvDataSize > 0 )
	{
		STDGetLogger()->log( STDLOG_L7, LOGC "recv id|%d| ip|%s:%d| received bytes|%05d|", m_nId, m_sRemoteIP.c_str(), m_nRemotePort, nRcvDataSize );
		onReceive( aRcvDataBuf, nRcvDataSize );
	}
	else
	{
		STDGetLogger()->log( STDLOG_L7, LOGC "id|%d| ip|%s:%d| no pending data in socket buffer", m_nId, m_sRemoteIP.c_str(), m_nRemotePort, nRcvDataSize );
	}
}

