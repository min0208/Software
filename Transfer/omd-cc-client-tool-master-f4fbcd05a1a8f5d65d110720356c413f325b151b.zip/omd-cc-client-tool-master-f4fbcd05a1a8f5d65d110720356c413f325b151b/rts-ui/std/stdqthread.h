////////////////////////////////////////////////////////////////////////////////
// Date         Ver             Name    Description
// 20040429     r1              RC              Initial revision
////////////////////////////////////////////////////////////////////////////////

#ifndef STDQTHREAD_H
#define STDQTHREAD_H

#include <deque>
#include "std/stdmutex.h"
#include "std/stdthread.h"
#include "std/stdsema.h"

using namespace std;

// STD Queue thread
template < class CDataType > class CQueueThrd : public STDThread
{
	public:
		CQueueThrd ();
		virtual ~ CQueueThrd ();

	public:
		// main routine of Thread
		virtual void thread ();

		// Put data to queue to process
		bool postData (const CDataType & oData);

		// Call upon Msg arrive
		virtual void onMsg () = 0;

		void setMaxQueueSize (int nMaxQueueSize);

	protected:
		// Wake up the thread to process data
		bool wake ();

		// Wait for new data
		bool wait ();

		// FIFO lock
		bool lockFifo ();
		bool unlockFifo ();

		int m_nMaxQueueSize;		// control the queue size, default is unlimited
		deque < CDataType > m_oFifo;
		STDMutex m_oMutex;
		STDSema m_oSemaphore;
};

template < class CDataType > CQueueThrd < CDataType >::CQueueThrd ():
	m_nMaxQueueSize (0)		// default queue size is unlimited
{
	m_oSemaphore.init ();
}

template < class CDataType > CQueueThrd < CDataType >::~CQueueThrd ()
{
	shutdown ();
	wake ();
	join ();
}

// Put data to queue to process
	template < class CDataType >
bool CQueueThrd < CDataType >::postData (const CDataType & oData)
{
	m_oMutex.lock ();

	if (m_nMaxQueueSize && m_oFifo.size () >= (unsigned int) m_nMaxQueueSize)
		m_oFifo.pop_front ();

	m_oFifo.push_back (oData);
	m_oMutex.unlock ();
	wake ();

	return true;
}

// Call upon Msg arrive
template < class CDataType > void CQueueThrd < CDataType >::onMsg ()
{
	// this is a pure virtual function

}

	template < class CDataType >
void CQueueThrd < CDataType >::setMaxQueueSize (int nMaxQueueSize)
{
	m_nMaxQueueSize = nMaxQueueSize;
}

// main loop of thread
template < class CDataType > void CQueueThrd < CDataType >::thread ()
{
	for (;;)
	{
		wait ();
		if (isShutdown ())
			return;

		onMsg ();
	}
}

// Wake up the thread to process data
template < class CDataType > bool CQueueThrd < CDataType >::wake ()
{
	return m_oSemaphore.post ();
}

// Wait for new data
template < class CDataType > bool CQueueThrd < CDataType >::wait ()
{
	m_oSemaphore.wait ();
	return true;
}

template < class CDataType > bool CQueueThrd < CDataType >::lockFifo ()
{
	m_oMutex.lock ();
	return true;
}

template < class CDataType > bool CQueueThrd < CDataType >::unlockFifo ()
{
	m_oMutex.unlock ();
	return true;
}

#endif /* STDQTHREAD */
