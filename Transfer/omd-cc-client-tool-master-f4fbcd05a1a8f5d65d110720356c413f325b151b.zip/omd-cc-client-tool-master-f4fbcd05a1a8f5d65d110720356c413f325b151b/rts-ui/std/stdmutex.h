////////////////////////////////////////////////////////////////////////////////
// Date 	Ver 	Name	Description
// 20040422 r1		RC		Initial revision

#ifndef _STD_MUTEX_H
#define _STD_MUTEX_H

#include <stdio.h>
#include <sys/poll.h>
#include <fcntl.h>
#include <unistd.h>

#include <pthread.h>

class STDMutex
{
	public:
		STDMutex(int nMutexType = PTHREAD_MUTEX_DEFAULT)
		{
			if (nMutexType != PTHREAD_MUTEX_DEFAULT)
			{
				pthread_mutexattr_t attr;
				pthread_mutexattr_init(&attr);
				pthread_mutexattr_settype(&attr,nMutexType);
				pthread_mutex_init( &m_oMutex, &attr );
				pthread_mutexattr_destroy(&attr);
			}
			else
			{
				pthread_mutex_init( &m_oMutex, NULL);
			}


		};
		~STDMutex()
		{

			pthread_mutex_destroy(&m_oMutex);
		};
		void lock()
		{
			pthread_mutex_lock( &m_oMutex );
		};

		void unlock()
		{
			pthread_mutex_unlock( &m_oMutex );
		};
		operator pthread_mutex_t * ()  { return &m_oMutex;}
	private:
		pthread_mutex_t m_oMutex;
};

#endif

