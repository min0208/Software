#ifndef _STDTCPServer_H
#define _STDTCPServer_H

#include <string>
#include <map>
#include "std/stdsocketbase.h"

using namespace std;


class STDTCPServer : public STDSocketBase
{ 
	public:
		//////////////////////////////////////////////////////////
		// nHeartBeatInterval: 
		// 	0	disable outbound heartbeat reminder
		// 	> 0	will trigger callback function onSendHeartBeat every n seconds for user sending their heartbeat message
		// nIdleTimeout: 
		// 	0	disable keepalive checking
		// 	> 0	if no data received within n seconds, auto close connection 
		// nReconnectAfterSec: 
		// 	0	disable auto reconnect 
		// 	> 0	if disconnect, auto reconnect every n seconds
		//
		STDTCPServer( int nId, const char* sDesc, const char* sLocalIP, int nLocalPort, int nHeartBeatInterval, int nIdleTimeout );
		~STDTCPServer();

		virtual bool send( int nClientFd, const char* pData, unsigned int nDataSize );

	protected:
		static const int STD_TCP_BUF_SIZE = 65535;

	protected:
		virtual void onAccept( int nClientFd, const sockaddr_in& tClientAddr ){};
		void onAcceptHandler( int nServerFd, short nEvents, void *pPtr );
		static void onAcceptCB( int nServerFd, short nEvents, void *pPtr );

		virtual void onReceive( int nClientFd, const char* pData, int nDataSize );
		virtual void onClose( int nClientFd );
		void onRead( int nClientFd, short nEvents, void* pPtr );
		static void onReadCB( int nClientFd, short nEvents, void* pPtr );

		virtual bool onInit();

		bool closeConnection( int nClientFd );

		bool createListenPort();
		int setNonBlock( int nFd );

	protected:
		////////////////////
		// TCP/IP info
		//
		int m_nId;
		string m_sDesc;
		string m_sLocalIP;
		int m_nLocalPort;

		int m_nServerFd;

		int HEARTBEAT_INTERVAL;
		int m_nHeartBeatIntervalCnt;
		int IDLE_TIMEOUT;
		int m_nIdleTimeoutCnt;

		//////////////////
		// libevent
		//
		struct event* m_pAcceptEv;

		map<int,event*> m_mClient;

		STDMutex m_oConnectionMutex;
};

#endif

