//////////////////////////////////////////////////////////////////////////////////
//// Date	Ver	Name	Description
//// 20120430	r1	RC	Initial revision
//////////////////////////////////////////////////////////////////////////////////

#include "std/stdsocketbase.h"
#include "std/stdmutexlocker.h"
#include "std/stdapp.h"

#define LOGC "|STDSocke| "

STDSocketBase::STDSocketBase( int nAppTimer ) :
	m_tBase(NULL),
	m_pHealthCheckEv(NULL),
	m_pAppTimerEv(NULL),
	m_nAppTimer(nAppTimer)
{
}

STDSocketBase::~STDSocketBase()
{
	if ( m_pHealthCheckEv ) event_del( m_pHealthCheckEv );
	if ( m_tBase ) event_base_loopbreak( m_tBase );

	STDMutexLocker oLocker(m_oBaseMutex);

	if ( m_tBase ) 
	{
		event_base_free( m_tBase );
	}

	STDGetLogger()->log( STDLOG_L3, "~STDSocketBase()" );
}

bool STDSocketBase::init()
{
	// create libevent base
	m_tBase = event_base_new();

	// create a 1 second callback event for connection health checking
	m_tHealthCheckTimerVal.tv_sec = 1;
	m_tHealthCheckTimerVal.tv_usec = 0;
	m_pHealthCheckEv = event_new( m_tBase, -1, EV_PERSIST, &onHealthCheckCB, this );
	event_add( m_pHealthCheckEv, &m_tHealthCheckTimerVal );

	if ( m_nAppTimer > 0 )
	{
		int nSec = m_nAppTimer / 1000000;
		int nUSec = m_nAppTimer % 1000000;
		m_tAppTimerVal.tv_sec = nSec;
		m_tAppTimerVal.tv_usec = nUSec;
		m_pAppTimerEv = event_new( m_tBase, -1, EV_PERSIST, &onAppTimerCB, this );
		event_add( m_pAppTimerEv, &m_tAppTimerVal );
	}
	return true;
}

void STDSocketBase::onAppTimerCB( int nLineFD, short nEvent, void *pPtr )
{
	((STDSocketBase*)pPtr)->onAppTimer( nLineFD, nEvent );
}

void STDSocketBase::onHealthCheckCB( int nLineFD, short nEvent, void *pPtr )
{
	((STDSocketBase*)pPtr)->onHealthCheck( nLineFD, nEvent );
}

void STDSocketBase::thread()
{
	init();
	onInit();	// virtual function for child override

	STDMutexLocker oLocker(m_oBaseMutex);

	event_base_dispatch( m_tBase );

	STDGetLogger()->log( STDLOG_L3, "STDSocketBase::thread() exit" );
}

void STDSocketBase::resetHealthCheckTimer()
{
	event_del( m_pHealthCheckEv );
	event_add( m_pHealthCheckEv, &m_tHealthCheckTimerVal );
}

