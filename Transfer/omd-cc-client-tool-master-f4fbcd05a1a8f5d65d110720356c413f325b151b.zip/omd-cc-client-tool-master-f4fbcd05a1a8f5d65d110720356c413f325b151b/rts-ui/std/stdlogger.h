////////////////////////////////////////////////////////////////////////////////
// Date     Ver     Name    Description
// 20040422 r1        RC        Initial revision
////////////////////////////////////////////////////////////////////////////////

#ifndef _STD_LOGGER_H
#define _STD_LOGGER_H

#include <sys/stat.h>
#include <errno.h>
#include "std/stdmutex.h"

using namespace std;


class STDLogger //: //public STDThread
{
public:

#define STDLOG_L7	7
#define STDLOG_L6	6
#define STDLOG_L5	5
#define STDLOG_L4	4
#define STDLOG_L3	3
#define STDLOG_L2	2
#define STDLOG_L1	1

#define STDLOGGER_LEVEL_DEBUG_3		7
#define STDLOGGER_LEVEL_DEBUG_2		6
#define STDLOGGER_LEVEL_DEBUG_1		5
#define STDLOGGER_LEVEL_TRAFFIC		4
#define STDLOGGER_LEVEL_OPERATION	3
#define STDLOGGER_LEVEL_ERROR       	2
#define STDLOGGER_LEVEL_ALARM       	1
#define STDLOGGER_LEVEL_DISABLE		0

	STDLogger( char *sPath = "./",char *sExt = "log" );
        ~STDLogger();

#define STDLOGGER_SUCCESS	0
#define STDLOGGER_FAIL		-1
#define STDLOGGER_INVALID_LEVEL	-2

	int setLevel(int nLevel);
/*
	{
		if ((nLevel < STDLOGGER_LEVEL_DISABLE) || (nLevel > STDLOGGER_LEVEL_DEBUG_3))
		{
			return STDLOGGER_INVALID_LEVEL;
		}

		m_nLevel = nLevel;

		return STDLOGGER_SUCCESS;
	};
*/
	// r8
	int getLevel() 
	{
		return m_nLevel;
	}

	// r3
	void setDisplay(bool bDisplay)
	{
		m_bDisplay = bDisplay;
	};

	bool getDisplay()
	{
		return m_bDisplay;
	};

#define STDLOGGER_NO_RIGHT		-3
#define STDLOGGER_CONSOLE_HIDE		0
#define STDLOGGER_CONSOLE_SHOW		1
#define STDLOGGER_INVALID_CATID		-1
#define STDLOGGER_INVALID_ALARMID	-1
#define STDLOGGER_INVALID_OPERID	-1

	int log(int nLevel, const char* pFmt, ...)
		//r12
		__attribute__ ((format (__printf__, 3,4 )));


protected:
	void rotateFile( const char* sFilename, const char* sBackupFilename, int nMaxFileSize );

private:
	STDMutex m_oMutex;

	int m_nLevel;
	bool m_bDisplay;
	char m_sPath[128];
	char m_sExt[10];

	int m_nMaxFileSize;
};

#endif

