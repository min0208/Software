//////////////////////////////////////////////////////////////////////////////////
//// Date	Ver	Name	Description
//// 20120430	r1	RC	Initial revision
//////////////////////////////////////////////////////////////////////////////////

#include "std/stdadminchild.h"
#include "std/stdapp.h"

#define LOGC "|STDAdmCh| "


STDAdminChild::STDAdminChild( int nFd, const sockaddr_in& tClientAddr ) :
	STDTCPServerChild( nFd, tClientAddr )
{
}

STDAdminChild::~STDAdminChild()
{
	STDGetLogger()->log( STDLOG_L3, LOGC "fd|%d| ip|%s:%d| ~STDAdminChild()", m_nFd, m_sIP.c_str(), m_nPort );
}

bool STDAdminChild::processMainCmd( const CMD_T& tCmd )
{
	return false;
}

bool STDAdminChild::processLogCmd( const CMD_T& tCmd )
{
	if ( strcmp(tCmd.sTag, TAG_LOG_LEVEL) == 0 )
	{
		STDGetLogger()->setLevel( atoi(tCmd.sValue) );
		STDGetLogger()->log( STDLOG_L3, LOGC "change log level to |%d|", STDGetLogger()->getLevel() );

		return true;
	}
	else if ( strcmp(tCmd.sTag, TAG_CONSOLE_DISPLAY) == 0 )
	{
		STDGetLogger()->setDisplay( (atoi(tCmd.sValue)==1) );
		STDGetLogger()->log( STDLOG_L3, LOGC "change console display log|%d|", STDGetLogger()->getDisplay() );

		return true;
	}

	return false;
}

bool STDAdminChild::processCmd( const CMD_T& tCmd )
{
	STDGetLogger()->log( STDLOG_L3, LOGC "process command group|%s| tag|%s| value|%s|", tCmd.sGrp, tCmd.sTag, tCmd.sValue );

	if ( strcmp(tCmd.sGrp, GRP_MAIN) == 0 )
	{
		return processMainCmd( tCmd );
	}
	else if ( strcmp(tCmd.sGrp, GRP_LOG) == 0 )
	{
		return processLogCmd( tCmd );
	}

	return false;
}

void STDAdminChild::onReceive( const char* pData, unsigned int nDataSize )
{
	static const char* GROUP_DELIMITER = ":";
	static const char* TAG_DELIMITER = "=";
	static const char* VALUE_DELIMITER = "\n";
	char sCmd[ nDataSize+1];
	CMD_T tCmd;

	memcpy( sCmd, pData, nDataSize );
	sCmd[ nDataSize] = 0;	

	//STDGetLogger()->log( STDLOG_L2, LOGC "onReceive bytes|%d| cmd|%s| from ip|%s:%d|", nDataSize, sCmd, m_sIP.c_str(), m_nPort );

	char* pPtr = NULL;
	char* pToken = strtok_r( sCmd, GROUP_DELIMITER, &pPtr );
	tCmd.sGrp = pToken;

	while ( pToken )
	{
		pToken = strtok_r( pPtr, TAG_DELIMITER, &pPtr );
		if ( pToken == NULL )	return;	// no tag, ignore the input
		tCmd.sTag = pToken;

		pToken = strtok_r( pPtr, VALUE_DELIMITER, &pPtr );
		if ( pToken == NULL )	return;	// no value, ignore the input
		tCmd.sValue = pToken;

		processCmd( tCmd );

		//////////////////////////
		// get next command
		//
		pToken = strtok_r( pPtr, GROUP_DELIMITER, &pPtr );
		if ( pToken == NULL )	return;	// no group, ignore the input
		tCmd.sGrp = pToken;
	};
}

