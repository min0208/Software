#ifndef _STDAdminChild_H
#define _STDAdminChild_H

#include "std/stdtcpserverchild.h"

class STDAdminChild : public STDTCPServerChild
{
	public:
		STDAdminChild( int nFd, const sockaddr_in& tClientAddr );
		~STDAdminChild();

		virtual void onReceive( const char* pData, unsigned int nDataSize );

	protected:
		struct CMD_T
		{
			const char* sGrp;
			const char* sTag;
			const char* sValue;

			CMD_T()
			{
				sGrp = NULL;
				sTag = NULL;
				sValue = NULL;
			};
		};

	protected:
		bool processCmd( const CMD_T& tCmd );
		bool processMainCmd( const CMD_T& tCmd );
		bool processLogCmd( const CMD_T& tCmd );
};

#endif

