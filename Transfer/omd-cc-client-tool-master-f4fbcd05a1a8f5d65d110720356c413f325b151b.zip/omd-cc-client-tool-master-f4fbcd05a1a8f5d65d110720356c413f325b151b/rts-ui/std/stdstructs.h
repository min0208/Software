#ifndef _STDStruct_H
#define _STDStruct_H

struct STD_CMD_T
{
	const char* sGrp;
	const char* sTag;
	const char* sValue;

	STD_CMD_T()
	{
		sGrp = NULL;
		sTag = NULL;
		sValue = NULL;
	};
};

#endif
