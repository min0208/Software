////////////////////////////////////////////////////////////////////////////////
// Date     Ver     Name    Description
// 20120430 r1	    RC     Initial revision
////////////////////////////////////////////////////////////////////////////////

#include "std/stdrawlogger.h"
#include "std/stdmutexlocker.h"
#include "std/stdtimeutil.h"

#include <sys/stat.h>
#include <stdlib.h>
#include <stdarg.h>

//static const unsigned long long MAX_STD_RAW_LOGFILE_SIZE = 4294967296L;

#define LOG_C 	"|STDRawLog| "

STDRawLogger::STDRawLogger( const char *sPath, const char *sFilename )
{
	int nPathLen = strlen( sPath );
	int nBufLen = sizeof( m_sPath );

	nPathLen = (nPathLen > nBufLen) ? nBufLen : nPathLen;

	strncpy( m_sPath, sPath, nPathLen );
	m_sPath[ nPathLen] = 0;

	if ( m_sPath[ nPathLen-1] != '/' )
	{
		if ( nPathLen < nBufLen - 1 )
		{
			m_sPath[ nPathLen] = '/';
			m_sPath[ nPathLen+1] = 0;
		}
		else
		{
			printf( "%s create log folder (%s) fail. folder name too long\n", LOG_C, m_sPath );
			return;
		}
	}

	if ( mkdir(m_sPath, S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH ) == -1 )	
	{
		if ( errno != EEXIST )
		{
			printf( "%s create log folder (%s) fail. %s\n", LOG_C, m_sPath, strerror(errno) );
			return;
		}
	}

	int nFLen = strlen( sFilename );
	nBufLen = sizeof( m_sFilename );

	nFLen = (nFLen > nBufLen) ? nBufLen : nFLen;
	strncpy( m_sFilename, sFilename, nFLen );
	m_sFilename[ nFLen] = 0;
}

STDRawLogger::~STDRawLogger()
{
}

bool STDRawLogger::log( int nLineNum, const char* pData, unsigned int nDataSize )
{
	STDMutexLocker oLocker(m_oMutex);

	FILE* pFile;

	char sFullPath[ 1024];

	sprintf( sFullPath, "%s%s", m_sPath, m_sFilename );

	if ( (pFile = fopen( sFullPath, "a")) == NULL )
	{
		return false;
	}

	// nanoseconds timestamp 
        struct timespec tCurTime;
        unsigned long long nNanoSec = 0;

        if ( clock_gettime( CLOCK_REALTIME, &tCurTime ) == 0 )
        {
                nNanoSec = tCurTime.tv_sec * 1000000000.0 + tCurTime.tv_nsec;   // nanoseconds since 1970-1-1
        }

        char aNanoSec[ 8];

        memcpy( aNanoSec, &nNanoSec, sizeof(aNanoSec) );

	int nPktSize = nDataSize + 12;

	fwrite( &nPktSize, 2, 1, pFile );
	fwrite( &nLineNum, 2, 1, pFile );
	fwrite( aNanoSec, sizeof(aNanoSec), 1, pFile );
	fwrite( pData, 1, nDataSize, pFile );
	fclose( pFile );

	return true;
}

/*
void STDRawLogger::rotateFile( const char* sFilename, const char* sBackupFilename, int nMaxFileSize )
{
	struct stat results;

	if ( stat( sFilename, &results ) == 0 )
	{
		if ( results.st_size > nMaxFileSize )
		{
			char sCmd[4096] = { 0 };
			sprintf( sCmd, "mv %s %s", sFilename, sBackupFilename );
			system( sCmd );
		}
	}
}
*/
