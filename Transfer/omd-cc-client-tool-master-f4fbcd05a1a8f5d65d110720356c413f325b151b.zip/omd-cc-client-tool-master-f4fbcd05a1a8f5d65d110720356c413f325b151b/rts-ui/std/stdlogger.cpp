////////////////////////////////////////////////////////////////////////////////
// Date     Ver     Name    Description
// 20040422 r1	    RC     Initial revision
////////////////////////////////////////////////////////////////////////////////

#include "std/stdlogger.h"
#include "std/stdtimeutil.h"
#include "std/stdmutexlocker.h"

#include <stdlib.h>
#include <stdarg.h>

static const int MAX_STD_LOGFILE_SIZE = 1024 * 1024 * 1024;
static const int MAX_DEBUG_LINE_LENGTH = 8192;

#define LOGC "|STDLogge| "

STDLogger::STDLogger( char *sPath,char *sExt )
{
	m_nLevel = STDLOG_L3;

	strcpy( m_sPath, sPath );

	int nLen = strlen(m_sPath);

	if ( m_sPath[nLen-1] != '/' )
	{
		m_sPath[ nLen] = '/';
		m_sPath[ nLen+1] = 0;
	}

	if ( mkdir(m_sPath, S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH ) == -1 )	// r15
	{
		if ( errno != EEXIST )
		{
			printf( "%screate log folder (%s) fail. %s\n", LOGC, m_sPath, strerror(errno) );
		}
	}

	strncpy( m_sExt, sExt, sizeof(m_sExt) );
	m_sExt[ sizeof(m_sExt)-1] = '\0';

	m_nMaxFileSize = MAX_STD_LOGFILE_SIZE; 
}

STDLogger::~STDLogger()
{
}

int STDLogger::setLevel( int nLevel )
{
	if ( (nLevel < STDLOGGER_LEVEL_DISABLE) || (nLevel > STDLOG_L7) )
	{
		return STDLOGGER_INVALID_LEVEL;
	}

	m_nLevel = nLevel;

	return STDLOGGER_SUCCESS;
}

int STDLogger::log( int nLevel, const char* pFmt, ... )
{
	if ( (nLevel < STDLOGGER_LEVEL_DISABLE) || (nLevel > STDLOG_L7) )
	{
		return STDLOGGER_INVALID_LEVEL;
	}
	else if ( nLevel > m_nLevel ) 
	{
		return STDLOGGER_NO_RIGHT;
	}

	// format the debug string
	char sEvent[MAX_DEBUG_LINE_LENGTH] = { 0 };
	va_list tArgList;
	va_start(tArgList, pFmt);
	vsnprintf(sEvent, sizeof(sEvent), pFmt, tArgList);
	va_end(tArgList);

	char sFilename[128] = { 0 };
	time_t t = time(NULL);

	////////////////////////////////////
	// filename
	// 
	struct timespec tCurTime;
	clock_gettime( CLOCK_REALTIME, &tCurTime );

	struct tm Now;
	struct tm *pNow = stdlocaltime_r(&t,&Now);
	sprintf( sFilename, "%s%04d%02d%02d.%s", m_sPath, pNow->tm_year+1900, pNow->tm_mon+1, pNow->tm_mday ,m_sExt );

	char sBackupFilename[128] = { 0 };
	sprintf( sBackupFilename, "%s.%02d%02d%02d", sFilename, pNow->tm_hour, pNow->tm_min, pNow->tm_sec );
	rotateFile( sFilename, sBackupFilename, m_nMaxFileSize );

	////////////////////////////////////
	// log event
	// 	
	STDMutexLocker oLocker(m_oMutex);

	FILE* pFile = fopen( sFilename, "a" );

	if ( pFile == NULL )
	{
		printf( "%slog file|%s| cannot be genertated. please contact administrator\n", LOGC, sFilename );

		return STDLOGGER_FAIL;
	}

	fprintf( pFile, "L%d %02d%02d%02d %02d%02d%02d.%06ld [%05u] %s\n", nLevel, (1900+pNow->tm_year)%100, pNow->tm_mon+1, pNow->tm_mday, pNow->tm_hour, pNow->tm_min, pNow->tm_sec, (tCurTime.tv_nsec / 1000) , (unsigned int)(pthread_self()) % 100000, sEvent );

	fclose( pFile );

	if ( m_bDisplay ) 
	{
		printf( "%s\n", sEvent );
	}

	return STDLOGGER_SUCCESS;
}

void STDLogger::rotateFile( const char* sFilename, const char* sBackupFilename, int nMaxFileSize )
{
	struct stat results;

	if ( stat( sFilename, &results ) == 0 )
	{
		if ( results.st_size > nMaxFileSize )
		{
			char sCmd[4096] = { 0 };
			sprintf( sCmd, "mv %s %s", sFilename, sBackupFilename );
			system( sCmd );
		}
	}
}

