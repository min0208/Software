////////////////////////////////////////////////////////////////////////////////
// Date     Ver     Name    Description
// 20040615 r1      RC     Initial revision
////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <signal.h>
#include "std/stdapp.h"
#include "std/stdlogger.h"

bool g_bSigTerm = false;

extern "C"
{
	void sig_quit(int signo);
	void sig_term(int signo);
}
int main(int argc, char** argv)
{
	signal(SIGQUIT, sig_quit);
	signal(SIGTERM, sig_term);
	signal(SIGINT, sig_term);
	signal(SIGPIPE, sig_quit);
	signal(SIGHUP, sig_quit);

	STDApp* pApp = STDGetApp();
	if (!pApp)
	{
		printf("No Application is defined\n");
		return 1;
	}

	if (!pApp->appInit(argc, argv))
	{
		pApp->appExit();
		return 2;
	}

	pApp->logger().log(STDLOG_L3, "appExit");

	if (!pApp->appExit())
	{
		return 3;
	}

	return 0;
}
// signal handler
void sig_quit(int signo)
{
	STDApp* pApp = STDGetApp();
	if (pApp)
	{
		//r3
		pApp->logger().log(STDLOG_L3, "Appmain received sig_quit|%d|", signo);
		pApp->post(STDApp::ABNORMAL_EXIT);
	}
}

void sig_term(int signo)
{
	if ( !g_bSigTerm ) {
		g_bSigTerm = true;
		STDApp* pApp = STDGetApp();
		if (pApp)
		{
			//r3
			pApp->logger().log(STDLOG_L3, "Appmain received sig_term|%d|", signo);
			pApp->post(STDApp::ABNORMAL_EXIT);
		}
	}
}

