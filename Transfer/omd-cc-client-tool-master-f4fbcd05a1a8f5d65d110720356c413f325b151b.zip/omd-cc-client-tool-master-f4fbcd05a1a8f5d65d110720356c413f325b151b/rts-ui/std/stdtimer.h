#ifndef _STD_TIMER_H
#define _STD_TIMER_H

// libevent headers
#include <event.h>
#include <event2/listener.h>
#include <event2/bufferevent.h>
#include <event2/buffer.h>
#include <event2/util.h>

#include "std/stdthread.h"

/*
// socket headers
// Network Includes
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#include <string>
*/

class STDTimer : public STDThread
{ 
	public:
		STDTimer( int nTimeoutSec, int nTimeoutUSec );
		~STDTimer();

	protected:
		virtual void onTimer( int nLineFD, short nEvent ) = 0;

		static void onTimerCB( int nLineFD, short nEvent, void *pPtr );
		virtual void thread();
		virtual void init();

		void startTimer();
		void resetTimer();
		void stopTimer();

		void getTimeout( int& nSec, int& nUSec );
		void setTimeout( int nSec, int nUSec );

	protected:
		struct timeval m_tTimeoutVal;
		int m_nTimeoutSec;
		int m_nTimeoutUSec;

		struct event_base* m_tBase;
		struct event* m_pTimeoutEv;

		STDMutex m_oMutex;
};

#endif

