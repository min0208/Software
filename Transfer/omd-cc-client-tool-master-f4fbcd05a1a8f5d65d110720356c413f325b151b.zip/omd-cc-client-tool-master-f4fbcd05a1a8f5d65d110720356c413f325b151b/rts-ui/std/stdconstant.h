#ifndef _STD_CONSTANT_H
#define _STD_CONSTANT_H

#define GRP_MAIN	"main"
#define GRP_LOG		"log"

#define TAG_LOG_LEVEL 		"log_level"
#define TAG_CONSOLE_DISPLAY 	"console_display"

#endif
