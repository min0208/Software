////////////////////////////////////////////////////////////////////////////////
// Date     Ver     Name    Description
// 20120510 r1	    RC     Initial revision
////////////////////////////////////////////////////////////////////////////////

#include "std/stdcsvlogger.h"
#include "std/stdmutexlocker.h"
#include "std/stdtimeutil.h"
#include <fstream>

#include <algorithm>
#include <sys/stat.h>
#define LOG_C	"|STDCSVLog| "

bool compareIndex( const STDCSVLogger::CSV_DATA& a, const STDCSVLogger::CSV_DATA& b )
{
	return a.nField < b.nField;
}

STDCSVLogger::STDCSVLogger( const char *sPath )
{
	int nPathLen = strlen( sPath );
	int nBufLen = sizeof( m_sPath );

	nPathLen = (nPathLen > nBufLen) ? nBufLen : nPathLen;

	strncpy( m_sPath, sPath, nPathLen );
	m_sPath[ nPathLen] = 0;

	if ( m_sPath[ nPathLen-1] != '/' )
	{
		if ( nPathLen < nBufLen - 1 )
		{
			m_sPath[ nPathLen] = '/';
			m_sPath[ nPathLen+1] = 0;
		}
		else
		{
			printf( "%s create log folder (%s) fail. folder name too long\n", LOG_C, m_sPath );
			return;
		}
	}

	if ( mkdir(m_sPath, S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH ) == -1 )	
	{
		if ( errno != EEXIST )
		{
			printf( "%s create log folder (%s) fail. %s\n", LOG_C, m_sPath, strerror(errno) );
			return;
		}
	}
}

STDCSVLogger::STDCSVLogger( vector<CSV_FIELD_LEN>& vTemplate, const char *sPath ) :
	m_vTemplate(vTemplate)
{
	int nPathLen = strlen( sPath );
	int nBufLen = sizeof( m_sPath );

	nPathLen = (nPathLen > nBufLen) ? nBufLen : nPathLen;

	strncpy( m_sPath, sPath, nPathLen );
	m_sPath[ nPathLen] = 0;

	if ( m_sPath[ nPathLen-1] != '/' )
	{
		if ( nPathLen < nBufLen - 1 )
		{
			m_sPath[ nPathLen] = '/';
			m_sPath[ nPathLen+1] = 0;
		}
		else
		{
			printf( "%s create log folder (%s) fail. folder name too long\n", LOG_C, m_sPath );
			return;
		}
	}

	if ( mkdir(m_sPath, S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH ) == -1 )	
	{
		if ( errno != EEXIST )
		{
			printf( "%s create log folder (%s) fail. %s\n", LOG_C, m_sPath, strerror(errno) );
			return;
		}
	}
}

STDCSVLogger::~STDCSVLogger()
{
}

void STDCSVLogger::escapeDoubleQuotes( const char* sInStr, char* sOutStr )
{
	while ( *sInStr != 0 )
	{
		//		printf( "0x%02X\n", (unsigned char) *sInStr );

		if ( *sInStr == '\"' ) 
		{
			*sOutStr = '\"';
			sOutStr++;
			*sOutStr = '\"';
			sOutStr++;
		} 
		else 
		{
			*sOutStr = *sInStr;
			sOutStr++;
		}

		sInStr++;
	}

	*sOutStr = 0;

}

bool STDCSVLogger::log( vector<CSV_DATA>& vLogData, bool bExcelFormat, const char* sFilename, const char* sHeader )
{
	STDMutexLocker oLocker(m_oMutex);

	string sCSVRecord;

	sort( vLogData.begin(), vLogData.end(), compareIndex );

	unsigned int nDataIndex = 0;

	for ( unsigned int i=0; i<m_vTemplate.size(); i++ )
	{
		if ( nDataIndex >= vLogData.size() )
		{
			if ( bExcelFormat )
			{
				sCSVRecord += "\"\"";
			}

			sCSVRecord += ",";
		}
		else if ( i == vLogData[ nDataIndex].nField )
		{
			char sConvertStr[ (MAX_DATA_SIZE*2) + 1];
			unsigned int MAX_FIELD_LEN = m_vTemplate[ i];

			if ( bExcelFormat )
			{
				sCSVRecord += "=\"";

				escapeDoubleQuotes( vLogData[ nDataIndex].sData, sConvertStr );
				memcpy( vLogData[ nDataIndex].sData, sConvertStr, MAX_DATA_SIZE );
				vLogData[ nDataIndex].sData[ MAX_DATA_SIZE] = 0;
			}

			if ( strlen(vLogData[ nDataIndex].sData) > MAX_FIELD_LEN )
			{
				// truncate exceed string
				char sBuf[ MAX_FIELD_LEN + 1];
				strncpy( sBuf, vLogData[ nDataIndex].sData, MAX_FIELD_LEN );
				sBuf[ MAX_FIELD_LEN] = 0;
				sCSVRecord += sBuf;
			}
			else
			{
				sCSVRecord += vLogData[ nDataIndex].sData;
			}

			if ( bExcelFormat )
			{
				sCSVRecord += "\"";
			}

			sCSVRecord += ",";

			nDataIndex++;
		}
		else
		{
			if ( bExcelFormat )
			{
				sCSVRecord += "\"\"";
			}

			sCSVRecord += ",";
		}
	}

	/// remove the last comma
	if ( !sCSVRecord.empty() )
	{
		sCSVRecord.erase( sCSVRecord.size() - 1 ); 
	}

	//////////////////////////////////////////////
	// write the record to log file
	FILE* pFile;
	char sFullPath[ 1024];

	sprintf( sFullPath, "%s%s", m_sPath, sFilename );

	bool bNewFile = fileExists( sFullPath );

	if ( (pFile = fopen(sFullPath, "a")) == NULL )
	{
		return false;
	}

	if ( sHeader && !bNewFile )
	{
		char BOM[] = { 0xEF, 0xBB, 0xBF };

		fwrite( BOM, 3, 1, pFile );
		fprintf( pFile, "%s\n", sHeader );
	}

	fprintf( pFile, "%s\n", sCSVRecord.c_str() );
	fclose( pFile );

	return true;
}

bool STDCSVLogger::fileExists( const char *sFilename )
{
	std::ifstream iFile( sFilename );

	return iFile;
} 

bool STDCSVLogger::loadTemplate( vector<CSV_FIELD_LEN>& vTemplate )
{
	if ( vTemplate.size() == 0 ) return false;

	m_vTemplate = vTemplate;

	return true;
}

