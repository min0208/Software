////////////////////////////////////////////////////////////////////////////////
// Date     Ver     Name    Description
// 20040422 r1        RC        Initial revision
////////////////////////////////////////////////////////////////////////////////

#ifndef _STD_RAW_LOGGER_H
#define _STD_RAW_LOGGER_H

#include <errno.h>

#include "std/stdmutex.h"

class STDRawLogger
{
public:
	STDRawLogger( const char* sPath="./", const char* sFilename="raw.log" );
        ~STDRawLogger(); 

	bool log( int nLineNum, const char* pData, unsigned int nDataSize );

protected:
	void rotateFile( const char* sFilename, const char* sBackupFilename, int nMaxFileSize );

private:
	STDMutex m_oMutex;

	char m_sPath[ 128];
	char m_sFilename[ 256];

	//unsigned long m_nMaxFileSize;
	bool m_bFileRotation;
	STDMutex m_oRotateMutex;
};

#endif

