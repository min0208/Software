//////////////////////////////////////////////////////////////////////////////////
//// Date	Ver	Name	Description
//// 20120430	r1	RC	Initial revision
//////////////////////////////////////////////////////////////////////////////////

#include "std/stdtcpserver.h"
#include "std/stdapp.h"
#include "std/stdmutexlocker.h"

#define LOGC "|STDTCPSe| "

STDTCPServer::STDTCPServer( int nId, const char* sDesc, const char* sLocalIP, int nLocalPort, int nHeartBeatInterval, int nIdleTimeout ) : 
	m_nId(nId),
	m_sDesc(sDesc),
	m_sLocalIP(sLocalIP),
	m_nLocalPort(nLocalPort),
	HEARTBEAT_INTERVAL(nHeartBeatInterval),
	m_nHeartBeatIntervalCnt(0),
	IDLE_TIMEOUT(nIdleTimeout),
	m_nIdleTimeoutCnt(0),
	m_pAcceptEv(NULL)
{
}

STDTCPServer::~STDTCPServer()
{
	if ( m_pAcceptEv )
	{
		close( m_nServerFd );
		event_del( m_pAcceptEv );
		free( m_pAcceptEv );
	}
}

bool STDTCPServer::createListenPort()
{
	m_nServerFd = socket( AF_INET, SOCK_STREAM, 0 );

	if ( m_nServerFd < 0 )
	{
		STDGetLogger()->log( STDLOG_L2, LOGC "id|%d| socket error|%d %s|", m_nId, errno, strerror(errno) );
		return false;
	}

	int nFlag = 1;

	// Set socket option
	if ( setsockopt(m_nServerFd, SOL_SOCKET, SO_REUSEADDR, &nFlag, sizeof(int)) < 0 )
	{
		STDGetLogger()->log( STDLOG_L2, LOGC "id|%d| setsockopt SO_REUSEADDR error|%d %s|", m_nId, errno, strerror(errno) );
		return false;
	}

	struct sockaddr_in tListenAddr;

	memset( &tListenAddr, 0, sizeof(tListenAddr) );
	tListenAddr.sin_family = AF_INET;
	tListenAddr.sin_addr.s_addr = INADDR_ANY;
	tListenAddr.sin_port = htons(m_nLocalPort);

	if ( bind(m_nServerFd, (struct sockaddr *)&tListenAddr, sizeof(tListenAddr)) < 0 )
	{
		STDGetLogger()->log( STDLOG_L2, LOGC "id|%d| bind error|%d %s|", m_nId, errno, strerror(errno) );
		return false;
	}

	if ( listen(m_nServerFd , 5) < 0 )
	{
		STDGetLogger()->log( STDLOG_L2, LOGC "id|%d| listen error|%d %s|", m_nId, errno, strerror(errno) );
		return false;
	}

	STDGetLogger()->log( STDLOG_L3, LOGC "listen port|%d| id|%d| desc|%s|", m_nLocalPort, m_nId, m_sDesc.c_str() );

	if ( setNonBlock(m_nServerFd) < 0 )
	{
		return false;
	}

	m_pAcceptEv = event_new( m_tBase, m_nServerFd, EV_READ|EV_PERSIST, onAcceptCB, this );
	event_add( m_pAcceptEv, NULL );

	return true;
}

bool STDTCPServer::onInit()
{
	return createListenPort();
}

int STDTCPServer::setNonBlock( int nFd )
{
	int nFlags = fcntl( m_nServerFd, F_GETFL );

	if ( nFlags < 0 )
	{
		STDGetLogger()->log( STDLOG_L2, LOGC "id|%d| fcntl F_GETFL error|%d %s|", m_nId, errno, strerror(errno) );
		return nFlags;
	}

	nFlags |= O_NONBLOCK;

	if ( fcntl(m_nServerFd, F_SETFL, nFlags) < 0 )
	{
		STDGetLogger()->log( STDLOG_L2, LOGC "id|%d| fcntl set O_NONBLOCK flag|%d| error|%d %s|", m_nId, nFlags, errno, strerror(errno) );
		return nFlags;
	}

	return nFlags;
}

bool STDTCPServer::closeConnection( int nClientFd )
{
	STDMutexLocker oLocker(m_oConnectionMutex);
	
	close( nClientFd );
	event_del( m_mClient[ nClientFd] );
	free( m_mClient[ nClientFd] );
	m_mClient.erase( nClientFd );

	return true;
}

void STDTCPServer::onRead( int nClientFd, short nEvents, void* pPtr )
{
	char aBuf[ 65535];
	int nDataLen;

	nDataLen = read( nClientFd, aBuf, sizeof(aBuf) );

	if ( nDataLen <= 0 ) 
	{
		onClose( nClientFd );
		closeConnection( nClientFd );
	}
	else
	{
		onReceive( nClientFd, aBuf, nDataLen );
	}
}

void STDTCPServer::onReceive( int nClientFd, const char* pData, int nDataSize )
{
	STDGetLogger()->log( STDLOG_L3, LOGC "id|%d| on recv data size|%d|", nClientFd, nDataSize );
}

void STDTCPServer::onClose( int nClientFd )
{
	STDGetLogger()->log( STDLOG_L3, LOGC "id|%d| on close", nClientFd );
}

void STDTCPServer::onReadCB( int nClientFd, short nEvents, void* pPtr )
{
	((STDTCPServer*)pPtr)->onRead( nClientFd, nEvents, pPtr );
}

void STDTCPServer::onAcceptHandler( int nServerFd, short nEvents, void *pPtr )
{
	STDMutexLocker oLocker(m_oConnectionMutex);

	struct sockaddr_in tClientAddr;

	socklen_t nClientLen = sizeof(tClientAddr);

	int nClientFd = accept( nServerFd, (struct sockaddr *)&tClientAddr, &nClientLen );;

	if ( nClientFd == -1) 
	{
		STDGetLogger()->log( STDLOG_L2, LOGC "id|%d| accept error|%d %s|", m_nId, errno, strerror(errno) );
		return;
	}

	if ( setNonBlock(nClientFd) < 0 )
	{
		return;
	}

	struct event* pClientEv = event_new( m_tBase, nClientFd, EV_READ|EV_PERSIST, onReadCB, this );

	if ( pClientEv == NULL )
	{
		STDGetLogger()->log( STDLOG_L2, LOGC "id|%d| create client event error|%d %s|", m_nId, errno, strerror(errno) );
		return;
	}

	STDGetLogger()->log( STDLOG_L2, LOGC "id|%d| accept connection from|%s:%d|", m_nId, inet_ntoa(tClientAddr.sin_addr), ntohs(tClientAddr.sin_port) );

	m_mClient[ nClientFd] = pClientEv;
	event_add( pClientEv, NULL );

	onAccept( nClientFd, tClientAddr );
}

void STDTCPServer::onAcceptCB( int nServerFd, short nEvents, void *pPtr )
{
	((STDTCPServer*)pPtr)->onAcceptHandler( nServerFd, nEvents, pPtr );
}

bool STDTCPServer::send( int nClientFd, const char* pData, unsigned int nDataSize )
{
	STDMutexLocker oLocker(m_oSendMutex);

	map<int,event*>::iterator oItr = m_mClient.find( nClientFd );	

	if ( oItr == m_mClient.end() )
	{
		STDGetLogger()->log( STDLOG_L2, LOGC "send data error. client fd|%d| not found", nClientFd );
		return false;
	}

	int nResult = write( nClientFd, (const char*) pData, nDataSize );

	STDGetLogger()->log( STDLOG_L5, LOGC "sending |%d|bytes to client fd|%d|", nResult, nClientFd );

	return (nResult > 0);
}

