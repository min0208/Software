//////////////////////////////////////////////////////////////////////////////////
//// Date	Ver	Name	Description
//// 20120430	r1	RC	Initial revision
//////////////////////////////////////////////////////////////////////////////////

#include "std/stdtimer.h"
#include "std/stdmutexlocker.h"
#include "std/stdapp.h"

#define LOGC "|STDTimer | "

STDTimer::STDTimer( int nTimeoutSec, int nTimeoutUSec ) :
	m_nTimeoutSec(nTimeoutSec),
	m_nTimeoutUSec(nTimeoutUSec),
	m_tBase(NULL),
	m_pTimeoutEv(NULL)
{
}

STDTimer::~STDTimer()
{
	STDMutexLocker oLocker(m_oMutex);

        if ( m_tBase )	event_base_loopbreak( m_tBase );
        if ( m_pTimeoutEv ) event_del( m_pTimeoutEv );
        if ( m_tBase ) event_base_free( m_tBase );

        join();
}

void STDTimer::init()
{
	m_tBase = event_base_new();

	m_tTimeoutVal.tv_sec = m_nTimeoutSec;
	m_tTimeoutVal.tv_usec = m_nTimeoutUSec;

	m_pTimeoutEv = event_new( m_tBase, -1, EV_PERSIST, &onTimerCB, this );
	event_add( m_pTimeoutEv, &m_tTimeoutVal );
}

void STDTimer::thread()
{
	init();

	event_base_dispatch( m_tBase );
}

void STDTimer::resetTimer()
{
	stopTimer();
	startTimer();
}

void STDTimer::onTimerCB( int nLineFD, short nEvent, void *pPtr )
{
        ((STDTimer*)pPtr)->onTimer( nLineFD, nEvent );
}

void STDTimer::startTimer()
{
	STDMutexLocker oLocker(m_oMutex);

	m_pTimeoutEv = event_new( m_tBase, -1, EV_PERSIST, &onTimerCB, this );
	event_add( m_pTimeoutEv, &m_tTimeoutVal );
}

void STDTimer::stopTimer()
{
	STDMutexLocker oLocker(m_oMutex);
	event_del( m_pTimeoutEv );
}

void STDTimer::getTimeout( int& nSec, int& nUSec )
{
	nSec = m_nTimeoutSec;
	nUSec = m_nTimeoutUSec;
}

void STDTimer::setTimeout( int nSec, int nUSec )
{
	m_nTimeoutSec = nSec;
	m_nTimeoutUSec = nUSec;
}
