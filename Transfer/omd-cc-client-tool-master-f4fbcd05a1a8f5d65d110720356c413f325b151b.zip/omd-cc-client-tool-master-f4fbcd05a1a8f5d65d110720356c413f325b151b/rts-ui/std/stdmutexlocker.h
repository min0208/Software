////////////////////////////////////////////////////////////////////////////////
// Date     Ver     Name    Description
// 20040619 r1      RC     Initial revision
//
////////////////////////////////////////////////////////////////////////////////

#ifndef STDMUTEXLOCKER_H
#define STDMUTEXLOCKER_H

#include "std/stdmutex.h"

class STDMutexLocker
{
public:
	STDMutexLocker(STDMutex& oMutex): m_oMutex(oMutex)
	{
		m_oMutex.lock();
	};

	~STDMutexLocker()
	{
		m_oMutex.unlock();
	}


private:
	STDMutex& m_oMutex;
};

#endif

