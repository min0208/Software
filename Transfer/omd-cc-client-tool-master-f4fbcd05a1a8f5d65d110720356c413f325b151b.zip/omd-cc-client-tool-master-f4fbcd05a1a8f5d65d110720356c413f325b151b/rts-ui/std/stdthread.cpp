////////////////////////////////////////////////////////////////////////////////
// Date 	Ver 	Name	Description
// 20040429 r1		RC		Initial revision
////////////////////////////////////////////////////////////////////////////////

#include <cassert>
#include <iostream>

#include "std/stdthread.h"

extern "C"
{
	static void* threadWrapper( void* threadParm )
	{
		assert( threadParm );
		STDThread* t = static_cast <STDThread *> ( threadParm );

		assert( t );

		t->thread();

		return 0;
	}
}

STDThread::STDThread() : m_tId(0), m_bShutdown(true), m_bDetach(false), m_nStackSize(-1)
{
}

STDThread::~STDThread()
{

	shutdown();

	join();

}

void STDThread::run()
{
	// r3, otherwise a shutdown thread cannot be started again
	m_oShutdownMutex.lock();
	m_bShutdown = false;
	m_oShutdownMutex.unlock();

	m_oDetachMutex.lock();
	m_bDetach = false;
	m_oDetachMutex.unlock();

	if ( m_nStackSize > 0 )
	{
		pthread_attr_t oThreadAttribute;
		pthread_attr_init( &oThreadAttribute );
		pthread_attr_setstacksize( &oThreadAttribute, m_nStackSize );
		// spawn the thread
		if ( int nRetVal = pthread_create( &m_tId, &oThreadAttribute, threadWrapper, this ) )
		{
			std::cerr << "Failed to spawn thread: " << nRetVal << std::endl;

			assert(0);
			// TODO - ADD LOGING HERE
		}

		pthread_attr_destroy( &oThreadAttribute );
	}
	else if ( int nRetVal = pthread_create( &m_tId, 0, threadWrapper, this ) )
	{
		std::cerr << "Failed to spawn thread: " << nRetVal << std::endl;
		assert(0);
		// TODO - ADD LOGING HERE
	}

}


int 
STDThread::detach() {

	if ( m_bDetach )
	{
		return 0;
	}

	m_oDetachMutex.lock();
	m_bDetach = true;
	m_oDetachMutex.unlock();

	return pthread_detach( m_tId );
}

	void
STDThread::join()
{
	if (m_tId == 0 || m_bDetach)
	{
		return;
	}

	void* pStat;

	int r = pthread_join( m_tId , &pStat );

	if ( r!= 0 )
	{
		assert(0);
		// TODO
	}

	m_tId = 0;
}

	void
STDThread::exit()
{
	assert(m_tId != 0);

	pthread_exit(0);

	m_tId = 0;
}

	STDThread::Id
STDThread::selfId()
{
	return pthread_self();
}

	void
STDThread::shutdown()
{
	m_oShutdownMutex.lock();

	m_bShutdown = true;

	m_oShutdownMutex.unlock();
}

bool
STDThread::isShutdown() const
{
	return ( m_bShutdown );
}

