#include <stdio.h>
#include <string.h>
#include <errno.h>
#include "std/stdsema.h"

STDSema::STDSema() :
	m_bOpened(false)
{
}

STDSema::~STDSema()
{
	destroy();
}

bool STDSema::init( unsigned int nValue )
{

	if ( sem_init( &m_tSem, 0, nValue ) == -1 )
	{
		perror("STDSema::Create");
		return false;
	}
	else
	{
		m_bOpened = true;
		return true;
	}
}

bool STDSema::destroy()
{
	if (m_bOpened)
	{
		if ( sem_destroy(&m_tSem) == -1)
		{
			perror("STDSema::Destory");
			return false;
		}
		else
		{
			memset(&m_tSem, 0, sizeof(m_tSem));
			m_bOpened = false;
			return true;
		}
	}
	else
	{
		return false;
	}		
}

bool STDSema::wait()
{
	return sem_wait(&m_tSem) == 0;
}

bool STDSema::post()
{
	return sem_post(&m_tSem) == 0;
}

