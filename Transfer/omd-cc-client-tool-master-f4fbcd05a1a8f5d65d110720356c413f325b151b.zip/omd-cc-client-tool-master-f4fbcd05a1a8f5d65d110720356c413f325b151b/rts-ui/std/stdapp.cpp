////////////////////////////////////////////////////////////////////////////////
// MODULE:    stdapp.cpp
//
// Date     Ver     Name    Description
// 20040615 r1      RC     Initial revision
//
////////////////////////////////////////////////////////////////////////////////

#include "std/stdapp.h"

#include <unistd.h>

// file scope constant variables
#ifndef DEFAULT_CONFIG
#define DEFAULT_CONFIG "resource.cfg"
#endif

#ifndef DEFAULT_ADMIN_PORT
#define DEFAULT_ADMIN_PORT	9000
#endif

#define CFG_GROUP_SYS		"main"
#define CFG_STD_ADMIN_PORT	"admin_port"
#define CFG_STD_SUBSYSTEM	"subsystem"

// STDApp definition
STDApp::STDApp( const char* sCfgFile ) :
	m_nMsg(IDLE),
	m_bInitVer( false ),
	m_argc(0),
	m_argv(NULL),
	m_pSTDAdminServer(NULL)
{
	m_sConfig = (sCfgFile) ? sCfgFile : DEFAULT_CONFIG;

	CAppInstance::instance()->regApp(this);

	m_pConfig = new STDConfig;
}

STDApp::~STDApp()
{
	if ( m_pConfig )
	{
		delete m_pConfig;
		m_pConfig = NULL;
	}

	if ( m_pSTDAdminServer )
	{
		delete m_pSTDAdminServer;
		m_pSTDAdminServer = NULL;
	}

	if ( m_pLogger )
	{
		delete m_pLogger;
		m_pLogger = NULL;
	}
}

void STDApp::initAppInfo(const string& sAppName, const string& sBuild, const string& sVersion, const string& sDescription)
{
	m_sAppName = sAppName;
	m_sBuild = sBuild;
	m_sVersion = sVersion;
	m_sDescription = sDescription;
}

void STDApp::initVerInfo(const string& sAppName, const string& sVersion, const string& sDescription, const string& sBuildDate ) 
{
	m_sAppName = sAppName;
	m_sBuild = "";
	m_sVersion = sVersion;
	m_sDescription = sDescription;
	m_sBuildDate = sBuildDate;
	m_bInitVer = true;
}

bool STDApp::onRecvAdminCmd( const STD_CMD_T& tCmd )
{
	logger().log( STDLOG_L3, "STDApp::onRecvAdminCmd()" );

	return false;
}

void STDApp::getCfgSubSystem()
{
	const char* sLogPath = GET_CFG_STR( "log", "log_path", "./log" );
	const char* sLogExt = GET_CFG_STR( "log", "log_ext", "log" );
	int nLogLevel = GET_CFG_INT( "log", "log_level", STDLOG_L7 );
	int nLogDisplay = GET_CFG_INT( "log", "console_display", 1 );

	m_pLogger = new STDLogger( (char*)sLogPath, (char*)sLogExt );
	STDGetLogger()->setLevel( nLogLevel );
	STDGetLogger()->setDisplay( nLogDisplay );

	char* pSubSystem = getConfig().get( CFG_GROUP_SYS, CFG_STD_SUBSYSTEM );

	if ( pSubSystem ) 
	{
		m_sSubSystem = pSubSystem;
	}
	else
	{
		m_sSubSystem = "stdapp";
	}

	//m_pLogger->log( STDLOG_L5, "SubSystem [%s]", m_sSubSystem.c_str() );
}

const char* STDApp::getSubSystem() const
{
	return m_sSubSystem.c_str();	
}

bool STDApp::initAdminServer()
{
	static const char* ADMIN_GRP = "main";
	static const char* ADMIN_TAG = "admin_port";

	if ( getConfig().get(ADMIN_GRP, ADMIN_TAG) )
	{
		int nAdminPort = GET_CFG_INT( ADMIN_GRP, ADMIN_TAG, DEFAULT_ADMIN_PORT );
		m_pSTDAdminServer = new STDTCPServerTmpl<STDAdminChild>( 0, "admin port", "127.0.0.1", nAdminPort, 0, 3600 );
		m_pSTDAdminServer->run();
		return true;
	}

	return false;
}

bool STDApp::appInit( int argc, char** argv )
{
	m_argc = argc;
	m_argv = argv;

	if (argc > 1)
	{
		if (!getParam(argc, argv))
			exit(0);
	}

	// init itself
	readConfig(m_sConfig);

	// get the subsystem name
	getCfgSubSystem();

	// start the admin port
	initAdminServer();

	// get the binary executable name
	m_sBinaryName.append( argv[0] );

	if ( m_sBinaryName.find( "./" ) == 0 ) 
	{
		m_sBinaryName = m_sBinaryName.substr( 2, m_sBinaryName.length() );
	}

	// init child
	if ( initInstance() )
	{
		if ( m_bInitVer )
		{
			m_pLogger->log( STDLOG_L3, version().c_str() );
		}

		post(RUNNING);
		run();
		return true;
	}

	return false;
}

bool STDApp::appExit()
{
	exitInstance();

	return true;
}

void STDApp::post(int nMsg)
{
	m_nMsg = nMsg;
}

void STDApp::run()
{
	bool bLoop = true;

	for (;;)
	{
		bLoop = (m_nMsg == RUNNING);

		if (!bLoop)
			break;

		struct timeval tVal = { 1, 0 };
		select( 0, NULL, NULL, NULL, &tVal );
	}

	m_pLogger->log( STDLOG_L3, "exit STDApp::run()" );
}

STDLogger& STDApp::logger()
{
	return *m_pLogger;
}

STDLogger* STDApp::getLogger()
{
	return m_pLogger;
}

STDConfig& STDApp::getConfig()
{
	return *m_pConfig;
}

string STDApp::version() const
{
	char aVersion[1024] = { 0 };

	sprintf( aVersion, "%s - v%s Build %s\t%s", m_sAppName.c_str(), m_sVersion.c_str(), m_sBuildDate.c_str(), m_sDescription.c_str());

	return string(aVersion);
}

bool STDApp::readConfig( const string& sConfig )
{
	return m_pConfig->read(sConfig.c_str(), NULL) == STD_CFG_SUCCESS;
}

void STDApp::printUsage()
{
	printf("%s Usage:\n", m_sAppName.c_str());
	printf("\t-h\t\tprint this manual\n");
	printf("\t-v\t\tprint version\n");
	printf("\t-c file\t\tspecify config file\n");
}

void STDApp::printVersion()
{
	string sVersion = version();
	printf("%s", sVersion.c_str());
}

bool STDApp::getParam(int argc, char** argv)
{
	extern char *optarg;

	int nInput; 

	while ( (nInput = getopt(argc, argv, "hvc:")) != -1)
	{
		switch (nInput)
		{
			case 'h': // help
				printUsage();
				return false;
			case 'v': // version
				printVersion();
				return false;
			case 'c': // config file
				if (optarg)
					m_sConfig = optarg;
				break;
			default:
				break;
		}
	}

	return true;
}

string STDApp::handleVersionCmd( vector<pair<string, string> >& paramList ) 
{
	logger().log( STDLOG_L3, version().c_str() );	
	return version();
}

// helper class CAppInstance
CAppInstance* CAppInstance::m_pAppInst = NULL;

CAppInstance::CAppInstance() :
	m_pApp(NULL)
{
}

CAppInstance::~CAppInstance()
{
}

CAppInstance* CAppInstance::instance()
{
	if (!m_pAppInst)
	{
		m_pAppInst = new CAppInstance;
	}
	return m_pAppInst;
}

STDApp* CAppInstance::GetApp()
{
	return m_pApp;
}

void CAppInstance::regApp(STDApp* pApp)
{
	m_pApp = pApp;
}

