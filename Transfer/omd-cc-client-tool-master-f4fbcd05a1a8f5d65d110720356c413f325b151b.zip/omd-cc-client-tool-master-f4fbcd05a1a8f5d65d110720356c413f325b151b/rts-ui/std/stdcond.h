////////////////////////////////////////////////////////////////////////////////
// Date		Ver		Name	Description
// 20040602	r1		RC	Initial revision
////////////////////////////////////////////////////////////////////////////////

#ifndef STD_COND_H
#define STD_COND_H
#include <pthread.h>
#include "std/stdmutex.h"

class STDCond
{
public:

  STDCond(STDMutex & mutex) : m_mutex(mutex) { pthread_cond_init(&m_cond,0); }

  int signal() { return pthread_cond_signal(&m_cond); }

  int broadcast() { return pthread_cond_broadcast(&m_cond); }

  int wait(const struct timeval * abstime = 0);

  ~STDCond() { pthread_cond_destroy(&m_cond); }


private:

  pthread_cond_t m_cond;
  STDMutex &m_mutex;

};




#endif
