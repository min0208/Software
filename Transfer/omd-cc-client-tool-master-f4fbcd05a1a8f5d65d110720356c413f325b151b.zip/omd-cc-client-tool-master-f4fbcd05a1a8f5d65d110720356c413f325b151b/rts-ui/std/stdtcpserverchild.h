#ifndef _STDTCPServerChild_H
#define _STDTCPServerChild_H

#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string>

using namespace std;

class STDTCPServerChild
{
	public:
		STDTCPServerChild( int nFd, const sockaddr_in& tClientAddr );
		~STDTCPServerChild();

		virtual void onReceive( const char* pData, unsigned int nDataSize );

	protected:
		static const int TCP_BUF_SIZE = 65535;

		int m_nFd;
		sockaddr_in m_tAddrInfo;
		string m_sIP;
		int m_nPort;

		char m_aRcvBuf[ TCP_BUF_SIZE];
		unsigned int m_nRcvDataSize;
};

#endif

