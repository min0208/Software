////////////////////////////////////////////////////////////////////////////////
// Date 	Ver 	Name	Description
// 20040422 r1		RC		Initial revision
////////////////////////////////////////////////////////////////////////////////

#ifndef _STD_CONFIG_H
#define _STD_CONFIG_H

//#include <stdio.h>

#include "std/stdutil.h"

typedef struct ConfigVar {
	struct ConfigVar *pNext;
	char *sName;
	char *pValue;
} ConfigVar_t;

typedef struct ConfigGroup {
	struct ConfigGroup *pNext;
	ConfigVar_t *pVarList;
	ConfigVar_t *pLastVar;
} ConfigGroup_t;

typedef struct Config {
	char *sFilename;
	ConfigGroup_t *pGroupList;
	ConfigGroup_t *pLastGroup;
} Config_t;

#define STD_CFG_FAIL	0
#define STD_CFG_SUCCESS 1

#define GET_CFG(group, key)     getConfig().get(group, key)
#define GET_CFG_STR(group, key, value)  GET_CFG(group, key) ? GET_CFG(group, key) : value
#define GET_CFG_INT(group, key, value)  GET_CFG(group, key) ? atoi(GET_CFG(group, key)) : value
#define GET_CFG_FLT(group, key, value)  GET_CFG(group, key) ? atof(GET_CFG(group, key)) : value
#define GET_CFG_BOL(group, key, value)  GET_CFG(group, key) ? atoi(GET_CFG(group, key)) != 0 : value

class STDConfig
{
	public:
		STDConfig();
		~STDConfig();

		bool set( const char* sGroup, const char* sName, const char* sValue );
		char* get(const char *sGroup, const char *sName);
		int read(const char *sFilename, const char *sDefaultFile);
		void show();
		void destroy();

	private:
		Config_t m_tCfg;
		char* configGet(ConfigGroup_t *pGroup, char *sName);
		ConfigGroup_t* configAddGroup();
		ConfigVar_t *findVar(ConfigGroup_t *pGroup, char *sName);
		ConfigGroup_t* configFirstGroup();
		ConfigGroup_t* configFindFirstGroup(char *sName, const char *pValue);
		ConfigGroup_t* configFindNextGroup(ConfigGroup_t *pGroup, char *sName, const char *pValue);
		ConfigGroup_t* configNextGroup(ConfigGroup_t *pGroup);
		ConfigGroup_t* findGroupStartingWith(ConfigGroup_t *pGroup, char *sName, const char *pValue);

		void configCreate(const char *sFilename);
		void configSet(ConfigGroup_t *pGroup, char *sName, char *pValue);
		int configSanityCheck();
		void configClear();
		int configRead();

		void *varMalloc(size_t nSize);
		char *parseValue(char* pValue);
};

#endif

