#ifndef _STD_SOCKET_BASE_H
#define _STD_SOCKET_BASE_H

// libevent headers
#include <event.h>
#include <event2/listener.h>
#include <event2/bufferevent.h>
#include <event2/buffer.h>
#include <event2/util.h>

// socket headers
// Network Includes
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#include <string>

using namespace std;

#include "std/stdthread.h"

class STDSocketBase : public STDThread
{ 
	public:
		STDSocketBase( int nAPpTimer=1000000 );
		~STDSocketBase();

	protected:
		virtual void onHealthCheck( int nLineFD, short nEvent ){};
		virtual void onAppTimer( int nLineFD, short nEvent ){};
		virtual bool onInit(){ return true; };

		virtual void thread();
		bool init();
		void resetHealthCheckTimer();
		static void onHealthCheckCB( int nLineFD, short nEvent, void *pPtr );
		static void onAppTimerCB( int nLineFD, short nEvent, void *pPtr );

	protected:
		struct event_base* m_tBase;

		struct timeval m_tHealthCheckTimerVal;
		struct event* m_pHealthCheckEv;

		int m_nAppTimer;
		struct timeval m_tAppTimerVal;
		struct event* m_pAppTimerEv;

		STDMutex m_oBaseMutex;
		STDMutex m_oSendMutex;
};

#endif

