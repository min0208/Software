////////////////////////////////////////////////////////////////////////////////
// MODULE:    stdapp.h
//
// Date     Ver     Name    Description
// 20040615 r1      RC      Initial revision
////////////////////////////////////////////////////////////////////////////////

#ifndef STDAPP_H
#define STDAPP_H

#include <string>
#include <utility>
#include <vector>

#include "std/stdadminchild.h"
#include "std/stdconfig.h"
//#include "std/stdmutex.h"
#include "std/stdconstant.h"
#include "std/stdlogger.h"
#include "std/stdstructs.h"
#include "std/stdtcpserver_tmpl.h"

using namespace std;

class STDApp
{
	public:
		enum
		{
			IDLE,
			RUNNING,
			NORMAL_EXIT,
			ABNORMAL_EXIT
		};

	public:
		STDApp( const char* sCfgFile );
		virtual ~STDApp() = 0;

		int getMsg() const { return m_nMsg; }

		// Initialize
		void initAppInfo(const string& sAppName, const string& sBuild, const string& sVersion, const string& sDescription);

		void initVerInfo(const string& sAppName, const string& sVersion, const string& sDescription, const string& sBuildDate = __DATE__ );		

		// public interfaces
		bool appInit(int argc, char** argv);
		bool appExit();

		std::pair<int,char **> getCommandArguments() { return std::make_pair(m_argc,m_argv); };
		// loop of main thread
		virtual void run();
		virtual bool onRecvAdminCmd( const STD_CMD_T& tCmd );

		// return logger object
		STDLogger& logger();

		// return logger ptr
		STDLogger* getLogger();

		// return config
		STDConfig& getConfig();

		// return version
		string version() const;

		string getBinaryName() const { return m_sBinaryName; }; 

		const char* getSubSystem() const;

		// can post message to app thread (main thread)
		void post(int nMsg);

		//static string onCmd( void* ptr, string& sCmd, vector< pair<string, string> >& paramList );

		string handleVersionCmd( vector<pair<string, string> >& paramList );

	protected:
		// customize init and exit routine
		// initInstance call after readConfig
		virtual bool initInstance() { return true; };
		// exitInstance call when shutdown or exit signal
		virtual bool exitInstance() { return true; };

		bool readConfig(const string& filename);
		bool initAdminServer();

		void getCfgSubSystem();

		// override
		virtual bool onConfig(const string& filename) { return true; };

		// helper
		void printUsage();
		void printVersion();
		bool getParam(int argc, char** argv);
		void setConfig(const string& filename) { m_sConfig = filename; };
		const string& getConfigName() const { return m_sConfig; };


	private:
		// internal variables
		string m_sConfig;

		// subsystem
		string m_sSubSystem;

		int m_nMsg;

		STDLogger *m_pLogger;
		STDConfig *m_pConfig;

		string m_sAppName;
		string m_sBuild;
		string m_sVersion;
		string m_sDescription;

		string m_sBinaryName;
		string m_sBuildDate;
		bool m_bInitVer;

		int m_argc;

		char ** m_argv;

		STDTCPServerTmpl<STDAdminChild>* m_pSTDAdminServer;
};


// help class for singletion app container
class CAppInstance
{
	friend class STDApp;

	public:
	~CAppInstance();

	// singleton interface
	static CAppInstance* instance();

	// public interface for app
	STDApp* GetApp();

	protected:
	CAppInstance();

	static CAppInstance* m_pAppInst;

	// protected interface for friend STDApp
	void regApp(STDApp* pApp);

	// this is the pointer for containing the app pointer
	STDApp* m_pApp;
};

// helper function
inline STDApp* STDGetApp()
{
	return CAppInstance::instance()->GetApp();
}

inline STDLogger* STDGetLogger() 
{
	return STDGetApp()->getLogger();
}

#endif

