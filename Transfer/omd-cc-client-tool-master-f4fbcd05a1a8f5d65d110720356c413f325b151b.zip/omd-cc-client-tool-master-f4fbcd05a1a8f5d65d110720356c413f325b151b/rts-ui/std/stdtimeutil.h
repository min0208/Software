////////////////////////////////////////////////////////////////////////////////
// Date		Ver		Name	Description
// 20040820     r4              RC       added operator+ operator- for data type integer 
////////////////////////////////////////////////////////////////////////////////
#ifndef STDTIMEUTIL_H
#define STDTIMEUTIL_H
#include <sys/time.h>
#include <time.h>
#include <string.h>
#include <string>
#include "std/stdmutex.h"

class STDTimeUtil
{
	public:
		static void normalize(struct timeval &val);
};

//r4
inline struct timeval operator - (const struct timeval & lhs,const int &rhs)
{
	struct timeval result; 
	result.tv_sec = lhs.tv_sec - rhs;
	result.tv_usec = 0;
	STDTimeUtil::normalize(result);
	return result;
}
inline struct timeval operator + (const struct timeval & lhs,const int &rhs)
{
	struct timeval result; 
	result.tv_sec = lhs.tv_sec + rhs;
	result.tv_usec = 0;
	STDTimeUtil::normalize(result);
	return result;
}
inline struct timeval operator + (const struct timeval & lhs,const struct timeval &rhs)
{
	struct timeval result; result.tv_sec = lhs.tv_sec + rhs.tv_sec;
	result.tv_usec = lhs.tv_usec + rhs.tv_usec;
	STDTimeUtil::normalize(result);
	return result;

}
inline struct timeval operator - (const struct timeval & lhs,const struct timeval &rhs)
{
	struct timeval result;
	result.tv_sec = lhs.tv_sec - rhs.tv_sec;
	result.tv_usec = lhs.tv_usec - rhs.tv_usec;
	STDTimeUtil::normalize(result);
	return result;

}
inline bool operator < (const struct timeval &lhs,const struct timeval &rhs)
{
	if(lhs.tv_sec < rhs.tv_sec)
		return true;
	else
		if(lhs.tv_sec == rhs.tv_sec &&
				lhs.tv_usec < rhs.tv_usec)
			return true;
	return false;
}
inline bool operator <= (const struct timeval &lhs,const struct timeval &rhs)
{
	if(lhs.tv_sec < rhs.tv_sec)
		return true;
	else
		if(lhs.tv_sec == rhs.tv_sec &&
				lhs.tv_usec <= rhs.tv_usec)
			return true;
	return false;

}

inline bool operator == (const struct timeval  &lhs,const struct timeval &rhs)
{
	return lhs.tv_sec == rhs.tv_sec &&
		lhs.tv_usec == rhs.tv_usec;
}

inline bool operator > (const struct timeval &lhs,const struct timeval &rhs)
{
	return rhs < lhs;
}

inline bool operator >= (const struct timeval &lhs,const struct timeval &rhs)
{
	return rhs <= lhs;
}

//r2
#ifdef __GLIBC__
inline struct tm *stdlocaltime_r(const time_t *timep, struct tm *result)
{
	return localtime_r(timep,result);
}
#else //solaris localtime_r() seem to be buggy and may cause program crash,use localtime protected by mutex
inline struct tm *stdlocaltime_r(const time_t *timep, struct tm *result)
{
	static STDMutex mutex;
	mutex.lock();
	struct tm * res = localtime(timep);
	memcpy(result,res, sizeof(struct tm));
	mutex.unlock();
	return result;
}
#endif

//r3
/* return a stringified time with the format used in stdlogger */
char *stdctime(const time_t *timep,char *buf);

#endif
