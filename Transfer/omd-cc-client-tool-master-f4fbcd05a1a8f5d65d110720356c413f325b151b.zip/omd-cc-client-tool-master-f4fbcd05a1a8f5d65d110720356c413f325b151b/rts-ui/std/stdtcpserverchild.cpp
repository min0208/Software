//////////////////////////////////////////////////////////////////////////////////
//// Date	Ver	Name	Description
//// 20120430	r1	RC	Initial revision
//////////////////////////////////////////////////////////////////////////////////

#include "std/stdtcpserverchild.h"
#include "std/stdapp.h"

#define LOGC "|STDTCPSC| "

STDTCPServerChild::STDTCPServerChild( int nFd, const sockaddr_in& tClientAddr ) :
	m_nFd(nFd),
	m_tAddrInfo(tClientAddr)
{
	m_sIP = inet_ntoa( m_tAddrInfo.sin_addr);
	m_nPort = ntohs( m_tAddrInfo.sin_port );	
}

STDTCPServerChild::~STDTCPServerChild()
{
	STDGetLogger()->log( STDLOG_L3, LOGC "fd|%d| ip|%s:%d| ~STDTCPServerChild()", m_nFd, m_sIP.c_str(), m_nPort );
}

void STDTCPServerChild::onReceive( const char* pData, unsigned int nDataSize )
{
	STDGetLogger()->log( STDLOG_L3, LOGC "receive data from fd|%d| ip|%s:%d|. implement your code here", m_nFd, m_sIP.c_str(), m_nPort );
}

