////////////////////////////////////////////////////////////////////////////////
// Date 	Ver 	Name	Description
// 20040422 r1		RC		Initial revision
////////////////////////////////////////////////////////////////////////////////

#include "std/stdconfig.h"

STDConfig::STDConfig()
{

	m_tCfg.pGroupList = NULL;

	m_tCfg.pLastGroup = NULL;

	m_tCfg.sFilename = NULL;
}

STDConfig::~STDConfig()
{

	destroy();

}

int STDConfig::read(const char *sFilename, const char *sDefaultFile)
{

		if (sFilename == NULL)
		{
				sFilename = sDefaultFile;
		}

		configCreate( sFilename );

		if (configRead() == -1)
		{

				destroy();

				return STD_CFG_FAIL;

		}

		if (configSanityCheck() == STD_CFG_FAIL)
		{

				destroy();

				return STD_CFG_FAIL;

		}

		return STD_CFG_SUCCESS;

}

void STDConfig::destroy()
{
		configClear();

		if (m_tCfg.sFilename != NULL)
		{
				free( m_tCfg.sFilename );
				m_tCfg.sFilename = NULL;
		}
}

char* STDConfig::get(const char *sGroup, const char *sName)
{
		ConfigGroup_t *pGrp;
		ConfigVar_t *pVar;

		pGrp = configFindFirstGroup( (char *)"group", sGroup );

		if (pGrp == NULL) return NULL;

		for (pVar = pGrp->pVarList; pVar != NULL; pVar = pVar->pNext)
		{
				if (strcmp(sName, pVar->sName) == 0)
						return pVar->pValue;
		}

		return NULL;
}

bool STDConfig::set( const char* sGroup, const char* sName, const char* sValue )
{
	ConfigGroup_t *pGrp;
	ConfigVar_t *pVar;

	pGrp = configFindFirstGroup( (char *)"group", sGroup );

	if (pGrp == NULL) return false;

	for (pVar = pGrp->pVarList; pVar != NULL; pVar = pVar->pNext)
	{
		if ( strcmp(sName, pVar->sName) == 0 )
		{
			if ( strlen(pVar->pValue) < strlen(sValue) )
			{ 
				char* pValue = (char *) varMalloc( strlen(sValue)+1 );
				strcpy( pValue, sValue );
				char* pTemp = pVar->pValue;
				pVar->pValue = pValue;
				free( pTemp );
			}
			else
			{
				strcpy( pVar->pValue, sValue );
			}
			return true;
		}
	}

	return false;
}

int STDConfig::configSanityCheck()
{
		ConfigGroup_t *pGrp;
		char *sGroup;

		pGrp = configFirstGroup();

		while(pGrp != NULL)
		{
				sGroup = configGet( pGrp, (char *)"group" );

				if (sGroup == NULL)
				{
						printf( "[STDConfig] A group without 'group' variable in configuration\n" );
						return STD_CFG_FAIL;
				}

				pGrp = configNextGroup( pGrp );
		}

		return STD_CFG_SUCCESS;
}

ConfigGroup_t* STDConfig::configFirstGroup()
{
		return m_tCfg.pGroupList;
}

ConfigGroup_t* STDConfig::configNextGroup(ConfigGroup_t *pGrp)
{
		if (pGrp == NULL) return NULL;

		return pGrp->pNext;
}

ConfigGroup_t* STDConfig::configFindFirstGroup(char *sName, const char *pValue)
{
		return findGroupStartingWith( m_tCfg.pGroupList, sName, pValue );
}

ConfigGroup_t* STDConfig::configFindNextGroup(ConfigGroup_t *pGrp, char *sName, const char *pValue)
{
		if (pGrp == NULL) return NULL;

		return findGroupStartingWith( pGrp->pNext, sName, pValue );
}

ConfigGroup_t* STDConfig::findGroupStartingWith(ConfigGroup_t *pGrp, char *sName, const char *pValue)
{
		char *pVar;

		while (pGrp != NULL)
		{
				pVar = configGet( pGrp, sName );

				if (pVar != NULL && strcmp(pVar, pValue) == 0)
						break;

				pGrp = pGrp->pNext;
		}

		return pGrp;
}

ConfigGroup_t* STDConfig::configAddGroup()
{
		ConfigGroup_t *pGrp;

		pGrp = (ConfigGroup_t *) varMalloc( sizeof(ConfigGroup_t) );

		pGrp->pNext = NULL;
		pGrp->pVarList = NULL;
		pGrp->pLastVar = NULL;

		if (m_tCfg.pGroupList == NULL)
		{
				m_tCfg.pGroupList = pGrp;
				m_tCfg.pLastGroup = pGrp;
		}
		else
		{
				m_tCfg.pLastGroup->pNext = pGrp;
				m_tCfg.pLastGroup = pGrp;
		}

		return pGrp;
}

ConfigVar_t *STDConfig::findVar(ConfigGroup_t *pGrp, char *sName)
{
		ConfigVar_t *pVar;

		for (pVar = pGrp->pVarList; pVar != NULL; pVar = pVar->pNext)
		{
				if (strcmp(pVar->sName, sName) == 0)
						return pVar;
		}

		return NULL;
}

char* STDConfig::configGet(ConfigGroup_t *pGrp, char *sName)
{
		ConfigVar_t *pVar;

		if (pGrp == NULL) return NULL;

		for (pVar = pGrp->pVarList; pVar != NULL; pVar = pVar->pNext)
		{
				if (strcmp(sName, pVar->sName) == 0)
						return pVar->pValue;
		}

		return NULL;
}

void STDConfig::configSet(ConfigGroup_t *pGrp, char *sName, char *pValue)
{
		ConfigVar_t *pVar, *pNewVar;
		char *pNewValue;

		if (pValue == NULL)
				return;

		pNewVar = NULL;

		pVar = findVar(pGrp, sName);

		if (pVar == NULL)
		{
				pNewVar = (ConfigVar_t *) varMalloc(sizeof(ConfigVar_t));

				pNewVar->pValue = NULL;
				pNewVar->pNext = NULL;
				pNewVar->sName = (char *) varMalloc( strlen(sName)+1 );
				strcpy( pNewVar->sName, sName );

				if (pGrp->pVarList == NULL)
				{
						pGrp->pVarList = pNewVar;
						pGrp->pLastVar = pNewVar;
				}
				else
				{
						pGrp->pLastVar->pNext = pNewVar;
						pGrp->pLastVar = pNewVar;
				}

				pVar = pNewVar;
		}

		pNewValue = (char *) varMalloc( strlen(pValue)+1 );
		strcpy( pNewValue, pValue );

		if (pVar->pValue != NULL)
		{
			char* pTemp = pVar->pValue;
			pVar->pValue = pNewValue;
			free( pTemp );
		}
		else
		{
			pVar->pValue = pNewValue;
		}
}

void STDConfig::configClear()
{
		ConfigGroup_t *pGrp, *pGrpNext;

		ConfigVar_t *pVar, *pVarNext;

		for (pGrp = m_tCfg.pGroupList; pGrp != NULL; pGrp = pGrpNext)
		{
				pGrpNext = pGrp->pNext;

				for (pVar = pGrp->pVarList; pVar != NULL; pVar = pVarNext)
				{
						pVarNext = pVar->pNext;
						free( pVar->sName );
						free( pVar->pValue );
						free( pVar );
				}

				free( pGrp );
		}

		m_tCfg.pGroupList = NULL;

		m_tCfg.pLastGroup = NULL;
}

void *STDConfig::varMalloc(size_t nSize)
{
		void *pMem;

		if (nSize <= 0)
		{
				printf( "[STDConfig] Memory allocation of %lu bytes failed\n",
					(unsigned long)nSize );
				return NULL;
		}

		pMem = malloc( nSize );

		if (pMem == NULL)
		{
			  printf( "[STDConfig] Memory allocation of %lu bytes failed\n",
					(unsigned long)nSize );
		}

		return pMem;
}

char *STDConfig::parseValue(char *sStr)
{
		char *p, *sStr2;

		STDUtil::trimLeft( sStr, sStr, ' ' );
		STDUtil::trimRight( sStr, sStr, ' ' );

		sStr2 = (char *) varMalloc(strlen(sStr) + 1);

		if (*sStr == '"') {
				++sStr;
				p = sStr2;
				while (*sStr != '"' && *sStr != '\0') {
						switch (*sStr) {
						case '\\':
								switch (sStr[1]) {
								case '\0':
										*p++ = '\\';
										sStr += 1;
										break;
								case '\\':
										*p++ = '\\';
										sStr += 2;
										break;
								case '"':
										*p++ = '"';
										sStr += 2;
										break;
								default:
										*p++ = '\\';
										*p++ = sStr[1];
										sStr += 2;
										break;
								}
								break;
						default:
								*p++ = *sStr++;
								break;
						}
				}
				*p = '\0';
		} else {
				strcpy( sStr2, sStr );;
		}

		return sStr2;
}

void STDConfig::show()
{
		ConfigGroup *pGrp;
		ConfigVar *pVar;

		printf( "Configuration file <%s>\n", m_tCfg.sFilename );

		for (pGrp=m_tCfg.pGroupList; pGrp!=NULL; pGrp=pGrp->pNext)
		{
				printf( "group:\n" );

				for (pVar = pGrp->pVarList; pVar != NULL; pVar = pVar->pNext)
						printf( "  <%s> = <%s>\n", pVar->sName, pVar->pValue );
		}
}

void STDConfig::configCreate(const char *sFilename)
{
		m_tCfg.sFilename = (char *)varMalloc( strlen(sFilename)+1 );
		strcpy( m_tCfg.sFilename, sFilename );

		m_tCfg.pGroupList = NULL;
		m_tCfg.pLastGroup = NULL;
}

int STDConfig::configRead()
{
		FILE *pFile;
		char sLine[ 10*1024];
		char *p, *pValue;
		ConfigGroup_t *pGrp;
		long lLineNo;

		configClear();

		pGrp = NULL;
		pValue = NULL;

		pFile = fopen( m_tCfg.sFilename, "r" );

		if (pFile == NULL)
		{
				return -1;
		}

		lLineNo = 0;

		for (;;)
		{
				++lLineNo;

				if (fgets(sLine, sizeof(sLine), pFile) == NULL)
				{
						if (!ferror(pFile))
						{
								break;
						}

						printf( "[STDConfig] Error return in reading `%s' in configRead call\n",
								m_tCfg.sFilename );

						goto error;
				}

				STDUtil::trimLeft( sLine, sLine, ' ' );
				STDUtil::trimRight( sLine, sLine, '\n' );

				if (*sLine == '#') continue;

				if (*sLine == '\0')
				{
						pGrp = NULL;
						continue;
				}

				p = strchr( sLine, '=' );

				if (p == NULL)
				{
						printf( "[STDConfig] Syntax error in reading %s:%ld in configRead call\n",
								m_tCfg.sFilename, lLineNo );
						goto error;
				}

				*p++ = '\0';

				STDUtil::trimRight( sLine, sLine, ' ' );

				pValue = parseValue( p );

				if (pValue == NULL) goto error;

				if (pGrp == NULL)
				{
						pGrp = configAddGroup();
				}

				configSet( pGrp, sLine, pValue );

				free( pValue );
				pValue = NULL;
		}

		if (fclose(pFile) != 0)
		{
				printf( "[STDConfig] Error return in closing `%s' in configRead call",
						m_tCfg.sFilename );
				goto error;
		}

		return 0;

error:
		if (pFile != NULL)
		{
				fclose( pFile );
		}

		free( pValue );

		configClear();

		return -1;
}

