#ifndef _STD_TCP_CLIENT_H
#define _STD_TCP_CLIENT_H

#include <string>
#include "std/stdsocketbase.h"

using namespace std;


class STDTCPClient : public STDSocketBase
{ 
	public:
		//////////////////////////////////////////////////////////
		// nHeartBeatInterval: 
		// 	0	disable outbound heartbeat reminder
		// 	> 0	will trigger callback function onSendHeartBeat every n seconds for user sending their heartbeat message
		// nIdleTimeout: 
		// 	0	disable keepalive checking
		// 	> 0	if no data received within n seconds, auto close connection 
		// nReconnectAfterSec: 
		// 	0	disable auto reconnect 
		// 	> 0	if disconnect, auto reconnect every n seconds
		//
		STDTCPClient( int nId, const char* sLocalIP, int nLocalPort, const char* sRemoteIP, int nRemotePort, int nHeartBeatInterval, int nIdleTimeout, int nReconnectAfterSec, int nAppTimer=0 );
		~STDTCPClient();

		bool send( const char* pData, unsigned int nDataSize );

		bool isConnected();

	protected:
		static const int STD_TCP_BUF_SIZE = 65535;

	protected:
		virtual void onHealthCheck( int nLineFD, short nEvent );
		virtual void onTimerCheck(){};

		bool reconnect();
		bool closeConnection( bool bLock=true );
		void onReceive( struct bufferevent* pEvent, void *pPtr );

		static void onReceiveCB( struct bufferevent* pEvent, void *pPtr );
		static void onSendCB( struct bufferevent* pEvent, void *pPtr );
		static void onEventCB( struct bufferevent* pEvent, short nEvents, void *pPtr );
		static void timeoutCB( int nLineFD, short nEvent, void *pPtr );

		virtual void onEvent( struct bufferevent* pEvent, short nEvents, void *pPtr );
		virtual void onConnected( struct bufferevent* pEvent, void *pPtr ) {};
		virtual void onClose( struct bufferevent* pEvent, void *pPtr ) {};
		virtual void onSend( struct bufferevent* pEvent, void *pPtr ) {};
		virtual void onReceive( const char* pData, unsigned int nDataSize ){};
		virtual void onSendHeartBeat() {};	// implement your own heartbeat message

		//void resetBuffer();

	protected:
		////////////////////
		// TCP/IP info
		//
		int m_nId;
		string m_sLocalIP;
		int m_nLocalPort;
		string m_sRemoteIP;
		int m_nRemotePort;

		int HEARTBEAT_INTERVAL;
		int m_nHeartBeatIntervalCnt;
		int IDLE_TIMEOUT;
		int m_nIdleTimeoutCnt;
		int RECONNECT_INTERVAL;
		int m_nReconnectAfterSecCnt;

		bool m_bConnected;

		//////////////////
		// libevent
		//
		struct bufferevent* m_pTCPEv;
};

#endif

