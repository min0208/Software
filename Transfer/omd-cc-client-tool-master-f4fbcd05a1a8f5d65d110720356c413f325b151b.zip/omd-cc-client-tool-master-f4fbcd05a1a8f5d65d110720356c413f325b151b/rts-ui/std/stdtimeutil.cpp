////////////////////////////////////////////////////////////////////////////////
// Date		Ver		Name	Description
// 20040603	r1		RC	Initial revision
////////////////////////////////////////////////////////////////////////////////

#include <sys/time.h>
#include <time.h>
#include <string>
using std::string;
#include "std/stdtimeutil.h"

void STDTimeUtil::normalize(struct timeval &val)
{
	while(val.tv_usec<0 && val.tv_sec>0)
	{
		val.tv_sec--;
		val.tv_usec+=1000000;
	}
	while(val.tv_usec>=1000000)
	{
		val.tv_usec-=1000000;
		val.tv_sec++;
	}

}
//r3
char *stdctime(const time_t *timep,char *buf)
{
	struct tm Now;
	stdlocaltime_r(timep,&Now);
	sprintf(buf,"%04d-%02d-%02d %02d:%02d:%02d",
			1900+Now.tm_year, Now.tm_mon+1, Now.tm_mday,
			Now.tm_hour, Now.tm_min, Now.tm_sec
	       );
	return buf;

}


