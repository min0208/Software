////////////////////////////////////////////////////////////////////////////////
// Date		Ver		Name	Description
// 20040602	r1		RC	Initial revision
////////////////////////////////////////////////////////////////////////////////
#include <pthread.h>
#include <time.h>
#include "std/stdcond.h"

int STDCond::wait(const struct timeval * abstime)
{
	struct timespec timeout;
	if(abstime==0)
	{
		return pthread_cond_wait(&m_cond,m_mutex);
	}
	else
	{
		timeout.tv_sec = abstime->tv_sec;
		timeout.tv_nsec = abstime->tv_usec * 1000;
		return pthread_cond_timedwait(&m_cond,m_mutex,&timeout);
	}
}
