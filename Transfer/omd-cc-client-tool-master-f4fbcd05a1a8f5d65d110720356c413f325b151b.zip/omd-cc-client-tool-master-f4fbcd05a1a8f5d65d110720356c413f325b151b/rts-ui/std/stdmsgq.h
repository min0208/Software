#ifndef STDMSGQ_H
#define STDMSGQ_H

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

static const int MSGQ_BUFSIZE = 4096;

class STDMsgQ
{
public:
	STDMsgQ();
	virtual ~STDMsgQ();

	bool init( key_t nKey, int nFlag=0 );
	bool init( const char* sPath, int nProjectId, int nFlag );
	bool post( int nMsgType, void* pData, int nDataSize, int nFlag=0 );
	bool recv( void* pBuf, int& nBufSize, long& nMsgType, int nFlag=0 );

protected:
	struct MSGQ_T
	{
		long int nMsgType;
		char aData[ MSGQ_BUFSIZE];
	};
	
private:
	key_t m_nMsgQId;
};

#endif /* STDMSGQ_H */
