////////////////////////////////////////////////////////////////////////////////
// Date     Ver     Name    Description
// 20120510 r1        RC        Initial revision
////////////////////////////////////////////////////////////////////////////////

#ifndef _STD_CSV_LOGGER_H
#define _STD_CSV_LOGGER_H

#include <errno.h>
#include <vector>
#include <string.h>

#include "std/stdmutex.h"

using namespace std;

class STDCSVLogger
{
public:
	typedef unsigned int CSV_FIELD_LEN;

	static const int MAX_DATA_SIZE = 500;

	struct CSV_DATA
	{
		unsigned int nField;
		char sData[ MAX_DATA_SIZE+1];

		CSV_DATA()
		{
			memset( sData, 0, sizeof(sData) );
		};
	};

	STDCSVLogger( vector<CSV_FIELD_LEN>& vTemplate, const char* sPath="./log" );
	STDCSVLogger( const char* sPath="./log" );
	~STDCSVLogger(); 

	bool log( vector<CSV_DATA>& vLogData, bool bExcelFormat=true, const char* sFilenameSuffix=NULL, const char* sHeader=NULL );
	bool loadTemplate( vector<CSV_FIELD_LEN>& vTemplate );

protected:
	void escapeDoubleQuotes( const char* sInStr, char* sOutStr );

	bool fileExists( const char *sFilename );

protected:

	STDMutex m_oMutex;

	vector<CSV_FIELD_LEN> m_vTemplate;	// define the max field length of each field. array index means the field#

	char m_sPath[ 128];
};

#endif

