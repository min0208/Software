////////////////////////////////////////////////////////////////////////////////
// Date 	Ver 	Name	Description
// 20040422 r1		RC		Initial revision
////////////////////////////////////////////////////////////////////////////////

#ifndef _STD_UTILITY_H
#define _STD_UTILITY_H

//#include <cctype>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

class STDUtil
{
	public:
		static bool convertUTF16toUTF8( char* sInStr, int nInStrLen, string& sOutStr );
		enum FORMAT
		{
			INTEGER_NORMAL,
			////////////////////////////////////////////////////////////////////////////////////////
			// Input data is an integer. convert to form form without dp
			// example:
			// input = 1956
			// output = 2K
			INTEGER_SHORT_FORM,
			INTEGER_2_DIGIT,
			INTEGER_3_DIGIT,
			INTEGER_4_DIGIT,
			INTEGER_5_DIGIT,
			INTEGER_2_DP,
			////////////////////////////////////////////////////////////////////////////////////////
			// Input data is an integer implied 4 decimal places.
			// example:
			// input = 1956
			// output = 1.956
			INTEGER_3_DP,
			////////////////////////////////////////////////////////////////////////////////////////
			// Input data is an integer implied 4 decimal places.
			// example:
			// input = 19561
			// output = 1.9561
			INTEGER_4_DP,
			INTEGER_4_DP_WITH_SIGN, // add +/- prefix
			////////////////////////////////////////////////////////////////////////////////////////
			// Input data is an integer implied 3 decimal places. convert to short form without dp
			// example:
			// input = 987654321
			// output = 988K
			INTEGER_3_DP_SHORT_FORM,
			////////////////////////////////////////////////////////////////////////////////////////
			// Input data is an integer implied 3 decimal places. convert to short form with 2 dp
			// example:
			// input = 987654321
			// output = 987.65K
			INTEGER_3_DP_SHORT_FORM_2_DP,	
			INTEGER_3_DP_SHORT_FORM_3_DP,	
			////////////////////////////////////////////////////////////////////////////////////////
			// Input data is an integer. convert to short form if input >= million
			// example:
			// input = 1000000
			// output = 1M
			// input = 100000
			// output = 100000 
			INTEGER_THOUSAND_SHORT_FORM_1_DP,
			INTEGER_HUNDRED_SHORT_FORM,
			INTEGER_THOUSAND_SHORT_FORM,
			INTEGER_MILLION_SHORT_FORM,
			INTEGER_MILLION_SHORT_FORM_3_DP,
			INTEGER_BILLION_SHORT_FORM,
			DATE_ONLY,
			DATE_TIME_SEC,
			DATE_TIME_MSEC,
			DATE_TIME_USEC,
			DATE_TIME_NSEC,
			TIME_SEC,
			TIME_MSEC,
			TIME_USEC,
			TIME_NSEC
		};

		enum STD_ALIGN_TYPE
		{
			ALIGN_LEFT,
			ALIGN_RIGHT,
			ALIGN_CENTER
		};
	public:
		static bool convertUnicode( const char* sInEncode, char* sInStr, int nInStrLen, const char* sOutEncode, char* sOutStr, int nOutBufLen );
		static bool convertInt64ToTimeStr( unsigned long long nData, int nFormat, string& sOutput );
		static bool convertIntToStr( unsigned int nData, int nFormat, string& sOutput );
		static bool convertInt64ToStr( unsigned long long nData, int nFormat, string& sOutput );
		static bool convertUInt64ToStr( unsigned long long nData, int nFormat, string& sOutput );
		static void dumpBuffer( const char* pBuf, int nBufSize );
		static bool padSpace( const char* sInStr, char* sOutStr, int nFieldLen, int nAlign=ALIGN_LEFT );
		static double roundOff( double dIn, int nDecimalPoint );
		static bool shortForm( double dData, int nDecimalPoint, string& sOutput, int nConvertIf=0 );
		static bool getStr( const char* pInBuf, int nInBufSize, char* pOutBuf, int nOutBufSize );
		static bool getStr( const char* pInBuf, int nInBufSize, string& sOutBuf );
		static bool charArrayToStr( const char* pInBuf, int nInBufSize, string& sOutStr );

		static void swap(char *pSrc, int nLen)
		{
			char cTmp;
			int nMid = nLen / 2;

			for (int i=0; i<nMid; i++)
			{
				cTmp = pSrc[ i];

				pSrc[ i] = pSrc[ nLen-i-1];

				pSrc[ nLen-i-1] = cTmp;
			}
		};

		static int postFill(char *sSrc, char *sResult, char cFill, int nTotalLen)
		{
			int nLen = strlen( sSrc );

			int nNum = nTotalLen - nLen;

			if (nNum <= 0)
			{
				return 0;
			}

			sprintf( sResult, "%s", sSrc );

			for (int i=0; i<nNum; i++)
			{
				sprintf( &sResult[ nLen+i], "%c", cFill );
			}

			return 1;
		};

		static int trimRight(char *sSrc, char *sResult, char cTarget)
		{
			int nLen = strlen( sSrc );

			if (nLen == 0) return 0;

			sprintf( sResult, "%s", sSrc );

			for (int i=nLen-1; i>=0; i--)
			{
				if (sResult[ i] == cTarget)
					sResult[ i] = 0;
				else
					break;
			}

			return 1;
		}

		static int trimLeft( char *sSrc, char *sResult, char cTarget );

		static void binToStr(char *pSrc, int nLen, char *sResult)
		{
			for (int i=0; i<nLen; i++)
			{
				sprintf( &sResult[ i*2], "%02x", pSrc[ i] );
			}
		}

		static short bytes2Short( const char* bytes ) {

			short result = 0;
			memcpy( &result, bytes, 2 );
			result = ntohs( result );
			return result;			
		}

		static int bytes2Int( const char* bytes ) {

			int result = 0;
			memcpy( &result, bytes, 4 );
			result = ntohl( result );
			return result;
		}

		static void short2Bytes( short s, char* shortBuf ) {
			s = htons( s );
			memcpy( shortBuf, &s, 2 );

		}

		static void int2Bytes( int i, char* intBuf ) {
			i = htonl( i );
			memcpy( intBuf, &i, 4 );

		}


		static bool isValidStr( const char* chkStr, int maxLen ) {

			for ( int i = 0; i < maxLen; i++ ) {
				if ( chkStr[i] == '\0' ) {
					return true;
				}
			}
			return false;
		}

		static bool isAllDigit( const char* chkStr, int maxLen ) {

			for ( int i = 0; i < maxLen; i++ ) {
				if ( isdigit( chkStr[i] ) == 0 ) {
					return false;
				}
			}
			return true;

		}

		static bool getLocalIP(char* pAddr, int nLen)
		{
			/*
			   char acHostname[128] = {0};
			   if (gethostname(acHostname, sizeof(acHostname)) == 0)
			   {
			// this call is NOT MT safe
			struct hostent aAddr;
#ifndef __sun__
struct hostent *pAddrList = &aAddr;
#endif
char aBuffer[1024];
int nError;
#ifdef __sun__
			//if( gethostbyname_r(acHostname,&aAddr,aBuffer,
			if( gethostbyname(acHostname,&aAddr,aBuffer,
			sizeof(aBuffer),&nError) != NULL)
#else
			//if (gethostbyname_r(acHostname, &aAddr, aBuffer,
			if (gethostbyname(acHostname, &aAddr, aBuffer,
			sizeof(aBuffer), &pAddrList, &nError) == 0)
#endif
{
if (inet_ntop(AF_INET, aAddr.h_addr, pAddr, nLen))
return true;
}
}
*/
		return false;
		}
//r5
static int char2BCD( const char *sSource, unsigned char* pResult , int nMaxLen = -1 )
{
	/*
	   int nSrcLen = strlen( (char*)sSource );
	   int nRemain = nSrcLen % 2;
	   int nLen = nSrcLen + nRemain;
	   int i;

	   unsigned char pTemp[ nLen];
	   memcpy( pTemp, sSource, nSrcLen );

	   if (nRemain)
	   {
	   pTemp[ nSrcLen] = 0x3F;
	   }

	   for ( i=0; i<nLen; i+=2 )
	   {
	   pResult[ i/2] = pTemp[ i] - 0x30;
	   pResult[ i/2] |= (pTemp[ i+1] - 0x30) << 4;
	   }
	   return (i/2);
	   */
	// r8
	int nSrcLen = strlen( (char*)sSource );

	if (nMaxLen >= 0 &&
			nMaxLen < nSrcLen)

		nSrcLen = nMaxLen;

	int nRemain = nSrcLen & 0x01;
	int nLen = nSrcLen + nRemain;

	unsigned char pTemp[ nLen];
	memcpy( pTemp, sSource, nSrcLen );

	if (nRemain)
	{
		pTemp[ nSrcLen] = 0x3F;
	}

	int nIndex=0;

	for ( int i=0; i<nLen; i+=2 )
	{
		nIndex = i >> 1;
		// r10
		pResult[ nIndex] = pTemp[ i] - 0x30;
		if (pTemp [i] > 0x40) //'A' or above 
		{
			pResult[ nIndex ] = toupper( pTemp[i] ) - 0x37; 
		}
		else
		{
			pResult[ nIndex] = pTemp[ i] - 0x30;
		}
		if (pTemp [ i+1 ] > 0x40) //'A' or above 
			pResult[ nIndex] |= (toupper( pTemp[ i+1] ) - 0x37) << 4;
		else
			pResult[ nIndex] |= (pTemp[ i+1] - 0x30) << 4;
	}
	return (nLen >> 1);
}

//r5
static void bcd2Char( const unsigned char *sSource, unsigned int nLen, char *sResult )
{

	int nIndex = 0;

	for ( unsigned  int i=0; i<nLen; i++ )
	{
		//r10
		sprintf( &sResult[ nIndex], "%02X", sSource[ i] );

		char cSwap = sResult[ nIndex];

		sResult[ nIndex] = sResult[ nIndex+1];

		sResult[ nIndex+1] = cSwap;

		nIndex += 2;

		sResult[ nIndex] = 0;

	}

	if ( nIndex > 0 )
	{

		if ( ( sResult[ nIndex-1] == 'F' ) || ( sResult[ nIndex-1] == 'f' ) )
		{

			sResult[ nIndex-1] = 0;

		}

	}

}
//r5
//r6
static void hexdump(const void *data,int nSize,std::ostream &out = std::cout)
{
	const unsigned char * pBuffer = (const unsigned char *) data;
	std::ios_base::fmtflags flags = out.flags();
	out << std::hex << std::uppercase <<  std::setfill('0');;
	for(int i =0 ; i < nSize;i++)
		out << std::setw(2)<< (int) pBuffer[i] << ' ';
	out.flags(flags);

}		

//r7
static unsigned long long ntohll(unsigned long long n)
{
#if __BYTE_ORDER == __BIG_ENDIAN
	return n;
#else
	return (((unsigned long long)ntohl(n)) << 32) + ntohl(n >> 32);
#endif
}

//r7
static unsigned long long htonll(unsigned long long n)
{
#if __BYTE_ORDER == __BIG_ENDIAN
	return n;
#else
	return (((unsigned long long)htonl(n)) << 32) + htonl(n >> 32);
#endif
}

// r9
static int axtoi( char *sHexStg, int nLen ) {

	int n = 0;         		// position in string
	int m = nLen - 1;  		// position in digit[] to shift
	int intValue = 0;  		// integer value of hex string
	int digit = 0;      	// hold values to convert

	while ( n < nLen ) {

		if ( sHexStg[n]=='\0')
			break;
		if ( sHexStg[n] > 0x2F && sHexStg[n] < 0x40 ) 		//if 0 to 9
			digit = sHexStg[n] & 0x0f;            			//convert to int
		else if ( sHexStg[n] >='a' && sHexStg[n] <= 'f') 	//if a to f
			digit = (sHexStg[n] & 0x0f) + 9;      			//convert to int
		else if ( sHexStg[n] >='A' && sHexStg[n] <= 'F') 	//if A to F
			digit = ( sHexStg[n] & 0x0f) + 9;      			//convert to int
		else return -1;

		intValue = intValue | (digit << (m << 2));
		m--;
		n++;
	}

	return intValue;
}

static long long axtoll( char *sHexStg, int nLen ) {

	int n = 0;         			// position in string
	int m = nLen - 1;  			// position in digit[] to shift
	long long llValue = 0;  	// long long value of hex string
	long long digit = 0;      	// hold values to convert

	while ( n < nLen ) {

		if ( sHexStg[n]=='\0')
			break;
		if ( sHexStg[n] > 0x2F && sHexStg[n] < 0x40 ) 		//if 0 to 9
			digit = sHexStg[n] & 0x0f;            			//convert to int
		else if ( sHexStg[n] >='a' && sHexStg[n] <= 'f') 	//if a to f
			digit = (sHexStg[n] & 0x0f) + 9;      			//convert to int
		else if ( sHexStg[n] >='A' && sHexStg[n] <= 'F') 	//if A to F
			digit = ( sHexStg[n] & 0x0f) + 9;      			//convert to int
		else return -1;

		llValue = llValue | (digit << (m << 2));
		m--;
		n++;
	}

	return llValue;
}



};

#endif

