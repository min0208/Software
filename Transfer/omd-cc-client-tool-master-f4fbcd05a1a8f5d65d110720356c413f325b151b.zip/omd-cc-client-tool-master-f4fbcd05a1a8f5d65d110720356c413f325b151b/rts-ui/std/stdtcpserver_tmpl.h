#ifndef _STDTCPServerTmplTmpl_H
#define _STDTCPServerTmplTmpl_H

#include "std/stdtcpserver.h"
#include "std/stdapp.h"

template < class T > class STDTCPServerTmpl : public STDTCPServer
{ 
	public:
		STDTCPServerTmpl( int nId, const char* sDesc, const char* sLocalIp, int nLocalPort, int nHeartBeatInterval, int nTimeoutLimit );
		~STDTCPServerTmpl();

	protected:
		virtual void onAccept( int nClientFd, const sockaddr_in& tClientAddr );
		virtual void onReceive( int nClientFd, const char* pData, int nDataSize );

	protected:
		typedef map<int,T*> CHILD_MAP;

	protected:
		CHILD_MAP m_mChild;
};

template < class T > STDTCPServerTmpl < T >::STDTCPServerTmpl( int nId, const char* sDesc, const char* sLocalIp, int nLocalPort, int nHeartBeatInterval, int nTimeoutLimit ) :
        STDTCPServer( nId, sDesc, sLocalIp, nLocalPort, nHeartBeatInterval, nTimeoutLimit )
{
};

template < class T > STDTCPServerTmpl < T >::~STDTCPServerTmpl()
{
	typename CHILD_MAP::iterator oItr = m_mChild.begin();

	while ( oItr != m_mChild.end() )
	{
		delete oItr->second;
		oItr->second = NULL;
		oItr++;
	};
};

template < class T > void STDTCPServerTmpl < T >::onAccept( int nClientFd, const sockaddr_in& tClientAddr )
{
        T* pChild = new T( nClientFd, tClientAddr );

        m_mChild[ nClientFd] = pChild;

        //STDGetLogger()->log( STDLOG_L3, "added child fd|%d| ip|%s:%d| into server id|%d| connection list", nClientFd, inet_ntoa(tClientAddr.sin_addr), ntohs(tClientAddr.sin_port), m_nId );
};

template < class T > void STDTCPServerTmpl < T >::onReceive( int nClientFd, const char* pData, int nDataSize )
{
        //STDGetLogger()->log( STDLOG_L3, "recv data from child fd|%d| in server id|%d| bytes|%d|", nClientFd, m_nId, nDataSize );

        m_mChild[ nClientFd]->onReceive( pData, nDataSize );
};


#endif

