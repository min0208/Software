#ifndef STDSEMA_H
#define STDSEMA_H

#include <semaphore.h>

class STDSema
{
public:
	STDSema();
	virtual ~STDSema();

public:
	bool init( unsigned int nValue = 0 );
	bool destroy();

	bool wait();
	bool post();
	
private:
	//ACE_sema_t m_tSem;

	sem_t m_tSem;

	bool m_bOpened;
};

#endif /* STDSEMA_H */
