////////////////////////////////////////////////////////////////////////////////
// Date     Ver     Name    Description
// 20040429 r1      RC      Initial revision
////////////////////////////////////////////////////////////////////////////////

#if !defined(STD_THREAD_H)
#define STD_THREAD_H

#include <pthread.h>

#include "std/stdmutex.h"

class STDThread
{
	public:
		STDThread();
		virtual ~STDThread();

		// runs the code in thread() .  Returns immediately
		virtual void run();

		// joins to the thread running thread()
		virtual void join();

		// forces the thread running to exit()
		virtual void exit();

		// request the thread running thread() to return, by setting  mShutdown
		void shutdown();

		// returns true if the thread has been asked to shutdown or not running
		bool isShutdown() const;

		int detach();

		void setStackSize( int nSize ) { m_nStackSize = nSize; };

		typedef pthread_t Id;

		static Id selfId();

		/* thread is a virtual method.  Users should derive and define
		   thread() such that it returns when isShutdown() is true.
		   */
		virtual void thread() = 0;

	protected:
		Id m_tId;

		bool m_bShutdown;

		STDMutex m_oShutdownMutex;

		bool m_bDetach;

		STDMutex m_oDetachMutex;

		int m_nStackSize;

	private:
		// Suppress copying
		STDThread(const STDThread &);

		const STDThread & operator=(const STDThread &);
};

#endif
