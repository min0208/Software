/////////////////////////////////////////////////////////////////////////////////
//// Date	Ver	Name	Description
//// 20120430	r1	RC	Initial revision
//////////////////////////////////////////////////////////////////////////////////

#include "std/stdutil.h"
#include "std/stdapp.h"

#include <stdio.h>
#include <string>
#include <math.h>
#include <iconv.h>

//#include "std/stdapp.h"

using namespace std;

static const int BILLION	= 1000000000;
static const int MILLION	= 1000000;
static const int THOUSAND	= 1000;
static const int HUNDRED	= 100;

static const int MSEC		= 1000;
static const int USEC		= 1000000;

bool STDUtil::charArrayToStr( const char* pInBuf, int nInBufSize, string& sOutStr )
{
	char sTmpBuf[ nInBufSize+1];

	strncpy( sTmpBuf, pInBuf, nInBufSize );
	sTmpBuf[ nInBufSize] = 0;
	sOutStr = sTmpBuf;
	
	return true;
}

void STDUtil::dumpBuffer( const char* pBuf, int nBufSize )
{
	string sDisplay;
	char sTemp[ 32];

	sprintf( sTemp, "buf size|%d|", nBufSize );
	sDisplay = sTemp;

	for ( int i=0; i<nBufSize; i++ )
	{
		if ( i % 10 == 0 )
		{
			sDisplay += "\n";
		}

		sprintf( sTemp, "0x%02X ", (unsigned char)pBuf[ i] );
		sDisplay += sTemp;
	}

	STDGetLogger()->log( STDLOG_L7, "%s", sDisplay.c_str() );
}

bool STDUtil::padSpace( const char* sInStr, char* sOutStr, int nFieldLen, int nAlign )
{
	int nInStrLen = strlen( sInStr );
	int nNeedSpace = nFieldLen - nInStrLen;

	if ( nNeedSpace < 0 )
	{
		strncpy( sOutStr, sInStr, nFieldLen );
	}
	else
	{
		memset( sOutStr, ' ', nFieldLen );

		switch (nAlign)
		{
			case ALIGN_LEFT:
				{
					strncpy( sOutStr, sInStr, nInStrLen );
					break;
				}
			case ALIGN_RIGHT:
				{
					strncpy( &sOutStr[ nNeedSpace], sInStr, nInStrLen );
					break;
				}
			case ALIGN_CENTER:
				{
					strncpy( &sOutStr[ nNeedSpace/2], sInStr, nInStrLen );
					break;
				}
		}
	}

	sOutStr[ nFieldLen] = 0;

	return true;
}

bool STDUtil::convertIntToStr( unsigned int nData, int nFormat, string& sOutput ) 
{
	char sText[ 128];

	switch ( nFormat )
	{
		case DATE_ONLY:
			{
				sprintf( sText, "%02d/%02d/%04d", (nData%100), ((nData/100)%100), (nData/10000) );
				break;
			}
		case INTEGER_2_DIGIT:
			{
				sprintf( sText, "%02u", nData );
				break;
			}
		case INTEGER_3_DIGIT:
			{
				sprintf( sText, "%03u", nData );
				break;
			}
		case INTEGER_5_DIGIT:
			{
				sprintf( sText, "%05u", nData );
				break;
			}
		case INTEGER_NORMAL:
			{
				sprintf( sText, "%u", nData );
				break;
			}
               case INTEGER_2_DP:
                        {
                                sprintf( sText, "%.02f", (nData*0.01) );
                                break;
                        }
		case INTEGER_3_DP:
			{
                                sprintf( sText, "%.03f", (nData*0.001) );
				break;
			}
                case INTEGER_4_DP:
                        {
                                sprintf( sText, "%.04f", (nData*0.0001) );
                                break;
                        }
                case INTEGER_4_DP_WITH_SIGN:
                        {
                                sprintf( sText, "%+.04f", (nData*0.0001) );
                                break;
                        }
		case INTEGER_THOUSAND_SHORT_FORM_1_DP:
			{
				shortForm( (double)nData, 1, sOutput, THOUSAND );
				return true;;
			}
		case INTEGER_HUNDRED_SHORT_FORM:
			{
				shortForm( (double)nData, 0, sOutput, HUNDRED );
				return true;;
			}
		case INTEGER_THOUSAND_SHORT_FORM:
			{
				shortForm( (double)nData, 0, sOutput, THOUSAND );
				return true;;
			}
		case INTEGER_MILLION_SHORT_FORM:
			{
				shortForm( (double)nData, 0, sOutput, MILLION );
				return true;;
			}
		case INTEGER_MILLION_SHORT_FORM_3_DP:
			{
				shortForm( (double)nData, 3, sOutput, MILLION );
				return true;;
			}
		case INTEGER_BILLION_SHORT_FORM:
			{
				shortForm( (double)nData, 0, sOutput, BILLION );
				return true;;
			}
		case INTEGER_SHORT_FORM:
			{
				shortForm( (double)nData, 0, sOutput );
				return true;;
			}
		default:
			{
				return false;
			}
	}

	sOutput = sText;

	return true;	
}

bool STDUtil::convertUInt64ToStr( unsigned long long nData, int nFormat, string& sOutput )
{
	char sText[ 128];

	switch ( nFormat )
	{
		case INTEGER_2_DIGIT:
			{
				sprintf( sText, "%02llu", nData );
				break;
			}

		case INTEGER_3_DIGIT:
			{
				sprintf( sText, "%03llu", nData );
				break;
			}

		case INTEGER_5_DIGIT:
			{
				sprintf( sText, "%05llu", nData );
				break;
			}

		case INTEGER_NORMAL:
			{
				sprintf( sText, "%llu", nData );
				break;
			}

		case INTEGER_2_DP:
			{
				sprintf( sText, "%.02f", (nData*0.01) );
				break;
			}

		case INTEGER_3_DP:
			{
				sprintf( sText, "%.03f", (nData*0.001) );
				break;
			}

		case INTEGER_4_DP:
			{
				sprintf( sText, "%.04f", (nData*0.0001) );
				break;
			}
		case INTEGER_4_DP_WITH_SIGN:
			{
				sprintf( sText, "%+.04f", (nData*0.0001) );
				break;
			}

		case INTEGER_SHORT_FORM:
			{
				shortForm( (double)nData, 0, sOutput );
				return true;;
			}

		case INTEGER_MILLION_SHORT_FORM:
			{
				shortForm( (double)nData, 0, sOutput, MILLION );
				return true;;
			}

		case INTEGER_3_DP_SHORT_FORM_2_DP:
			{
				shortForm( ((double)nData/1000), 2, sOutput, MILLION );
				return true;;
			}

		case INTEGER_3_DP_SHORT_FORM_3_DP:
			{
				shortForm( ((double)nData/1000), 3, sOutput, MILLION );
				return true;;
			}

		default:
			{
				return false;
			}
	}

	sOutput = sText;

	return true;
}

bool STDUtil::convertInt64ToStr( unsigned long long nData, int nFormat, string& sOutput ) 
{
	char sText[ 128];

	switch ( nFormat )
	{
		case INTEGER_2_DIGIT:
			{
				sprintf( sText, "%02lld", nData );
				break;
			}
		case INTEGER_3_DIGIT:
			{
				sprintf( sText, "%03lld", nData );
				break;
			}
		case INTEGER_5_DIGIT:
			{
				sprintf( sText, "%05lld", nData );
				break;
			}
		case INTEGER_NORMAL:
			{
				sprintf( sText, "%lld", nData );
				break;
			}
		case INTEGER_2_DP:
			{
				sprintf( sText, "%.02f", (nData*0.01) );
				break;
			}
		case INTEGER_3_DP:
			{
				sprintf( sText, "%.03f", (nData*0.001) );
				break;
			}
		case INTEGER_4_DP:
			{
				sprintf( sText, "%.04f", (nData*0.0001) );
				break;
			}
		case INTEGER_4_DP_WITH_SIGN:
			{
				sprintf( sText, "%+.04f", (nData*0.0001) );
				break;
			}
		case INTEGER_SHORT_FORM:
			{
				shortForm( (double)nData, 0, sOutput );
				return true;;
			}
		case INTEGER_THOUSAND_SHORT_FORM_1_DP:
			{
				shortForm( (double)nData, 1, sOutput, THOUSAND );
				return true;;
			}
		case INTEGER_HUNDRED_SHORT_FORM:
			{
				shortForm( (double)nData, 0, sOutput, HUNDRED );
				return true;;
			}
		case INTEGER_THOUSAND_SHORT_FORM:
			{
				shortForm( (double)nData, 0, sOutput, THOUSAND );
				return true;;
			}
		case INTEGER_MILLION_SHORT_FORM:
			{
				shortForm( (double)nData, 0, sOutput, MILLION );
				return true;;
			}
		case INTEGER_MILLION_SHORT_FORM_3_DP:
			{
				shortForm( (double)nData, 3, sOutput, MILLION );
				return true;;
			}
		case INTEGER_BILLION_SHORT_FORM:
			{
				shortForm( (double)nData, 0, sOutput, BILLION );
				return true;;
			}
		case INTEGER_3_DP_SHORT_FORM:
			{
				shortForm( ((double)nData/1000), 0, sOutput, MILLION );
				return true;;
			}
		case INTEGER_3_DP_SHORT_FORM_2_DP:
			{
				shortForm( ((double)nData/1000), 2, sOutput, MILLION );
				return true;;
			}
		case INTEGER_3_DP_SHORT_FORM_3_DP:
			{
				shortForm( ((double)nData/1000), 3, sOutput, MILLION );
				return true;;
			}
		default:
			{
				return false;
			}
	}

	sOutput = sText;

	return true;	
}

double STDUtil::roundOff( double dIn, int nDecimalPoint )
{
	double p = pow( 10, nDecimalPoint );

	return round( dIn * p ) / p;
}

bool STDUtil::getStr( const char* pInBuf, int nInBufSize, string& sOutBuf )
{
	char sTemp[ nInBufSize+1];

	memcpy( sTemp, pInBuf, nInBufSize );
	sTemp[ nInBufSize] = 0;

	sOutBuf = sTemp;

	return true;
}

bool STDUtil::getStr( const char* pInBuf, int nInBufSize, char* pOutBuf, int nOutBufSize )
{
	if ( nInBufSize >= nOutBufSize ) return false;  // out buffer needs in buffer + 1 for null terminate string

	memcpy( pOutBuf, pInBuf, nInBufSize );
	pOutBuf[ nInBufSize] = 0;

	return true;
}

bool STDUtil::convertUnicode( const char* sInEncode, char* sInStr, int nInStrLen, const char* sOutEncode, char* sOutStr, int nOutBufLen )
{
	char sText[ nInStrLen+1];
	size_t nChar = -1;

	if ( getStr( sInStr, nInStrLen, sText, nInStrLen+1) )
	{
		//int nTextLen = strlen(sText);
		int nTextLen = sizeof(sText);
		memset( sOutStr, 0, nOutBufLen );

		iconv_t tIconv = iconv_open( sOutEncode, sInEncode );

		if ( tIconv == 0 )
		{
			return false;
		}

		char* pInStr = sText;
		char* pOutStr = sOutStr;
		size_t i = nTextLen;
		size_t j = nOutBufLen;
		nChar = iconv( tIconv, &pInStr, &i, &pOutStr, &j );

		iconv_close( tIconv );
	}

	return ( ((int)nChar) == 0 );
}

int STDUtil::trimLeft( char *sSrc, char *sResult, char cTarget )
{
	int nLen = strlen( sSrc );

	sprintf( sResult, "%s", sSrc );

	if ( nLen == 0 )
	{
		return 0;
	}

	for ( int i=0; i<nLen; i++ )
	{
		if ( sSrc[ i] != cTarget )
		{
			sprintf( sResult, "%s", &sSrc[ i] );
			break;
		}
	}

	return 0;
}

bool STDUtil::convertInt64ToTimeStr( unsigned long long nData, int nFormat, string& sOutput )
{
	char sText[ 256];
	time_t t;
	memset( &t, 0, sizeof(t) );
	t = nData / 1000000000;
	unsigned int nNanoSec = nData % 1000000000;
	struct tm* pTime = localtime( &t );

	switch ( nFormat )
	{
		/////////////////////////////
		// DATE
		//
		case DATE_TIME_NSEC:
			{
				sprintf( sText, "%02d/%02d/%04d %02d:%02d:%02d.%09d",
						pTime->tm_mday, (pTime->tm_mon + 1), (pTime->tm_year - 100),
						pTime->tm_hour, pTime->tm_min, pTime->tm_sec, (int)(nNanoSec) );
				break;
			}
		case DATE_TIME_USEC:
			{
				sprintf( sText, "%02d/%02d/%04d %02d:%02d:%02d.%06d",
						pTime->tm_mday, (pTime->tm_mon + 1), (pTime->tm_year - 100),
						pTime->tm_hour, pTime->tm_min, pTime->tm_sec, (int)(nNanoSec / 1000) );
				break;
			}
		case DATE_TIME_MSEC:
			{
				sprintf( sText, "%02d/%02d/%04d %02d:%02d:%02d.%03d",
						pTime->tm_mday, (pTime->tm_mon + 1), (pTime->tm_year - 100),
						pTime->tm_hour, pTime->tm_min, pTime->tm_sec, (int)(nNanoSec / 1000000) );
				break;
			}
		case DATE_TIME_SEC:
			{
				sprintf( sText, "%02d/%02d/%04d %02d:%02d:%02d",
						pTime->tm_mday, (pTime->tm_mon + 1), (pTime->tm_year - 100),
						pTime->tm_hour, pTime->tm_min, pTime->tm_sec );
				break;
			}

			/////////////////////////////
			// TIME
			//
		case TIME_NSEC:
			{
				sprintf( sText, "%02d:%02d:%02d.%09d",
						pTime->tm_hour, pTime->tm_min, pTime->tm_sec, (int)(nNanoSec) );
				break;
			}
		case TIME_USEC:
			{
				sprintf( sText, "%02d:%02d:%02d.%06d",
						pTime->tm_hour, pTime->tm_min, pTime->tm_sec, (int)(nNanoSec / 1000) );
				break;
			}
		case TIME_MSEC:
			{
				sprintf( sText, "%02d:%02d:%02d.%03d",
						pTime->tm_hour, pTime->tm_min, pTime->tm_sec, (int)(nNanoSec / 1000000) );
				break;
			}

		case TIME_SEC:
		default:
			{
				sprintf( sText, "%02d:%02d:%02d",
						pTime->tm_hour, pTime->tm_min, pTime->tm_sec );
				break;
			}
	}

	sOutput = sText;

	return true;
}

bool STDUtil::shortForm( double dData, int nDecimalPoint, string& sOutput, int nConvertIf )
{
	char sText[ 128];
	double dDouble = 0.0;

	if ( (dData >= BILLION) && (nConvertIf <= BILLION) )
	{
		dDouble = dData / BILLION;

		if ( nDecimalPoint == 1 ) nDecimalPoint = ( dDouble < 10 ) ? 1 : 0;

		double dRound = roundOff( dDouble, nDecimalPoint );
		sprintf( sText, "%gB", dRound );
	}
	else if ( (dData >= MILLION) && (nConvertIf <= MILLION) )
	{
		dDouble = dData / MILLION;

		if ( nDecimalPoint == 1 ) nDecimalPoint = ( dDouble < 10 ) ? 1 : 0;

		double dRound = roundOff( dDouble, nDecimalPoint );
		sprintf( sText, "%gM", dRound );
	}
	else if ( (dData >= THOUSAND) && (nConvertIf <= THOUSAND) )
	{
		dDouble = dData / THOUSAND;

		if ( nDecimalPoint == 1 ) nDecimalPoint = ( dDouble < 10 ) ? 1 : 0;

		double dRound = roundOff( dDouble, nDecimalPoint );
		sprintf( sText, "%gK", dRound );
	}
	else if ( (dData > HUNDRED) && (nConvertIf <= HUNDRED) )
	{
		dDouble = dData / HUNDRED;

		if ( nDecimalPoint == 1 ) nDecimalPoint = ( dDouble < 10 ) ? 1 : 0;

		double dRound = roundOff( dDouble, nDecimalPoint );
		sprintf( sText, "%gH", dRound );
	}
	else
	{
		sprintf( sText, "%g", dData );
	}

	sOutput = sText;

	return true;
}

bool STDUtil::convertUTF16toUTF8( char* sInStr, int nInStrLen, string& sOutStr )
{
	char** pInBuf = &sInStr;
	size_t nInBytesLeft = nInStrLen;
	int nMaxOutLen = nInBytesLeft / 2 * 6;

	char sOutput[ nMaxOutLen+1];
	char* pOutBuf = sOutput;

	memset( pOutBuf, 0, nMaxOutLen+1 );
	size_t nOutBytesLeft = nMaxOutLen;

	iconv_t cd = iconv_open( "UTF8", "UTF16LE" );

	if ( cd == (iconv_t)-1 )
	{
		return false;
	}

	if ( iconv(cd, pInBuf, &nInBytesLeft, &pOutBuf, &nOutBytesLeft) == (size_t)-1 )
	{
		return false;
	}

	sOutStr = sOutput;

	//STDGetLogger()->log( STDLOG_L7, "outstr|%s|", sOutStr.c_str() );

	iconv_close( cd );

	return true;
}

