#include "main.h"

#include "std/stdutil.h"
#include "std/stdmutexlocker.h"
#include <time.h>

using namespace std;

#define LOGC "|MAIN    | "

static ClientTool oClientTool;

ClientTool* ClientTool::m_gClientTool = NULL;

ClientTool::ClientTool() :
	STDApp("omdc-rts-tui.conf"),
	m_pCTSvrConnector(NULL)
{
}

ClientTool::~ClientTool()
{
	logger()->log( STDLOG_L3, "~ClientTool()" );
}

ClientTool* ClientTool::inst()
{
	return m_gClientTool;
}

STDLogger* ClientTool::logger()
{
	return STDGetLogger();
}

void ClientTool::recvRefreshComplete()
{
	redraw();
}

void ClientTool::recvCTSvrResponse( int nStatus )
{
	return m_pCTSvrConnector->recvResponse( nStatus );
}

bool ClientTool::setCTRequest( bool bOneOffRequest, int nInfoType, int nProductType, int nArg0, int nArg1, int nArg2, int nArg3 )
{
        if ( !m_pCTSvrConnector ) return false;

        return m_pCTSvrConnector->setRequest( bOneOffRequest, nInfoType, nProductType, nArg0, nArg1, nArg2, nArg3 );
}

bool ClientTool::initServerSocket()
{
	//////////////////////////////////////////
	// init message handler
	//
	static const char* GRP = "ct_server";
	const char* LOCAL_NIC = GET_CFG_STR( GRP, "local_nic", "127.0.0.1" );
	unsigned int LOCAL_PORT = GET_CFG_INT( GRP, "local_port", 0);
	const char* REMOTE_IP = GET_CFG_STR( GRP, "remote_ip", "127.0.0.1" );
	unsigned int REMOTE_PORT = GET_CFG_INT( GRP, "remote_port", 10001 );
	unsigned int HEARTBEAT = GET_CFG_INT( GRP, "heartbeat", 10 );
	unsigned int IDLE_TIMEOUT = GET_CFG_INT( GRP, "idle_timeout", 25 );
	unsigned int RECONNECT = GET_CFG_INT( GRP, "reconnect", 5 );
	unsigned int REQUEST_TIME = GET_CFG_INT( GRP, "request_time", 200000 );

	logger()->log( STDLOG_L3, LOGC "OMD CT server|%s:%d| local nic|%s:%d| heartbeat interval|%d sec| idle timeout|%d| reconnect interval|%d sec|", REMOTE_IP, REMOTE_PORT, LOCAL_NIC, LOCAL_PORT, HEARTBEAT, IDLE_TIMEOUT, RECONNECT );

	m_pCTSvrConnector = new CTSvrConnector( MsgHandler::inst(), REMOTE_IP, REMOTE_PORT, LOCAL_NIC, LOCAL_PORT, HEARTBEAT, IDLE_TIMEOUT, RECONNECT, REQUEST_TIME );
	m_pCTSvrConnector->STDTCPClient::run();

	return true;
}

bool ClientTool::exitInstance()
{
	if ( m_pMsgHandler )
	{
		delete m_pMsgHandler;
		m_pMsgHandler = NULL;
	}

	logger()->log( STDLOG_L3, LOGC "exitInstance() exit" );

	return true;
}

bool ClientTool::init()
{
	initGUI();

	initServerSocket();

	return true;
}

///////////////////////////////////////
// PROGRAM START HERE
//
bool ClientTool::initInstance()
{
	if ( !STDApp::initInstance() )
	{
		return false;
	}

	STDGetLogger()->setDisplay( 0 );

	m_gClientTool = this;

	// set GUI title
	const char* TITLE = GET_CFG_STR( "main", "name", PROGRAM_NAME );
	setTitle( TITLE );

	logger()->log( STDLOG_L3, "==============================================================" );
	logger()->log( STDLOG_L3, "%s Built on %s", TITLE, VERSION_DATE );
	logger()->log( STDLOG_L3, "==============================================================" );

	init();

        m_nWaitForInput = GET_CFG_INT( "main", "wait_time", 5 );

	return pollingUserInput();
}

