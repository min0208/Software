WORK_DIR=$(readlink -e $(dirname $0))
DATA_DIR=$WORK_DIR/files

# Project list
# pattern "Group:Name:Version"
# NEXUS_PROJECTS
PROJECTS_FILE=$WORK_DIR/project.deps

# Nexus parameters
NEXUS_URL=http://mtl.msky:8081/repository
NEXUS_USER=admin
NEXUS_PASSWD=admin123

REPOSITORY_ID=nexus
OS_RELEASE=$(uname -r | sed -e 's/\.[^\.]*$//' -e 's/^.*\.//')
ARCH=$(uname -m)

nexus_fetch()
{
  REPO=$1
  GROUP=$2
  NAME=$3
  VERSION=$4
  rm -f ${NAME}-${VERSION}.zip
  echo "curl -sO -X GET -u $NEXUS_USER:$NEXUS_PASSWD"\
    "$NEXUS_URL/$REPO/$GROUP/$NAME/$VERSION/${NAME}-${VERSION}.zip"
  curl -sO -X GET -u $NEXUS_USER:$NEXUS_PASSWD \
    $NEXUS_URL/$REPO/$GROUP/$NAME/$VERSION/${NAME}-${VERSION}.zip
  if [ $? -ne 0 ]; then
    echo "Error: failed to pull $NAME-$VERSION from nexus"
    exit 1
  fi

  unzip -qo ${NAME}-${VERSION}.zip
  if [ $? -ne 0 ]; then
    echo "Error: failed to unzip $NAME-$VERSION.zip"
    exit 1
  fi
  rm -f ${NAME}-${VERSION}.zip
}

clean()
{
  DIR=$1
  if [ -d "$DIR" ]; then
    date=`stat "$DIR" | grep Modify | awk '{print $2}'`
    today=`date '+%Y-%m-%d'`
    if [ "X$date" != "X$today" ]; then
      rm -rf "$DIR"
    fi
  fi
}

pull()
{
  echo "Pulling projects from nexus.."

  if [ ! -f "$PROJECTS_FILE" ]; then
    echo "Error: $PROJECTS_FILE isn't found"
    exit 1
  fi
  . "$PROJECTS_FILE"

  mkdir -p "$DATA_DIR"
  cd "$DATA_DIR"
  for p in $PROJECT_LIST; do
    echo "Downloading $p"
    REPO_NAME=`echo $p | awk -F: '{print $1}'`
    GROUP=`echo $p | awk -F: '{print $2}'`
    NAME=`echo $p | awk -F: '{print $3}'`
    VERSION=`echo $p | awk -F: '{print $4}'`
    REPO=$REPO_NAME-$OS_RELEASE-$ARCH
    if [ "X" = "X$REPO_NAME" ] || [ "X" = "X$GROUP" ]\
      || [ "X" = "X$NAME" ] || [ "X" = "X$VERSION" ]; then
      echo "Error: invalid project pattern $p"
      exit 1
    fi

    nexus_fetch $REPO $GROUP $NAME $VERSION
  done

  echo "Done"
}

if [ "X$1" = "Xforce_download" ]; then
  rm -rf "$DATA_DIR"
  pull
elif [ "X$1" = "Xdownload" ]; then
  clean "$DATA_DIR"
  if [ ! -d "$DATA_DIR" ]; then
    pull
  else
    echo "$DATA_DIR already exists, ignore download"
    echo "Use '$(basename $0) force_download' to force download files"
  fi
else
  echo "Usage: $(basename $0) force_download|download"
  echo
fi
