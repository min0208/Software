#!/bin/sh

WORK_DIR=$(readlink -e $(dirname $0)/..)
$WORK_DIR/nexus/nexus_pull.sh download

cp -r $WORK_DIR/nexus/files/include/* $WORK_DIR
$WORK_DIR/rpmbuild/rpmbuild-quickfix.sh

cd $WORK_DIR/
./bootstrap
CXXFLAGS="-Wdeprecated-declarations -Wunused-result" ./configure --enable-static=yes  --enable-shared=yes
make -j4
