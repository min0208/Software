NAME=fix-m-proxy
VERSION=1.1.0
GROUP=wabi

FILELIST="
rpm:${HOME}/rpmbuild/RPMS/x86_64/fixmproxy-${VERSION}-*.rpm
"

NEXUS_URL=http://mtl.msky:8081/repository
NEXUS_USER=admin
NEXUS_PASSWD=admin123

REPOSITORY_ID=nexus

HOME=$(readlink -e $(dirname $0)/..)
WORK_DIR="$HOME/NexusFiles"
WORK_DIR_SRC="$WORK_DIR/src"
WORK_DIR_ZIP="$WORK_DIR/zip"
OS_RELEASE=$(uname -r | sed -e 's/\.[^\.]*$//' -e 's/^.*\.//')
ARCH=$(uname -m)
REPO=MTL-Cpp-wip-$OS_RELEASE-$ARCH

copy()
{
  echo "Copying files.."
  cd $HOME
  rm -rf $WORK_DIR
  mkdir -p $WORK_DIR_SRC
  mkdir -p $WORK_DIR_ZIP

  # copy files
  for f in $FILELIST; do
    TARGET_DIR=`echo $f | awk -F: '{print $1}'`
    SOURCE_FILES=`echo $f | awk -F: '{print $2}'`

    if [ "X" = "X$WORK_DIR" ] || [ "X" = "X$SOURCE_FILES" ]; then
      echo "Error: invalid filelist $f"
      exit 1
    fi

    mkdir -p $WORK_DIR_SRC/$TARGET_DIR
    echo "Copy $SOURCE_FILES to $WORK_DIR_SRC/$TARGET_DIR"
    cp -Lr $SOURCE_FILES $WORK_DIR_SRC/$TARGET_DIR

    if [ $? -ne 0 ]; then
      echo "Error: failed to copy files"
      exit 1
    fi
  done
  echo "Done"
}

build_zip()
{
  echo "Zip files.."
  # zip files
  cd $WORK_DIR_SRC && zip -r $WORK_DIR_ZIP/$NAME-${VERSION}.zip .
  echo "Done"
}

push()
{
  echo "Pushing to nexus.."
  cd $PWD
  echo "curl -u $NEXUS_USER:$NEXUS_PASSWD" \
       "--upload-file $WORK_DIR_ZIP/$NAME-${VERSION}.zip" \
       "$NEXUS_URL/$REPO/$GROUP/$NAME/$VERSION/${NAME}-${VERSION}.zip"
  curl -u $NEXUS_USER:$NEXUS_PASSWD \
    --upload-file $WORK_DIR_ZIP/$NAME-${VERSION}.zip \
    $NEXUS_URL/$REPO/$GROUP/$NAME/$VERSION/${NAME}-${VERSION}.zip

  if [ $? -ne 0 ]; then
    echo "Error: failed to push files to nexus"
    exit 1
  fi

  echo "Done"
}

clean_up()
{
  echo "Clean up..."
  echo "rm -rf $WORK_DIR"
  rm -rf $WORK_DIR
}


checksum()
{
  echo "Generating checksum for non-text files.."
  cd $WORK_DIR_SRC
  FILELIST=$(find . -type f)
  for f in $FILELIST; do
    TYPE=`file --mime-type $f | sed 's/.*: //'`
    if [[ "$TYPE" != *"text"* ]]; then
      echo "Generate $f.md5"
      md5sum $f > $f.md5
      echo "Generate $f.sha1"
      sha1sum $f > $f.sha1
    fi
  done
}

copy
checksum
build_zip
push
clean_up

