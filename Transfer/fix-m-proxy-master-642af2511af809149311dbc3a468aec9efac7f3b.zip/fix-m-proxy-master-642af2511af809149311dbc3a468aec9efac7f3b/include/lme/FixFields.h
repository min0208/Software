#ifndef LME_FIX_FIELDS_H
#define LME_FIX_FIELDS_H

#include "quickfix/Field.h"
#include "lme/FixFieldNumbers.h"
#include "lme/FixValues.h"

namespace FIX
{
    DEFINE_INT(TradeSeqNo);
    DEFINE_INT(TradeSeqNoSeries);
    DEFINE_INT(NoTradeSeqNoSeries);
    DEFINE_STRING(MaturityRollingPrompt);
    DEFINE_STRING(MaturityAveragePrompt);
    DEFINE_STRING(LegMaturityRollingPrompt);
    DEFINE_CHAR(PromptType);
    DEFINE_CHAR(LegPromptType);
    DEFINE_CHAR(SecurityStrikeType);
    DEFINE_INT(NoStrikeTableRows);
    DEFINE_FLOAT(StrikeLowLimit);
    DEFINE_FLOAT(StrikeGradation);
    DEFINE_INT(NoOfInstrumentLegs);
    DEFINE_INT(RollingPromptDate);
    DEFINE_INT(MDEntryPxType);
    DEFINE_STRING(CCPMatchStatus);
    DEFINE_STRING(CCPMatchNo);
    DEFINE_STRING(SelectTradeID);
    DEFINE_STRING(IsMonthlyContract);
    DEFINE_STRING(NoOfMonthlyContracts);
    DEFINE_STRING(PublishTime);
    DEFINE_FLOAT(MDEntryPxDifferential);
    DEFINE_STRING(MDReportCode);
    DEFINE_STRING(MDReportName);
    DEFINE_INT(MDReportVersion);
    DEFINE_INT(MDReportFragmentNo);
    DEFINE_BOOLEAN(MDReportLastFragment);
    DEFINE_STRING(MDSource);
    DEFINE_FLOAT(MDEntryPremium);
    DEFINE_STRING(MDEntrySession);
    DEFINE_STRING(MDEntryTradeType);
    DEFINE_STRING(MDEntryMarketMakerID);
    DEFINE_STRING(TradeTime);
    DEFINE_INT(NoMDReportCodes);
    DEFINE_BOOLEAN(LastTrade);
    DEFINE_STRING(MaturityExchangeRateDate);
    DEFINE_BOOLEAN(Withdrawn);
    DEFINE_BOOLEAN(Deleted);
    DEFINE_STRING(InvestmentDecisionCountry);
    DEFINE_STRING(ExecutionDecisionCountry);
    DEFINE_BOOLEAN(DEA);
    DEFINE_STRING(TradingCapacity);
    DEFINE_STRING(LegAbbreviatedPrice);
    DEFINE_STRING(CommodityDerivativeIndicator);


    DEFINE_INT(InstrumentLegNo);
    DEFINE_INT(LegInstrument);
    DEFINE_STRING(UniqueProductID);
    DEFINE_STRING(ComplexTradeComponentID);
    DEFINE_STRING(StrategyID);
    DEFINE_STRING(StrategyMatchID);
    DEFINE_CHAR(GreenTradeFlag);
    DEFINE_STRING(StrategyClOrdId);
    DEFINE_UTCTIMESTAMP(TrdClearedTime);
    DEFINE_STRING(MatchingSlipID);
    DEFINE_INT(RequestType);
    DEFINE_STRING(RequestID);
    DEFINE_INT(NumMsg);
    DEFINE_INT(ReqResponseTo);
    DEFINE_INT(ReqResponseStatus);
    DEFINE_STRING(AbbreviatedPrice);
    DEFINE_STRING(PrivateReference);
    DEFINE_STRING(PublicReference);
    DEFINE_UTCTIMESTAMP(TrdMatchTime);
    DEFINE_INT(ExchangeTradeType);
    DEFINE_STRING(ClearingRefNo);
    DEFINE_STRING(MatchingRefNo);
    DEFINE_STRING(SelectOrderNumber);
    DEFINE_STRING(SelectTradeNumber);
    DEFINE_STRING(RejectCode);
    DEFINE_INT(SecDefStatus);
    DEFINE_BOOLEAN(TradeOrigin);
    DEFINE_INT(VenueID);
    DEFINE_STRING(ContactPhoneNumber);
    DEFINE_STRING(ContactEmailAddress);
    DEFINE_STRING(FirmID);
    DEFINE_STRING(MemberName);
    DEFINE_STRING(MemberAddress);
    DEFINE_STRING(ContactFax);
    DEFINE_STRING(AltPhone1);
    DEFINE_STRING(AltPhone2);
    DEFINE_CHAR(ClearingStatus);

    DEFINE_STRING(TradeLinkId);
    DEFINE_STRING(CancellationFlag);
    DEFINE_STRING(CancelLinkId);

    DEFINE_STRING(ClientBranchCountry);
    DEFINE_STRING(CountryOfBranchOfClient);
    DEFINE_STRING(RegulatoryTradeId);
    DEFINE_STRING(TradedPremium);
    DEFINE_STRING(TradedPrice);

}

#endif
