#ifndef LME_FIX44_TRADECANCELREJECT_H
#define LME_FIX44_TRADECANCELREJECT_H

#include "quickfix/fix44/Message.h"
#include "lme/FixFields.h"
#include "lme/FixFieldNumbers.h"

namespace FIX44
{
  // 7.8.4.2  Trade Cancel Reject, MsgType=9


  // ClOrdID
  // OrigClOrdID
  // StrategyClOrdId
  // OrderID
  // OrdStatus
  // CxlRejReason
  // Text

  class TradeCancelReject : public Message
  {
  public:
    TradeCancelReject() : Message(MsgType()) {}
    TradeCancelReject(const FIX::Message& m) : Message(m) {}
    TradeCancelReject(const Message& m) : Message(m) {}
    TradeCancelReject(const TradeCancelReject& m) : Message(m) {}
    static FIX::MsgType MsgType() { return FIX::MsgType("9"); }

    TradeCancelReject(
      const FIX::ClOrdID& ClOrdID,
      const FIX::OrderID& OrderID,
      const FIX::OrdStatus& OrdStatus,
      const FIX::CxlRejReason& CxlRejReason )
    : Message(MsgType())
    {

      set(ClOrdID);
      set(OrderID);
      set(OrdStatus);
      set(CxlRejReason);
    }

    FIELD_SET(*this, FIX::ClOrdID);
    FIELD_SET(*this, FIX::OrigClOrdID);
    FIELD_SET(*this, FIX::StrategyClOrdId);
    FIELD_SET(*this, FIX::OrderID);
    FIELD_SET(*this, FIX::OrdStatus);
    FIELD_SET(*this, FIX::CxlRejReason);
    FIELD_SET(*this, FIX::Text);
  };
}

#endif
