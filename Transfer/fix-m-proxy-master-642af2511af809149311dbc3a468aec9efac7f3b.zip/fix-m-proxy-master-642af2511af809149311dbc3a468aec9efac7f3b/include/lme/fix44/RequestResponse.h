#ifndef LME_FIX44_REQUESTRESPONSE_H
#define LME_FIX44_REQUESTRESPONSE_H

#include "quickfix/fix44/Message.h"
#include "lme/FixFields.h"
#include "lme/FixFieldNumbers.h"

namespace FIX44
{
  // 7.8.4.3  Request Response, MsgType=cm3

  // 
  // ReqResponseTo
  // MassStatusReqID
  // RequestID
  // ReqResponseStatus
  // NumMsg
  // RejectCode
  // Text
  // TransactTime
  // 

  class RequestResponse : public Message
  {
  public:
    RequestResponse() : Message(MsgType()) {}
    RequestResponse(const FIX::Message& m) : Message(m) {}
    RequestResponse(const Message& m) : Message(m) {}
    RequestResponse(const RequestResponse& m) : Message(m) {}
    static FIX::MsgType MsgType() { return FIX::MsgType("cm3"); }

    RequestResponse(

      const FIX::ReqResponseTo& ReqResponseTo,
      const FIX::ReqResponseStatus& ReqResponseStatus,
      const FIX::NumMsg& NumMsg,
      const FIX::TransactTime& TransactTime )
    : Message(MsgType())
    {
      set(ReqResponseTo);
      set(ReqResponseStatus);
      set(NumMsg);
      set(TransactTime);

    }
    FIELD_SET(*this, FIX::ReqResponseTo);
    FIELD_SET(*this, FIX::MassStatusReqID);
    FIELD_SET(*this, FIX::RequestID);
    FIELD_SET(*this, FIX::ReqResponseStatus);
    FIELD_SET(*this, FIX::NumMsg);
    FIELD_SET(*this, FIX::RejectCode);
    FIELD_SET(*this, FIX::Text);
    FIELD_SET(*this, FIX::TransactTime);

  };
}

#endif
