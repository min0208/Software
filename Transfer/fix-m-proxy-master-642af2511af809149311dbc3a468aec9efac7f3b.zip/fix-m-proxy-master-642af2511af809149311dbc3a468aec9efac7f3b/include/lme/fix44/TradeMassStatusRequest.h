#ifndef LME_FIX44_TRADEMASSSTATUSREQUEST_H
#define LME_FIX44_TRADEMASSSTATUSREQUEST_H

#include "quickfix/fix44/Message.h"
#include "lme/FixFields.h"
#include "lme/FixFieldNumbers.h"

namespace FIX44
{
  // 7.8.3.3  Trade Mass Status Request, MsgType=AF

  // MassStatusReqID
  // MassStatusReqType
  // ClOrdID
  // StrategyClOrdId
  // Symbol
  // SecurityType
  // OrdStatus
  // TrdMatchTime
  // TradeDate
  // 

  class TradeMassStatusRequest : public Message
  {
  public:
    TradeMassStatusRequest() : Message(MsgType()) {}
    TradeMassStatusRequest(const FIX::Message& m) : Message(m) {}
    TradeMassStatusRequest(const Message& m) : Message(m) {}
    TradeMassStatusRequest(const TradeMassStatusRequest& m) : Message(m) {}
    static FIX::MsgType MsgType() { return FIX::MsgType("AF"); }

    TradeMassStatusRequest(
      const FIX::MassStatusReqID& MassStatusReqID,
      const FIX::MassStatusReqType& MassStatusReqType)
    : Message(MsgType())
    {
      set(MassStatusReqID);
      set(MassStatusReqType);
    }

    FIELD_SET(*this, FIX::MassStatusReqID);
    FIELD_SET(*this, FIX::MassStatusReqType);
    FIELD_SET(*this, FIX::ClOrdID);
    FIELD_SET(*this, FIX::StrategyClOrdId);
    FIELD_SET(*this, FIX::Symbol);
    FIELD_SET(*this, FIX::SecurityType);
    FIELD_SET(*this, FIX::OrdStatus);
    FIELD_SET(*this, FIX::TrdMatchTime);
    FIELD_SET(*this, FIX::TradeDate);

  }; // end of class
}; // end of namespace

#endif
