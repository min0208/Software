#ifndef LME_FIX44_MEMBERDEFINITION_H
#define LME_FIX44_MEMBERDEFINITION_H

#include "quickfix/fix44/Message.h"
#include "lme/FixFields.h"
#include "lme/FixFieldNumbers.h"

namespace FIX44
{

  // 7.8.4.6 Member Definition

  // RequestID
  // FirmID
  // MemberName
  // MemberAddress
  // ContactPhoneNumber
  // ContactEmailAddress
  // ContactFax
  // AltPhone1
  // AltPhone2

  class MemberDefinition : public Message
  {
  public:
    MemberDefinition() : Message(MsgType()) {}
    MemberDefinition(const FIX::Message& m) : Message(m) {}
    MemberDefinition(const Message& m) : Message(m) {}
    MemberDefinition(const MemberDefinition& m) : Message(m) {}
    static FIX::MsgType MsgType() { return FIX::MsgType("cm4"); }

    MemberDefinition(

      const FIX::FirmID& FirmID,
      const FIX::MemberName& MemberName,
      const FIX::MemberAddress& MemberAddress,
      const FIX::ContactPhoneNumber& ContactPhoneNumber,
      const FIX::ContactEmailAddress& ContactEmailAddress,
      const FIX::ContactFax& ContactFax,
      const FIX::AltPhone1& AltPhone1,
      const FIX::AltPhone2& AltPhone2 )
    : Message(MsgType())
    {

      set(FirmID);
      set(MemberName);
      set(MemberAddress);
      set(ContactPhoneNumber);
      set(ContactEmailAddress);
      set(ContactFax);
      set(AltPhone1);
      set(AltPhone2);

    }

    FIELD_SET(*this, FIX::RequestID);
    FIELD_SET(*this, FIX::FirmID);
    FIELD_SET(*this, FIX::MemberName);
    FIELD_SET(*this, FIX::MemberAddress);
    FIELD_SET(*this, FIX::ContactPhoneNumber);
    FIELD_SET(*this, FIX::ContactEmailAddress);
    FIELD_SET(*this, FIX::ContactFax);
    FIELD_SET(*this, FIX::AltPhone1);
    FIELD_SET(*this, FIX::AltPhone2);

  };

}

#endif
