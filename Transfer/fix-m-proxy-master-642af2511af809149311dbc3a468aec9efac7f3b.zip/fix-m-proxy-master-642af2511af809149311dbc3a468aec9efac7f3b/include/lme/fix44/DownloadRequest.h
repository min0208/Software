#ifndef LME_FIX44_DOWNLOADREQUEST_H
#define LME_FIX44_DOWNLOADREQUEST_H

#include "quickfix/fix44/Message.h"
#include "lme/FixFields.h"
#include "lme/FixFieldNumbers.h"

namespace FIX44
{
  // 7.8.3.4  Download Request, MsgType=cm2

  // RequestID
  // RequestType
  // Symbol
  // SecurityType
  // TransactTime
  // 


  class DownloadRequest : public Message
  {
  public:
    DownloadRequest() : Message(MsgType()) {}
    DownloadRequest(const FIX::Message& m) : Message(m) {}
    DownloadRequest(const Message& m) : Message(m) {}
    DownloadRequest(const DownloadRequest& m) : Message(m) {}
    static FIX::MsgType MsgType() { return FIX::MsgType("cm2"); }

    DownloadRequest(
      const FIX::RequestID& RequestID,
      const FIX::RequestType& RequestType,
      const FIX::TransactTime& TransactTime)
    : Message(MsgType())
    {
      set(RequestID);
      set(RequestType);
      set(TransactTime);
    }

    FIELD_SET(*this, FIX::RequestID);
    FIELD_SET(*this, FIX::RequestType);
    FIELD_SET(*this, FIX::Symbol);
    FIELD_SET(*this, FIX::SecurityType);
    FIELD_SET(*this, FIX::TransactTime);

  };

}

#endif
