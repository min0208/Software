#ifndef LME_FIX44_TRADECANCELREQUEST_H
#define LME_FIX44_TRADECANCELREQUEST_H

#include "quickfix/fix44/Message.h"
#include "lme/FixFields.h"
#include "lme/FixFieldNumbers.h"

namespace FIX44
{

  // 7.8.3.2  Trade Cancel Request, MsgType=F

  // ClOrdID
  // OrigClOrdID
  // StrategyClOrdId
  // TransactTime

  class TradeCancelRequest : public Message
  {
  public:

    TradeCancelRequest() : Message(MsgType()) {}
    TradeCancelRequest(const FIX::Message& m) : Message(m) {}
    TradeCancelRequest(const Message& m) : Message(m) {}
    TradeCancelRequest(const TradeCancelRequest& m) : Message(m) {}
    static FIX::MsgType MsgType() { return FIX::MsgType("F"); }

    TradeCancelRequest(

      const FIX::ClOrdID& ClOrdID,
      const FIX::TransactTime& TransactTime )
    : Message(MsgType())
    {
      set(ClOrdID);
      set(TransactTime);
    }

    FIELD_SET(*this, FIX::ClOrdID);
    FIELD_SET(*this, FIX::OrigClOrdID);
    FIELD_SET(*this, FIX::StrategyClOrdId);
    FIELD_SET(*this, FIX::TransactTime);

  }; // end of class
};  // end of namespace

#endif
