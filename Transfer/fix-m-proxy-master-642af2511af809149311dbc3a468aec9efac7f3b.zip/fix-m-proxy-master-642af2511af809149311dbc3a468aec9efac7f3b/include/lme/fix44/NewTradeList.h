#ifndef LME_FIX44_NEWTRADELIST_H
#define LME_FIX44_NEWTRADELIST_H

#include "quickfix/fix44/Message.h"
#include "lme/FixFields.h"
#include "lme/FixFieldNumbers.h"


namespace FIX44
{

  // 7.8.3.1  New Trade List, MsgType=E

  // * Parties
  // ExchangeTradeType
  // VenueID
  // MarketID
  // TimeBracket
  // TradeTime
  // TradeDate
  // StrategyClOrdId
  // CommodityDerivativeIndicator
  // NoTrades
  //   ClOrdId
  //   * Instrument
  //   ComplexTradeComponentID
  //   TradingCapacity
  //   CountryOfBranchOfClient
  //   TradeLinkId
  //   CancellationFlag
  //   CancelLinkId
  //   LastPx
  //   TradedPremium
  //   UnderlyingPx
  //   PriceType
  //   Side
  //   NoLegs
  //     LegInstrument
  //     LegSide
  //     LegLastQty
  //     AbbreviatedPrice
  //     LegLastPx
  //     TradedPrice
  // Account
  // AccountType
  // TransactTime
  // PrivateReference
  // PublicReference

  class NewTradeList : public Message
  {
  public:
    NewTradeList() : Message(MsgType()) {}
    NewTradeList(const FIX::Message& m) : Message(m) {}
    NewTradeList(const Message& m) : Message(m) {}
    NewTradeList(const NewTradeList& m) : Message(m) {}
    static FIX::MsgType MsgType() { return FIX::MsgType("E"); }

    NewTradeList(

      // required fields

      // ExchangeTradeType
      // VenueID
      // MarketID
      // NoTrades
      // AccountType
      // TransactTime

      const FIX::ExchangeTradeType& ExchangeTradeType,
      const FIX::VenueID& VenueID,
      const FIX::MarketID& MarketID,
      const FIX::NoTrades& NoTrades,
      // const FIX::AccountType& AccountType,
      const FIX::TransactTime& TransactTime

      )
    : Message(MsgType())
    {
      set(ExchangeTradeType);
      set(VenueID);
      set(MarketID);
      set(NoTrades);
      // set(AccountType);
      set(TransactTime);
    }

    FIELD_SET(*this, FIX::NoPartyIDs);
    class NoPartyIDs: public FIX::Group
    {
    public:
    // Parties
    NoPartyIDs() : FIX::Group(453,447,FIX::message_order(447,448,452,0)) {}
      FIELD_SET(*this, FIX::PartyIDSource);
      FIELD_SET(*this, FIX::PartyID);
      FIELD_SET(*this, FIX::PartyRole);
    };

    FIELD_SET(*this, FIX::ExchangeTradeType);
    FIELD_SET(*this, FIX::VenueID);
    FIELD_SET(*this, FIX::MarketID);
    FIELD_SET(*this, FIX::TimeBracket);
    FIELD_SET(*this, FIX::TradeTime);
    FIELD_SET(*this, FIX::TradeDate);
    FIELD_SET(*this, FIX::StrategyClOrdId);
    FIELD_SET(*this, FIX::CommodityDerivativeIndicator);

    FIELD_SET(*this, FIX::NoTrades);

    class NoTrades: public FIX::Group{

      public:
      NoTrades() : FIX::Group(897,11,FIX::message_order(11,20020,10051,10052,820,20032,20033,31,20031,810,423,54,0)){}

      FIELD_SET(*this, FIX::ClOrdID);

      // Instrument start
      FIELD_SET(*this, FIX::Symbol);
      FIELD_SET(*this, FIX::SecurityType);
      FIELD_SET(*this, FIX::CFICode);
      FIELD_SET(*this, FIX::NoOfInstrumentLegs);

      class NoOfInstrumentLegs: public FIX::Group
      {
        public:
        NoOfInstrumentLegs() : FIX::Group(10010,20004,FIX::message_order(20004,10004,10000,541,202,5678,20008,0)) {}


        FIELD_SET(*this, FIX::InstrumentLegNo);
        FIELD_SET(*this, FIX::PromptType);
        FIELD_SET(*this, FIX::MaturityRollingPrompt);
        FIELD_SET(*this, FIX::MaturityDate);
        FIELD_SET(*this, FIX::StrikePrice);
        FIELD_SET(*this, FIX::Volatility);
        FIELD_SET(*this, FIX::UniqueProductID);
      };
      // Instrument end

      FIELD_SET(*this, FIX::ComplexTradeComponentID);
      FIELD_SET(*this, FIX::TradingCapacity);

      FIELD_SET(*this, FIX::CountryOfBranchOfClient);
      FIELD_SET(*this, FIX::TradeLinkId);
      FIELD_SET(*this, FIX::CancellationFlag);
      FIELD_SET(*this, FIX::CancelLinkId);
      FIELD_SET(*this, FIX::LastPx);
      FIELD_SET(*this, FIX::TradedPremium);

      FIELD_SET(*this, FIX::UnderlyingPx);
      FIELD_SET(*this, FIX::PriceType);
      FIELD_SET(*this, FIX::Side);
      FIELD_SET(*this, FIX::NoLegs);

      class NoLegs : public FIX::Group{

        public:
        NoLegs() : FIX::Group(555,20005, FIX::message_order(20005,624,10003,5474,637,20030,0)){}

        FIELD_SET(*this, FIX::LegInstrument);
        FIELD_SET(*this, FIX::LegSide);
        FIELD_SET(*this, FIX::LegLastQty);
        FIELD_SET(*this, FIX::AbbreviatedPrice);
        FIELD_SET(*this, FIX::LegLastPx);
        FIELD_SET(*this, FIX::TradedPrice);
      };

    };

    FIELD_SET(*this, FIX::Account);
    FIELD_SET(*this, FIX::AccountType);
    FIELD_SET(*this, FIX::TransactTime);
    FIELD_SET(*this, FIX::PrivateReference);
    FIELD_SET(*this, FIX::PublicReference);
  }; // end of class
}; // end of namespace

#endif
