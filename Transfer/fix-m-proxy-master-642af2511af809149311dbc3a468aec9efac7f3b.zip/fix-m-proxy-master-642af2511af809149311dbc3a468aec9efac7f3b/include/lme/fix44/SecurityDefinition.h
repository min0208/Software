#ifndef LME_FIX44_SECURITYDEFINITION_H
#define LME_FIX44_SECURITYDEFINITION_H

#include "quickfix/fix44/Message.h"
#include "lme/FixFields.h"
#include "lme/FixFieldNumbers.h"

namespace FIX44
{

  // 7.8.4.5  Security Definition, MsgType=d

  // RequestID
  // Symbol
  // SecurityType
  // CFICode
  // Maturity Date
  // SecDefStatus

  class SecurityDefinition : public Message
  {
  public:
    SecurityDefinition() : Message(MsgType()) {}
    SecurityDefinition(const FIX::Message& m) : Message(m) {}
    SecurityDefinition(const Message& m) : Message(m) {}
    SecurityDefinition(const SecurityDefinition& m) : Message(m) {}
    static FIX::MsgType MsgType() { return FIX::MsgType("d"); }

    SecurityDefinition(
      const FIX::Symbol& Symbol,
      const FIX::SecurityType& SecurityType,
      const FIX::CFICode& CFICode,
      const FIX::SecDefStatus& SecDefStatus)
    : Message(MsgType())
    {
      set(Symbol);
      set(SecurityType);
      set(CFICode);
      set(SecDefStatus);
    }

    FIELD_SET(*this, FIX::RequestID);
    FIELD_SET(*this, FIX::Symbol);
    FIELD_SET(*this, FIX::SecurityType);
    FIELD_SET(*this, FIX::CFICode);
    FIELD_SET(*this, FIX::MaturityDate);
    FIELD_SET(*this, FIX::SecDefStatus);

  };

}

#endif
