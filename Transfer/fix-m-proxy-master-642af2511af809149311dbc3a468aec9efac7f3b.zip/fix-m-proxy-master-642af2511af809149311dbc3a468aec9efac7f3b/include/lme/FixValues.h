#ifndef LME_FIX_VALUES_H
#define LME_FIX_VALUES_H

namespace FIX
{

    const char MsgType_NewTradeList[] = "E";
    const char MsgType_TradeCancelRequest[] = "F";
    const char MsgType_TradeMassStatusRequest[] = "AF";
    const char MsgType_DownloadRequest[] = "cm2";

    const char MsgType_TradeExecutionReport[] = "8";
    const char MsgType_TradeCancelReject[] = "9";
    const char MsgType_RequestResponse[] = "cm3";
    // const char MsgType_SecurityDefinition[] = "d";
    const char MsgType_MemberDefinition[] = "cm4";

}

#endif
