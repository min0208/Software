#ifndef LME_FIX_FIELD_NUMBERS_H
#define LME_FIX_FIELD_NUMBERS_H

namespace FIX
{
    namespace FIELD
    {
        const int TradeSeqNo                 = 7554;
        const int TradeSeqNoSeries           = 7555;
        const int NoTradeSeqNoSeries         = 7565;
        const int MaturityRollingPrompt      = 10000;
        const int MaturityAveragePrompt      = 10001;
        const int LegMaturityRollingPrompt   = 10002;
        const int PromptType                 = 10004;
        const int LegPromptType              = 10005;
        const int SecurityStrikeType         = 10006;
        const int NoStrikeTableRows          = 10007;
        const int StrikeLowLimit             = 10008;
        const int StrikeGradation            = 10009;
        const int NoOfInstrumentLegs         = 10010;
        const int RollingPromptDate          = 10011;
        const int MDEntryPxType              = 10013;
        const int CCPMatchStatus             = 10020;
        const int CCPMatchNo                 = 10021;
        const int SelectTradeID              = 10022;
        const int IsMonthlyContract          = 10026;
        const int NoOfMonthlyContracts       = 10027;
        const int PublishTime                = 10028;
        const int MDEntryPxDifferential      = 10029;
        const int MDReportCode               = 10030;
        const int MDReportName               = 10031;
        const int MDReportVersion            = 10032;
        const int MDReportFragmentNo         = 10033;
        const int MDReportLastFragment       = 10034;
        const int MDSource                   = 10035;
        const int MDEntryPremium             = 10036;
        const int MDEntrySession             = 10037;
        const int MDEntryTradeType           = 10038;
        const int MDEntryMarketMakerID       = 10039;
        const int NoMDReportCodes            = 10041;
        const int LastTrade                  = 10042;
        const int MaturityExchangeRateDate   = 10043;
        const int Withdrawn                  = 10044;
        const int Deleted                    = 10046;
        const int InvestmentDecisionCountry  = 10048;
        const int ExecutionDecisionCountry   = 10049;
        const int DEA                        = 10050;
        const int TradingCapacity            = 10051;
        const int LegAbbreviatedPrice        = 10055;
        // TODO, duplicate tag, different name
        const int ClientBranchCountry          = 10052;
        const int CountryOfBranchOfClient      = 10052;
        const int CommodityDerivativeIndicator = 20023;

        const int InstrumentLegNo         =  20004;
        const int LegInstrument           =  20005;
        const int UniqueProductID         =  20008;
        const int ComplexTradeComponentID =  20020;
        const int StrategyID              =  20021;
        const int StrategyMatchID         =  20022;
        const int GreenTradeFlag          =  20024;
        const int StrategyClOrdId         =  20025;
        const int TrdClearedTime          =  20026;
        const int MatchingSlipID          =  5442;
        const int RequestType             =  5446;
        const int RequestID               =  5447;
        const int NumMsg                  =  5448;
        const int ReqResponseTo           =  5449;
        const int ReqResponseStatus       =  5469;
        const int AbbreviatedPrice        =  5474;
        const int PrivateReference        =  5476;
        const int PublicReference         =  5477;
        const int TrdMatchTime            =  5507;
        const int ExchangeTradeType       =  5681;
        const int ClearingRefNo           =  5934;
        const int MatchingRefNo           =  5935;
        const int SelectOrderNumber       =  5939;
        const int SelectTradeNumber       =  5940;
        const int RejectCode              =  6396;
        const int SecDefStatus            =  653;
        const int TradeOrigin             =  6574;
        const int VenueID                 =  7931;
        const int ContactPhoneNumber      =  9675;
        const int ContactEmailAddress     =  9677;
        const int FirmID                  =  5322;
        const int MemberName              =  5364;
        const int MemberAddress           =  5365;
        const int ContactFax              =  5366;
        const int AltPhone1               =  5367;
        const int AltPhone2               =  5368;
        const int ClearingStatus          =  5440;

        const int TradeLinkId              = 820;
        const int CancellationFlag         = 20032;
        const int CancelLinkId             = 20033;
        const int RegulatoryTradeId        = 1903;
        const int TradedPremium            = 20031;
        const int TradedPrice              = 20030;

        const int TradeTime                  = 5179;
    }
}

#endif
