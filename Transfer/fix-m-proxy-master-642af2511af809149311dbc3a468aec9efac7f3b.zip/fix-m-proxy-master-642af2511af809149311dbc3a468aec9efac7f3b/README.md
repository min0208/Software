# WABI FIX Proxy for LME FIX Communications
A Proxy based on QuickFIX to handle LME Select FIX sessions, and provides json interface for message query/matching/counting

* Able to commnucate with LME Select FIX gateways
* Support message query by JSON request
* Support message matching by JSON request
* Support message counting by JSON request