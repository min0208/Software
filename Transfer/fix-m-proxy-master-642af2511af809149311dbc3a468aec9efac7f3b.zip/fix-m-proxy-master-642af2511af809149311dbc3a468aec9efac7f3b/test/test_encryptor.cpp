/****************************************************************************
 *   Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : test_encryptor.cpp
 *   Project  : FIXProxy for LME
 *   Description: Test cases for encryptor
 *
 *   Created  : 2017/07/17
 *   Author   : Daniel Liang
 ****************************************************************************/

#include <chrono>
#include <gtest/gtest.h>
#include "test_encryptor.hpp"

TEST(EncryptorTest, GetEncryptedPassword) {
  long timeInMillis =
    std::chrono::duration_cast<std::chrono::milliseconds>(
      std::chrono::system_clock::now().time_since_epoch()).count();
  const std::string data("123qaz");
  const std::string faxKey("6e09297fbf6bdd1529fc901e4be03c196e09297fbf6bdd1529fc901e4be03c19");
  std::cout << "TimeInMillis: " << timeInMillis
            << "\nFax Key: " << faxKey
            << "\nPassword: " << data << std::endl;
  std::string encoded =
    FIXProxy::Encryptor::generateEncryptedPassword(data, faxKey, timeInMillis);
  std::cout << "Encrypted Password: " << encoded << std::endl;
}
