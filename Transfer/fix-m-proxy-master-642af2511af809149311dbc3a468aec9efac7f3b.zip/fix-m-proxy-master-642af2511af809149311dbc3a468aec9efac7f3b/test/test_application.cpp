/****************************************************************************
 *   Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : test_application.cpp
 *   Project  : Wabi III
 *   Description: Test cases for application class
 *
 *   Created  : 2015/06/09
 *   Author   : Yang Du
 ****************************************************************************/

#include <string>
#include <iostream>
#include <gtest/gtest.h>
#include "quickfix/SessionSettings.h"
#include "quickfix/FileStore.h"
#include "quickfix/SocketInitiator.h"
#include "test_application.hpp"

TEST(ApplicationTest, LookupMessage) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string clOrdIDStr = "11";
  const std::string clOrdID = "9_5LGTqiyaDB_PVIg3HkUw";
  const std::string time = "2015-05-22 19:29:16.091050";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  const auto matchedRequestVector =
    application.lookupFIXRequest(clOrdIDStr + "=" + clOrdID, time, false);
  for (const auto& request : matchedRequestVector)
  {
      const std::string& tags = request.tags;
      const std::string& text = request.text;
      std::cout << "Request: " << tags << '\n';
      std::cout << "Request Text: " << text << '\n';
      std::size_t found = tags.find("38=30000");
      EXPECT_NE (found, std::string::npos);
  }


  const auto matchedResponseVector =
    application.lookupFIXResponse(clOrdIDStr + "=" + clOrdID, time, false);
  for (const auto& response : matchedResponseVector)
  {
      const std::string& tags = response.tags;
      const std::string& text = response.text;
      std::cout << "Response: " << tags << '\n';
      std::cout << "ResponseText: " << text << '\n';
      std::size_t found = tags.find("14=30000");
      EXPECT_NE (found, std::string::npos);
      found = text.find("LastShares=30000");
      EXPECT_NE (found, std::string::npos);
  }

  const auto matchedMessageVector =
    application.lookupFIXMessage(clOrdIDStr + "=" + clOrdID, time, false);
  for (const auto& message : matchedMessageVector)
  {
    const std::string& tagsRequest  = message.tags;
    const std::string& tagsResponse = message.text;
    std::cout << "Request: " << tagsRequest << '\n';
    std::cout << "Response: " << tagsResponse << '\n';
    std::size_t found = tagsRequest.find("38=30000");
    EXPECT_NE (found, std::string::npos);
    found = tagsResponse.find("14=30000");
    EXPECT_NE (found, std::string::npos);
  }

}

TEST(ApplicationTest, MatchFIXResponseFailedWithMessageNotInSequence) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string expectedText = "11=5164784;35=8;34=1117";
  const std::string time = "2015-08-05 16:48:10.644354";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  std::string errorMsg;
  bool matched =
    application.matchFIXResponse(expectedText, time, false, errorMsg);

  EXPECT_FALSE (matched);  
  ASSERT_STREQ (errorMsg.substr(0,90).c_str(), "response matched but not fulfill the time constraint, maybe it is not received in sequence");
}

TEST(ApplicationTest, MatchFIXResponseFailedWithAdmnistritiveReject) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string expectedText = "11=5164772;34=1105";
  const std::string time = "2015-08-05 16:48:02.454705";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  std::string errorMsg;
  bool matched =
    application.matchFIXResponse(expectedText, time, false, errorMsg);

  EXPECT_FALSE (matched);  
  ASSERT_STREQ (errorMsg.substr(0,36).c_str(), "Required tag missing, ref tag ID: 54");
}

TEST(ApplicationTest, MatchFIXResponseFailedWithValueMismatch) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string expectedText = "11=5164784;MsgSeqNum=1117;OrderQty=30000;BeginString=FIX.4.2;Account=T1234567890;Symbol=0005.hk;8=FIX.4.2;49=EXECUTOR;56=CLIENT2;35=8;150=2;";
  const std::string time = "2015-08-05 16:48:09.428105";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  std::string errorMsg;
  bool matched =
    application.matchFIXResponse(expectedText, time, false, errorMsg);

  EXPECT_FALSE (matched);  
  ASSERT_STREQ (errorMsg.substr(0, 108).c_str(), "expect fields Account=T1234567890 Symbol=0005.hk, but actually received Account=Q1234567890 Symbol=0007.hk. ");
}

TEST(ApplicationTest, MatchFIXResponseFailedWithFieldNotFound) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string expectedText = "11=5164784;MsgSeqNum=1117;OrderQty=30000;BeginString=FIX.4.2;Account=Q1234567890;Symbol=0007.hk;8=FIX.4.2;49=EXECUTOR;56=CLIENT2;35=8;150=2;50=2";
  const std::string time = "2015-08-05 16:48:09.428105";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  std::string errorMsg;
  bool matched =
    application.matchFIXResponse(expectedText, time, false, errorMsg);

  EXPECT_FALSE (matched);
  ASSERT_STREQ (errorMsg.substr(0, 21).c_str(), "fields 50 not found. ");
}

TEST(ApplicationTest, MatchFIXResponseSuccess) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string expectedText = "11=5164784;MsgSeqNum=1117;OrderQty=30000;BeginString=FIX.4.2;Account=Q1234567890;Symbol=0007.hk;8=FIX.4.2;49=EXECUTOR;56=CLIENT2;35=8;150=2;";
  const std::string time = "2015-08-05 16:48:09.428105";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  std::string errorMsg;
  bool matched =
    application.matchFIXResponse(expectedText, time, false, errorMsg);

  EXPECT_TRUE (matched);  
}

TEST(ApplicationTest, MatchFIXResponseSuccessWithNoValue) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string expectedText = "11=5164785;MsgSeqNum=1117;OrderQty=30000;BeginString=FIX.4.2;Account=Q1234567890;Symbol=0007.hk;8=FIX.4.2;49=EXECUTOR;56=CLIENT2;35=8;150=2;1812=;151=<novalue>";
  const std::string time = "2015-08-05 16:48:09.428105";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  std::string errorMsg;
  bool matched =
    application.matchFIXResponse(expectedText, time, false, errorMsg);

  EXPECT_TRUE (matched);  
}

TEST(ApplicationTest, MatchFIXResponseFailedWithNoValue) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string expectedText = "11=5164784;MsgSeqNum=1117;OrderQty=30000;BeginString=FIX.4.2;Account=Q1234567890;Symbol=0007.hk;8=FIX.4.2;49=EXECUTOR;56=CLIENT2;35=8;150=2;Price=<novalue>";
  const std::string time = "2015-08-05 16:48:09.428105";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  std::string errorMsg;
  bool matched =
    application.matchFIXResponse(expectedText, time, false, errorMsg);

  EXPECT_FALSE (matched);  
}

TEST(ApplicationTest, CountFIXMessagesSuccess) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string expectedText = "11=5164784;MsgSeqNum=1117;OrderQty=30000;BeginString=FIX.4.2;Account=Q1234567890;Symbol=0007.hk;8=FIX.4.2;49=EXECUTOR;56=CLIENT2;35=8;150=2;_StartTime=2015-08-05 16:48:09.428;_EndTime=20150805-08:48:09.900;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  std::string messages;
  std::string errorMsg;
  int32_t count =
    application.countFIXMessages(expectedText, false, messages, errorMsg);

  EXPECT_EQ (1, count);  
}

TEST(ApplicationTest, LookupMessageNotFound) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string clOrdIDStr = "11";
  const std::string clOrdID = "9_5LGTqiyaDB_PVIg3HkUw";
  const std::string time = "2015-05-23 19:29:16.091050";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  const auto request =
    application.lookupFIXRequest(clOrdIDStr + "=" + clOrdID, time, false);

  const auto response =
    application.lookupFIXResponse(clOrdIDStr + "=" + clOrdID, time, false);
  
  const auto message =
    application.lookupFIXMessage(clOrdIDStr + "=" + clOrdID, time, false);

  std::size_t found = request.size();
  EXPECT_EQ (found, 0);
  found = response.size();
  EXPECT_EQ (found, 0);
  found = message.size();
  EXPECT_EQ (found, 0);
}

TEST(ApplicationTest, SendFIXMessageLogon) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "BeginString=FIXT.1.1;BodyLength=443;MsgType=A;MsgSeqNum=3;SenderCompID=CO99999901;SendingTime=20151218-07:27:57.572;TargetCompID=HKEXCO;EncryptMethod=0;HeartBtInt=20;NextExpectedMsgSeqNum=2;DefaultApplVerID=9;EncryptedPasswordMethod=101;EncryptedPassword=letliSPjqDN9PhTTzI16ZTpgbiMUudVW+z4sMLgKzHJ+vT1bha7dNgXSoRLxkxnkmtf3uF10FXU0NRVbSJNX3UceGwL2jHgl741xU+C+1Lc7Az7znW/kKMUOm6z/4gKSa06u72k80y7N/9snqitS8bBsbwWF3VgabL9qoM0kQD4alsJfQ90+zTg4uYB8Rh1d+ryztjUYDNNUaeLb0aU7J9HIG4lB3GdMaFUmA8m+tHWnjgxPri8dIMwoDg8oFSeT/SVN6lfF/dSscqscF05NSUabs/IA4uAGJQ0t4Vrsp3BEu/esllAxXj95FI7gaKlBZ4bceBD8rKZpQOVItRdyQQ==;CheckSum=004;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  application.sendFIXMessage(msgStr);
}

TEST(ApplicationTest, SendFIXMessageSequenceReset) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "BeginString=FIXT.1.1;BodyLength=64;MsgType=4;MsgSeqNum=3;SenderCompID=CO99999901;SendingTime=20151218-07:27:57.572;TargetCompID=HKEXCO;NewSeqNo=1;TransactTime=;CheckSum=027;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  application.sendFIXMessage(msgStr);
}

TEST(ApplicationTest, SendFIXMessage1) {
  // FIX.4.2 && New Order – Single
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  //const std::string msgStr = "8=FIX.4.2;9=162;35=D;34=5;49=CLIENT2;52=20150522-11:28:11.718;56=EXECUTOR;60=20150522-11:28:11;1=123456789A;11=ZbC-ibVeQ8eZRFWIMWKhBA;21=3;38=8000;40=2;44=150.70;54=2;55=0001.hk;10=228;";
  const std::string msgStr = "8=FIX.4.2;9=162;35=D;34=5;49=CLIENT2;52=20150522-11:28:11.718;56=EXECUTOR;60=20150522-11<sc>28<sc>11.111;1=123456789A;11=ZbC-ibVeQ8eZRFWIMWKhBA;21=3;38=8000;40=2;44=150.70;54=2;55=0001.hk;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  application.sendFIXMessage(msgStr);
}

TEST(ApplicationTest, SendFIXMessage2) {
  // FIX.4.2 && Order Cancel/Replace Request
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "8=FIX.4.2;9=162;35=G;34=5;49=CLIENT2;52=20150522-11:28:11.718;56=EXECUTOR;60=20150522-11:28:11;1=123456789A;11=ZbC-ibVeQ8eZRFWIMWKhBA;21=3;38=8000;40=2;44=150.70;54=2;55=0001.hk;10=228;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  application.sendFIXMessage(msgStr);
}

TEST(ApplicationTest, SendFIXMessage3) {
  // FIX.4.2 && Order Cancel Request
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "8=FIX.4.2;9=162;35=F;34=5;49=CLIENT2;52=20150522-11:28:11.718;56=EXECUTOR;60=20150522-11:28:11;1=123456789A;11=ZbC-ibVeQ8eZRFWIMWKhBA;21=3;38=8000;40=2;44=150.70;54=2;55=0001.hk;10=228;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  application.sendFIXMessage(msgStr);
}

TEST(ApplicationTest, SendFIXMessage4) {
  // FIX.4.2 && Other
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "8=FIX.4.2;9=162;35=5;34=5;49=CLIENT2;52=20150522-11:28:11.718;56=EXECUTOR;60=20150522-11:28:11;1=123456789A;11=ZbC-ibVeQ8eZRFWIMWKhBA;21=3;38=8000;40=2;44=150.70;54=2;55=0001.hk;10=228;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  application.sendFIXMessage(msgStr);
}

TEST(ApplicationTest, FromApp) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "8=FIX.4.2;9=174;35=8;34=542;49=EXECUTOR;52=20151225-08:43:25.307;56=CLIENT2;1=Q1234567890;6=30;11=37404003;14=10000;17=72;20=0;31=30;32=10000;37=72;38=10000;39=2;54=1;55=0005.hk;150=2;151=0;10=151;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  FIX::Message message = FIXProxy::Utils::toFIX(msgStr);
  application.fromApp(message, FIX::SessionID());
}

TEST(ApplicationTest, ToApp) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "8=FIX.4.2;9=162;35=D;34=5;49=CLIENT2;52=20150522-11:28:11.718;56=EXECUTOR;60=20150522-11:28:11;1=123456789A;11=ZbC-ibVeQ8eZRFWIMWKhBA;21=3;38=8000;40=2;44=150.70;54=2;55=0001.hk;10=228;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  FIX::Message message = FIXProxy::Utils::toFIX(msgStr);
  application.toApp(message, FIX::SessionID());
}

TEST(ApplicationTest, ToAppFailed) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "8=FIX.4.2;9=167;35=D;34=5;43=Y;49=CLIENT2;52=20150522-11:28:11.718;56=EXECUTOR;60=20150522-11:28:11;1=123456789A;11=ZbC-ibVeQ8eZRFWIMWKhBA;21=3;38=8000;40=2;44=150.70;54=2;55=0001.hk;10=231;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  FIX::Message message = FIXProxy::Utils::toFIX(msgStr);
  try
  {
    application.toApp(message, FIX::SessionID());
  }
  catch (FIX::DoNotSend& e)
  {
    std::cout << "Failed: " << e.what() << std::endl;
  }
}

TEST(ApplicationTest, sendFIXMessageNewOrderSingle) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "8=FIXT.1.1;9=163;35=D;34=5;49=CO99999901;52=20150522-11:28:11.718;56=HKEXCO;60=20150522-11:28:11;1=123456789A;11=ZbC-ibVeQ8eZRFWIMWKhBA;21=3;38=8000;40=2;44=150.70;54=2;55=0001.hk;10=52;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  application.sendFIXMessage(msgStr);
}

TEST(ApplicationTest, sendFIXMessageOrderCancelRequest) {
  // FIXT.1.1 && Order Cancel/Replace Request
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "8=FIXT.1.1;9=163;35=G;34=5;49=CO99999901;52=20150522-11:28:11.718;56=HKEXCO;60=20150522-11:28:11;1=123456789A;11=ZbC-ibVeQ8eZRFWIMWKhBA;21=3;38=8000;40=2;44=150.70;54=2;55=0001.hk;10=52;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  application.sendFIXMessage(msgStr);
}

TEST(ApplicationTest, sendFIXMessageOrderCancel) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "8=FIXT.1.1;9=163;35=F;34=5;49=CO99999901;52=20150522-11:28:11.718;56=HKEXCO;60=20150522-11:28:11;1=123456789A;11=ZbC-ibVeQ8eZRFWIMWKhBA;21=3;38=8000;40=2;44=150.70;54=2;55=0001.hk;10=52;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  application.sendFIXMessage(msgStr);
}

TEST(ApplicationTest, sendFIXMessageOrderMassCancel) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "8=FIXT.1.1;9=132;35=q;34=5;49=CO99999901;52=20150522-11:28:11.718;56=HKEXCO;60=;11=ZbC-ibVeQ8eZRFWIMWKhBA;21=3;38=8000;40=2;44=150.70;54=2;55=0001.hk;10=52;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  application.sendFIXMessage(msgStr);
}

TEST(ApplicationTest, sendFIXMessageUserRequest) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "8=FIXT.1.1;9=125;35=BE;34=5;49=CO99999901;52=20150522-11:28:11.718;56=HKEXCO;60=20150522-11:28:11;923=ZbC-ibVeQ8eZRFWIMWKhBA;924=5;553=CLIENT2;10=52;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  application.sendFIXMessage(msgStr);
}

TEST(ApplicationTest, sendFIXMessagePartyEntitlementRequest) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "8=FIXT.1.1;9=114;35=CU;34=5;49=CO99999901;52=20150522-11:28:11.718;56=HKEXCO;60=20150522-11:28:11;1770=ZbC-ibVeQ8eZRFWIMWKhBA;10=52;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  application.sendFIXMessage(msgStr);
}

TEST(ApplicationTest, sendFIXMessageFIX50Other) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "8=FIXT.1.1;9=163;35=5;34=5;49=CO99999901;52=20150522-11:28:11.718;56=HKEXCO;60=20150522-11:28:11;1=123456789A;11=ZbC-ibVeQ8eZRFWIMWKhBA;21=3;38=8000;40=2;44=150.70;54=2;55=0001.hk;10=52;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  application.sendFIXMessage(msgStr);
}

TEST(ApplicationTest, sendFIXMessageUnsupported) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "8=FIXT.4.4;9=162;35=D;34=5;49=CLIENT2;52=20150522-11:28:11.718;56=EXECUTOR;60=20150522-11:28:11;1=123456789A;11=ZbC-ibVeQ8eZRFWIMWKhBA;21=3;38=8000;40=2;44=150.70;54=2;55=0001.hk;10=52;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  application.sendFIXMessage(msgStr);
}

TEST(ApplicationTest, ProcessSessionSetting) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string logonMsgStr = "8=FIXT.1.1;9=93;35=A;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;98=0;108=20;789=1;1137=9;1400=102;10=89;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  FIX::SessionID sessionID("FIXT.1.1", "CO99999901", "HKEXCO");

  // Application::getSessionSettingString
  std::string startTimeStr = application.getSessionSettingString(sessionID, "_StartTime");
  ASSERT_STREQ ("", startTimeStr.c_str());

  // Application::setSessionSettingString
  application.setSessionSettingString(sessionID, "_StartTime", "20151218-07:27:57.572");

  // Application::getSessionSettingString
  startTimeStr = application.getSessionSettingString(sessionID, "_StartTime");
  ASSERT_STREQ ("20151218-07:27:57.572", startTimeStr.c_str());

  FIX::Message message = FIXProxy::Utils::toFIX(logonMsgStr);

  // Application::setSessionSettingString
  FIX::Dictionary dictSession;
  application.setSessionSettingString(message, 1400, "EncryptedPasswordMethod", dictSession);

  ASSERT_STREQ ("102", dictSession.getString("EncryptedPasswordMethod").c_str());

  // Application::updateSessionSettings
  application.updateSessionSettings(message, sessionID);
  std::string senderCompID = application.getSessionSettingString(sessionID, "SenderCompID");
  std::string encryptedPasswordMethod = application.getSessionSettingString(sessionID, "EncryptedPasswordMethod");

  ASSERT_STREQ ("CO99999901", senderCompID.c_str());
  ASSERT_STREQ ("102", encryptedPasswordMethod.c_str());
}

TEST(ApplicationTest, ToAdminLogon) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr1 = "8=FIXT.1.1;9=84;35=A;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;98=0;108=20;789=1;1137=9;10=195;";
  const std::string msgStr2 = "8=FIXT.1.1;9=84;35=A;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;98=0;108=20;789=1;1137=9;10=195;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  FIX::SessionID sessionID("FIXT.1.1", "CO99999901", "HKEXCO");
  FIX::Message message1 = FIXProxy::Utils::toFIX(msgStr1);
  FIX::Message message2 = FIXProxy::Utils::toFIX(msgStr2);
  // Relogging
  application.toAdmin(message1, sessionID); 

  ASSERT_STREQ ("T0NHIFRlc3QK", message1.getField(1402).c_str());
  ASSERT_STREQ ("T0NHIFRlc3QgTmV3Cg==", message1.getField(1404).c_str());
  ASSERT_STREQ ("101", message1.getField(1400).c_str());

  // Logon
  application.toAdmin(message2, sessionID); 

  ASSERT_STREQ ("T0NHIFRlc3QK", message2.getField(1402).c_str());
  ASSERT_STREQ ("T0NHIFRlc3QgTmV3Cg==", message2.getField(1404).c_str());
  ASSERT_STREQ ("101", message2.getField(1400).c_str());
}

TEST(ApplicationTest, ToAdminLogout) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string logonMsgStr = "8=FIXT.1.1;9=84;35=5;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;98=0;108=20;789=1;1137=9;10=183;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  FIX::Message message = FIXProxy::Utils::toFIX(logonMsgStr);
  application.toAdmin(message, FIX::SessionID("FIXT.1.1", "CO99999901", "HKEXCO"));
}

TEST(ApplicationTest, ProcessLogonMessage1) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string logonMsgStr = "8=FIXT.1.1;9=78;35=A;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;98=0;108=20;1137=9;10=175;";
  //const std::string logonMsgStr = "8=FIXT.1.1;9=443;35=A;34=3;49=CO99999901;52=20151218-07:27:57.572;56=HKEXCO;98=0;108=20;789=2;1137=9;1400=101;1402=letliSPjqDN9PhTTzI16ZTpgbiMUudVW+z4sMLgKzHJ+vT1bha7dNgXSoRLxkxnkmtf3uF10FXU0NRVbSJNX3UceGwL2jHgl741xU+C+1Lc7Az7znW/kKMUOm6z/4gKSa06u72k80y7N/9snqitS8bBsbwWF3VgabL9qoM0kQD4alsJfQ90+zTg4uYB8Rh1d+ryztjUYDNNUaeLb0aU7J9HIG4lB3GdMaFUmA8m+tHWnjgxPri8dIMwoDg8oFSeT/SVN6lfF/dSscqscF05NSUabs/IA4uAGJQ0t4Vrsp3BEu/esllAxXj95FI7gaKlBZ4bceBD8rKZpQOVItRdyQQ==;10=052;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  FIX::Message message = FIXProxy::Utils::toFIX(logonMsgStr);
  application.processLogonMessage(message, FIX::SessionID("FIXT.1.1", "CO99999901", "HKEXCO"));

  std::cout << "Source: " << logonMsgStr << std::endl;
  std::cout << "Result: " << FIXProxy::Utils::toString(message) << std::endl;
  ASSERT_STREQ ("T0NHIFRlc3QK", message.getField(1402).c_str());
  ASSERT_STREQ ("T0NHIFRlc3QgTmV3Cg==", message.getField(1404).c_str());
  ASSERT_STREQ ("101", message.getField(1400).c_str());
}

TEST(ApplicationTest, ProcessLogonMessage2) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string logonMsgStr = "8=FIXT.1.1;9=108;35=A;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;98=0;108=20;1137=9;554=Ee12345678;925=Ff12345678;10=49;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  FIX::Message message = FIXProxy::Utils::toFIX(logonMsgStr);
  FIX::SessionID sessionID("FIXT.1.1", "CO99999901", "HKEXCO");
  FIX::Session* session = FIX::Session::lookupSession(sessionID);
  session->setIsBinary(true);
  application.processLogonMessage(message, sessionID);

  std::cout << "Source: " << logonMsgStr << std::endl;
  std::cout << "Result: " << FIXProxy::Utils::toString(message) << std::endl;

  std::string encriptedPassword = message.getField(1402);
  std::string encriptedNewPassword = message.getField(1404);
  ASSERT_NE(0, encriptedPassword.length());
  ASSERT_NE(0, encriptedNewPassword.length());
}

TEST(ApplicationTest, ProcessMessageLogging1) {
  const std::string testMsgStr1 = "8=FIXT.1.1;9=216;35=CU;34=159;49=HKEXCCCO;52=20150921-03:20:19.085;56=CO99999901;1128=9;893=Y;1511=0;1512=2;1770=40;1771=144280561915566521;1772=1;1671=1;1691=1123;1692=D;1693=1;1773=1;1774=Y;1775=0;1776=2;1310=2;1301=ASHR;1301=ASZR;10=147;";
  const std::string testMsgStr2 = "BeginString=FIXT.1.1;BodyLength=216;MsgType=CV;MsgSeqNum=159;SenderCompID=HKEXCCCO;SendingTime=20150921-03:20:19.085;TargetCompID=CO99999901;ApplVerID=9;LastFragment=Y;RequestResult=0;TotNoPartyList=2;EntitlementsRequestID=40;EntitlementsReportID=144280561915566521;NoEntitlements=1;EntitlementIndicator=Y;EntitlementType=0;EntitlementID=2;NoMarketSegments=2;MarketID=ASHR;MarketID=ASZR;CheckSum=147;";
  const std::string testMsgStr3 = "8=FIXT.1.1;9=216;35=CV;34=159;49=HKEXCCCO;52=20150921-03:20:19.085;56=CO99999901;1128=9;893=Y;1511=0;1512=2;1770=40;1771=144280561915566521;1772=1;1671=1;1691=1123;1692=D;1693=1;1773=1;1774=Y;1775=0;1776=2;1310=2;1301=ASHR;1301=ASZR;";
  const std::string newMessage1
    = FIXProxy::Application::processMessageLogging(testMsgStr1);
  const std::string newMessage2
    = FIXProxy::Application::processMessageLogging(testMsgStr2);
  const std::string newMessage3
    = FIXProxy::Application::processMessageLogging(testMsgStr3);
  std::cout << "New Message: " << newMessage1 << std::endl;
  std::cout << "New Message: " << newMessage2 << std::endl;
  std::cout << "New Message: " << newMessage3 << std::endl;

  size_t found1 = newMessage1.find(";58=");
  size_t found2 = newMessage2.find(";Text=");
  size_t found3 = newMessage3.find(";58=");
  EXPECT_EQ (found1, std::string::npos);
  EXPECT_EQ (found2, std::string::npos);
  EXPECT_EQ (found3, std::string::npos);
}

TEST(ApplicationTest, ProcessMessageLogging2) {
  const std::string testMsgStr1 = "8=FIXT.1.1;9=216;35=CV;34=159;49=HKEXCCCO;52=20150921-03:20:19.085;56=CO99999901;1128=9;893=Y;1511=0;1512=2;1770=40;1771=144280561915566521;1772=1;1671=1;1691=1123;1692=D;1693=1;1773=1;1774=Y;1775=0;1776=2;1310=2;1301=ASHR;1301=ASZR;10=147;";
  const std::string testMsgStr2 = "BeginString=FIXT.1.1;BodyLength=216;MsgType=CV;MsgSeqNum=159;SenderCompID=HKEXCCCO;SendingTime=20150921-03:20:19.085;TargetCompID=CO99999901;ApplVerID=9;LastFragment=Y;RequestResult=0;TotNoPartyList=2;EntitlementsRequestID=40;EntitlementsReportID=144280561915566521;NoPartyEntitlements=1;NoPartyDetails=1;PartyDetailID=1123;PartyDetailIDSource=D;PartyDetailRole=1;NoEntitlements=1;EntitlementIndicator=Y;EntitlementType=0;EntitlementID=2;NoMarketSegments=2;MarketID=ASHR;MarketID=ASZR;CheckSum=147;";
  const std::string newMessage1
    = FIXProxy::Application::processMessageLogging(testMsgStr1);
  const std::string newMessage2
    = FIXProxy::Application::processMessageLogging(testMsgStr2);
  std::cout << "New Message: " << newMessage1 << std::endl;
  std::cout << "New Message: " << newMessage2 << std::endl;

  size_t found1 = newMessage1.find(";58=");
  size_t found2 = newMessage2.find(";Text=");
  EXPECT_NE (found1, std::string::npos);
  EXPECT_NE (found2, std::string::npos);
}

TEST(ApplicationTest, ProcessMessageLogging3) {
  const std::string testMsgStr1 = "8=FIXT.1.1;9=213;35=BF;34=159;49=HKEXCCCO;52=20150921-03:20:19.085;56=CO99999901;1128=9;893=Y;1511=0;1512=2;1770=40;1771=144280561915566521;1610=1;1611=2;1612=0;1614=1;1615=0;1773=1;1774=Y;1775=0;1776=2;1310=2;1301=ASHR;1301=ASZR;10=147;";
  const std::string testMsgStr2 = "BeginString=FIXT.1.1;BodyLength=213;MsgType=BF;MsgSeqNum=159;SenderCompID=HKEXCCCO;SendingTime=20150921-03:20:19.085;TargetCompID=CO99999901;ApplVerID=9;LastFragment=Y;RequestResult=0;TotNoPartyList=2;EntitlementsRequestID=40;EntitlementsReportID=144280561915566521;NoThrottles=1;ThrottleAction=2;ThrottleType=1;ThrottleTimeInterval=1;ThrottleTimeUnit=0;NoEntitlements=1;EntitlementIndicator=Y;EntitlementType=0;EntitlementID=2;NoMarketSegments=2;MarketID=ASHR;MarketID=ASZR;CheckSum=147;";
  const std::string newMessage1
    = FIXProxy::Application::processMessageLogging(testMsgStr1);
  const std::string newMessage2
    = FIXProxy::Application::processMessageLogging(testMsgStr2);
  std::cout << "New Message: " << newMessage1 << std::endl;
  std::cout << "New Message: " << newMessage2 << std::endl;

  size_t found1 = newMessage1.find(";58=");
  size_t found2 = newMessage2.find(";Text=");
  EXPECT_NE (found1, std::string::npos);
  EXPECT_NE (found2, std::string::npos);
}

TEST(ApplicationTest, HandleLogonMessage) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string logonMsgStr = "BeginString=FIXT.1.1;BodyLength=447;MsgType=A;MsgSeqNum=3;SenderCompID=CO99999901;SendingTime=20151218-07:27:57.572;TargetCompID=HKEXCO;PossDupFlag=;EncryptMethod=0;HeartBtInt=20;NextExpectedMsgSeqNum=2;DefaultApplVerID=9;EncryptedPasswordMethod=101;EncryptedPassword=letliSPjqDN9PhTTzI16ZTpgbiMUudVW+z4sMLgKzHJ+vT1bha7dNgXSoRLxkxnkmtf3uF10FXU0NRVbSJNX3UceGwL2jHgl741xU+C+1Lc7Az7znW/kKMUOm6z/4gKSa06u72k80y7N/9snqitS8bBsbwWF3VgabL9qoM0kQD4alsJfQ90+zTg4uYB8Rh1d+ryztjUYDNNUaeLb0aU7J9HIG4lB3GdMaFUmA8m+tHWnjgxPri8dIMwoDg8oFSeT/SVN6lfF/dSscqscF05NSUabs/IA4uAGJQ0t4Vrsp3BEu/esllAxXj95FI7gaKlBZ4bceBD8rKZpQOVItRdyQQ==;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  FIX::Message message;
  application.handleLogonMessage(logonMsgStr, message);

  std::cout << "Source: " << logonMsgStr << std::endl;
  std::cout << "Result: " << FIXProxy::Utils::toString(message) << std::endl;

  //ASSERT_STREQ ("T0NHIFRlc3QK", message.getField(1402).c_str());
  //ASSERT_STREQ ("T0NHIFRlc3QgTmV3Cg==", message.getField(1404).c_str());
  ASSERT_STREQ ("101", message.getField(1400).c_str());
}

TEST(ApplicationTest, HandleLogonMessageFailed) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string logonMsgStr = "BeginString=FIXT.1.1;BodyLength=443;MsgType=A;MsgSeqNum=3;SenderCompID=HKEXCO;SendingTime=20151218-07:27:57.572;TargetCompID=CO99999901;EncryptMethod=0;HeartBtInt=20;NextExpectedMsgSeqNum=2;DefaultApplVerID=9;EncryptedPasswordMethod=101;EncryptedPassword=letliSPjqDN9PhTTzI16ZTpgbiMUudVW+z4sMLgKzHJ+vT1bha7dNgXSoRLxkxnkmtf3uF10FXU0NRVbSJNX3UceGwL2jHgl741xU+C+1Lc7Az7znW/kKMUOm6z/4gKSa06u72k80y7N/9snqitS8bBsbwWF3VgabL9qoM0kQD4alsJfQ90+zTg4uYB8Rh1d+ryztjUYDNNUaeLb0aU7J9HIG4lB3GdMaFUmA8m+tHWnjgxPri8dIMwoDg8oFSeT/SVN6lfF/dSscqscF05NSUabs/IA4uAGJQ0t4Vrsp3BEu/esllAxXj95FI7gaKlBZ4bceBD8rKZpQOVItRdyQQ==;CheckSum=004;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  FIX::Message message;
  application.handleLogonMessage(logonMsgStr, message);
}

TEST(ApplicationTest, HandleSequenceResetMessage) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string messageText = "BeginString=FIXT.1.1;BodyLength=64;MsgType=4;MsgSeqNum=3;SenderCompID=CO99999901;SendingTime=20151218-07:27:57.572;TargetCompID=HKEXCO;NewSeqNo=1;CheckSum=027;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  FIX::Message message;
  application.handleSequenceResetMessage(messageText, message);

  std::cout << "Source: " << messageText << std::endl;
  std::cout << "Result: " << FIXProxy::Utils::toString(message) << std::endl;
  
  //ASSERT_STREQ ("Y", message.getField(43).c_str());
  ASSERT_STREQ ("Y", message.getHeader().getField(43).c_str());
}

TEST(ApplicationTest, HandleSequenceResetMessageFailed) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string messageText = "BeginString=FIXT.1.1;BodyLength=64;MsgType=4;MsgSeqNum=3;SenderCompID=HKEXCO;SendingTime=20151218-07:27:57.572;TargetCompID=CO99999901;NewSeqNo=1;CheckSum=027;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  FIX::Message message;
  application.handleSequenceResetMessage(messageText, message);
}

//TEST(ApplicationTest, GetBinMessage1) {
//  const std::string settingsFile = "hkex/hkex.cfg";
//  const std::string msgLogFile = "message.log";
//  const std::string logonResponseMsgStr = "8=FIXT.1.1;9=108;35=A;34=238;49=HKEXCO;52=20150825-07:37:58.449;56=CO99999901;1128=9;98=0;108=20;464=Y;789=181;1137=9;1409=0;10=128;";
//  FIX::Message message = FIXProxy::Utils::toFIX(logonResponseMsgStr);
//
//  // load session settings from file
//  FIX::SessionSettings settings(settingsFile);
//
//  // create application
//  // FIX::SessionID sessionID("FIXT.1.1", "CO99999901", "HKEXCO");
//  FIX::SessionID sessionID("FIXT.1.1", "HKEXCO", "CO99999901");
//  FIXProxy::Application application(msgLogFile, settings);
//  //application.fromAdmin(message, sessionID);
//  FIX::FileStoreFactory storeFactory(settings);
//  FIX::ScreenLogFactory logFactory(settings);
//  FIX::SocketInitiator initiator(application,
//                                 storeFactory,
//                                 settings,
//                                 logFactory);
//
//  std::string binary;
//  std::string binMsg;
//  application.getBinMessage(message, sessionID, true, binary, binMsg);
//  std::cout << "Binary Message: " << binMsg << std::endl;
//  std::cout << "Binary: " << binary << std::endl;
//  std::string expectedPrefix = "";
//  ASSERT_STREQ (binMsg.data(), expectedPrefix.data());
//  ASSERT_STREQ (binary.data(), expectedPrefix.data());
//}
//
//TEST(ApplicationTest, GetBinMessage2) {
//  const std::string settingsFile = "hkex/hkex.cfg";
//  const std::string msgLogFile = "message.log";
//  const std::string logonResponseMsgStr = "8=FIXT.1.1;9=108;35=A;34=238;49=HKEXCO;52=20150825-07:37:58.449;56=CO99999901;1128=9;98=0;108=20;464=Y;789=181;1137=9;1409=0;10=128;";
//  FIX::Message message = FIXProxy::Utils::toFIX(logonResponseMsgStr);
//
//  // load session settings from file
//  FIX::SessionSettings settings(settingsFile);
//
//  // create application
//  FIX::SessionID sessionID("FIXT.1.1", "CO99999901", "HKEXCO");
//  //FIX::SessionID sessionID("FIXT.1.1", "HKEXCO", "CO99999901");
//  FIXProxy::Application application(msgLogFile, settings);
//  //application.fromAdmin(message, sessionID);
//  FIX::FileStoreFactory storeFactory(settings);
//  FIX::ScreenLogFactory logFactory(settings);
//  FIX::SocketInitiator initiator(application,
//                                 storeFactory,
//                                 settings,
//                                 logFactory);
//  FIX::Session* session = FIX::Session::lookupSession(sessionID);
//  session->setIsBinary(true);
//  std::string binary;
//  std::string binMsg;
//  application.getBinMessage(message, sessionID, true, binary, binMsg);
//  std::cout << "Binary Message: " << binMsg << std::endl;
//  std::cout << "Binary: " << binary << std::endl;
//  std::string expectedPrefix = "Start of Message=02;";
//  ASSERT_STREQ (binMsg.substr(0, expectedPrefix.size()).c_str(), expectedPrefix.data());
//  expectedPrefix = "02";
//  ASSERT_STREQ (binary.substr(0, expectedPrefix.size()).c_str(), expectedPrefix.data());
//}
//
//TEST(ApplicationTest, GetBinMessage3) {
//  const std::string settingsFile = "hkex/hkex.cfg";
//  const std::string msgLogFile = "message.log";
//  const std::string logonResponseMsgStr = "8=FIXT.1.1;9=108;35=A;34=238;49=HKEXCO;52=20150825-07:37:58.449;56=CO99999901;1128=9;98=0;108=20;464=Y;789=181;1137=9;1409=0;10=128;";
//  FIX::Message message = FIXProxy::Utils::toFIX(logonResponseMsgStr);
//
//  // load session settings from file
//  FIX::SessionSettings settings(settingsFile);
//
//  // create application
//  FIX::SessionID sessionID("FIXT.1.1", "CO99999901", "HKEXCO");
//  //FIX::SessionID sessionID("FIXT.1.1", "HKEXCO", "CO99999901");
//  FIXProxy::Application application(msgLogFile, settings);
//  //application.fromAdmin(message, sessionID);
//  FIX::FileStoreFactory storeFactory(settings);
//  FIX::ScreenLogFactory logFactory(settings);
//  FIX::SocketInitiator initiator(application,
//                                 storeFactory,
//                                 settings,
//                                 logFactory);
//  FIX::Session* session = FIX::Session::lookupSession(sessionID);
//  session->setIsBinary(true);
//  session->setExchangeType("OCG");
//  std::string binary;
//  std::string binMsg;
//  application.getBinMessage(message, sessionID, true, binary, binMsg);
//  std::cout << "Binary Message: " << binMsg << std::endl;
//  std::cout << "Binary: " << binary << std::endl;
//  std::string expectedPrefix = "Start of Message=02;";
//  ASSERT_STREQ (binMsg.substr(0, expectedPrefix.size()).c_str(), expectedPrefix.data());
//  expectedPrefix = "02";
//  ASSERT_STREQ (binary.substr(0, expectedPrefix.size()).c_str(), expectedPrefix.data());
//}
//
//TEST(ApplicationTest, GetBinMessage4) {
//  const std::string settingsFile = "hkex/hkex.cfg";
//  const std::string msgLogFile = "message.log";
//  const std::string logonResponseMsgStr = "8=FIXT.1.1;9=108;35=A;34=238;49=HKEXCO;52=20150825-07:37:58.449;56=CO99999901;1128=9;98=0;108=20;464=Y;789=181;1137=9;1409=0;10=128;";
//  FIX::Message message = FIXProxy::Utils::toFIX(logonResponseMsgStr);
//
//  // load session settings from file
//  FIX::SessionSettings settings(settingsFile);
//
//  // create application
//  FIX::SessionID sessionID("FIXT.1.1", "CO99999901", "HKEXCO");
//  //FIX::SessionID sessionID("FIXT.1.1", "HKEXCO", "CO99999901");
//  FIXProxy::Application application(msgLogFile, settings);
//  //application.fromAdmin(message, sessionID);
//  FIX::FileStoreFactory storeFactory(settings);
//  FIX::ScreenLogFactory logFactory(settings);
//  FIX::SocketInitiator initiator(application,
//                                 storeFactory,
//                                 settings,
//                                 logFactory);
//  FIX::Session* session = FIX::Session::lookupSession(sessionID);
//  session->setIsBinary(true);
//  std::string binary;
//  std::string binMsg;
//  application.getBinMessage(message, sessionID, false, binary, binMsg);
//  std::cout << "Binary Message: " << binMsg << std::endl;
//  std::cout << "Binary: " << binary << std::endl;
//  std::string expectedPrefix = "";
//  ASSERT_STREQ (binMsg.data(), expectedPrefix.data());
//  ASSERT_STREQ (binary.data(), expectedPrefix.data());
//}

TEST(ApplicationTest, HandleFromAdminLogonResponse1) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string logonResponseMsgStr = "8=FIXT.1.1;9=108;35=A;34=238;49=CO99999901;52=20150825-07:37:58.449;56=HKEXCO;1128=9;98=0;108=20;464=Y;789=181;1137=9;1409=0;10=128;";
  FIX::Message message = FIXProxy::Utils::toFIX(logonResponseMsgStr);

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  FIX::SessionID sessionID("FIXT.1.1", "CO99999901", "HKEXCO");
  //application.handleFromAdmin(message, sessionID);
  application.fromAdmin(message, sessionID);

  FIX::Session* session = FIX::Session::lookupSession(sessionID);
  if (session)
  {
    std::cout << session->getExpectedTargetNum() << std::endl;
  }
}

TEST(ApplicationTest, HandleFromAdminLogonResponse2) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string logonResponseMsgStr = "8=FIXT.1.1;9=164;35=5;34=238;49=CO99999901;52=20150825-07:37:58.449;56=HKEXCO;58=Sequence number is less than expected : Expected=238;1128=9;98=0;108=20;464=Y;789=181;1137=9;1409=0;10=153;";
  FIX::Message message = FIXProxy::Utils::toFIX(logonResponseMsgStr);

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  FIX::SessionID sessionID("FIXT.1.1", "CO99999901", "HKEXCO");
  //application.handleFromAdmin(message, sessionID);
  application.fromAdmin(message, sessionID);

  FIX::Session* session = FIX::Session::lookupSession(sessionID);
  if (session)
  {
    std::cout << session->getExpectedTargetNum() << std::endl;
  }
}

TEST(ApplicationTest, HandleFromAdminLogonResponse3) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string logonResponseMsgStr = "8=FIXT.1.1;9=161;35=5;34=238;49=CO99999901;52=20150825-07:37:58.449;56=HKEXCO;58=MsgSeqNum too low, expecting 238 but received 237;1128=9;98=0;108=20;464=Y;789=181;1137=9;1409=0;10=224;";
  FIX::Message message = FIXProxy::Utils::toFIX(logonResponseMsgStr);

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  FIX::SessionID sessionID("FIXT.1.1", "CO99999901", "HKEXCO");
  FIX::Session* session = FIX::Session::lookupSession(sessionID);
  if (nullptr != session)
  {
    session->setIsBinary(true);
  }
  //application.handleFromAdmin(message, sessionID);
  application.fromAdmin(message, sessionID);

  if (nullptr != session)
  {
    std::cout << session->getExpectedTargetNum() << std::endl;
  }
}

TEST(ApplicationTest, InitCurrentSessionSettings) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  FIX::SessionID sessionID("FIXT.1.1", "CO99999901", "HKEXCO");
  FIX::Dictionary& dictCurrent = application.getCurrentSessionSetting(sessionID);
  const FIX::Dictionary& dictDefault = settings.get(sessionID);

  std::string currentHT = dictCurrent.getString("HeartBtInt");
  std::string defaultHT = dictDefault.getString("HeartBtInt");

  ASSERT_STREQ(currentHT.c_str(), defaultHT.c_str());
}

TEST(ApplicationTest, GetCurrentSessionSetting) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  FIX::SessionID sessionID("FIXT.1.1", "CO99999901", "HKEXCO");
  FIX::Dictionary& dict = application.getCurrentSessionSetting(sessionID);

  ASSERT_STREQ("20", dict.getString("HeartBtInt").c_str());
  ASSERT_STREQ("9", dict.getString("DefaultApplVerID").c_str());
}

TEST(ApplicationTest, GetFieldFromSessionSettings) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  FIX::SessionID sessionID("FIXT.1.1", "CO99999901", "HKEXCO");
  const FIX::Dictionary& dictDefault = settings.get(sessionID);
  
  application.setSessionSettingString(sessionID, "HeartBtInt", "30");

  FIX::Dictionary& dictCurrent = application.getCurrentSessionSetting(sessionID);

  ASSERT_STREQ("20", dictDefault.getString("HeartBtInt").c_str());
  ASSERT_STREQ("30", dictCurrent.getString("HeartBtInt").c_str());

  std::string value = FIXProxy::Application::getFieldFromSessionSettings(dictCurrent, dictDefault, "HeartBtInt");
  ASSERT_STREQ("30", value.c_str());

  std::string emptyString;
  application.setSessionSettingString(sessionID, "HeartBtInt", emptyString);

  value = FIXProxy::Application::getFieldFromSessionSettings(dictCurrent, dictDefault, "HeartBtInt");
  ASSERT_STREQ("20", value.c_str());
}

TEST(ApplicationTest, GetSessionStatus) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string logonMsgStr = "BeginString=FIXT.1.1;BodyLength=443;MsgType=A;MsgSeqNum=3;SenderCompID=CO99999901;SendingTime=20151218-07:27:57.572;TargetCompID=HKEXCO;EncryptMethod=0;HeartBtInt=20;NextExpectedMsgSeqNum=2;DefaultApplVerID=9;EncryptedPasswordMethod=101;EncryptedPassword=letliSPjqDN9PhTTzI16ZTpgbiMUudVW+z4sMLgKzHJ+vT1bha7dNgXSoRLxkxnkmtf3uF10FXU0NRVbSJNX3UceGwL2jHgl741xU+C+1Lc7Az7znW/kKMUOm6z/4gKSa06u72k80y7N/9snqitS8bBsbwWF3VgabL9qoM0kQD4alsJfQ90+zTg4uYB8Rh1d+ryztjUYDNNUaeLb0aU7J9HIG4lB3GdMaFUmA8m+tHWnjgxPri8dIMwoDg8oFSeT/SVN6lfF/dSscqscF05NSUabs/IA4uAGJQ0t4Vrsp3BEu/esllAxXj95FI7gaKlBZ4bceBD8rKZpQOVItRdyQQ==;CheckSum=004;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  //FIX::Message message;
  //application.handleLogonMessage(logonMsgStr, message);

  std::string statusStr = application.getSessionStatus(logonMsgStr);
  ASSERT_STREQ ("Unknown", statusStr.c_str());

  FIX::SessionID sessionID("FIXT.1.1", "HKEXCO", "CO99999901");

  application.onLogon(sessionID);
  statusStr = application.getSessionStatus(sessionID);
  ASSERT_STREQ ("Unknown", statusStr.c_str());

  
  application.onLogout(sessionID);
  statusStr = application.getSessionStatus(sessionID);
  ASSERT_STREQ ("Unknown", statusStr.c_str());
}

TEST(ApplicationTest, LookupMalformedMessage) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile   = "message.log";
  const std::string messageText  = "BeginString=FIX.4.2;SenderCompID=EXECUTOR;TargetCompID=CLIENT2;_StartTime=2016-04-27 12:10:54.304270;_EndTime=2016-04-27 12:10:56.620651;";
  const std::string targetMsg  = "BeginString=FIX.4.2;BodyLength=108;MsgType=3;MsgSeqNum=18;SenderCompID=EXECUTOR;SendingTime=20160427-04:10:54.342;TargetCompID=CLIENT2;RefSeqNum=25;Text=Required tag missing;RefTagID=21;RefMsgType=D;SessionRejectReason=1;CheckSum=113;  RejectReason=Tag not defined for this message type:373;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  //FIX::Message message;
  //application.handleLogonMessage(logonMsgStr, message);

  std::vector<FIXProxy::MessageLog::Message> msgVector =
    application.lookupMalformedMessage(messageText, false);

  std::string malformedMsg;
  if (msgVector.size() > 0)
  {
      malformedMsg = msgVector[0].tags;
  }
  
  ASSERT_NE(0, msgVector.size());
  ASSERT_STREQ(targetMsg.c_str(), malformedMsg.c_str());
}

TEST(ApplicationTest, GetFIXFields) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string messageText = "8=FIXT.1.1;9=108;35=A;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;98=0;108=20;1137=9;1867=12345;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  std::string messageTextNew = application.getFIXFields(messageText);

  std::cout << "Source: " << messageText << std::endl;
  std::cout << "Result: " << messageTextNew << std::endl;

  std::string expectMsg = "8=BeginString;9=BodyLength;35=MsgType;34=MsgSeqNum;49=SenderCompID;52=SendingTime;56=TargetCompID;98=EncryptMethod;108=HeartBtInt;1137=DefaultApplVerID;1867=1867;";
  ASSERT_STREQ(expectMsg.c_str(), messageTextNew.c_str());
}

//TEST(ApplicationTest, GetBinaryFields) {
//  const std::string settingsFile = "hkex/hkex.cfg";
//  const std::string msgLogFile = "message.log";
//  const std::string messageText = "35=A;34=5;49=CO99999901;1867=12345;";
//
//  // load session settings from file
//  FIX::SessionSettings settings(settingsFile);
//
//  // create application
//  FIXProxy::Application application(msgLogFile, settings);
//  FIX::FileStoreFactory storeFactory(settings);
//  FIX::ScreenLogFactory logFactory(settings);
//  FIX::SocketInitiator initiator(application,
//                                 storeFactory,
//                                 settings,
//                                 logFactory);
//
//  std::string messageTextNew = application.getBinaryFields(messageText);
//
//  std::cout << "Source: " << messageText << std::endl;
//  std::cout << "Result: " << messageTextNew << std::endl;
//
//  std::string expectMsg = "35=Message Type;34=Sequence Number;49=Comp ID;1867=Quote Offer ID;";
//  ASSERT_STREQ(expectMsg.c_str(), messageTextNew.c_str());
//}
//
TEST(ApplicationTest, GetConnectionInfo) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string messageText = "8=FIXT.1.1;9=108;35=A;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;98=0;108=20;1137=9;1867=12345;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  std::string connectionInfo = application.getConnectionInfo(messageText);

  std::cout << "Source: " << messageText << std::endl;
  std::cout << "Result: " << connectionInfo << std::endl;
}

TEST(ApplicationTest, PrintMessageLog) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string messageText = "info=Test<space>Started:<space>Case=Logon001<sc>Title=Logon;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  application.printMessageLog(messageText);
}

TEST(ApplicationTest, SendFIX44NewOrderSingle) {
  const std::string settingsFile = "lme/lme.cfg";
  const std::string msgLogFile   = "message.log";
  const std::string msgStr       = "NoPartyIDs=PartyID:5001,PartyRole:1;BeginString=FIX.4.4;"
                                   "MsgType=D;SenderCompID=CLIENT2;SendingTime=20150323-03:19:54.567;"
                                   "TargetCompID=EXECUTOR;HandlInst=1;OrderQty=8000;OrdType=2;"
				   "Price=150.70;ClOrdID=88496263;Side=1;"
                                   "NoOfInstrumentLegs=PromptType:R,MaturityRollingPrompt:C;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  application.sendFIXMessage(msgStr);
}
