/****************************************************************************
 *   Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : test_converter.cpp
 *   Project  : Wabi II
 *   Description: Test cases for encoder
 *
 *   Created  : 2015/04/13
 *   Author   : Yang Du
 ****************************************************************************/

#include <string>
#include <boost/regex.hpp>
#include <gtest/gtest.h>
#include "quickfix/DataDictionary.h"
#include "test_utils.hpp"


TEST(UtilsTest, ToFIXWithNoException) {
  const std::string messageText = "8=FIXT.1.1;9=84;35=A;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;98=0;108=20;789=1;1137=9;10=195;";
  FIX::Message message = FIXProxy::Utils::toFIX(messageText);
  std::cout << "FIX Message: " << message.toString() << std::endl;
}

TEST(UtilsTest, ToFIXWithNoExceptionWithSC) {
  const std::string messageText = "8=FIXT.1.1;9=84;35=A;34=5;49=CO99999901;52=20150709-06<sc>25<sc>14.863;56=HKEXCO;98=0;108=20;789=<space>;1137=9;10=180;";
  FIX::Message message = FIXProxy::Utils::toFIX(messageText);
  std::cout << "FIX Message: " << message.toString() << std::endl;
}

TEST(UtilsTest, ToFIXWithException) {
  const std::string messageText = "8=FIXT.1.1;9=84;35=A;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;98=0;108=20;789=1;1137=9;10=194;";
  FIX::Message message = FIXProxy::Utils::toFIX(messageText);
  std::cout << "FIX Message: " << message.toString() << std::endl;
}

TEST(UtilsTest, ToString) {
  const std::string messageText = "8=FIXT.1.1;9=84;35=A;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;98=0;108=20;789=1;1137=9;10=195;";
  FIX::Message message = FIXProxy::Utils::toFIX(messageText);
  std::cout << "FIX Message: " << message.toString() << std::endl;

  std::string msgStr = FIXProxy::Utils::toString(message);
  std::cout << "Format to string: " << msgStr << std::endl;
}

TEST(UtilsTest, ToTextString) {
  const std::string messageText = "8=FIX.4.4;35=D;34=2;49=CLIENT2;52=20150409-08:55:06.409;56=EXECUTOR;60=20150409-08:55:06;1=Q00100002;11=jp5_qXm2TO0KUL-t3mDyDQ;38=8000;44=150.10;54=1;55=0001.hk;";
  const std::string messageText2 = "=FIX.4.4;=D;=;49=CLIENT2;52=20150409-08:55:06.409;56=EXECUTOR;60=;1=;11=jp5_qXm2TO0KUL-t3mDyDQ;38=8000;44=150.10;54=1;55=0001.hk;";
  const std::string dataDictionaryFile = "hkex/FIX50SP2.xml";
  const std::string appDataDictionaryFile = "hkex/FIXT11.xml";
  const FIX::DataDictionary dataDictionary(dataDictionaryFile);
  const FIX::DataDictionary appDataDictionary(dataDictionaryFile);

  const std::string messageTextNew = FIXProxy::Utils::toTextString(FIXProxy::Converter::toFIXMessage<FIX44::NewOrderSingle>(messageText), dataDictionary, appDataDictionary);
  FIXProxy::Utils::toTextString(FIXProxy::Converter::toFIXMessage<FIX44::NewOrderSingle>(messageText2), dataDictionary, appDataDictionary);
  std::size_t found = messageTextNew.find("BeginString=FIX.4.4");
  EXPECT_NE (found, std::string::npos);
  found = messageTextNew.find("TargetCompID=EXECUTOR");
  EXPECT_NE (found, std::string::npos);
  found = messageTextNew.find("ClOrdID=jp5_qXm2TO0KUL-t3mDyDQ");
  EXPECT_NE (found, std::string::npos);
}

TEST(UtilsTest, GetTimeString) {
  const std::string datetime1 = FIXProxy::Utils::getTimeString(boost::posix_time::microsec_clock::local_time());
  const std::string datetime2 = FIXProxy::Utils::getTimeString(boost::posix_time::microsec_clock::local_time());
  const std::string datetime3 = FIXProxy::Utils::getTimeString(boost::posix_time::microsec_clock::local_time());
  ASSERT_STRNE(datetime1.c_str(), datetime2.c_str());
  ASSERT_STRNE(datetime2.c_str(), datetime3.c_str());
}

TEST(UtilsTest, StrToField) {
  const std::string clOrdIDStr = "11";
  const std::string invalid = "invalid";

  EXPECT_EQ (11, FIXProxy::Utils::strToField(clOrdIDStr));
  EXPECT_EQ (0, FIXProxy::Utils::strToField(invalid));
}

TEST(UtilsTest, GetOrderID) {
  auto orderID1 = FIXProxy::Utils::getOrderID();
  auto orderID2 = FIXProxy::Utils::getOrderID();
  std::cout << "OrderID1: " << orderID1 << " | "
            << "OrderID2: " << orderID2 << std::endl;

  EXPECT_NE(0, orderID2 - orderID1);
}

TEST(UtilsTest, RSAEncrypt) {
  const std::string toEncryptStr("abcdef123");
  std::string encryptStr = FIXProxy::Utils::rsaEncrypt(toEncryptStr);
  std::cout << "Befor Encrypted: " << toEncryptStr << std::endl;
  std::cout << "After Encrypted: " << encryptStr << std::endl;

  EXPECT_STRNE(toEncryptStr.c_str(), encryptStr.c_str());
  EXPECT_EQ(344, encryptStr.length());
}

TEST(UtilsTest, GetUTCTimeStamp) {
  std::string timeStamp = FIXProxy::Utils::getUTCTimeStamp();
  std::cout << timeStamp << std::endl;

  EXPECT_STRNE("", timeStamp.c_str());
}

TEST(UtilsTest, HandlingSpecialCharacters) {
  const std::string messageText = "8=FIXT.1.1;9=84;35=A;34=5;49=CO99999901;52=20150709-06<sc>25<sc>14.863;56=HKEXCO;98=0;108=20;789=<space>;1137=9;10=180;";
  std::string messageTextNew = FIXProxy::Utils::showSpecChars(messageText);
  std::cout << "Show Special Characters: " << messageTextNew << std::endl;

  messageTextNew = FIXProxy::Utils::hideSpecChars(messageText);
  std::cout << "Hide Special Characters: " << messageTextNew << std::endl;

  messageTextNew = FIXProxy::Utils::showSpecChars(messageText, " ");
  std::cout << "Only show space: " << messageTextNew << std::endl;

  messageTextNew = FIXProxy::Utils::showSpecChars(messageText);
  messageTextNew = FIXProxy::Utils::hideSpecChars(messageText, ";");
  std::cout << "Hide Special Characters: " << messageTextNew << std::endl;
}

TEST(UtilsTest, IsEraseFile) {
  const std::string filePasted = "test_sample_file1.txt";
  const std::string filePresent = "test_sample_file2.txt";

  std::string cmd = "";
  cmd = "touch " + filePresent;
  system(cmd.c_str());
  cmd = "touch -d 20160222 " + filePasted;
  system(cmd.c_str());

  bool result1 = FIXProxy::Utils::isEraseFile(filePasted);
  bool result2 = FIXProxy::Utils::isEraseFile(filePresent);

  EXPECT_TRUE(result1);
  EXPECT_FALSE(result2);
}

TEST(UtilsTest, Processtag2field) {
  const std::string dataDictionaryFile = "hkex/FIX50SP2.xml";
  const std::string appDataDictionaryFile = "hkex/FIXT11.xml";
  const FIX::DataDictionary dataDictionary(dataDictionaryFile);
  const FIX::DataDictionary appDataDictionary(dataDictionaryFile);

  int32_t tag;
  std::string field;
  bool result = FIXProxy::Utils::tag2field(dataDictionary, appDataDictionary, "371", tag, field);

  EXPECT_TRUE(result);
  EXPECT_EQ(371, tag);
  EXPECT_STREQ("RefTagID", field.c_str());

  result = FIXProxy::Utils::tag2field(dataDictionary, appDataDictionary, "RefSeqNum", tag, field);

  EXPECT_TRUE(result);
  EXPECT_EQ(45, tag);
  EXPECT_STREQ("RefSeqNum", field.c_str());

  result = FIXProxy::Utils::tag2field(dataDictionary, appDataDictionary, "2000", tag, field);

  EXPECT_FALSE(result);
}

TEST(UtilsTest, GetSessionID) {
  FIX::SessionID sessionID = FIXProxy::Utils::getSessionID("FIXT.1.1", "CO99999901", "HKEXCO");

  ASSERT_STREQ("FIXT.1.1", sessionID.getBeginString().getString().c_str());
  ASSERT_STREQ("CO99999901", sessionID.getSenderCompID().getString().c_str());
  ASSERT_STREQ("HKEXCO", sessionID.getTargetCompID().getString().c_str());
}

//TEST(UtilsTest, ToString_WithGroupString) {
//  const std::string dataDictionaryFile = "hkex/FIX50SP2.xml";
//  const std::string appDataDictionaryFile = "hkex/FIXT11.xml";
//  const FIX::DataDictionary dataDictionary(dataDictionaryFile);
//  const FIX::DataDictionary appDataDictionary(dataDictionaryFile);
//
//  const std::string messageText = "8=FIXT.1.1;9=84;35=D;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;98=0;108=20;789=1;1137=9;1812=1813:100,1814:1;1812=1813:101,1814:1;";
//  FIX::Message message =
//    FIXProxy::Converter::toFIXMessage<FIX50SP2::HKExNewOrderSingle>(messageText);
//  std::cout << "FIX Message(NoDisclosureInstructions): " << message.toString() << std::endl;
//
//  std::string msgStr = FIXProxy::Utils::toString(message,
//                                                 dataDictionary,
//                                                 appDataDictionary);
//  std::cout << "FIX Message with group(NoDisclosureInstructions): " << msgStr << std::endl;
//
//  EXPECT_NE(std::string::npos, msgStr.find("NoDisclosureInstructions[2]=[DisclosureType:101,DisclosureInstruction:1]"));
//
//  const std::string messageQuoteText = "8=FIXT.1.1;9=262;35=S;34=235;49=CO51900001;52=20160826-02:38:41.824;56=HKEXCO;1128=9;22=8;48=8102;58=Quote;60=20160826-02:38:41.824;77=C;132=0.415;133=0.42;134=5000;135=10000;207=XHKG;390=23948181;453=448:5482,447:D,452:1;537=1;1867=23948182;1868=1869:1,1870:0;1868=1869:2,1870:0;";
//  FIX::Message messageQuote =
//    FIXProxy::Converter::toFIXMessage<FIX50SP2::HKExQuote>(messageQuoteText);
//  std::cout << "FIX Message(NoValueChecks): " << messageQuote.toString() << std::endl;
//
//  std::string msgStrQuote = FIXProxy::Utils::toString(messageQuote,
//                                                 dataDictionary,
//                                                 appDataDictionary);
//  std::cout << "FIX Message with group(NoValueChecks): " << msgStrQuote << std::endl;
//
//  EXPECT_NE(std::string::npos, msgStrQuote.find("NoPartyIDs[1]=[PartyID:5482,PartyIDSource:D,PartyRole:1];"));
//
//  const std::string messageQuoteCText = "8=FIXT.1.1;9=143;35=Z;34=184;49=CO51900001;52=20160826-02:28:01.471;56=HKEXCO;1128=9;295=48:8102,22:8,207:XHKG;298=1;453=448:5482,447:D,452:1;1166=23947813;";
//  FIX::Message messageQuoteC =
//    FIXProxy::Converter::toFIXMessage<FIX50SP2::QuoteCancel>(messageQuoteCText);
//  std::cout << "FIX Message(NoQuoteEntries): " << messageQuoteC.toString() << std::endl;
//
//  std::string msgStrQuoteC = FIXProxy::Utils::toString(messageQuoteC,
//                                                 dataDictionary,
//                                                 appDataDictionary);
//  std::cout << "FIX Message with group(NoQuoteEntries): " << msgStrQuoteC << std::endl;
//  
//  EXPECT_NE(std::string::npos, msgStrQuoteC.find("NoQuoteEntries[1]=[SecurityID:8102,SecurityIDSource:8,SecurityExchange:XHKG];"));
//
//  const std::string messageTextTCR = "8=FIXT.1.1;9=296;35=AE;34=352;49=HKEXCC;52=20160826-02:38:05.646;56=CC51100001;1128=9;22=8;31=8.9;32=2000;48=8101;60=20160826-02:38:05.000;150=F;207=XHKG;487=2;552=[54:2,453[1]:[448:5401,447:D,452:1],576:[577:0],18:c,58:123];552=[54:1,453[1]:[448:5411,447:D,452:17],77:C,58:ABC];571=23948137;797=Y;828=4;856=0;939=0;1003=8101000000011;1123=0;5681=R;";
//  FIX::Message messageTCR = 
//    FIXProxy::Converter::toFIXMessage<FIX50SP2::TradeCaptureReport>(messageTextTCR);
//  std::cout << "FIX Message(NoSides): " << messageTCR.toString() << std::endl;
//
//  std::string msgStrTCR = FIXProxy::Utils::toString(messageTCR,
//                                                    dataDictionary,
//                                                    appDataDictionary);
//  std::cout << "FIX Message with group(NoSides): " << msgStrTCR << std::endl;
//
//  EXPECT_NE(std::string::npos, msgStrTCR.find("NoSides[1]=[Side:2,NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1],NoClearingInstructions:[ClearingInstruction:0],Text:123,ExecInst:c];"));
//}

TEST(UtilsTest, FindNoPartyIDsFromMsg) {
  const std::string messageText = "8=FIXT.1.1;9=313;35=AE;34=1425;49=HKEXCO;52=20160923-07:49:20.098;56=CO51100001;1128=9;22=8;31=10;32=501;48=8104;60=20160923-07:49:20.000;150=F;207=XHKG;487=2;552=2;54=2;453=2;448=5402;447=D;452=75;448=5401;447=D;452=1;576=1;577=0;54=1;453=1;448=5411;447=D;452=17;571=21451743;828=102;856=0;939=0;1003=8104000000078;1123=0;5681=O;10=022;NoPartyIDs[1]=[PartyID:5402,PartyIDSource:D,PartyRole:75];NoPartyIDs[2]=[PartyID:5402,PartyIDSource:D,PartyRole:1];NoSides[1]=[Side:2,NoPartyIDs:[PartyID:5402,PartyIDSource:D,PartyRole:75],NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1],NoClearingInstructions:[ClearingInstruction:0]];NoSides[2]=[Side:1,NoPartyIDs:[PartyID:5411,PartyIDSource:D,PartyRole:17]];OwningBrokerID=5401;SubmittingBrokerID=5401;BrokerLocationID=5402;CounterpartyBrokerID=5411;";

  std::vector<std::string> res =
    FIXProxy::Utils::findNoPartyIDsFromMsg(messageText);
  for (const auto& item : res)
  {
      std::cout << item << std::endl;
  }
  ASSERT_EQ(5, res.size());
  ASSERT_STREQ("NoPartyIDs[2]+NoPartyIDs[2]=[PartyID:5402,PartyIDSource:D,PartyRole:1]", res[1].c_str());
  ASSERT_STREQ("NoSides[1]+NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1]", res[3].c_str());
}

TEST(UtilsTest, SplitToPairVector1) {
  std::string expectText  = "Side:1,NoPartyIDs:[PartyID:5411,PartyIDSource:D],PositionEffect:C,Text:ABC";
  std::vector<std::string> result;

  
  std::cout << "expectaton: " << expectText << std::endl;
  result = FIXProxy::Utils::splitToPairVector(expectText, ",");
  for (const auto& item : result)
  {
      std::cout << item << std::endl;
  }
}

TEST(UtilsTest, SplitToPairVector2) {
  std::string expectText  = "BeginString=FIXT.1.1;MsgType=AE;SenderCompID=HKEXCC;TargetCompID=CC51100001;NoSides=[Side:1,NoPartyIDs:[PartyID:5411,PartyIDSource:D],PositionEffect:C,Text:ABC];";
  std::vector<std::string> result;

  
  std::cout << "expectaton: " << expectText << std::endl;
  result = FIXProxy::Utils::splitToPairVector(expectText, ";");
  for (const auto& item : result)
  {
      std::cout << item << std::endl;
  }
}

