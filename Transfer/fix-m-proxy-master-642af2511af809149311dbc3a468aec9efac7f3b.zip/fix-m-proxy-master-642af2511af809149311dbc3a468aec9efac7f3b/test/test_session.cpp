/****************************************************************************
 *   Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : test_session.cpp
 *   Project  : Wabi III
 *   Description: Test cases for session class
 *
 *   Created  : 2015/06/09
 *   Author   : Yang Du
 ****************************************************************************/

#include <string>
#include <gtest/gtest.h>
#include "quickfix/SessionSettings.h"
#include "quickfix/FileStore.h"
#include "quickfix/SocketInitiator.h"
#include "test_session.hpp"

TEST(SessionTest, Go) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "/tmp/message.log";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  session->go();
}

/*
TEST(SessionTest, WriteResponse) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string pattern = "35=8;11=9_5LGTqiyaDB_PVIg3HkUw";
  const std::string time = "2015-05-22 19:29:16.091050";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  const std::string jsonMessage = 
    session->handleRetrieveResponse(pattern, time);
  std::cout << "Json Message: " << jsonMessage << '\n';

  boost::asio::yield_context yield;
  session->writeResponse(yield, jsonMessage);

}
*/

TEST(SessionTest, HandleSendMessage) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStr = "8=FIXT.1.1;9=162;35=D;34=5;49=CO99999901;52=20150522-11:28:11.718;56=HKEXCO;60=20150522-11:28:11;1=123456789A;11=ZbC-ibVeQ8eZRFWIMWKhBA;21=3;38=8000;40=2;44=150.70;54=2;55=0001.hk;10=228;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  session->handleSendMessage(msgStr);
  std::cout << "Message: " << msgStr << std::endl;
}

TEST(SessionTest, HandleSendMessageWithSC) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string msgStrWithComma = "8=FIXT.1.1;9=162;35=D;34=5;49=CO99999901;52=20150522-11:28:11.718;56=HKEXCO;60=20150522-11<sc>28<sc>11;1=123456789A;11=ZbC-ibVeQ8eZRFWIMWKhBA;21=3;38=8000;40=2;44=150.70;54=2;55=0001.hk;10=228;";
  const std::string msgStrWithSpace = "8=FIXT.1.1;9=162;35=D;34=5;49=CO99999901;52=20150522-11:28:11.718;56=HKEXCO;60=20150522-11:28:11;1=123456789A;11=ZbC-ibVeQ8eZRFWIMWKhBA;21=3;38=8000;40=2;44=<space>;54=2;55=0001.hk;10=228;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  session->handleSendMessage(msgStrWithComma);
  std::cout << "Message: " << msgStrWithComma << std::endl;
  session->handleSendMessage(msgStrWithSpace);
  std::cout << "Message: " << msgStrWithSpace << std::endl;
}

TEST(SessionTest, HandleSendMessage2) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  // remove tab 60 if value is empty
  const std::string msgStr = "8=FIXT.1.1;9=166;35=D;34=5;43=;49=CO99999901;52=20150522-11:28:11.718;56=HKEXCO;60= ;1=123456789A;11=ZbC-ibVeQ8eZRFWIMWKhBF;21=3;38=8000;40=2;44=150.70;54=2;55=0001.hk;10=228;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);
  FIX::FileStoreFactory storeFactory(settings);
  FIX::ScreenLogFactory logFactory(settings);
  FIX::SocketInitiator initiator(application,
                                 storeFactory,
                                 settings,
                                 logFactory);
  //FIX::Session* session = FIX::Session::lookupSession(FIX::SessionID("FIXT.1.1", "CO99999901", "HKEXCO"));

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  session->handleSendMessage(msgStr);
}

TEST(SessionTest, HandleRetrieveRequest) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string pattern = "35=D;11=9_5LGTqiyaDB_PVIg3HkUw";
  const std::string time = "2015-05-22 19:29:16.091050";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  const std::string jsonMessage = 
    session->handleRetrieveRequest(pattern, time, false);
  std::cout << "Message: " << jsonMessage << '\n';

  std::size_t found = jsonMessage.find("\"11\": \"9_5LGTqiyaDB_PVIg3HkUw\"");
  EXPECT_NE (found, std::string::npos);

  found = jsonMessage.find("\"56\": \"EXECUTOR\"");
  EXPECT_NE (found, std::string::npos);

  found = jsonMessage.find("\"10\": \"017\"");
  EXPECT_NE (found, std::string::npos);
}

TEST(SessionTest, HandleRetrieveRequestWithSC) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string pattern = "35=D;34=150;11=89274377;";
  const std::string time = "2016-01-22 16:45:15.091050";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  const std::string jsonMessage = 
    session->handleRetrieveRequest(pattern, time, false);
  std::cout << "Message: " << jsonMessage << '\n';

  std::size_t found = jsonMessage.find("\"11\": \"89274377\"");
  EXPECT_NE (found, std::string::npos);

  found = jsonMessage.find("\"56\": \"EXECUTOR\"");
  EXPECT_NE (found, std::string::npos);

  found = jsonMessage.find("\"10\": \"058\"");
  EXPECT_NE (found, std::string::npos);
}

TEST(SessionTest, HandleRetrieveRequestNonExist) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string pattern = "11=9_5LGTqiyaDB_PVIg3HkUT";
  const std::string time = "2015-05-22 19:29:16.091050";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  const std::string jsonMessage = 
    session->handleRetrieveRequest(pattern, time, false);
  std::cout << "Message: " << jsonMessage << '\n';

  std::size_t found = jsonMessage.find("\"11\": \"9_5LGTqiyaDB_PVIg3HkUT\"");
  EXPECT_EQ (found, std::string::npos);

  found = jsonMessage.find("\"56\": \"CLIENT2\"");
  EXPECT_EQ (found, std::string::npos);

  found = jsonMessage.find("\"10\": \"044\"");
  EXPECT_EQ (found, std::string::npos);
}

TEST(SessionTest, HandleRetrieveResponse) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string pattern = "35=8;11=9_5LGTqiyaDB_PVIg3HkUw";
  const std::string time = "2015-05-22 19:29:16.091050";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  const std::string jsonMessage = 
    session->handleRetrieveResponse(pattern, time, false);
  std::cout << "Message: " << jsonMessage << '\n';

  std::size_t found = jsonMessage.find("\"11\": \"9_5LGTqiyaDB_PVIg3HkUw\"");
  EXPECT_NE (found, std::string::npos);

  found = jsonMessage.find("\"TargetCompID\": \"CLIENT2\"");
  EXPECT_NE (found, std::string::npos);

  found = jsonMessage.find("\"CheckSum\": \"044\"");
  EXPECT_NE (found, std::string::npos);
}

TEST(SessionTest, HandleRetrieveResponseWithSC) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string pattern = "35=3;34=149;371=60;372=D;373=6;";
  const std::string time = "2016-01-22 16:45:15.091050";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  const std::string jsonMessage = 
    session->handleRetrieveResponse(pattern, time, false);
  std::cout << "Message: " << jsonMessage << '\n';

  std::size_t found = jsonMessage.find("\"TargetCompID\": \"CLIENT2\"");
  EXPECT_NE (found, std::string::npos);

  found = jsonMessage.find("\"CheckSum\": \"211\"");
  EXPECT_NE (found, std::string::npos);
}

TEST(SessionTest, HandleRetrieveResponseNonExist) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string pattern = "11=9_5LGTqiyaDB_PVIg3HkUT";
  const std::string time = "2015-05-22 19:29:16.091050";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  const std::string jsonMessage = 
    session->handleRetrieveResponse(pattern, time, false);
  std::cout << "Message: " << jsonMessage << '\n';

  std::size_t found = jsonMessage.find("\"11\": \"9_5LGTqiyaDB_PVIg3HkUT\"");
  EXPECT_EQ (found, std::string::npos);

  found = jsonMessage.find("\"TargetCompID\": \"CLIENT2\"");
  EXPECT_EQ (found, std::string::npos);

  found = jsonMessage.find("\"CheckSum\": \"044\"");
  EXPECT_EQ (found, std::string::npos);
}

TEST(SessionTest, HandleMatchResponse) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string pattern = "11=5164784;MsgSeqNum=1117;OrderQty=30000;BeginString=FIX.4.2;Account=Q1234567890;Symbol=0007.hk;8=FIX.4.2;49=EXECUTOR;56=CLIENT2;35=8;150=2;";
  const std::string time = "2015-08-05 16:48:09.428105";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  std::cout << session->generateStatusResponse(application.getSessionStatus(pattern)) << std::endl;

  std::string errorMsg;
  bool matched = session->handleMatchResponse(pattern, time, false, errorMsg);

  if (!matched)
  {
     std::string responseStr = session->generateFailedResponse(errorMsg);
     std::cout << "Response: " << responseStr << std::endl;
  }
  
  EXPECT_TRUE(matched);
}

TEST(SessionTest, HandleMatchResponseWithSC) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string pattern = "35=3;11=;372=D;373=6;8=FIX.4.2;49=EXECUTOR;56=CLIENT2;Text=Incorrect<space>data<space>format<space>for<space>value;";
  const std::string time = "2016-01-22 16:45:19.428105";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  std::cout << session->generateStatusResponse(application.getSessionStatus(pattern)) << std::endl;

  std::string errorMsg;
  bool matched = session->handleMatchResponse(pattern, time, false, errorMsg);

  if (!matched)
  {
     std::string responseStr = session->generateFailedResponse(errorMsg);
     std::cout << "Response: " << responseStr << std::endl;
  }
  
  EXPECT_TRUE(matched);

}

TEST(SessionTest, HandleCountMessages) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";
  const std::string pattern =  "11=5164784;MsgSeqNum=1117;OrderQty=30000;BeginString=FIX.4.2;Account=Q1234567890;Symbol=0007.hk;8=FIX.4.2;49=EXECUTOR;56=CLIENT2;35=8;150=2;_StartTime=2015-08-05 16:48:09.428;_EndTime=20150805-08:48:09.900;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  std::string messages;
  std::string errorMsg;
  int32_t count = session->handleCountMessages(pattern, false, messages, errorMsg);
  
  std::string responseStr = session->generateCountingResponse(count);
  std::cout << "Response: " << responseStr << std::endl;

  EXPECT_EQ(1, count);
}

TEST(SessionTest, GenerateOrderIDResponse) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile = "message.log";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  std::string responseStr = session->generateOrderIDResponse(FIXProxy::Utils::getOrderID());
  std::cout << "Response: " << responseStr << std::endl;
}

TEST(SessionTest, HandleRetrieveMalformedMsg) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile   = "message.log";
  const std::string messageText  = "BeginString=FIX.4.2;SenderCompID=EXECUTOR;TargetCompID=CLIENT2;_StartTime=2016-04-27 12:10:54.304270;_EndTime=2016-04-27 12:10:56.620651;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  std::string malformedMsg = session->handleRetrieveMalformedMsg(messageText, false);
  
  std::cout << "Response: " << malformedMsg << std::endl;

  EXPECT_NE(0, malformedMsg.length());
}

TEST(SessionTest, HandleSessionInfo) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile   = "message.log";
  const std::string messageText  = "8=FIXT.1.1;9=108;35=A;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;98=0;108=20;1137=9;1867=12345;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  std::string sessionConnectInfo= session->handleSessionInfo(messageText);
  
  std::cout << "Response: " << sessionConnectInfo << std::endl;

  EXPECT_NE(0, sessionConnectInfo.length());
}

TEST(SessionTest, HandlePrintMessageLog) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile   = "message.log";
  const std::string messageText  = "info=Test<space>Started:<space>Case=Logon001<sc>Title=Logon;";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  session->handlePrintMessageLog(messageText);
}

TEST(SessionTest, GenerateFailedResponse) {
  const std::string settingsFile = "hkex/hkex.cfg";
  const std::string msgLogFile   = "message.log";

  // load session settings from file
  FIX::SessionSettings settings(settingsFile);

  // create application
  FIXProxy::Application application(msgLogFile, settings);

  boost::asio::io_service io_service;

  using boost::asio::ip::tcp;
  tcp::socket socket(io_service);
  std::shared_ptr<FIXProxy::Session> session(
    new FIXProxy::Session(std::move(socket), application));

  std::string errorMsg = "Failed to retrieve malformed message.";
  std::string responseMsg = session->generateFailedResponse(errorMsg);

  std::size_t postion = responseMsg.find(errorMsg);

  ASSERT_NE(0, postion);
}
