/****************************************************************************
 *   Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : test_message_log.hpp
 *   Project  : Wabi III
 *   Description: Test cases for message log handler
 *
 *   Created  : 2015/06/09
 *   Author   : Yang Du
 ****************************************************************************/

#include "../src/MessageLog.h"

#ifndef TEST_MESSAGELOG_H
#define TEST_MESSAGELOG_H


#endif // TEST_APPLICATION_H

