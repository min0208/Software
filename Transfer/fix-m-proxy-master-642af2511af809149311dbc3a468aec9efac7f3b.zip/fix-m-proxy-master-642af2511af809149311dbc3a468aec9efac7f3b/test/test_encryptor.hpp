/****************************************************************************
 *   Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : test_encryptor.hpp
 *   Project  : FIXProxy for LME
 *   Description: Test cases for encryptor
 *
 *   Created  : 2017/07/17
 *   Author   : Daniel Liang
 ****************************************************************************/

#ifndef TEST_ENCRYPTOR_H
#define TEST_ENCRYPTOR_H

#include "../src/Encryptor.h"

#endif // TEST_ENCRYPTOR_H
