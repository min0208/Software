/****************************************************************************
 *   Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : test_message_log.cpp
 *   Project  : Wabi III
 *   Description: Test cases for message log handler
 *
 *   Created  : 2015/06/09
 *   Author   : Yang Du
 ****************************************************************************/

#include <string>
#include <vector>
#include <gtest/gtest.h>
//#include <boost/fusion/tuple.hpp>
#include "test_message_log.hpp"

const std::string msgLogFile = "message.log";

TEST(MessageLogTest, Message) {
  const auto msgVector =
    FIXProxy::MessageLog(msgLogFile).message("11=MIv9pBE6tjW8I-9_zZ19wQ;",
      "2015-05-22 19:28:11", false);

  int msgNo = msgVector.size();
  EXPECT_EQ(1, msgNo);
}

TEST(MessageLogTest, ParseLine) {
    const std::string validLine = "[2017-06-22 10:05:38.904065] Received AdminFIXMsg: 8=FIXT.1.1;9=68;35=0;34=200;49=HKEXCC;52=20170622-02:05:38.887;56=CC01077002;1128=9;10=166;";
    std::string time;
    std::string message;
    bool result = FIXProxy::MessageLog::parseLine(validLine, time, message);
    ASSERT_TRUE(result);

    const std::string invalidLine = "1]=[PartyID:7203,PartyIDSource:D,PartyRole:17];NoPartyIDs[2]=[PartyID:7203,PartyIDSource:D,PartyRole:1];OwningBrokerID=7203;SubmittingBrokerID=7203;CounterpartyBrokerID=7203;";
    result = FIXProxy::MessageLog::parseLine(invalidLine, time, message);
    ASSERT_FALSE(result);
}

TEST(MessageLogTest, Request) {
  const auto requestMsgVector = 
    FIXProxy::MessageLog(msgLogFile).request("35=D;11=MIv9pBE6tjW8I-9_zZ19wQ;",
      "2015-05-22 19:28:11", false);

  int requestNo = requestMsgVector.size();

  EXPECT_EQ(1, requestNo);

  if (requestMsgVector.size() > 0)
  {
    const FIXProxy::MessageLog::Message& message = requestMsgVector[0];
    //const std::string& request = boost::fusion::get<1>(message);
    //const std::string& requestText = boost::fusion::get<2>(message);
    //const std::string& requestTime = boost::fusion::get<0>(message);
    const std::string& request     = message.tags;
    const std::string& requestText = message.text;
    const std::string& requestTime = message.time;
    std::cout << "Request: " << request << std::endl;
    std::cout << "Request Text: " << requestText << std::endl;
    std::cout << "Request Time: " << requestTime << std::endl;

    std::size_t found = request.find("11=MIv9pBE6tjW8I-9_zZ19wQ;");
    EXPECT_NE (found, std::string::npos);

    found = request.find("35=D;");
    EXPECT_NE (found, std::string::npos);

    found = request.find("44=150.10;");
    EXPECT_NE (found, std::string::npos);
  }
}

TEST(MessageLogTest, Response) {
  const auto responseMsgVector = 
    FIXProxy::MessageLog(msgLogFile).response("35=8;11=MIv9pBE6tjW8I-9_zZ19wQ;",
      "2015-05-22 19:28:11", false);

  int responseNo = responseMsgVector.size();

  EXPECT_EQ(1, responseNo);

  if (responseMsgVector.size() > 0)
  {
    const FIXProxy::MessageLog::Message& message = responseMsgVector[0];
    //const std::string& response = boost::fusion::get<1>(message);
    //const std::string& responseText= boost::fusion::get<2>(message);
    //const std::string& responseTime = boost::fusion::get<0>(message);
    const std::string& response     = message.tags;
    const std::string& responseText = message.text;
    const std::string& responseTime = message.time;
    std::cout << "Response: " << response << std::endl;
    std::cout << "Response Text: " << responseText << std::endl;
    std::cout << "Response Time: " << responseTime << std::endl;

    std::size_t found = response.find("11=MIv9pBE6tjW8I-9_zZ19wQ;");
    EXPECT_NE (found, std::string::npos);

    found = response.find("35=8;");
    EXPECT_NE (found, std::string::npos);

    found = response.find("55=0001.hk;");
    EXPECT_NE (found, std::string::npos);
  }
}

TEST(MessageLogTest, MatchRequest1) {
  std::string errorMsg;
  const bool matched = 
    FIXProxy::MessageLog(msgLogFile).matchRequest("35=D;11=MIv9pBE6tjW8I-9_zZ19wQ;",
      "2015-05-22 19:28:11", false, errorMsg);

  EXPECT_TRUE(matched);
}

TEST(MessageLogTest, MatchRequest2) {
  std::string errorMsg;
  const bool matched = 
    FIXProxy::MessageLog(msgLogFile).matchRequest("35=F;11=MIv9pBE6tjW8I-9_zZ19wQ;",
      "2015-05-22 19:28:11", false, errorMsg);

  EXPECT_FALSE(matched);
}

TEST(MessageLogTest, MatchBusinessReject) {
  std::string errorMsg;
  const bool matched = 
    FIXProxy::MessageLog(msgLogFile).matchBusinessReject("2015-05-22 19:28:11", false, errorMsg);

  EXPECT_FALSE(matched);
}

TEST(MessageLogTest, MatchAdminReject) {
  std::string errorMsg;
  const bool matched = 
    FIXProxy::MessageLog(msgLogFile).matchAdminReject("34=1105;49=EXECUTOR;",
      "2015-08-05 08:48:03", false, errorMsg);

  EXPECT_TRUE(matched);
}

TEST(MessageLogTest, MatchResponse1) {
  std::string errorMsg;
  const bool matched = 
    FIXProxy::MessageLog(msgLogFile).matchResponse("35=8;11=MIv9pBE6tjW8I-9_zZ19wQ;",
      "2015-05-22 19:28:11", false, errorMsg);

  EXPECT_TRUE(matched);
}

TEST(MessageLogTest, MatchResponse2) {
  std::string errorMsg;
  const bool matched = 
    FIXProxy::MessageLog(msgLogFile).matchResponse("35=D;11=MIv9pBE6tjW8I-9_zZ19wQ;",
      "2015-05-22 19:28:11", false, errorMsg);

  EXPECT_FALSE(matched);
}

TEST(MessageLogTest, ParseOrderID1) {
  const std::string msg = "8=FIX.4.2;9=188;35=8;34=3;49=EXECUTOR;52=20150522-11:28:11.231;56=CLIENT2;1=Q00100002;6=150.1;11=MIv9pBE6tjW8I-9_zZ19wQ;14=10000;17=1;20=0;31=150.1;32=10000;37=1;38=10000;39=2;54=2;55=0001.hk;150=2;151=0;10=172;";
  const std::string clordID = 
    FIXProxy::MessageLog(msgLogFile).parseRequestID(msg, ";");

  ASSERT_STREQ("MIv9pBE6tjW8I-9_zZ19wQ", clordID.c_str());
}

TEST(MessageLogTest, ParseOrderID2) {
  const std::string msg = "BeginString=FIX.4.2;BodyLength=188;MsgType=8;MsgSeqNum=3;SenderCompID=EXECUTOR;SendingTime=20150522-11:28:11.231;TargetCompID=CLIENT2;Account=Q00100002;AvgPx=150.1;ClOrdID=MIv9pBE6tjW8I-9_zZ19wQ;CumQty=10000;ExecID=1;ExecTransType=0;LastPx=150.1;LastShares=10000;OrderID=1;OrderQty=10000;OrdStatus=2;Side=2;Symbol=0001.hk;ExecType=2;LeavesQty=0;CheckSum=172;";
  const std::string clordID = 
    FIXProxy::MessageLog(msgLogFile).parseRequestID(msg, ";");

  std::cout << "clordID: " << std::endl;

  ASSERT_STREQ("MIv9pBE6tjW8I-9_zZ19wQ", clordID.c_str());
}

TEST(MessageLogTest, MalformedMessageSuccess) {
  std::string expectText = "BeginString=FIX.4.2;SenderCompID=EXECUTOR;TargetCompID=CLIENT2;";
  std::string startTime  = "2016-04-27 12:10:54.304270";
  std::string endTime    = "2016-04-27 12:10:56.620651";
  std::string errorMsg;
  const std::string targetMsg  = "BeginString=FIX.4.2;BodyLength=108;MsgType=3;MsgSeqNum=18;SenderCompID=EXECUTOR;SendingTime=20160427-04:10:54.342;TargetCompID=CLIENT2;RefSeqNum=25;Text=Required tag missing;RefTagID=21;RefMsgType=D;SessionRejectReason=1;CheckSum=113;  RejectReason=Tag not defined for this message type:373;";

  std::vector<FIXProxy::MessageLog::Message> msgVector = 
    FIXProxy::MessageLog(msgLogFile).malformedMessage(expectText,
      startTime, endTime, false, errorMsg);

  std::string malformedMsg;
  if (msgVector.size() > 0)
  {
      malformedMsg = msgVector[0].tags;
  }

  ASSERT_NE(0, msgVector.size());
  ASSERT_STREQ(targetMsg.c_str(), malformedMsg.c_str());

}

TEST(MessageLogTest, MalformedMessageFailed) {
  std::string expectText = "BeginString=FIX.4.2;SenderCompID=EXECUTOR;TargetCompID=CLIENT2;";
  std::string startTime  = "2016-04-27 12:10:56.620651";
  std::string endTime    = "2016-04-27 12:10:54.304270";
  std::string errorMsg;

  std::vector<FIXProxy::MessageLog::Message> msgVector = 
    FIXProxy::MessageLog(msgLogFile).malformedMessage(
      expectText, startTime, endTime, false, errorMsg);

  ASSERT_EQ(0, msgVector.size());
  ASSERT_STREQ("Invalid start time/end time.", errorMsg.c_str());
}

TEST(MessageLogTest, Match) {
  std::string expectText1 = "MsgType=(.*)";
  std::string expectText2 = "Price=(.*)";
  std::string errorMsg;

  const std::string messageText = "BeginString=FIX.4.2;BodyLength=188;MsgType=8;MsgSeqNum=3;SenderCompID=EXECUTOR;SendingTime=20150522-11:28:11.231;TargetCompID=CLIENT2;Account=Q00100002;AvgPx=150.1;ClOrdID=MIv9pBE6tjW8I-9_zZ19wQ;CumQty=10000;ExecID=1;ExecTransType=0;LastPx=150.1;LastShares=10000;OrderID=1;OrderQty=10000;OrdStatus=2;Side=2;Symbol=0001.hk;ExecType=2;LeavesQty=0;CheckSum=172;";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);

  ASSERT_TRUE(matchResult1);
  ASSERT_FALSE(matchResult2);
}

TEST(MessageLogTest, Match_Test1) {
  std::string expectText1 = "35=D;34=5;49=CO99999901;";
  std::string expectText2 = "35=D;34=5;49=CO99999901;NoDisclosureInstructions=[DisclosureType:100,DisclosureInstruction:1];";
  std::string errorMsg;

  const std::string messageText = "8=FIXT.1.1;9=130;35=D;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;1128=9;98=0;108=20;789=1;1137=9;1812=2;1813=100;1814=1;1813=101;1814=1;10=032;NoDisclosureInstructions=[DisclosureType:100,DisclosureInstruction:1];";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_TRUE(matchResult1);
  ASSERT_TRUE(matchResult2);
}

TEST(MessageLogTest, Match_Test2) {
  std::string expectText1 = "35=D;34=5;49=CO99999901;";
  std::string expectText2 = "35=D;34=5;49=CO99999901;NoDisclosureInstructions=[DisclosureType:100,DisclosureInstruction:1];";
  std::string errorMsg;

  const std::string messageText = "8=FIXT.1.1;9=130;35=D;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;1128=9;98=0;108=20;789=1;1137=9;1812=2;1813=100;1814=1;1813=101;1814=1;10=032;NoDisclosureInstructions=[DisclosureType:100,DisclosureInstruction:1];NoDisclosureInstructions=[DisclosureType:101,DisclosureInstruction:1];";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_TRUE(matchResult1);
  ASSERT_TRUE(matchResult2);
}

TEST(MessageLogTest, Match_Test3) {
  std::string expectText1 = "35=D;34=5;49=CO99999901;";
  std::string expectText2 = "35=D;34=5;49=CO99999901;NoDisclosureInstructions=[DisclosureType:102,DisclosureInstruction:1];";
  std::string errorMsg;

  const std::string messageText = "8=FIXT.1.1;9=130;35=D;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;1128=9;98=0;108=20;789=1;1137=9;1812=2;1813=100;1814=1;1813=101;1814=1;10=032;NoDisclosureInstructions=[DisclosureType:100,DisclosureInstruction:1];NoDisclosureInstructions=[DisclosureType:101,DisclosureInstruction:1];";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_TRUE(matchResult1);
  ASSERT_FALSE(matchResult2);
}

TEST(MessageLogTest, Match_Test4) {
  std::string expectText1 = "35=D;34=5;49=CO99999901;";
  std::string expectText2 = "35=D;34=5;49=CO99999901;1812=2;NoDisclosureInstructions=DisclosureType:102,DisclosureInstruction:1;";
  std::string errorMsg;

  const std::string messageText = "8=FIXT.1.1;9=130;35=D;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;1128=9;98=0;108=20;789=1;1137=9;1812=2;1813=100;1814=1;1813=101;1814=1;10=032;NoDisclosureInstructions[1]=[DisclosureType:100,DisclosureInstruction:1];NoDisclosureInstructions[2]=[DisclosureType:101,DisclosureInstruction:1];";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_TRUE(matchResult1);
  ASSERT_FALSE(matchResult2);
}

TEST(MessageLogTest, Match_Test5) {
  std::string expectText1 = "35=D;34=5;49=CO99999901;";
  std::string expectText2 = "35=D;34=5;49=CO99999901;1812=2;NoDisclosureInstructions=DisclosureInstruction:1;";
  std::string errorMsg;

  const std::string messageText = "8=FIXT.1.1;9=130;35=D;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;1128=9;98=0;108=20;789=1;1137=9;1812=2;1813=100;1814=1;1813=101;1814=1;10=032;NoDisclosureInstructions[1]=[DisclosureType:100,DisclosureInstruction:1];NoDisclosureInstructions[2]=[DisclosureType:101,DisclosureInstruction:1];";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_TRUE(matchResult1);
  ASSERT_TRUE(matchResult2);
}

TEST(MessageLogTest, Match_Test6) {
  std::string expectText1 = "35=D;34=5;49=CO99999901;";
  std::string expectText2 = "35=D;34=5;49=CO99999901;1812=2;DisclosureType=101;NoDisclosureInstructions=DisclosureInstruction:1;";
  std::string errorMsg;

  const std::string messageText = "8=FIXT.1.1;9=130;35=D;34=5;49=CO99999901;52=20150709-06:25:14.863;56=HKEXCO;1128=9;98=0;108=20;789=1;1137=9;1812=2;1813=100;1814=1;1813=101;1814=1;10=032;NoDisclosureInstructions[1]=[DisclosureType:100,DisclosureInstruction:1];NoDisclosureInstructions[2]=[DisclosureType:101,DisclosureInstruction:1];";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_TRUE(matchResult1);
  ASSERT_FALSE(matchResult2);
}

TEST(MessageLogTest, Match_Test7) {
  std::string expectText1 = "8=FIXT.1.1;35=AE;34=352;49=HKEXCC;56=CC51100001;";
  std::string expectText2 = "8=FIXT.1.1;35=AE;34=352;49=HKEXCC;56=CC51100001;NoSides=[Side:2,NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1],NoClearingInstructions:[ClearingInstruction:0],Text:123,ExecInst:c];";
  std::string errorMsg;

  const std::string messageText = "8=FIXT.1.1;9=327;35=AE;34=352;49=HKEXCC;52=20160826-02:38:05.646;56=CC51100001;1128=9;22=8;31=8.9;32=2000;48=8101;60=20160826-02:38:05.000;150=F;207=XHKG;487=2;552=2;54=2;453=1;448=5401;447=D;452=1;576=1;577=0;58=123;18=c;54=1;453=1;448=5411;447=D;452=17;77=C;58=ABC;571=23948137;797=Y;828=4;856=0;939=0;1003=8101000000011;1123=0;1128=9;5681=R;10=237;NoSides[1]=[Side:2,NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1],NoClearingInstructions:[ClearingInstruction:0],Text:123,ExecInst:c];NoSides[2]=[Side:1,NoPartyIDs:[PartyID:5411,PartyIDSource:D,PartyRole:17],PositionEffect:C,Text:ABC];OwningBrokerID=5401;SubmittingBrokerID=5401;CounterpartyBrokerID=5411;";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_TRUE(matchResult1);
  ASSERT_TRUE(matchResult2);
}

TEST(MessageLogTest, Match_Test8) {
  std::string expectText1 = "8=FIXT.1.1;35=AE;34=352;49=HKEXCC;56=CC51100001;";
  std::string expectText2 = "8=FIXT.1.1;35=AE;34=352;49=HKEXCC;56=CC51100001;NoSides=[Side:2,NoPartyIDs:[PartyID:5402,PartyIDSource:D,PartyRole:1],NoClearingInstructions:[ClearingInstruction:0],Text:123,ExecInst:c];";
  std::string errorMsg;

  const std::string messageText = "8=FIXT.1.1;9=327;35=AE;34=352;49=HKEXCC;52=20160826-02:38:05.646;56=CC51100001;1128=9;22=8;31=8.9;32=2000;48=8101;60=20160826-02:38:05.000;150=F;207=XHKG;487=2;552=2;54=2;453=1;448=5401;447=D;452=1;576=1;577=0;58=123;18=c;54=1;453=1;448=5411;447=D;452=17;77=C;58=ABC;571=23948137;797=Y;828=4;856=0;939=0;1003=8101000000011;1123=0;1128=9;5681=R;10=237;NoSides[1]=[Side:2,NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1],NoClearingInstructions:[ClearingInstruction:0],Text:123,ExecInst:c];NoSides[2]=[Side:1,NoPartyIDs:[PartyID:5411,PartyIDSource:D,PartyRole:17],PositionEffect:C,Text:ABC];OwningBrokerID=5401;SubmittingBrokerID=5401;CounterpartyBrokerID=5411;";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_TRUE(matchResult1);
  ASSERT_FALSE(matchResult2);
}

TEST(MessageLogTest, Match_Test9) {
  std::string expectText1 = "8=FIXT.1.1;35=AE;34=352;49=HKEXCC;56=CC51100001;";
  std::string expectText2 = "8=FIXT.1.1;35=AE;34=352;49=HKEXCC;56=CC51100001;NoPartyIDs=[PartyID:5401,PartyIDSource:D,PartyRole:1]";
  std::string errorMsg;

  const std::string messageText = "8=FIXT.1.1;9=327;35=AE;34=352;49=HKEXCC;52=20160826-02:38:05.646;56=CC51100001;1128=9;22=8;31=8.9;32=2000;48=8101;60=20160826-02:38:05.000;150=F;207=XHKG;487=2;552=2;54=2;453=1;448=5401;447=D;452=1;576=1;577=0;58=123;18=c;54=1;453=1;448=5411;447=D;452=17;77=C;58=ABC;571=23948137;797=Y;828=4;856=0;939=0;1003=8101000000011;1123=0;1128=9;5681=R;10=237;NoSides[1]=[Side:2,NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1],NoClearingInstructions:[ClearingInstruction:0],Text:123,ExecInst:c];NoSides[2]=[Side:1,NoPartyIDs:[PartyID:5411,PartyIDSource:D,PartyRole:17],PositionEffect:C,Text:ABC];OwningBrokerID=5401;SubmittingBrokerID=5401;CounterpartyBrokerID=5411;";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_TRUE(matchResult1);
  ASSERT_FALSE(matchResult2);
}

TEST(MessageLogTest, Match_Test10) {
  std::string expectText1 = "8=FIXT.1.1;35=8;34=1063;49=HKEXCO;56=CO51100001;";
  std::string expectText2 = "8=FIXT.1.1;35=8;34=1063;49=HKEXCO;56=CO51100001;NoPartyIDs=PartyID:<novalue>;";
  std::string errorMsg;

  const std::string messageText = "8=FIXT.1.1;9=243;35=8;34=1063;49=HKEXCO;52=20160829-07:26:05.629;56=CO51100001;1128=9;11=98498604;14=0;17=NI/.1E.K1;22=8;37=214;38=1000;39=0;40=2;44=10;48=8104;54=1;59=0;60=20160829-07:26:05.000;150=0;151=1000;207=XHKG;453=1;448=5401;447=D;452=1;1090=1;1093=2;10=046;NoPartyIDs[1]=[PartyID:,PartyIDSource:D,PartyRole:1];OwningBrokerID=5401;SubmittingBrokerID=5401;";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_TRUE(matchResult1);
  ASSERT_TRUE(matchResult2);
}

TEST(MessageLogTest, Match_Test11) {
  std::string expectText1 = "8=FIXT.1.1;35=8;34=1063;49=HKEXCO;56=CO51100001;";
  std::string expectText2 = "8=FIXT.1.1;35=8;34=1063;49=HKEXCO;56=CO51100001;NoPartyIDs=ABC;";
  std::string errorMsg;

  const std::string messageText = "8=FIXT.1.1;9=243;35=8;34=1063;49=HKEXCO;52=20160829-07:26:05.629;56=CO51100001;1128=9;11=98498604;14=0;17=NI/.1E.K1;22=8;37=214;38=1000;39=0;40=2;44=10;48=8104;54=1;59=0;60=20160829-07:26:05.000;150=0;151=1000;207=XHKG;453=1;448=5401;447=D;452=1;1090=1;1093=2;10=046;NoPartyIDs[1]=[PartyID:,PartyIDSource:D,PartyRole:1];OwningBrokerID=5401;SubmittingBrokerID=5401;";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_TRUE(matchResult1);
  ASSERT_FALSE(matchResult2);
}

TEST(MessageLogTest, Match_Test12) {
  std::string expectText1 = "8=FIXT.1.1;35=8;34=1063;49=HKEXCO;56=CO51100001;";
  std::string expectText2 = "8=FIXT.1.1;35=8;34=1063;49=HKEXCO;56=CO51100001;NoPartyIDs=PartyID:;";
  std::string errorMsg;

  const std::string messageText = "8=FIXT.1.1;9=243;35=8;34=1063;49=HKEXCO;52=20160829-07:26:05.629;56=CO51100001;1128=9;11=98498604;14=0;17=NI/.1E.K1;22=8;37=214;38=1000;39=0;40=2;44=10;48=8104;54=1;59=0;60=20160829-07:26:05.000;150=0;151=1000;207=XHKG;453=1;448=5401;447=D;452=1;1090=1;1093=2;10=046;NoPartyIDs[1]=[PartyID:5401,PartyIDSource:D,PartyRole:1];OwningBrokerID=5401;SubmittingBrokerID=5401;";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_TRUE(matchResult1);
  ASSERT_FALSE(matchResult2);
}

TEST(MessageLogTest, Match_Test13) {
  std::string expectText1 = "8=FIXT.1.1;35=8;34=1063;49=HKEXCO;56=CO51100001;";
  std::string expectText2 = "8=FIXT.1.1;35=8;34=1063;49=HKEXCO;56=CO51100001;NoPartyIDs=PartyID:;";
  std::string errorMsg;

  const std::string messageText = "8=FIXT.1.1;9=243;35=8;34=1063;49=HKEXCO;52=20160829-07:26:05.629;56=CO51100001;1128=9;11=98498604;14=0;17=NI/.1E.K1;22=8;37=214;38=1000;39=0;40=2;44=10;48=8104;54=1;59=0;60=20160829-07:26:05.000;150=0;151=1000;207=XHKG;453=1;448=5401;447=D;452=1;1090=1;1093=2;10=046;NoPartyIDs[1]=[PartyIDSource:D,PartyRole:1];OwningBrokerID=5401;SubmittingBrokerID=5401;";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_TRUE(matchResult1);
  ASSERT_TRUE(matchResult2);
}

TEST(MessageLogTest, Match_Test14) {
  std::string expectText1 = "8=FIXT.1.1;49=CO51900001;56=HKEXCO;35=S;";
  std::string expectText2 = "8=FIXT.1.1;49=CO51900001;56=HKEXCO;35=S;NoValueChecks=ValueCheckType:1,ValueCheckAction:0;";
  std::string errorMsg;

  const std::string messageText = "8=FIXT.1.1;9=262;35=S;34=979;49=CO51900001;52=20160830-06:57:37.450;56=HKEXCO;1128=9;22=8;48=8102;58=Quote;60=20160830-06:57:37.450;77=C;132=0.415;133=0.42;134=5000;135=10000;207=XHKG;390=32259531;453=1;448=5482;447=D;452=1;537=1;1867=32259532;1868=2;1869=1;1870=0;1869=2;1870=0;10=053;NoPartyIDs[1]=[PartyID:5482,PartyIDSource:D,PartyRole:1];NoValueChecks[1]=[ValueCheckType:1,ValueCheckAction:0];NoValueChecks[1]=[ValueCheckType:2,ValueCheckAction:0];OwningBrokerID=5482;SubmittingBrokerID=5482;";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_TRUE(matchResult1);
  ASSERT_TRUE(matchResult2);
}

TEST(MessageLogTest, Match_Test15) {
  std::string expectText1 = "8=FIXT.1.1;49=CO51900001;56=HKEXCO;35=S;";
  std::string expectText2 = "8=FIXT.1.1;49=CO51900001;56=HKEXCO;35=S;NoValueChecks=;";
  std::string errorMsg;

  const std::string messageText = "8=FIXT.1.1;9=262;35=S;34=979;49=CO51900001;52=20160830-06:57:37.450;56=HKEXCO;1128=9;22=8;48=8102;58=Quote;60=20160830-06:57:37.450;77=C;132=0.415;133=0.42;134=5000;135=10000;207=XHKG;390=32259531;453=1;448=5482;447=D;452=1;537=1;1867=32259532;1868=2;1869=1;1870=0;1869=2;1870=0;10=053;NoPartyIDs[1]=[PartyID:5482,PartyIDSource:D,PartyRole:1];NoValueChecks[1]=[ValueCheckType:1,ValueCheckAction:0];NoValueChecks[2]=[ValueCheckType:2,ValueCheckAction:0];OwningBrokerID=5482;SubmittingBrokerID=5482;";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_TRUE(matchResult1);
  ASSERT_FALSE(matchResult2);
}

TEST(MessageLogTest, Match_Test16) {
  std::string expectText1  = "BeginString=FIXT.1.1;MsgType=AE;SenderCompID=HKEXCC;TargetCompID=CC51100001;";
  std::string expectText2  = "NoSides=[Side:1,NoPartyIDs:[PartyID:5411,PartyIDSource:D],PositionEffect:C,Text:ABC];";
  std::string errorMsg;

  std::string messageText = "8=FIXT.1.1;9=327;35=AE;34=352;49=HKEXCC;52=20160826-02:38:05.646;56=CC51100001;1128=9;22=8;31=8.9;32=2000;48=8101;60=20160826-02:38:05.000;150=F;207=XHKG;487=2;552=2;54=2;453=1;448=5401;447=D;452=1;576=1;577=0;58=123;18=c;54=1;453=1;448=5411;447=D;452=17;77=C;58=ABC;571=23948137;797=Y;828=4;856=0;939=0;1003=8101000000011;1123=0;1128=9;5681=R;10=237;NoSides[1]=[Side:2,NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1],NoClearingInstructions:[ClearingInstruction:0],Text:123,ExecInst:c];NoSides[2]=[Side:1,NoPartyIDs:[PartyID:5411,PartyIDSource:D,PartyRole:17],PositionEffect:C,Text:ABC];OwningBrokerID=5401;SubmittingBrokerID=5401;CounterpartyBrokerID=5411;";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_FALSE(matchResult1);
  ASSERT_TRUE(matchResult2);
}

TEST(MessageLogTest, Match_Test17) {
  std::string expectText1  = "35=AE;34=1123;49=CO51100001;56=HKEXCO;571=795357;";
  std::string expectText2  = "35=AE;34=1123;49=CO51100001;56=HKEXCO;NoSides=[Side:2,NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1],NoClearingInstructions:[ClearingInstruction:0]];NoSides=[Side:1,NoPartyIDs:[PartyID:5411,PartyIDSource:D,PartyRole:17],NoClearingInstructions:[ClearingInstruction:0],PositionEffect:C,OrderID:2294];";
  std::string errorMsg;

  std::string messageText = "8=FIXT.1.1;9=263;35=AE;34=1123;49=CO51100001;52=20160907-08:44:57.185;56=HKEXCO;1128=9;22=8;31=10;32=501;48=8104;60=20160907-08:44:57.185;207=XHKG;552=2;54=2;453=1;448=5401;447=D;452=1;576=1;577=0;54=1;453=1;448=5411;447=D;452=17;576=1;577=0;77=C;37=2294;571=795357;828=102;856=0;10=239;NoSides[1]=[Side:2,NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1],NoClearingInstructions:[ClearingInstruction:0]];NoSides[2]=[Side:1,NoPartyIDs:[PartyID:5411,PartyIDSource:D,PartyRole:17],NoClearingInstructions:[ClearingInstruction:0],PositionEffect:C,OrderID:2294];OwningBrokerID=5401;SubmittingBrokerID=5401;CounterpartyBrokerID=5411;BeginString=FIXT.1.1;BodyLength=242;MsgType=8;MsgSeqNum=1117;SenderCompID=HKEXCO;SendingTime=20160907-08:45:39.552;TargetCompID=CO51100001;ApplVerID=9;ClOrdID=795359;CumQty=0;ExecID=NI/.eF.4Y;SecurityIDSource=8;OrderID=2310;OrderQty=1000;OrdStatus=0;OrdType=2;Price=10;SecurityID=8104;Side=1;TimeInForce=0;TransactTime=20160907-08:45:39.000;ExecType=0;LeavesQty=1000;SecurityExchange=XHKG;NoPartyIDs=1;PartyID=5401;PartyIDSource=D;PartyRole=1;MaxPriceLevels=1;LotType=2;CheckSum=063;";
  
  bool matchResult1 = FIXProxy::MessageLog(msgLogFile).match(expectText1, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult1 << "|" << errorMsg << std::endl;
  bool matchResult2 = FIXProxy::MessageLog(msgLogFile).match(expectText2, messageText, ";", errorMsg);
  std::cout << "Result: " << matchResult2 << "|" << errorMsg << std::endl;

  ASSERT_TRUE(matchResult1);
  ASSERT_TRUE(matchResult2);
}

TEST(MessageLogTest, GenGroupFieldTemplate1) {
  std::string expectText  = "BeginString=FIX.4.2;BodyLength=190;MsgType=D;MsgSeqNum=2;SenderCompID=CLIENT2;TargetCompID=EXECUTOR;Account=Q1234567890;NoPartyIDs=[PartyID:5482,PartyRole:1];";
  std::string messageText = "8=FIX.4.2;9=176;35=8;34=14;49=EXECUTOR;52=20160902-01:58:20.183;56=CLIENT2;1=Q1234567890;6=8.9;11=12632561;14=1000;17=9084;20=0;31=8.9;32=1000;37=9084;38=1000;39=2;54=1;55=0001.hk;150=2;151=0;453=2;447=5482;448=D;452=1;447=5483;448=D;452=17;10=184;NoPartyIDs[1]=[PartyID:5482,PartyIDSource:D,PartyRole:1];NoPartyIDs[2]=[PartyID:5483,PartyIDSource:D,PartyRole:17];";
  std::string result;

  
  std::cout << "expectaton: " << expectText << std::endl;
  std::cout << "message: " << messageText << std::endl;
  result = FIXProxy::MessageLog(msgLogFile).genGroupTemplateTags(expectText, messageText);
  std::cout << "Result: " << result << std::endl;

  ASSERT_STREQ("PartyID=[1],PartyRole=[1],NoPartyIDs,", result.c_str());
}

TEST(MessageLogTest, GenGroupFieldTemplate2) {
  std::string expectText  = "BeginString=FIXT.1.1;MsgType=AE;SenderCompID=HKEXCC;TargetCompID=CC51100001;NoSides=[Side:1,NoPartyIDs:[PartyID:5411,PartyIDSource:D],PositionEffect:C,Text:ABC];";
  std::string messageText = "8=FIXT.1.1;9=327;35=AE;34=352;49=HKEXCC;52=20160826-02:38:05.646;56=CC51100001;1128=9;22=8;31=8.9;32=2000;48=8101;60=20160826-02:38:05.000;150=F;207=XHKG;487=2;552=2;54=2;453=1;448=5401;447=D;452=1;576=1;577=0;58=123;18=c;54=1;453=1;448=5411;447=D;452=17;77=C;58=ABC;571=23948137;797=Y;828=4;856=0;939=0;1003=8101000000011;1123=0;1128=9;5681=R;10=237;NoSides[1]=[Side:2,NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1],NoClearingInstructions:[ClearingInstruction:0],Text:123,ExecInst:c];NoSides[2]=[Side:1,NoPartyIDs:[PartyID:5411,PartyIDSource:D,PartyRole:17],PositionEffect:C,Text:ABC];OwningBrokerID=5401;SubmittingBrokerID=5401;CounterpartyBrokerID=5411;";
  std::string result;

  
  std::cout << "expectaton: " << expectText << std::endl;
  std::cout << "message: " << messageText << std::endl;
  result = FIXProxy::MessageLog(msgLogFile).genGroupTemplateTags(expectText, messageText);
  std::cout << "Result: " << result << std::endl;

  ASSERT_STREQ("Side=[2],PartyID=[2],PartyIDSource=[2],NoPartyIDs=[2],PositionEffect=[2],Text=[2],NoSides=[2],", result.c_str());
}

TEST(MessageLogTest, GenGroupFieldTemplate3) {
  std::string result;

  std::string expectText  = "BeginString=FIXT.1.1;MsgType=AE;SenderCompID=HKEXCO;TargetCompID=CO51100001;NoSides=[Side:1,NoPartyIDs:[PartyID:5411,PartyIDSource:D]];NoPartyIDs=[PartyID:5402,PartyIDSource:D,PartyRole:75];NoSides=[Side:2,NoPartyIDs:[PartyID:5401,PartyIDSource:D]];";
  const std::string messageText = "8=FIXT.1.1;9=313;35=AE;34=1425;49=HKEXCO;52=20160923-07:49:20.098;56=CO51100001;1128=9;22=8;31=10;32=501;48=8104;60=20160923-07:49:20.000;150=F;207=XHKG;487=2;552=2;54=2;453=2;448=5402;447=D;452=75;448=5401;447=D;452=1;576=1;577=0;54=1;453=1;448=5411;447=D;452=17;571=21451743;828=102;856=0;939=0;1003=8104000000078;1123=0;5681=O;10=022;NoPartyIDs[1]=[PartyID:5402,PartyIDSource:D,PartyRole:75];NoPartyIDs[2]=[PartyID:5401,PartyIDSource:D,PartyRole:1];NoSides[1]=[Side:2,NoPartyIDs:[PartyID:5402,PartyIDSource:D,PartyRole:75],NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1],NoClearingInstructions:[ClearingInstruction:0]];NoSides[2]=[Side:1,NoPartyIDs:[PartyID:5411,PartyIDSource:D,PartyRole:17]];OwningBrokerID=5401;SubmittingBrokerID=5401;BrokerLocationID=5402;CounterpartyBrokerID=5411;";

  
  std::cout << "expectaton: " << expectText << std::endl;
  std::cout << "message: " << messageText << std::endl;
  result = FIXProxy::MessageLog(msgLogFile).genGroupTemplateTags(expectText, messageText);
  std::cout << "Result: " << result << std::endl;

  ASSERT_STREQ("Side=[2],PartyID=[5],PartyIDSource=[5],NoPartyIDs=[2],NoSides=[2],PartyID=[1],PartyIDSource=[1],PartyRole=[1],NoPartyIDs,Side=[1],PartyID=[4],PartyIDSource=[4],NoPartyIDs=[1],NoSides=[1],", result.c_str());
}

TEST(MessageLogTest, GenGroupFieldTemplate4) {
  std::string result;

  std::string expectText  = "BeginString=FIXT.1.1;MsgType=AE;SenderCompID=HKEXCO;TargetCompID=CO51100001;NoSides=[Side:1,NoPartyIDs:[PartyID:5411,PartyIDSource:D]];NoPartyIDs=[PartyID:5402,PartyIDSource:D,PartyRole:75];NoSides=[Side:2,NoPartyIDs:[PartyID:5401,PartyIDSource:D]];";
  const std::string messageText = "8=FIXT.1.1;9=313;35=AE;34=1425;49=HKEXCO;52=20160923-07:49:20.098;56=CO51100001;1128=9;22=8;31=10;32=501;48=8104;60=20160923-07:49:20.000;150=F;207=XHKG;487=2;552=2;54=2;453=2;448=5402;447=D;452=75;448=5401;447=D;452=1;576=1;577=0;54=1;453=1;448=5411;447=D;452=17;571=21451743;828=102;856=0;939=0;1003=8104000000078;1123=0;5681=O;10=022;NoPartyIDs[1]=[PartyID:5402,PartyIDSource:D,PartyRole:75];NoPartyIDs[2]=[PartyID:5401,PartyIDSource:D,PartyRole:1];NoSides[1]=[Side:2,NoPartyIDs:[PartyID:5402,PartyIDSource:D,PartyRole:75],NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1],NoClearingInstructions:[ClearingInstruction:0]];NoSides[2]=[Side:1,NoPartyIDs:[PartyID:5411,PartyIDSource:D,PartyRole:17]];OwningBrokerID=5401;SubmittingBrokerID=5401;BrokerLocationID=5402;CounterpartyBrokerID=5411;";

  
  std::cout << "expectaton: " << expectText << std::endl;
  std::cout << "message: " << messageText << std::endl;
  result = FIXProxy::MessageLog(msgLogFile).genGroupTemplateTags(expectText, messageText);
  std::cout << "Result: " << result << std::endl;

  ASSERT_STREQ("Side=[2],PartyID=[5],PartyIDSource=[5],NoPartyIDs=[2],NoSides=[2],PartyID=[1],PartyIDSource=[1],PartyRole=[1],NoPartyIDs,Side=[1],PartyID=[4],PartyIDSource=[4],NoPartyIDs=[1],NoSides=[1],", result.c_str());
}

TEST(MessageLogTest, GetGroupTemplateTags1) {
  std::string groupText = "NoPartyIDs=[PartyID:5402,PartyIDSource:D,PartyRole:1]";
  std::string groupName = "NoPartyIDs[2]";
  std::vector<std::string> groups;
  groups.push_back("NoPartyIDs[1]+NoPartyIDs[1]=[PartyID:5402,PartyIDSource:D,PartyRole:75]");
  groups.push_back("NoPartyIDs[2]+NoPartyIDs[2]=[PartyID:5402,PartyIDSource:D,PartyRole:1]");
  groups.push_back("NoSides[1]+NoPartyIDs:[PartyID:5402,PartyIDSource:D,PartyRole:75]");
  groups.push_back("NoSides[1]+NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1]");
  groups.push_back("NoSides[2]+NoPartyIDs:[PartyID:5411,PartyIDSource:D,PartyRole:17]");

  std::string result =
    FIXProxy::MessageLog(msgLogFile).getGroupTemplateTags(groupText, groupName, ";", "=", groups);

  std::cout << "RESULT: " << result << std::endl;

  ASSERT_STREQ("PartyID=[2],PartyIDSource=[2],PartyRole=[2],NoPartyIDs,", result.c_str());
}

TEST(MessageLogTest, GetGroupTemplateTags2) {
  std::string groupText = "NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1]";
  std::string groupName = "NoSides[1]";
  std::vector<std::string> groups;
  groups.push_back("NoPartyIDs[1]+NoPartyIDs[1]=[PartyID:5402,PartyIDSource:D,PartyRole:75]");
  groups.push_back("NoPartyIDs[2]+NoPartyIDs[2]=[PartyID:5402,PartyIDSource:D,PartyRole:1]");
  groups.push_back("NoSides[1]+NoPartyIDs:[PartyID:5402,PartyIDSource:D,PartyRole:75]");
  groups.push_back("NoSides[1]+NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1]");
  groups.push_back("NoSides[2]+NoPartyIDs:[PartyID:5411,PartyIDSource:D,PartyRole:17]");

  std::string result =
    FIXProxy::MessageLog(msgLogFile).getGroupTemplateTags(groupText, groupName, ",", ":", groups);

  std::cout << "RESULT: " << result << std::endl;

  ASSERT_STREQ("PartyID=[4],PartyIDSource=[4],PartyRole=[4],NoPartyIDs=[1],", result.c_str());
}

TEST(MessageLogTest, GetGroupTemplateTags3) {
  std::string groupText = "NoPartyIDs=[PartyID:5401,PartyIDSource:D,PartyRole:1]";
  std::string groupName = "NoSides[1]";
  std::vector<std::string> groups;
  groups.push_back("NoPartyIDs[1]+NoPartyIDs[1]=[PartyID:5402,PartyIDSource:D,PartyRole:75]");
  groups.push_back("NoPartyIDs[2]+NoPartyIDs[2]=[PartyID:5402,PartyIDSource:D,PartyRole:1]");
  groups.push_back("NoSides[1]+NoPartyIDs:[PartyID:5402,PartyIDSource:D,PartyRole:75]");
  groups.push_back("NoSides[1]+NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1]");
  groups.push_back("NoSides[2]+NoPartyIDs:[PartyID:5411,PartyIDSource:D,PartyRole:17]");

  std::string result =
    FIXProxy::MessageLog(msgLogFile).getGroupTemplateTags(groupText, groupName, ";", "=", groups);

  std::cout << "RESULT: " << result << std::endl;

  ASSERT_STRNE("PartyID=[4],PartyIDSource=[4],PartyRole=[4],NoPartyIDs=[1],", result.c_str());
}
