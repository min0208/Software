/****************************************************************************
 *   Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : test_utils.hpp
 *   Project  : Wabi II
 *   Description: Test cases for encoder
 *
 *   Created  : 2015/04/22
 *   Author   : Yang Du
 ****************************************************************************/

#include "../src/Utils.h"
#include "../src/Converter.h"

#ifndef TEST_UTILS_H
#define TEST_UTILS_H


#endif // TEST_CONVERTER
