/****************************************************************************
 *   Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : test_converter.cpp
 *   Project  : Wabi II
 *   Description: Test cases for encoder
 *
 *   Created  : 2015/04/13
 *   Author   : Yang Du
 ****************************************************************************/

#include <string>
#include <vector>
#include <gtest/gtest.h>
#include <boost/algorithm/string.hpp>
#include "quickfix/SessionSettings.h"
#include "quickfix/Message.h"
//#include "hkex/fix50sp2/NewOrderSingle.h"
#include "test_converter.hpp"

TEST(ConverterTest, SetTansactTime) {
  FIX::Message message;
  FIXProxy::Converter::setTransactTime(message, 3, true);
  std::string transactTime = message.getField(60);
  EXPECT_EQ (21, transactTime.length());
}

TEST(ConverterTest, GetMsgTypeTagSuccess) {
  const std::string messageStr = "8=FIXT.1.1;9=216;35=CV;34=159;49=HKEXCCCO;52=20150921-03:20:19.085;56=CO99999901;1128=9;893=Y;1511=0;1512=2;1770=40;1771=144280561915566521;1772=1;1671=1;1691=1123;1692=D;1693=1;1773=1;1774=Y;1775=0;1776=2;1310=2;1301=ASHR;1301=ASZR;10=147;";

  std::string msgType = FIXProxy::Converter::getMsgType(messageStr);
  EXPECT_STREQ ("CV", msgType.c_str());
}

TEST(ConverterTest, GetMsgTypeStringSuccess) {
  const std::string messageStr = "BeginString=FIXT.1.1;BodyLength=216;MsgType=CV;MsgSeqNum=159;SenderCompID=HKEXCCCO;SendingTime=20150921-03:20:19.085;TargetCompID=CO99999901;ApplVerID=9;LastFragment=Y;RequestResult=0;TotNoPartyList=2;EntitlementsRequestID=40;EntitlementsReportID=144280561915566521;NoPartyEntitlements=1;NoPartyDetails=1;PartyDetailID=1123;PartyDetailIDSource=D;PartyDetailRole=1;NoEntitlements=1;EntitlementIndicator=Y;EntitlementType=0;EntitlementID=2;NoMarketSegments=2;MarketID=ASHR;MarketID=ASZR;CheckSum=147;";

  std::string msgType = FIXProxy::Converter::getMsgType(messageStr);
  EXPECT_STREQ ("CV", msgType.c_str());
}

TEST(ConverterTest, GetMsgTypeFail) {
  const std::string messageStr = "8=FIXT.1.1;9=216;34=159;49=HKEXCCCO;52=20150921-03:20:19.085;56=CO99999901;1128=9;893=Y;1511=0;1512=2;1770=40;1771=144280561915566521;1772=1;1671=1;1691=1123;1692=D;1693=1;1773=1;1774=Y;1775=0;1776=2;1310=2;1301=ASHR;1301=ASZR;10=147;";

  std::string msgType = FIXProxy::Converter::getMsgType(messageStr);
  EXPECT_STREQ ("", msgType.c_str());
}

TEST(ConverterTest, GetBeginStringTagSuccess) {
  const std::string messageStr = "8=FIXT.1.1;9=216;35=CV;34=159;49=HKEXCCCO;52=20150921-03:20:19.085;56=CO99999901;1128=9;893=Y;1511=0;1512=2;1770=40;1771=144280561915566521;1772=1;1671=1;1691=1123;1692=D;1693=1;1773=1;1774=Y;1775=0;1776=2;1310=2;1301=ASHR;1301=ASZR;10=147;";

  std::string beginString = FIXProxy::Converter::getBeginString(messageStr);
  EXPECT_STREQ ("FIXT.1.1", beginString.c_str());
}

TEST(ConverterTest, GetBeginStringStringSuccess) {
  const std::string messageStr = "BeginString=FIXT.1.1;BodyLength=216;MsgType=CV;MsgSeqNum=159;SenderCompID=HKEXCCCO;SendingTime=20150921-03:20:19.085;TargetCompID=CO99999901;ApplVerID=9;LastFragment=Y;RequestResult=0;TotNoPartyList=2;EntitlementsRequestID=40;EntitlementsReportID=144280561915566521;NoPartyEntitlements=1;NoPartyDetails=1;PartyDetailID=1123;PartyDetailIDSource=D;PartyDetailRole=1;NoEntitlements=1;EntitlementIndicator=Y;EntitlementType=0;EntitlementID=2;NoMarketSegments=2;MarketID=ASHR;MarketID=ASZR;CheckSum=147;";

  std::string beginString = FIXProxy::Converter::getBeginString(messageStr);
  EXPECT_STREQ ("FIXT.1.1", beginString.c_str());
}

TEST(ConverterTest, GetBeginStringFail) {
  const std::string messageStr = "9=216;35=CV;34=159;49=HKEXCCCO;52=20150921-03:20:19.085;56=CO99999901;1128=9;893=Y;1511=0;1512=2;1770=40;1771=144280561915566521;1772=1;1671=1;1691=1123;1692=D;1693=1;1773=1;1774=Y;1775=0;1776=2;1310=2;1301=ASHR;1301=ASZR;10=147;";

  std::string beginString = FIXProxy::Converter::getBeginString(messageStr);
  EXPECT_STREQ ("", beginString.c_str());
}

TEST(ConverterTest, GetSenderCompIDTagSuccess) {
  const std::string messageStr = "8=FIXT.1.1;9=216;35=CV;34=159;49=HKEXCCCO;52=20150921-03:20:19.085;56=CO99999901;1128=9;893=Y;1511=0;1512=2;1770=40;1771=144280561915566521;1772=1;1671=1;1691=1123;1692=D;1693=1;1773=1;1774=Y;1775=0;1776=2;1310=2;1301=ASHR;1301=ASZR;10=147;";

  std::string senderCompID = FIXProxy::Converter::getSenderCompID(messageStr);
  EXPECT_STREQ ("HKEXCCCO", senderCompID.c_str());
}

TEST(ConverterTest, GetSenderCompIDStringSuccess) {
  const std::string messageStr = "BeginString=FIXT.1.1;BodyLength=216;MsgType=CV;MsgSeqNum=159;SenderCompID=HKEXCCCO;SendingTime=20150921-03:20:19.085;TargetCompID=CO99999901;ApplVerID=9;LastFragment=Y;RequestResult=0;TotNoPartyList=2;EntitlementsRequestID=40;EntitlementsReportID=144280561915566521;NoPartyEntitlements=1;NoPartyDetails=1;PartyDetailID=1123;PartyDetailIDSource=D;PartyDetailRole=1;NoEntitlements=1;EntitlementIndicator=Y;EntitlementType=0;EntitlementID=2;NoMarketSegments=2;MarketID=ASHR;MarketID=ASZR;CheckSum=147;";

  std::string senderCompID = FIXProxy::Converter::getSenderCompID(messageStr);
  EXPECT_STREQ ("HKEXCCCO", senderCompID.c_str());
}

TEST(ConverterTest, GetSenderCompIDFail) {
  const std::string messageStr = "8=FIXT.1.1;9=216;35=CV;34=159;52=20150921-03:20:19.085;56=CO99999901;1128=9;893=Y;1511=0;1512=2;1770=40;1771=144280561915566521;1772=1;1671=1;1691=1123;1692=D;1693=1;1773=1;1774=Y;1775=0;1776=2;1310=2;1301=ASHR;1301=ASZR;10=147;";

  std::string senderCompID = FIXProxy::Converter::getSenderCompID(messageStr);
  EXPECT_STREQ ("", senderCompID.c_str());
}

TEST(ConverterTest, GetTargetCompIDTagSuccess) {
  const std::string messageStr = "8=FIXT.1.1;9=216;35=CV;34=159;49=HKEXCCCO;52=20150921-03:20:19.085;56=CO99999901;1128=9;893=Y;1511=0;1512=2;1770=40;1771=144280561915566521;1772=1;1671=1;1691=1123;1692=D;1693=1;1773=1;1774=Y;1775=0;1776=2;1310=2;1301=ASHR;1301=ASZR;10=147;";

  std::string targetCompID = FIXProxy::Converter::getTargetCompID(messageStr);
  EXPECT_STREQ ("CO99999901", targetCompID.c_str());
}

TEST(ConverterTest, GetTargetCompIDStringSuccess) {
  const std::string messageStr = "BeginString=FIXT.1.1;BodyLength=216;MsgType=CV;MsgSeqNum=159;SenderCompID=HKEXCCCO;SendingTime=20150921-03:20:19.085;TargetCompID=CO99999901;ApplVerID=9;LastFragment=Y;RequestResult=0;TotNoPartyList=2;EntitlementsRequestID=40;EntitlementsReportID=144280561915566521;NoPartyEntitlements=1;NoPartyDetails=1;PartyDetailID=1123;PartyDetailIDSource=D;PartyDetailRole=1;NoEntitlements=1;EntitlementIndicator=Y;EntitlementType=0;EntitlementID=2;NoMarketSegments=2;MarketID=ASHR;MarketID=ASZR;CheckSum=147;";

  std::string targetCompID = FIXProxy::Converter::getTargetCompID(messageStr);
  EXPECT_STREQ ("CO99999901", targetCompID.c_str());
}

TEST(ConverterTest, GetTargetCompIDFail) {
  const std::string messageStr = "8=FIXT.1.1;9=216;35=CV;34=159;49=HKEXCCCO;52=20150921-03:20:19.085;1128=9;893=Y;1511=0;1512=2;1770=40;1771=144280561915566521;1772=1;1671=1;1691=1123;1692=D;1693=1;1773=1;1774=Y;1775=0;1776=2;1310=2;1301=ASHR;1301=ASZR;10=147;";

  std::string targetCompID = FIXProxy::Converter::getTargetCompID(messageStr);
  EXPECT_STREQ ("", targetCompID.c_str());
}

TEST(ConverterTest, RemoveFieldTag) {
  const std::string messageStr = "8=FIXT.1.1;9=216;35=CV;34=159;49=HKEXCCCO;52=20150921-03:20:19.085;56=CO99999901;1128=9;893=Y;1511=0;1512=2;1770=40;1771=144280561915566521;1772=1;1671=1;1691=1123;1692=D;1693=1;1773=1;1774=Y;1775=0;1776=2;1310=2;1301=ASHR;1301=ASZR;10=147;";

  std::string msgStrAfter = FIXProxy::Converter::removeField(messageStr, "49");
  std::cout << "Message before remove: " << messageStr << std::endl;
  std::cout << "Message after remove: " << msgStrAfter << std::endl;

  size_t found = msgStrAfter.find(";49=");

  EXPECT_EQ (std::string::npos, found);
}

TEST(ConverterTest, RemoveFieldString) {
  const std::string messageStr = "BeginString=FIXT.1.1;BodyLength=216;MsgType=CV;MsgSeqNum=159;SenderCompID=HKEXCCCO;SendingTime=20150921-03:20:19.085;TargetCompID=CO99999901;ApplVerID=9;LastFragment=Y;RequestResult=0;TotNoPartyList=2;EntitlementsRequestID=40;EntitlementsReportID=144280561915566521;NoPartyEntitlements=1;NoPartyDetails=1;PartyDetailID=1123;PartyDetailIDSource=D;PartyDetailRole=1;NoEntitlements=1;EntitlementIndicator=Y;EntitlementType=0;EntitlementID=2;NoMarketSegments=2;MarketID=ASHR;MarketID=ASZR;CheckSum=147;";

  std::string msgStrAfter = FIXProxy::Converter::removeField(messageStr, "TargetCompID");
  std::cout << "Message before remove: " << messageStr << std::endl;
  std::cout << "Message after remove: " << msgStrAfter << std::endl;

  size_t found = msgStrAfter.find(";TargetCompID=");

  EXPECT_EQ (std::string::npos, found);
}

// empty string to FIX message
TEST(ConverterTest, EmptyStringToFIXMessage) {
  const std::string messageText = "";
  std::string exceptionDesc = "";
  FIX::Message message = FIXProxy::Converter::toFIXMessage<FIX44::NewOrderSingle>(messageText);
  try
  {
    std::string expectedBeginString = message.getHeader().getField(8);
    std::string expectedSenderCompID = message.getHeader().getField(49);
    std::string expectedTargetCompID = message.getHeader().getField(56);
    std::string expectedClOrdID = message.getField(11);
    std::string expectedSymbol = message.getField(55);
  }
  catch (std::exception& e)
  {
    exceptionDesc = e.what();
  }
  ASSERT_STREQ ("Field not found", exceptionDesc.c_str());
}

// empty string to FIX message
TEST(ConverterTest, EmptyStringToFIXMessage2) {
  const std::string messageText = "   ;";
  FIX::Message message = FIXProxy::Converter::toFIXMessage<FIX44::NewOrderSingle>(messageText);
  std::string exceptionDesc = "";
  try
  {
    std::string expectedBeginString = message.getHeader().getField(8);
    std::string expectedSenderCompID = message.getHeader().getField(49);
    std::string expectedTargetCompID = message.getHeader().getField(56);
    std::string expectedClOrdID = message.getField(11);
    std::string expectedSymbol = message.getField(55);
  }
  catch (std::exception& e)
  {
    exceptionDesc = e.what();
  }
  ASSERT_STREQ ("Field not found", exceptionDesc.c_str());
}

// comma sperated string to FIX message
TEST(ConverterTest, CommaSperatedStringToFIXMessage) {
  const std::string messageText = "8=FIX.4.4;35=D;34=2;49=CLIENT2;52=20150409-08:55:06.409;56=EXECUTOR;60=20150409-08:55:06;1=Q00100002;11=jp5_qXm2TO0KUL-t3mDyDQ;38=8000;44=150.10;54=1;55=0001.hk;1812=1;1813=101;1814=1;";

  FIX::Message message = FIXProxy::Converter::toFIXMessage<FIX44::NewOrderSingle>(messageText);
  std::string expectedBeginString = message.getHeader().getField(8);
  std::string expectedSenderCompID = message.getHeader().getField(49);
  std::string expectedTargetCompID = message.getHeader().getField(56);
  std::string expectedClOrdID = message.getField(11);
  std::string expectedSymbol = message.getField(55);

  ASSERT_STREQ ("FIX.4.4", expectedBeginString.c_str());
  ASSERT_STREQ ("CLIENT2", expectedSenderCompID.c_str());
  ASSERT_STREQ ("EXECUTOR", expectedTargetCompID.c_str());
  ASSERT_STREQ ("jp5_qXm2TO0KUL-t3mDyDQ", expectedClOrdID.c_str());
  ASSERT_STREQ ("0001.hk", expectedSymbol.c_str());
}

// comma sperated string to FIX message
TEST(ConverterTest, CommaSperatedStringToFIXMessageWithSC) {
  const std::string messageText = "8=FIX.4.4;35=D;34=2;49=CLIENT2;52=20150409-08<sc>55<sc>06.409;56=EXECUTOR;60=20150409-08:55:06;1=Q00100<sc>002;11=jp5_qXm2TO0KUL-t3mDyDQ;38=8000;44=150.10;54=1;55=0001.hk;1812=1;1813=101;1814=1;";

  FIX::Message message = FIXProxy::Converter::toFIXMessage<FIX44::NewOrderSingle>(messageText);
  std::string expectedBeginString = message.getHeader().getField(8);
  std::string expectedSenderCompID = message.getHeader().getField(49);
  std::string expectedTargetCompID = message.getHeader().getField(56);
  std::string expectedClOrdID = message.getField(11);
  std::string expectedSymbol = message.getField(55);
  std::string expectedSendingTime = message.getHeader().getField(52);
  //std::string expectedAccount = message.getHeader().getField(1);
  ASSERT_STREQ ("FIX.4.4", expectedBeginString.c_str());
  ASSERT_STREQ ("CLIENT2", expectedSenderCompID.c_str());
  ASSERT_STREQ ("EXECUTOR", expectedTargetCompID.c_str());
  ASSERT_STREQ ("jp5_qXm2TO0KUL-t3mDyDQ", expectedClOrdID.c_str());
  ASSERT_STREQ ("0001.hk", expectedSymbol.c_str());
  ASSERT_STREQ ("20150409-08;55;06.409", expectedSendingTime.c_str());
  //ASSERT_STREQ ("Q00100;002", expectedAccount.c_str());
}

// space sperated string to FIX message
TEST(ConverterTest, SpaceSperatedStringToFIXMessage) {
  const std::string messageText = "8=FIX.4.4;9=224;35=D;34=78;49=CLIENT2;52=20150630-02:41:40.316;56=EXECUTOR;1128=9;11=jp5_qXm2TO0KUL-t3mDyDQ;38=4000;40=2;44=30;55=0001.hk;60=20150630-02:41:40.301;102=0;434=1;453=1;448=1123;447=D;452=1;58=new order single;";

  FIX::Message message = FIXProxy::Converter::toFIXMessage<FIX44::NewOrderSingle>(messageText);
  std::string expectedBeginString = message.getHeader().getField(8);
  std::string expectedSenderCompID = message.getHeader().getField(49);
  std::string expectedTargetCompID = message.getHeader().getField(56);
  std::string expectedClOrdID = message.getField(11);
  std::string expectedSymbol = message.getField(55);
  ASSERT_STREQ ("FIX.4.4", expectedBeginString.c_str());
  ASSERT_STREQ ("CLIENT2", expectedSenderCompID.c_str());
  ASSERT_STREQ ("EXECUTOR", expectedTargetCompID.c_str());
  ASSERT_STREQ ("jp5_qXm2TO0KUL-t3mDyDQ", expectedClOrdID.c_str());
  ASSERT_STREQ ("0001.hk", expectedSymbol.c_str());
}

TEST(ConverterTest, ToString) {
  const std::string messageText = "8=FIX.4.4;35=D;34=2;49=CLIENT2;52=20150409-08:55:06.409;56=EXECUTOR;60=20150409-08:55:06;1=Q00100002;11=jp5_qXm2TO0KUL-t3mDyDQ;38=8000;44=150.10;54=1;55=0001.hk;";
  FIXProxy::Converter::FieldValuePairs messageAttrs;

  // split to tag=value pairs and save to a vector
  std::vector<std::string> messageAttrsVector;
  boost::algorithm::split(messageAttrsVector,
                          messageText,
                          boost::algorithm::is_any_of(" ;|"),
                          boost::token_compress_on);

  for (auto const& pair : messageAttrsVector)
  {
    std::vector<std::string> tagValuePair;
    boost::algorithm::split(tagValuePair,
                            pair,
                            boost::algorithm::is_any_of("="));

    if (tagValuePair.size() >= 2)
    {
      std::string firstValue = boost::algorithm::trim_copy(tagValuePair[0]);
      std::string secondValue = boost::algorithm::trim_copy(tagValuePair[1]);
      messageAttrs.push_back(FIXProxy::Converter::FieldValuePair(firstValue, secondValue));
    }
  }

  const std::string messageTextNew = FIXProxy::Converter::toString(messageAttrs);
  std::size_t found = messageTextNew.find("8=FIX.4.4");
  EXPECT_NE (found, std::string::npos);
  found = messageTextNew.find("56=EXECUTOR");
  EXPECT_NE (found, std::string::npos);
  found = messageTextNew.find("11=jp5_qXm2TO0KUL-t3mDyDQ");
  EXPECT_NE (found, std::string::npos);

}

TEST(ConverterTest, ParseJSONRequest1) {
  const std::string jsonRequest = "{ \"action\" : \"send\", \"message\": { \"tags\": [ { \"8\": \"FIX.4.4\" }, { \"9\": \"187\" }, { \"35\": \"8\" }, { \"34\": \"38\" }, { \"49\": \"EXECUTOR\" }, { \"52\": \"20150522-11:29:16.174\" }, { \"56\": \"CLIENT2\" }, { \"1\": \"Q1234567890\" }, { \"6\": \"30\" }, { \"11\": \"9_5LGTqiyaDB_PVIg3HkUw\" }, { \"14\": \"30000\" }, { \"17\": \"15\" }, { \"20\": \"0\" }, { \"31\": \"30\" }, { \"32\": \"30000\" }, { \"37\": \"15\" }, { \"38\": \"30000\" }, { \"39\": \"2\" }, { \"54\": \"1\" }, { \"55\": \"0007.hk\" }, { \"150\": \"2\" }, { \"151\": \"0\" }, { \"10\": \"044\" } ] }, \"time\" : \"2015-05-22 19:28:19.972954\" }";
  std::string action;
  std::string message;
  std::string time;

  FIXProxy::Converter::parseJSONRequest(jsonRequest, action, message, time);
  std::cout << "Action: " << action << '\n';
  std::cout << "Message: " << message << '\n';
  std::cout << "Time: " << time << '\n';

  ASSERT_STREQ ("send", action.c_str());
  ASSERT_STREQ ("2015-05-22 19:28:19.972954", time.c_str());

  std::size_t found = message.find("11=9_5LGTqiyaDB_PVIg3HkUw");
  EXPECT_NE (found, std::string::npos);
}

TEST(ConverterTest, ParseJSONRequestWithSC) {
  const std::string jsonRequest = "{ \"action\" : \"send\", \"message\": { \"tags\": [ { \"8\": \"FIX.4.4\" }, { \"9\": \"187\" }, { \"35\": \"8\" }, { \"34\": \"38\" }, { \"49\": \"EXECUTOR\" }, { \"52\": \"20150522-11;29;16.174\" }, { \"56\": \"CLIENT2\" }, { \"1\": \"Q123456;7890\" }, { \"6\": \"30\" }, { \"11\": \"9_5LGTqiyaDB_PVIg3HkUw\" }, { \"14\": \"30000\" }, { \"17\": \"15\" }, { \"20\": \"0\" }, { \"31\": \"30\" }, { \"32\": \"30000\" }, { \"37\": \"15\" }, { \"38\": \" \" }, { \"39\": \"2\" }, { \"54\": \"1\" }, { \"55\": \"0007.hk\" }, { \"150\": \"2\" }, { \"151\": \"0\" }, { \"10\": \"<space><space><space>\" } ] }, \"time\" : \"2015-05-22 19:28:19.972954\" }";
  std::string action;
  std::string message;
  std::string time;

  FIXProxy::Converter::parseJSONRequest(jsonRequest, action, message, time);
  std::cout << "Action: " << action << '\n';
  std::cout << "Message: " << message << '\n';
  std::cout << "Time: " << time << '\n';

  ASSERT_STREQ ("send", action.c_str());
  ASSERT_STREQ ("2015-05-22 19:28:19.972954", time.c_str());

  std::size_t found = message.find("11=9_5LGTqiyaDB_PVIg3HkUw");
  EXPECT_NE (found, std::string::npos);
}

TEST(ConverterTest, ParseInvalidJSONRequest) {
  const std::string jsonRequest = "{ \"action\" : \"send\", \"message\": { \"tags\": { \"8\": \"FIX.4.4\", \"9\": \"187\", \"35\": \"8\", \"34\": \"38\", \"49\": \"EXECUTOR\", \"52\": \"20150522-11:29:16.174\", \"56\": \"CLIENT2\", \"1\": \"Q1234567890\", \"6\": \"30\", \"11\": \"9_5LGTqiyaDB_PVIg3HkUw\", \"14\": \"30000\", \"17\": \"15\", \"20\": \"0\", \"31\": \"30\", \"32\": \"30000\", \"37\": \"15\", \"38\": \"30000\", \"39\": \"2\", \"54\": \"1\", \"55\": \"0007.hk\", \"150\": \"2\", \"151\": \"0\", \"10\": \"044\" } }, \"time\" : \"2015-05-22 19:28:19.972954\"";
  std::string action;
  std::string message;
  std::string time;

  bool success = FIXProxy::Converter::parseJSONRequest(jsonRequest, action, message, time);

  EXPECT_FALSE (success);
}

TEST(ConverterTest, EncodeJSONResponse) {
  const std::string response = "8=FIX.4.4;9=187;35=8;34=38;49=EXECUTOR;52=20150522-11:29:16.174;56=CLIENT2;1=Q1234567890;6=30;11=9_5LGTqiyaDB_PVIg3HkUw;14=30000;17=15;20=0;31=30;32=30000;37=15;38=30000;39=2;54=1;55=0007.hk;150=2;151=0;10=044;";
  const std::string responseText = "BeginString=FIX.4.4;BodyLength=187;MsgType=8;MsgSeqNum=38;SenderCompID=EXECUTOR;SendingTime=20150522-11:29:16.174;TargetCompID=CLIENT2;Account=Q1234567890;AvgPx=30;ClOrdID=9_5LGTqiyaDB_PVIg3HkUw;CumQty=30000;ExecID=15;ExecTransType=0;LastPx=30;LastShares=30000;OrderID=15;OrderQty=30000;OrdStatus=2;Side=1;Symbol=0007.hk;ExecType=2;LeavesQty=0;CheckSum=044;";

  const std::string binText = "";
  const std::string binary = "";
  const std::string time = "2015-07-28 16:03:18.410103";
  const std::string grpTags = "";
  FIXProxy::MessageLog::Message msg(time, response, responseText, binText, binary, grpTags);
  const std::string jsonResponseStr = FIXProxy::Converter::encodeJSONResponse(msg);

  std::cout << "JSON Response: " << jsonResponseStr << '\n';

  std::size_t found = jsonResponseStr.find("\"11\": \"9_5LGTqiyaDB_PVIg3HkUw\"");
  EXPECT_NE (found, std::string::npos);

  found = jsonResponseStr.find("\"TargetCompID\": \"CLIENT2\"");
  EXPECT_NE (found, std::string::npos);

  found = jsonResponseStr.find("\"CheckSum\": \"044\"");
  EXPECT_NE (found, std::string::npos);
}

//// comma sperated string to FIX message
//TEST(ConverterTest, AddPartyGroup) {
//  const std::string messageText = "8=FIX.4.4;35=D;34=2;49=CLIENT2;52=20150409-08:55:06.409;56=EXECUTOR;60=20150409-08:55:06;1=Q00100002;11=jp5_qXm2TO0KUL-t3mDyDQ;38=8000;44=150.10;54=1;55=0001.hk;";
//
//  FIX::Message message = FIXProxy::Converter::toFIXMessage<FIX50SP2::HKExNewOrderSingle>(messageText);
//  FIXProxy::Converter::addPartyGroup(static_cast<FIX50SP2::HKExNewOrderSingle&>(message), std::string("453=448:1122,447:D,452:1;"));
//  std::string expectedParties = message.getField(453);
//  ASSERT_STREQ ("1", expectedParties.c_str());
//}

//// comma sperated string to FIX message
//TEST(ConverterTest, AddDisclosureGroup) {
//  const std::string messageText = "8=FIX.4.4;35=D;34=2;49=CLIENT2;52=20150409-08:55:06.409;56=EXECUTOR;60=20150409-08:55:06;1=Q00100002;11=jp5_qXm2TO0KUL-t3mDyDQ;38=8000;44=150.10;54=1;55=0001.hk;";
//
//  FIX::Message message = FIXProxy::Converter::toFIXMessage<FIX50SP2::HKExNewOrderSingle>(messageText);
//  FIXProxy::Converter::addDisclosureGroup(static_cast<FIX50SP2::HKExNewOrderSingle&>(message), std::string("1812=1814:1,1813:100;"));
//  std::string expectedDisclosureInstructions = message.getField(1812);
//  ASSERT_STREQ ("1", expectedDisclosureInstructions.c_str());
//}

TEST(ConverterTest, ProcessGroupText) {
  const std::string dataDictionaryFile = "hkex/FIX50SP2.xml";
  const FIX::DataDictionary dataDictionary(dataDictionaryFile);
  const std::string appDataDictionaryFile = "hkex/FIXT11.xml";
  const FIX::DataDictionary appDataDictionary(appDataDictionaryFile);
  const std::string expectedString = FIXProxy::Converter::processGroupText(std::string("PartyID:1122,PartyIDSource:D,PartyRole:1"), dataDictionary, appDataDictionary);
  ASSERT_STREQ ("448:1122,447:D,452:1", expectedString.c_str());
}

TEST(ConverterTest, ToFieldVaulePairs) {
  const std::string messageStr = "8=FIXT.1.1;9=216;35=CV;34=159;49=HKEXCCCO;52=20150921-03:20:19.085;56=CO99999901;1128=9;893=Y;1511=0;1512=2;1770=40;1771=144280561915566521;1772=1;1671=1;1691=1123;1692=D;1693=1;1773=1;1774=Y;1775=0;1776=2;1310=2;1301=ASHR;1301=ASZR;10=147;";

  FIXProxy::Converter::FieldValuePairs fieldValuePairs = FIXProxy::Converter::toFieldValuePairs(messageStr);
  std::cout << "Vector's size: " << fieldValuePairs.size() << std::endl;

  EXPECT_EQ(26, fieldValuePairs.size());

  const std::string dataDictionaryFile = "hkex/FIX50SP2.xml";
  const FIX::DataDictionary dataDictionary(dataDictionaryFile);
  const std::string appDataDictionaryFile = "hkex/FIXT11.xml";
  const FIX::DataDictionary appDataDictionary(appDataDictionaryFile);
  const std::string messageAttrs("PartyID=1122");

  FIXProxy::Converter::setMessageAttrs(fieldValuePairs,
                                       messageAttrs,
                                       dataDictionary,
                                       appDataDictionary);
  std::cout << "Size of vector: " << fieldValuePairs.size() << std::endl;

  EXPECT_EQ(27, fieldValuePairs.size());
}


TEST(ConverterTest, TokenizeGroupText) {
  const std::string groupText = "[Side:1,NoPartyIDs:[PartyID:1234,PartyIdSource:D,PartyRole:1],NoClearingInstructions:[ClearingInstruction:0]]";
  std::vector<std::string> vec = FIXProxy::Converter::tokenizeGroupText(groupText);
  EXPECT_TRUE(std::find(vec.begin(), vec.end(),
    "Side:1") != vec.end());
  EXPECT_TRUE(std::find(vec.begin(), vec.end(),
    "NoPartyIDs:[PartyID:1234,PartyIdSource:D,PartyRole:1]") != vec.end());
  EXPECT_TRUE(std::find(vec.begin(), vec.end(),
    "NoClearingInstructions:[ClearingInstruction:0]") != vec.end());
}

TEST(ConverterTest, IsGroup) {
  EXPECT_TRUE(FIXProxy::Converter::isGroup("NoPartyIDs"));
  EXPECT_TRUE(FIXProxy::Converter::isGroup("NoClearingInstructions"));
  EXPECT_TRUE(FIXProxy::Converter::isGroup("NoSides"));
  EXPECT_TRUE(FIXProxy::Converter::isGroup("NoDisclosureInstructions"));
  EXPECT_TRUE(FIXProxy::Converter::isGroup("NoQuoteEntries"));
  EXPECT_TRUE(FIXProxy::Converter::isGroup("453"));
  EXPECT_TRUE(FIXProxy::Converter::isGroup("552"));
  EXPECT_TRUE(FIXProxy::Converter::isGroup("1812"));
}

//TEST(ConverterTest, AddQuoteEntriesGroup1) {
//  const std::string messageText = "8=FIXT.1.1;35=Z;34=181;49=CLIENT2;52=20160428-08:56:26.284;56=EXECUTOR;1128=9;298=1;";
//
//  FIX::Message message = FIXProxy::Converter::toFIXMessage<FIX50SP2::QuoteCancel>(messageText);
//  FIXProxy::Converter::addQuoteEntriesGroup(static_cast<FIX50SP2::QuoteCancel&>(message), std::string("295=48:8101,22:8,207:XHKG"));
//  std::string expectedQuoteEntriesGroup= message.getField(295);
//
//  ASSERT_STREQ ("1", expectedQuoteEntriesGroup.c_str());
//}
//
//TEST(ConverterTest, AddQuoteEntriesGroup2) {
//  const std::string messageText = "8=FIXT.1.1;35=Z;34=181;49=CLIENT2;52=20160428-08:56:26.284;56=EXECUTOR;1128=9;298=1;295=48:8101,22:8,207:XHKG;";
//
//  FIX::Message message = FIXProxy::Converter::toFIXMessage<FIX50SP2::QuoteCancel>(messageText);
//  std::string expectedQuoteEntriesGroup= message.getField(295);
//
//  ASSERT_STREQ ("1", expectedQuoteEntriesGroup.c_str());
//}
//
//TEST(ConverterTest, AddQuoteEntriesGroup3) {
//  const std::string messageText = "8=FIXT.1.1;35=D;34=181;49=CLIENT2;52=20160428-08:56:26.284;56=EXECUTOR;1128=9;298=1;295=48:8101,22:8,207:XHKG;";
//
//  FIX::Message message = FIXProxy::Converter::toFIXMessage<FIX50SP2::HKExNewOrderSingle>(messageText);
//
//  std::string expectedQuoteEntriesGroup;
//  if (message.isSetField(295))
//  {
//    expectedQuoteEntriesGroup = message.getField(295);
//  }
//
//  ASSERT_TRUE (expectedQuoteEntriesGroup.empty());
//}
//
//TEST(ConverterTest, AddSideGroup1) {
//  const std::string messageText = "8=FIXT.1.1;35=AE;34=2;49=CLIENT2;52=20150409-08:55:06.409;56=EXECUTOR;60=20150409-08:55:06;";
//
//  FIX::Message message = FIXProxy::Converter::toFIXMessage<FIX50SP2::TradeCaptureReport>(messageText);
//  FIXProxy::Converter::addSideGroup(static_cast<FIX50SP2::TradeCaptureReport&>(message), std::string("[54:1,453:[448:1234,447:D,452:1],576:[577:0]]"));
//  std::string expectedSideGroup = message.getField(552);
//
//  ASSERT_STREQ ("1", expectedSideGroup.c_str());
//}
//
//TEST(ConverterTest, AddSideGroup2) {
//  const std::string messageText = "8=FIXT.1.1;35=AE;34=2;49=CLIENT2;52=20150409-08:55:06.409;56=EXECUTOR;60=20150409-08:55:06;552=[54:1,453:[448:1234,447:D,452:1],576:[577:0]];";
//
//  FIX::Message message = FIXProxy::Converter::toFIXMessage<FIX50SP2::TradeCaptureReport>(messageText);
//  std::string expectedSideGroup = message.getField(552);
//
//  ASSERT_STREQ ("1", expectedSideGroup.c_str());
//}
//
//TEST(ConverterTest, AddSideGroup3) {
//  const std::string messageText = "8=FIXT.1.1;35=D;34=2;49=CLIENT2;52=20150409-08:55:06.409;56=EXECUTOR;60=20150409-08:55:06;552=[54:1,453:[448:1234,447:D,452:1],576:[577:0]];";
//
//  FIX::Message message = FIXProxy::Converter::toFIXMessage<FIX50SP2::HKExNewOrderSingle>(messageText);
//
//  std::string expectedSideGroup;
//  if (message.isSetField(552))
//  {
//    expectedSideGroup = message.getField(552);
//  }
//
//  ASSERT_TRUE(expectedSideGroup.empty());
//}
