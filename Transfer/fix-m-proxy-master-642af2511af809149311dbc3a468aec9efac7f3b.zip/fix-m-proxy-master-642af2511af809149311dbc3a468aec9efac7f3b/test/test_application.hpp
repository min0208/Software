/****************************************************************************
 *   Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : test_application.hpp
 *   Project  : Wabi III
 *   Description: Test cases for application class
 *
 *   Created  : 2015/06/09
 *   Author   : Yang Du
 ****************************************************************************/

#include "../src/Application.h"
#include "../src/Utils.h"

#ifndef TEST_APPLICATION_H
#define TEST_APPLICATION_H


#endif // TEST_APPLICATION_H
