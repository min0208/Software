/****************************************************************************
 *   Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : test_converter.hpp
 *   Project  : Wabi II
 *   Description: Test cases for encoder
 *
 *   Created  : 2015/04/13
 *   Author   : Yang Du
 ****************************************************************************/

#include "../src/Converter.h"

#ifndef TEST_CONVERTER
#define TEST_CONVERTER


#endif // TEST_CONVERTER
