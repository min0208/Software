/****************************************************************************
 *   Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : test_session.hpp
 *   Project  : Wabi III
 *   Description: Test cases for session class
 *
 *   Created  : 2015/06/09
 *   Author   : Yang Du
 ****************************************************************************/

#include "../src/Application.h"
#include "../src/Session.h"

#ifndef TEST_SESSION_H
#define TEST_SESSION_H


#endif // TEST_SESSION_H
