/****************************************************************************
 *     Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : converter.hpp
 *   Project  : Wabi II
 *   Description: encoder header file
 *
 *   Created  : 2015/03/17
 *   Author   : Yang Du
 ****************************************************************************/

#ifndef FIXPROXY_ENCODER_H
#define FIXPROXY_ENCODER_H

#include <string>
#include <vector>
#include <map>
#include <cstdint>
#include <mutex>

// quick-fix
#include "quickfix/Session.h"
#include "quickfix/Message.h"

// protocol FIX44
#include "lme/fix44/NewOrderSingle.h"
#include "lme/fix44/OrderCancelReplaceRequest.h"
#include "lme/fix44/OrderCancelRequest.h"
#include "lme/fix44/OrderStatusRequest.h"
#include "lme/fix44/TradeCaptureReportRequest.h"
#include "quickfix/fix44/SecurityListRequest.h"

// // LMFI, LME Member FIX
#include "lme/fix44/NewTradeList.h"
#include "lme/fix44/TradeCancelRequest.h"
#include "lme/fix44/TradeMassStatusRequest.h"
#include "lme/fix44/DownloadRequest.h"

#include "lme/fix44/TradeExecutionReport.h"
#include "lme/fix44/TradeCancelReject.h"
#include "lme/fix44/RequestResponse.h"

#include "quickfix/fix44/News.h"
#include "lme/fix44/SecurityDefinition.h"
#include "lme/fix44/MemberDefinition.h"

// boost
#include <boost/algorithm/string.hpp>
#include <boost/regex.hpp>
#include <boost/mpl/set.hpp>

#include "Utils.h"
#include "MessageLog.h"

namespace FIXProxy
{
class Converter
{
    public:
    // typedefs
    typedef std::pair<std::string, std::string> FieldValuePair;
    typedef std::vector<FieldValuePair> FieldValuePairs;

    // convert ';' seperated string to FIX message
    template<class T>
    static T toFIXMessage(const std::string&) noexcept;

    // convert a map to FIX message
    template<class T>
    static T toFIXMessage(const FieldValuePairs&,
        const FIX::DataDictionary&) noexcept;

    // convert a map to string
    static std::string toString(const FieldValuePairs&,
                                const char delimiter = ';') noexcept;
    // set message transaction time
    static void setTransactTime(FIX::Message&,
                                int32_t,
                                bool overwrite = true) noexcept;

    // convert message string to FieldValuePairs
    static FieldValuePairs toFieldValuePairs(const std::string&,
                                      const std::string delimiter = ";") noexcept;

    // parse  a json string
    static bool parseJSONRequest(const std::string&,
                                 std::string&,
                                 std::string&,
                                 std::string&) noexcept;
    // encode a message to JSON string as response message
    static std::string encodeJSONResponse(
      const FIXProxy::MessageLog::Message&) noexcept;

    // save a string message to map
    static void setMessageAttrs(FieldValuePairs&,
                                const std::string&) noexcept;
    // save a string message to map and 
    // convert all possible Text Fields to integer fields
    static void setMessageAttrs(FieldValuePairs&,
                                const std::string&,
                                const FIX::DataDictionary&,
                                const FIX::DataDictionary&) noexcept;
    // Split group Text Fields in to a vector
    static std::vector<std::string> tokenizeGroupText(const std::string&
                                                    ) noexcept;

    // Check if a field is supported group or not
    static bool isGroup(const std::string& field) noexcept;

    // convert all possible group Text Fields to integer fields
    static std::string processGroupText(const std::string&,
                                        const FIX::DataDictionary&,
                                        const FIX::DataDictionary&) noexcept;

    template<class T, class G>
    static void addGroup(T&, const std::string&) noexcept;

    // Detail implementation 
    // Allow choose Party/Dsiclosure/QuoteEntries group implementation
    // based on a template boolean parameter.
    // Do nothing if the bool parameter evaluates to false
    struct Detail
    {
        // template declaration
        //  T: fix message type
        //  T: bool value for template specialization
        template<class T, bool>
        struct PartyHelper
        {
        };

        // template specializaton
        // to add a Party group to FIX message
        template<class T>
        struct PartyHelper<T, true>
        {
            static void addPartyGroup(T&, const std::string&) noexcept;
        };

        // template specializaton
        // to do nothing
        template<class T>
        struct PartyHelper<T, false>
        {
            static void addPartyGroup(T&, const std::string&) noexcept
            {
            }
        };

        // template declaration
        //  T: fix message type
        //  T: bool value for template specialization
        template<class T, bool>
        struct InstrumentLegsHelper
        {
        };

        // template specializaton
        // to add a TrdCapRptSideGrp group to FIX message
        template<class T>
        struct InstrumentLegsHelper<T, true>
        {
            static void addInstrumentLegsGroup(T&, const std::string&) noexcept;
        };

        // template specializaton to do nothing
        template<class T>
        struct InstrumentLegsHelper<T, false>
        {
            static void addInstrumentLegsGroup(T&, const std::string&) noexcept
            {
            }
        };

        // template declaration
        // T: fix message type
        // T: bool value for template specialization
        template<class T, bool>
        struct DatesHelper
        {
        };

        // template specializaton
        // to add a Dates group to FIX message
        template<class T>
        struct DatesHelper<T, true>
        {
            static void addDatesGroup(T&, const std::string&) noexcept;
        };

        // template specializaton to do nothing
        template<class T>
        struct DatesHelper<T, false>
        {
            static void addDatesGroup(T&, const std::string&) noexcept
            {
            }
        };

        // to add a TradeLeg 
        template<class T, bool>
        struct TradesHelper
        {
        };

        template<class T>
        struct TradesHelper<T, true>
        {
            static void addTradesGroup(T&, const std::string&) noexcept;
        };

        template<class T>
        struct TradesHelper<T, false>
        {
            static void addTradesGroup(T&, const std::string&) noexcept
            {
            }
        };

        // to add a TradeLeg 
        template<class T, bool>
        struct TradeLegsHelper
        {
        };

        template<class T>
        struct TradeLegsHelper<T, true>
        {
            static void addTradeLegsGroup(T&, const std::string&) noexcept;
        };

        template<class T>
        struct TradeLegsHelper<T, false>
        {
            static void addTradeLegsGroup(T&, const std::string&) noexcept
            {
            }
        };

    };

    // add a Party group to FIX message
    template<class T>
    static inline void addPartyGroup(T& message,
                                     const std::string& groupText) noexcept;

    // add a InstrumentLegs group to FIX message
    template<class T>
    static inline void addInstrumentLegsGroup(T& message,
                                              const std::string& groupText) noexcept;

    // add a Dates group to FIX message
    template<class T>
    static inline void addDatesGroup(T& message,
                                     const std::string& groupText) noexcept;

    // add a Trades group
    template<class T>
    static inline void addTradesGroup(T& message,
                                     const std::string& groupText) noexcept;
    // add a TradeLegs group
    template<class T>
    static inline void addTradeLegsGroup(T& message,
                                     const std::string& groupText) noexcept;

    // get a field value from a string message
    static std::string getFieldValue(const std::string&,
                                     const std::string&) noexcept;
    // remove a field value from a string message
    static std::string removeField(const std::string&,
                                   const std::string&) noexcept;
    // get msgType from string message
    static std::string getMsgType(const std::string&) noexcept;
    // get beginString from string message
    static std::string getBeginString(const std::string&) noexcept;
    // get SenderCompID from string message
    static std::string getSenderCompID(const std::string&) noexcept;
    // get TargetCompID from string message
    static std::string getTargetCompID(const std::string&) noexcept;
    // Get ID field based on a message type
    static std::string getIDField(const std::string&) noexcept;
    static std::string getIDFieldName(const std::string&) noexcept;

    private:
    // static mutex for read json
    static std::mutex readJsonMutex;
    // common header tags
    static const std::vector<std::string> headerTags_;
    static const int32_t                  clOrdIDField     = 11;
    static const int32_t                  trasactTimeField = 60;
};

// Parse PartyGroup from given group text
// and set all the given tags to the given message.
//
// The group text is expected to be in this format,
//   PartyID:1122,PartyIDSource:D,PartyRole:1
//   or
//   448:1122,447:D,452:1
//
template<class T>
void Converter::Detail::PartyHelper<T, true>::addPartyGroup(T& message,
  const std::string& groupText) noexcept
{
    addGroup<T, typename T::NoPartyIDs>(message, groupText);
}

// Only for OCG
// Parse Value Check Group from given group text
// and set all the given tags to the given message.
//
// The group text is expected to be in this format,
//   ValueCheckType:0,ValueCheckAction:1
//   or
//   1869:0,1870:1
//
template<class T>
void Converter::Detail::InstrumentLegsHelper<T, true>::addInstrumentLegsGroup(T& message,
  const std::string& groupText) noexcept
{
    addGroup<T, typename T::NoOfInstrumentLegs>(message, groupText);
}

// Only for OCG
// Parse Value Check Group from given group text
// and set all the given tags to the given message.
//
// The group text is expected to be in this format,
//   ValueCheckType:0,ValueCheckAction:1
//   or
//   1869:0,1870:1
//
template<class T>
void Converter::Detail::DatesHelper<T, true>::addDatesGroup(T& message,
  const std::string& groupText) noexcept
{
    addGroup<T, typename T::NoDates>(message, groupText);
}

template<class T>
void Converter::Detail::TradesHelper<T, true>::addTradesGroup(T& message,
  const std::string& groupText) noexcept
{
    addGroup<T, typename T::NoTrades>(message, groupText);
}

template<class T>
void Converter::Detail::TradeLegsHelper<T, true>::addTradeLegsGroup(T& message,
  const std::string& groupText) noexcept
{
    addGroup<T, typename T::NoLegs>(message, groupText);
}

// Add a Party group to FIX message/group
//
// If type T supports Party group, the group will be
// added the message, else do nothing.

template<class T>
void Converter::addPartyGroup(T& message, const std::string& groupText) noexcept
{
    // Types supports Party group
    typedef boost::mpl::set<FIX44::NewOrderSingle,
                            FIX44::OrderCancelReplaceRequest,
                            FIX44::TradeCaptureReportRequest,
                            FIX44::NewTradeList,
                            FIX44::TradeExecutionReport
                            > PartyGroupAllowedTypes;
    Detail::PartyHelper<T,
      boost::mpl::contains<PartyGroupAllowedTypes, T>::value
        >::addPartyGroup(message, groupText);
}

// Add a InstrumentLegs group to FIX message
//
// If type T supports InstrumentLegs group,
// the group will be added the message, else do nothing.
template<class T>
void Converter::addInstrumentLegsGroup(T& message,
                                       const std::string& groupText) noexcept
{
    // Types supports InstrumentLegs group
    typedef boost::mpl::set<FIX44::NewOrderSingle,
                            FIX44::OrderCancelReplaceRequest,
                            FIX44::OrderCancelRequest,
                            FIX44::OrderStatusRequest,
                            FIX44::TradeCaptureReportRequest,
                            FIX44::NewTradeList::NoTrades,
                            FIX44::TradeExecutionReport::NoTrades
                            > ClrInstGroupAllowedTypes;
    Detail::InstrumentLegsHelper<T,
      boost::mpl::contains<ClrInstGroupAllowedTypes, T>::value
        >::addInstrumentLegsGroup(message, groupText);
}

// Add a Dates group to FIX message
//
// If type T supports Dates group,
// the group will be added the message, else do nothing.
template<class T>
void Converter::addDatesGroup(T& message,
                              const std::string& groupText) noexcept
{
    // Types supports Dates group
    typedef boost::mpl::set<FIX44::TradeCaptureReportRequest
                            > ClrInstGroupAllowedTypes;
    Detail::DatesHelper<T,
      boost::mpl::contains<ClrInstGroupAllowedTypes, T>::value
        >::addDatesGroup(message, groupText);
}

template<class T>
void Converter::addTradesGroup(T& message,
                               const std::string& groupText) noexcept
{
    typedef boost::mpl::set<FIX44::NewTradeList,
                            FIX44::TradeExecutionReport> TradeAllowedTypes;
    Detail::TradesHelper<T,
        boost::mpl::contains<TradeAllowedTypes, T>::value
            >::addTradesGroup(message, groupText);
}



template<class T>
void Converter::addTradeLegsGroup(T& message,
                               const std::string& groupText) noexcept
{
    typedef boost::mpl::set<FIX44::NewTradeList::NoTrades,
                            FIX44::TradeExecutionReport::NoTrades> TradeLegsAllowedTypes;
    Detail::TradeLegsHelper<T,
        boost::mpl::contains<TradeLegsAllowedTypes, T>::value
            >::addTradeLegsGroup(message, groupText);
}
// Convert comma/space seperated string message to FIX message
// It treats the input message as a comma or pipe seperated string,
// and parse out each entry and save it to a vector,
// and then set to an message with type T.
//
// It parses session information (BeginString(8), SenderCompID(49), TargetCompID(56))
// from the given message text.
//
// It gets the data dictionaries from the session configuration.
// FIX50* has both transport and application data dictionaries. But FIX4*
// has only one data dictionary.
// The data dictionaries are for text field to integer convertion in
// function setMessageAttrs.
//
template<class T>
T Converter::toFIXMessage(const std::string& messageText) noexcept
{
    // get session with message session settings
    std::string beginString  = getBeginString(messageText);
    std::string senderCompID = getSenderCompID(messageText);
    std::string targetCompID = getTargetCompID(messageText);
    FIX::SessionID sessionID(beginString, senderCompID, targetCompID);

    // get session data dictionary
    FIX::DataDictionary dataDictionary;
    FIX::DataDictionary appDataDictionary;
    Utils::getSessionDataDictionaries(sessionID,
                                      dataDictionary,
                                      appDataDictionary);

    // initinize a field/value pair vector
    // for storing message attributes
    // split a message string and save to a vector
    std::vector<std::string> messageAttrsVector;
    boost::algorithm::split(messageAttrsVector,
                            messageText,
                            boost::algorithm::is_any_of(";"),
                            boost::token_compress_on);

    // iterate messageAttrsVector 
    // and save message attributes to messageAttrs
    FieldValuePairs fvPairs;
    auto parseFunc = [&](const std::string& messageText)
    {
        setMessageAttrs(fvPairs,
                        messageText,
                        dataDictionary,
                        appDataDictionary);
    };

    // save message attribues to fvPairs
    std::for_each(messageAttrsVector.begin(),
                  messageAttrsVector.end(), parseFunc);

    // generate FIX message with type T
    T message = toFIXMessage<T>(fvPairs, dataDictionary);

    return std::move(message);
}

// Convert messageAttrs to FIX message
// It convert a vector of <tag, value> pair to a message with type T.
//
// And it can handle group tag NoPartyIDs and NoDisclosureInstructions.
// The value format of those 2 groups should be like
//   PartyID:1122,PartyIDSource:D,PartyRole:1
//
template<class T>
T Converter::toFIXMessage(const FieldValuePairs& fvPairs,
                          const FIX::DataDictionary& dataDictionary) noexcept
{
    T message;
    // get message header
    FIX::Header& header = message.getHeader();
    for (auto const& pair : fvPairs)
    {
        int32_t field = Utils::strToField(pair.first);
        if (!field)
        {
            continue;
        }
        
        // check if it's header tag
        if (dataDictionary.isHeaderField(field)
          or std::find(headerTags_.begin(),
                       headerTags_.end(),
                       pair.first) != headerTags_.end())
        {
            header.setField(field, Utils::showSpecChars(pair.second));

            if (pair.second.empty())
            {
                header.removeField(field);
            }
        }
        // set it to message body if not header tag
        else
        {
            // group NoPartyIDs
            if (FIX::FIELD::NoPartyIDs == field)
            {
                addPartyGroup(message, pair.second);
            }
            else if (FIX::FIELD::NoTrades == field)
            {
                addTradesGroup(message, pair.second);
            }
            // group NoOfInstrumentLegs
            else if (FIX::FIELD::NoOfInstrumentLegs == field)
            {
                addInstrumentLegsGroup(message, pair.second);
            }
            // group NoDates
            else if (FIX::FIELD::NoDates == field)
            {
                addDatesGroup(message, pair.second);
            }
            else if (FIX::FIELD::NoLegs == field)
            {
                addTradeLegsGroup(message, pair.second);
            }
            else
            {
                // set a normal tag
                try
                {
                    message.setField(field, Utils::showSpecChars(pair.second));
                }
                catch(...)
                {
                    std::cout << "Error: failed to set message tag: " << field << std::endl;
                }

                if (pair.second.empty())
                {
                    message.removeField(field);
                }
            }
        }
    }

    return std::move(message);
}

// Parse A FIX Repeating Group from given group text
// and set all the given tags to the given message.
//
// The group text is expected to be in this format,
//   PartyID:1122,PartyIDSource:D,PartyRole:1
//   or
//   448:1122,447:D,452:1
//
template<class T, class G>
void Converter::addGroup(T& message, const std::string& groupText) noexcept
{
    G group;

    // loop the vector and handle each group value
    for(const auto& messageAttr : tokenizeGroupText(groupText))
    {   
        std::size_t pos = messageAttr.find(':');
        if (std::string::npos != pos)
        {
            std::string firstValue =
              boost::algorithm::trim_copy(messageAttr.substr(0, pos));
            std::string secondValue =
              boost::algorithm::trim_copy(messageAttr.substr(pos+1));
    
            uint32_t field = Utils::strToField(firstValue);
            if (!field)
            {
                std::cout << "Error: failed to set group tag: " << firstValue << std::endl;
                continue;
            }

            if (FIX::FIELD::NoPartyIDs == field)
            {
                addPartyGroup(group, secondValue);
            }
            else if (FIX::FIELD::NoTrades == field)
            {
                addTradesGroup(group, secondValue);
            }
            else if (FIX::FIELD::NoOfInstrumentLegs == field)
            {
                addInstrumentLegsGroup(group, secondValue);
            }
            else if (FIX::FIELD::NoLegs == field)
            {
                addTradeLegsGroup(group, secondValue);
            }
            else if (FIX::FIELD::NoDates == field)
            {
                addDatesGroup(group, secondValue);
            }
            else
            {
                try
                {
                    group.setField(field, Utils::showSpecChars(secondValue));
                }
                catch(...)
                {
                    std::cout << "Error: failed to set group tag: " << field << std::endl;
                }

                if (secondValue.empty())
                {
                    group.removeField(field);
                }
            }
            
        }
        else
        {
            std::cout << "Error: failed to parse group entry: "
                      << groupText << std::endl;
        }
    }

    // add the group to the message
    message.addGroup(group);
}

// Template specialization for FIX::Message
template<>
FIX::Message Converter::toFIXMessage(const FieldValuePairs&,
                                     const FIX::DataDictionary&) noexcept;

} //end namespace
#endif
