/****************************************************************************
 *     Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : utils.hpp
 *   Project  : Wabi II
 *   Description: utility header file
 *
 *   Created  : 2015/03/19
 *   Author   : Yang Du
 ****************************************************************************/

#ifndef FIXPROXY_UTILS_H
#define FIXPROXY_UTILS_H

#include <string>
#include <cstdint>

#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/date_time/posix_time/posix_time_io.hpp>

#include "quickfix/Session.h"
#include "quickfix/Message.h"
#include "quickfix/FixValues.h"
#include "quickfix/BinaryUtils.h"
#include "quickfix/FieldMap.h"

#include <cryptopp/cryptlib.h>
#include <cryptopp/secblock.h>
#include <cryptopp/sha.h>
#include <cryptopp/hmac.h>
#include <cryptopp/filters.h>
#include <cryptopp/hex.h>


namespace FIXProxy
{
constexpr auto FaxKeyFile       = "omd_fax_key.pem";
constexpr auto timedoutMsg      = "process timed out";

class Utils
{
    public:
    // print system log
    static void printSysLog(const std::string&) noexcept;

    // convert a string to integer
    static int32_t strToField(const std::string&) noexcept;

    // convert FIX message to string
    static std::string toString(const FIX::Message&,
                                const std::string delimiter = ";") noexcept;

    // convert FIX message to string and
    // append group string to tag message
    static std::string toString(const FIX::Message&,
                                const FIX::DataDictionary&,
                                const FIX::DataDictionary&,
                                const std::string delimiter = ";") noexcept;

    // convert FIX message to text string
    static std::string toTextString(const FIX::Message&,
                                    const FIX::DataDictionary&,
                                    const FIX::DataDictionary&,
                                    const std::string delimiter = ";") noexcept;

    // convert string to FIX message
    static FIX::Message toFIX(const std::string&,
                              const std::string delimiter = ";") noexcept;

    // get group string with text format from FIX message
    static std::string getGroupString(const FIX::Message&,
                                      const FIX::DataDictionary&,
                                      const FIX::DataDictionary&) noexcept;

    // parse group field string
    static std::string parseGroupField(const FIX::FieldMap&,
                                       const FIX::DataDictionary&,
                                       const FIX::DataDictionary&) noexcept;

    // find group NoPartyIDs from message text
    static std::vector<std::string> findNoPartyIDsFromMsg(const std::string&) noexcept;

    // get time string in specifcial format
    static std::string getTimeString(
        const boost::posix_time::ptime time =
          boost::posix_time::microsec_clock::local_time()) noexcept;

    // get a 8 digits number by using current system time
    static uint32_t getMilliseconds() noexcept;

    // get an unique 8 digits ID
    static uint32_t getOrderID() noexcept;

    // RSA encryptor
    static std::string rsaEncrypt(const std::string&) noexcept;

    // Standard base64 encoder
    static std::string base64Encode(const std::string&) noexcept;

    // Generate a UTC timestamp like 'YYYYMMDDHHMMSS'
    static std::string getUTCTimeStamp() noexcept;

    // Hide the special characters
    static std::string hideSpecChars(const std::string&,
                                     const std::string specialChars = "all") noexcept;
    // Show the special characters
    static std::string showSpecChars(const std::string&,
                                     const std::string specialChars = "all") noexcept;
    // Format messeage text
    static std::string formatMessageText(const std::string&) noexcept;
    
    // Get Session ID
    static FIX::SessionID getSessionID(const std::string&,
                                       const std::string&,
                                       const std::string&) noexcept;

    // Get Session
    static FIX::Session* getSession(const std::string&,
                                    const std::string&,
                                    const std::string&) noexcept;
    // Get Session
    static FIX::Session* getSession(const FIX::SessionID&) noexcept;

    // Get session data dictionaries
    static bool getSessionDataDictionaries(const FIX::SessionID&,
                                           FIX::DataDictionary&,
                                           FIX::DataDictionary&) noexcept;

    // Convert a FIX tag to a FIX field or a FIX field to a FIX tag
    static bool tag2field(const FIX::DataDictionary&,
                          const FIX::DataDictionary&,
                          const std::string&,
                          int32_t&, std::string&) noexcept;

    // Check if the log file should be erase or not
    static bool isEraseFile(const std::string&) noexcept;

    // Split a string to 2 parts using a seperator
    static void splitTo2Parts(const std::string&,
                              const char,
                              std::string&,
                              std::string&) noexcept;

    // Remove the outter square brackets for a string
    static std::string removeSquareBrackets(const std::string&) noexcept;

    // split a FIX message string to a vector of pairs
    static std::vector<std::string> splitToPairVector(const std::string&,
                                                      const std::string&) noexcept;

    // Get broker ID list as a string
    template<class T>
    static std::string getBrokerIDs(T& message) noexcept;

    // Get broker ID list for both sides of TCR request
    template<class T>
    static std::string getTCRBrokerIDs(T& message) noexcept;

    private:
    static const std::string m_publicKey;
    static const std::string m_faxKey;
};

// Return all broker IDs in a string
//
// The input message can be either
//  FIX message or a FIX group
//
// The possible broker IDs are
//  - Investor ID (452=5)
//  - Owning Broker ID (452=1)
//  - Submitting Broker ID (452=36)
//  - Counterparty Broker ID (452=17)
//  - Broker Location ID (425=75)
//
// The output broker IDs will be parsed out from
// repeating group NoPartyIDs(453)
// The output will be like, e.g.
//   SubmittingBrokerID=5001;InvestorID=5101
//   SubmittingBrokerID=5001;BrokerLocationID=5102

template<class T>
std::string Utils::getBrokerIDs(T& message) noexcept
{
    std::string brokerIDs;

    std::string owningBrokerID;
    if (FIX::BinaryUtils::getBrokerID(message, owningBrokerID))
    {
        brokerIDs += "OwningBrokerID=" + owningBrokerID + ";";
    }

    std::string investorID;
    if (FIX::BinaryUtils::getInvestorID(message, investorID))
    {
        brokerIDs += "InvestorID=" + investorID + ";";
    }

    std::string submittingBrokerID;
    if (FIX::BinaryUtils::getSubmittingBrokerID(message,
                                                submittingBrokerID))
    {
        brokerIDs += "SubmittingBrokerID=" + submittingBrokerID + ";";
    }

    std::string counterpartyBrokerID;
    if (FIX::BinaryUtils::getContraBrokerID(message,
                                            counterpartyBrokerID))
    {
        brokerIDs += "CounterpartyBrokerID=" + counterpartyBrokerID + ";";
    }

    std::string brokerLocationID;
    if (FIX::BinaryUtils::getBrokerLocationID(message, brokerLocationID))
    {
        brokerIDs += "BrokerLocationID=" + brokerLocationID + ";";
    }

    std::string brokerClientID;
    if (FIX::BinaryUtils::getBrokerClientID(message, brokerClientID))
    {
        brokerIDs += "BrokerClientID=" + brokerClientID + ";";
    }

    return std::move(brokerIDs);
}

template<class T>
std::string Utils::getTCRBrokerIDs(T& message) noexcept
{
    std::string brokerIDs;
    if (((FIX::FieldMap)message).hasGroup(FIX::FIELD::NoSides))
    {
        for (FIX::FieldMap::g_iterator i = message.g_begin(); i != message.g_end(); ++i)
        {
            if (FIX::FIELD::NoSides == i->first)
            {
                for (uint32_t j = 0; j < i->second.size(); ++j)
                {
                    const FIX::FieldMap& group = *(i->second[j]);
                    brokerIDs += getBrokerIDs(group);
                }
            }
        }
    }
    return std::move(brokerIDs);
}
} //end namespace
#endif
