/****************************************************************************
 *     Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : Session.h
 *   Project  : Wabi III
 *   Description: Socket Client Session Handler
 *
 *   Created  : 2015/05/19
 *   Author   : Yang Du
 ****************************************************************************/

#ifndef SESSION_H
#define SESSION_H

#include <boost/asio/ip/tcp.hpp>
#include <boost/asio/spawn.hpp>
#include <boost/asio/steady_timer.hpp>
#include <boost/asio/read.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>

using boost::asio::ip::tcp;

namespace FIXProxy
{
class Application;

// This session class is used to handle a incoming connection
// from client side.
// server will spwan one session for each connection.
//
// As it inherits from std::enable_shared_from_this<T>,
// its instances are constructed from heap and has shared_from_this()
// to access itsself.
class Session : public std::enable_shared_from_this<Session>
{
    public:
    // require non-default constructor
    explicit Session(tcp::socket socket, Application& app)
      : m_socket(std::move(socket)),
        m_timer(m_socket.get_io_service()),
        m_strand(m_socket.get_io_service()),
        m_app(app),
        m_isTimedout(false),
        m_receivedResponse("{ \"status\": \"received\" }"),
        m_successResponse("{ \"status\": \"success\" }"),
        m_failedResponse("{ \"status\": \"failed\" }")
    {
    }

    // Session entrance
    void go() noexcept;
    // handler for incomming request
    void handleRequest(boost::asio::yield_context&) noexcept;
    // handler for timeout
    void handleTimeout(boost::asio::yield_context&) noexcept;

    // read request from socket
    std::string readRequest(boost::asio::yield_context&) noexcept;

    // generate failed response with error message
    inline std::string generateFailedResponse(const std::string& errorMsg) const
    {
        boost::property_tree::ptree pt;
        pt.put("status", "failed");
        pt.put("error_msg", errorMsg);

        thread_local std::ostringstream oss;
        oss.str("");
        oss.clear();
        boost::property_tree::write_json(oss, pt);
        return oss.str();
    }

    // generate sending request's JSON response
    inline std::string generateSendingResponse(const std::string& time) const
    {
        return "{ \"status\": \"received\", \"time\" : \"" + time + "\" }";
    }

    // generate counting response with message count
    inline std::string generateCountingResponse(int32_t count,
      const std::string& messages = std::string()) const
    {
        //return "{ \"status\": \"success\", \"count\" : \"" + std::to_string(count) + "\" }";
        boost::property_tree::ptree pt;
        pt.put("status", "success");
        pt.put("count", std::to_string(count));
        pt.put("messages", messages);

        thread_local std::ostringstream oss;
        oss.str("");
        oss.clear();
        boost::property_tree::write_json(oss, pt);
        return oss.str();
    }

    // generate session status response
    inline std::string generateStatusResponse(const std::string& status) const
    {
        return "{ \"status\": \"success\", \"session_status\" : \"" + status + "\" }";
    }

    // generate order ID response
    inline std::string generateOrderIDResponse(uint32_t id) const
    {
        return "{ \"status\": \"success\", \"order_id\" : \""
          + std::to_string(id) + "\" }";
    }

    // write response to socket
    void writeResponse(boost::asio::yield_context&, const std::string&) noexcept;

    // handle sending request message
    bool handleSendMessage(const std::string&) noexcept;

    // handle "retrieverequest" JSON request
    std::string handleRetrieveRequest(const std::string&,
                                      const std::string&,
                                      const bool&) const noexcept;

    // handle "retrieveresponse" JSON request
    std::string handleRetrieveResponse(const std::string&,
                                       const std::string&,
                                       const bool&) const noexcept;

    // handle session connection information request
    std::string handleSessionInfo(const std::string&) const noexcept;

    // handle response matching
    bool handleMatchResponse(const std::string&,
                             const std::string&,
                             const bool&,
                             std::string&) noexcept;

    // handle message counting
    int32_t handleCountMessages(const std::string&,
                                const bool&,
                                std::string&,
                                std::string&) noexcept;

    // process timed out
    void processTimedout(const boost::system::error_code&) noexcept;

    // handle WABI integer tags conversion
    std::string handleTagsToFIXFieldsConversion(const std::string&) noexcept;

    // handle WABI integer tags conversion
    std::string handleTagsToBinaryFieldsConversion(const std::string&) noexcept;

    // handle print log request
    void handlePrintMessageLog(const std::string&) noexcept;

    // handle retrieve malformed message request
    std::string handleRetrieveMalformedMsg(const std::string&,
                                           const bool&) const noexcept;

    inline void cancelTimer() noexcept
    {
        if (m_timer.expires_from_now() >= std::chrono::seconds(0))
        {
            m_timer.cancel();
        }
    }

    private:
    tcp::socket                       m_socket;
    boost::asio::steady_timer         m_timer;
    boost::asio::io_service::strand   m_strand;
    Application&                      m_app;
    bool                              m_isTimedout;

    const std::string                 m_receivedResponse;
    const std::string                 m_successResponse;
    const std::string                 m_failedResponse;
};
}
#endif // SESSION_H
