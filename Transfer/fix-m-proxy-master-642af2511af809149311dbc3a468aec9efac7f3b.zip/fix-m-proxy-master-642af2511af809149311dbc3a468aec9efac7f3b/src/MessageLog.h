/****************************************************************************
 *     Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : MessageLog.hpp
 *   Project  : Wabi III
 *   Description: Message Log Handler
 *
 *   Created  : 2015/06/02
 *   Author   : Yang Du
 ****************************************************************************/

#include <chrono>
#include <string>
#include <fstream>
#include <iostream>

#include "Utils.h"

#ifndef FIXPROXY_MESSAGE_LOG_H
#define FIXPROXY_MESSAGE_LOG_H

namespace FIXProxy
{
class MessageLog
{
    public:
    // A struct for saving message log relative
    // time    -- timestamp of message
    // tags    -- message tags log
    // text    -- message text log
    // binText -- binary text log
    // binMsg  -- binary message log
    // grpTags -- template tags of group field
    struct Message
    {
        Message(const std::string& aTime,
                const std::string& aTags,
                const std::string& aText,
                const std::string& aBinText,
                const std::string& aBinMsg,
                const std::string& aGrpTags)
        {
            time     = aTime;
            tags     = aTags;
            text     = aText;
            binText  = aBinText;
            binMsg   = aBinMsg;
            grpTags  = aGrpTags;
        }

        Message(const Message& msg)
        {
            *this = msg;
        }

        std::string time;
        std::string tags;
        std::string text;
        std::string binText;
        std::string binMsg;
        std::string grpTags;
    };

    MessageLog(const std::string&);
    ~MessageLog()
    {
    }

    // get message  matching expected text, time range, patterns
    const std::vector<Message> message(const std::string&,
                                       const std::string&,
                                       const std::string&,
                                       const std::string&,
                                       const bool&) noexcept;

    // get message matching expected text, and time range
    const std::vector<Message> message(const std::string&,
                                       const std::string&,
                                       const bool&) noexcept;

    // get request message matching expected text, and time range
    const std::vector<Message> request(const std::string&,
                                       const std::string&,
                                       const bool&) noexcept;

    // get response message matching expected text, and time range
    const std::vector<Message> response(const std::string&,
                                        const std::string&,
                                        const bool&) noexcept;

    // match a request with an expected text string and time range
    bool matchRequest(const std::string&,
                      const std::string&,
                      const bool&,
                      std::string&) noexcept;

    // get malformed message with a period
    const std::vector<Message> malformedMessage(const std::string&,
                                                const std::string&,
                                                const std::string&,
                                                const bool&,
                                                std::string&) noexcept;

    // lookup business reject response with a time range
    bool matchBusinessReject(const std::string&,
                             const bool&,
                             std::string&) noexcept;

    // lookup admin reject response with
    // an expected text string and time range
    bool matchAdminReject(const std::string&,
                          const std::string&,
                          const bool&,
                          std::string&) noexcept;

    // match a response with an expected text string and time range
    bool matchResponse(const std::string&,
                       const std::string&,
                       const bool&,
                       std::string&) noexcept;

    // process matching
    bool match(const std::string&,
               const std::string&,
               const std::string&,
               std::string&,
               const std::string& connector = "=") noexcept;

    // process group field matching by group
    bool matchGroup(const std::vector<std::string>&,
                    const std::string&,
                    const std::string&,
                    std::string) noexcept;

    // generate template tags of group field
    std::string genGroupTemplateTags(const std::string&,
                                     const std::string&) noexcept;

    // Get group filed string
    std::string getGroupTemplateTags(const std::string&,
                                     const std::string&,
                                     const std::string&,
                                     const std::string&,
                                     const std::vector<std::string>&) noexcept;

    // count messages with an expected text string and time range
    int32_t count(const std::string&,
                  const std::string&,
                  const std::string&,
                  const bool&,
                  std::string&,
                  std::string&) noexcept;

    // parse log line
    static bool parseLine(const std::string&,
                          std::string&,
                          std::string&) noexcept;

    // parse message order field
    static const std::string parseOrderField(const std::string&,
                                             const std::string&,
                                             const std::string&,
                                             const std::string&) noexcept;
    // parse message order id
    static const std::string parseRequestID(const std::string&,
                                            const std::string&) noexcept;

    // parse message order message sequence number
    static const std::string parseOrderMsgSeqNum(const std::string&,
                                                 const std::string&) noexcept;

    private:
    // check if a text is in format "regex(<text>)"
    bool isRegex(const std::string&) const noexcept;

    // remove the prefix string 'regex' from a regex pattern text
    std::string getRegex(const std::string& pattern) const noexcept;

    // check if an entry is regex matched
    bool isRegexMatched(const std::vector<std::string>&,
                        const std::string&) const noexcept;

    // ReInit log stream to proper position that the
    // message time is a bit just older than the given time.
    // The intention here is to avoid start log matching start from begining,
    // and get better performance
    void resetLogStream(const std::string&);

    // Return all messages' text in the vector in a string
    static std::string getRefMessageText(const std::vector<Message>&) noexcept;

    private:
    const std::string m_logpath;
    std::ifstream m_log;
    // message log line pattern
    const std::string m_message_pattern;
    // message text log line pattern
    const std::string m_messagetext_pattern;
    // request log line pattern
    const std::string m_request_pattern;
    // request text log line pattern
    const std::string m_requesttext_pattern;
    // response log line pattern
    const std::string m_response_pattern;
    // response text log line pattern
    const std::string m_responsetext_pattern;
    // binary log line pattern
    const std::string m_bin_fields_pattern;
    // binary log line pattern
    const std::string m_bin_pattern;
    // FIX string delimiter
    const std::string m_delimiters;
};
} // namespace

#endif
