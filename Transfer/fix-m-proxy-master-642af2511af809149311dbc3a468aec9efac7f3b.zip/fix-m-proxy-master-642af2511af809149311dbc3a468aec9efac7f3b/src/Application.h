/****************************************************************************
 *     Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : application.hpp
 *   Project  : Wabi II
 *   Description: application class for fix client initiator
 *
 *   Created  : 2015/03/17
 *   Author   : Yang Du
 ****************************************************************************/

#ifndef FIXPROXY_APPLICATION_H
#define FIXPROXY_APPLICATION_H

#include <string>
#include <queue>
#include <fstream>
#include <mutex>

// quick-fix
#include "quickfix/Utility.h"
#include "quickfix/Application.h"

// boost
#include <boost/regex.hpp>

#include "MessageLog.h"
#include "Utils.h"

namespace FIXProxy
{
class Encryptor;
// Application which implements all callbacks for QuickFIX
// engine. And users can implement all their business logic here.
class Application : public FIX::Application
{
    public:
    // FIX session status enum type
    enum class FIXSessionStatus
    {
        NOT_LOGON,
        LOGON,
        LOGOFF,
        UNKNOWN
    };

    public:
    // Constructor
    Application(const std::string&, FIX::SessionSettings&);

    // Destructor
    ~Application()
    {
    }

    // user logic
    void run(const int16_t port) noexcept;

    // return session status in string
    std::string sessionStatus(const FIXSessionStatus&) const noexcept;
    // get session status using the session information
    // provided in the message string
    std::string getSessionStatus(const std::string&) const noexcept;
    // Get session status for a session
    std::string getSessionStatus(const FIX::SessionID&) const noexcept;
    // Get session status for a session by
    // BeginString/SenderCompID/TargetCompID
    std::string getSessionStatus(const std::string&,
                                 const std::string&,
                                 const std::string&) const noexcept;

    // user function for sending message
    bool sendFIXMessage(const std::string&) noexcept;
    // generate Logon Message according to the message string
    void handleLogonMessage(const std::string&, FIX::Message&) noexcept;
    // generate a Sequence Reset Message according to the message string
    void handleSequenceResetMessage(const std::string&, FIX::Message&) noexcept;
    // generate a FIX44 Message according to the message string
    void handleFIX44Message(const std::string&, FIX::Message&) noexcept;
    void handleFIX44MemberFIXMessage(const std::string&, FIX::Message&) noexcept;
    void handleFIX44SelectFIXMessage(const std::string&, FIX::Message&) noexcept;

    // lookup FIX request from log file
    std::vector<MessageLog::Message> lookupFIXRequest(const std::string&,
                                                      const std::string&,
                                                      const bool&) noexcept;
    // lookup FIX response from log file
    std::vector<MessageLog::Message> lookupFIXResponse(const std::string&,
                                                       const std::string&,
                                                       const bool&) noexcept;
    // lookup ALl FIX message from log file
    std::vector<MessageLog::Message> lookupFIXMessage(const std::string&,
                                                      const std::string&,
                                                      const bool&) noexcept;
    // matching FIX response from log file
    bool matchFIXResponse(const std::string&,
                          const std::string&,
                          const bool&,
                          std::string&) noexcept;
    // count FIX messages in log file
    int32_t countFIXMessages(const std::string&,
                             const bool&,
                             std::string&,
                             std::string&) noexcept;

    // set a session setting
    void setSessionSettingString(const FIX::SessionID&,
                                 const std::string&,
                                 const std::string&) noexcept;
    // set a session setting
    void setSessionSettingString(const FIX::Message&,
                                 const int32_t,
                                 const std::string&,
                                 FIX::Dictionary&) noexcept;
    // get a session setting
    std::string getSessionSettingString(const FIX::SessionID&,
                                        const std::string&) noexcept;
    // set a list of session setting
    void updateSessionSettings(const FIX::Message&,
                               const FIX::SessionID&) noexcept;

    // process outgoing logon message
    void processLogonMessage(FIX::Message& message,
                             const FIX::SessionID& sessionID) noexcept;
    // Set encypted password
    void setEncryptedPassword(FIX::Message& message,
                              const FIX::SessionID& sessionID) noexcept;

    // Set a tag from session setting
    static void setTagFromSetting(FIX::Message&,
                                  const FIX::Dictionary&,
                                  const FIX::Dictionary&,
                                  const std::string&,
                                  uint32_t tag) noexcept;

    // handle logon/logout responses
    void handleFromAdmin(const FIX::Message&,
                         const FIX::SessionID&) noexcept;

    // callback on session creation
    void onCreate(const FIX::SessionID&) noexcept
    {
    }
    // callback on session logon
    void onLogon(const FIX::SessionID& sessionID) noexcept;
    // callback on session logout
    void onLogout(const FIX::SessionID& sessionID) noexcept;
    // callback on admin message send out
    void toAdmin(FIX::Message&, const FIX::SessionID&) noexcept;
    // callback on application message send out
    void toApp(FIX::Message&, const FIX::SessionID&)
        throw (FIX::DoNotSend);
    // callback on receiving admin message
    void fromAdmin(const FIX::Message& message,
                   const FIX::SessionID& sessionID)
        throw (FIX::FieldNotFound,
               FIX::IncorrectDataFormat,
               FIX::IncorrectTagValue,
               FIX::RejectLogon)
    {
        // handle logon/logout responses
        handleFromAdmin(message, sessionID);

        // write message & session log
        logMessage(message, sessionID,
                   "Received AdminFIXMsg: ",
                   "Received AdminMsgText: ",
                   "Received AdminBinFields: ",
                   "Received AdminBinMsg: ");
        std::cout << "Received AdminFIXMsg: "
                  << Utils::showSpecChars(Utils::toString(message)) << std::endl;
    }
    // callback on receiving application message
    void fromApp(const FIX::Message& message,
                 const FIX::SessionID& sessionID)
        throw (FIX::FieldNotFound,
               FIX::IncorrectDataFormat,
               FIX::IncorrectTagValue,
               FIX::UnsupportedMessageType);

    // Process outing application message
    // just before it sends out
    void processOutgoingAppMessage(const std::string&,
                                   FIX::Message&,
                                   const FIX::SessionID&) noexcept;
    // Log message for a session log
    // as well as the message.log
    void logMessage(const FIX::Message&,
                    const FIX::SessionID&,
                    const std::string&,
                    const std::string&,
                    const std::string&,
                    const std::string&);
    // log message to <message>.log
    inline void logMessage(const std::string& messageText,
                           const std::string& prefix) const noexcept
    {
        // message log
        std::fstream msgLog;
        // Erase file if passed
        if (Utils::isEraseFile(m_msgLogFile))
        {
            // open message log file for output and truncate
            msgLog.open(m_msgLogFile, std::ios::trunc | std::ios::out);
        }
        else
        {
            // open message log file for output and appending
            msgLog.open(m_msgLogFile, std::ios::out | std::ios::app);
        }
        // write received FIX admin message to log
        msgLog << "[" << Utils::getTimeString() << "] "
               << prefix << processMessageLogging(messageText) << "\n";
        msgLog.close();
    }

    // Reformat a substring of message string
    static std::string reformatMessage(const std::string&,
                                       size_t,
                                       size_t,
                                       const std::string&) noexcept;

    // Process a message before logging to message log
    static std::string processMessageLogging(const std::string&) noexcept;

    // Log message to <sessionID>.log
    // Every message will be recorded in a session file accordingly
    inline void logSession(const std::string& messageText,
                           const std::string& prefix,
                           const FIX::SessionID& sessionID) const noexcept
    {
        // write message to a session specific log file
        std::fstream sessionLog;
        std::string logPath = getSessionLogFileName(sessionID);
        // Erase file if passed
        if (Utils::isEraseFile(logPath))
        {
            // open session log file for truncate and output
            sessionLog.open(logPath, std::ios::trunc | std::ios::out);
        }
        else
        {
            // open session log file for output and append
            sessionLog.open(logPath, std::ios::out | std::ios::app);
        }

        // write log
        sessionLog << "[" << Utils::getTimeString() << "] "
                   << prefix << messageText << "\n";
        sessionLog.close();
    }

    inline std::string
    getSessionLogFileName(const FIX::SessionID& sessionID) const noexcept
    {
        // session log file name
        return sessionID.getBeginString().getValue() + "."
            + sessionID.getSenderCompID().getValue() + "."
            + sessionID.getTargetCompID().getValue()
            + ".log";
    }

    typedef std::map <FIX::SessionID, FIX::Dictionary> SessionDictionaries;

    // Convert WABI integer tags to text fields
    // in both FIX
    std::string getFIXFields(const std::string&) const noexcept;

    // Get Connection Information
    std::string getConnectionInfo(const FIX::SessionID&) const noexcept;
    std::string getConfigConnectionInfo(const FIX::SessionID&) const noexcept;
    std::string getConnectionInfo(const std::string&) const noexcept;
    // print normal messsage log
    void printMessageLog(const std::string&) noexcept;
    // initiate session dictionaries base on session settings
    void initCurrentSessionSettings() noexcept;
    // get session setting from session dictionaries
    FIX::Dictionary& getCurrentSessionSetting(const FIX::SessionID&);
    // get field from session settings
    static std::string
    getFieldFromSessionSettings(const FIX::Dictionary&,
                                const FIX::Dictionary&,
                                const std::string&) noexcept;
    // lookup malformed message from message log
    std::vector<MessageLog::Message>
    lookupMalformedMessage(const std::string&, const bool&) noexcept;


    private:
    std::set<FIX::SessionID>   m_workingSessions;
    // default session settings
    FIX::SessionSettings&      m_settings;
    // message log path
    std::string                m_msgLogFile;
    // session dictionaries
    SessionDictionaries        m_currentSessionSettings;
    // message log write mutex
    std::mutex                 m_msgLogFileMutex;
};

} //end namespace
#endif
