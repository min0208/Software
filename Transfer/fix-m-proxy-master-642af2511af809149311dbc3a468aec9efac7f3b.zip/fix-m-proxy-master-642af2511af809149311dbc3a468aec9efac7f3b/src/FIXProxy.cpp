/****************************************************************************
 *     Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *     All rights reserved.
 *
 *     Filename : FIXProxy.cpp
 *     Project  : Wabi II
 *     Description: main function for fix client initiator
 *
 *     Created  : 2015/03/17
 *     Author   : Yang Du
****************************************************************************/

#include "quickfix/FileStore.h"
#include "quickfix/SocketInitiator.h"
#include "quickfix/SessionSettings.h"
#include "quickfix/Log.h"
#include "quickfix/Utility.h"
#include "Application.h"
#include <functional>
#include <string>
#include <iostream>
#include <fstream>
#include <cstdint>

int32_t main(int32_t argc, char** argv)
{
    // this application accepts 2 parameters
    const int16_t minArgNum = 3;
    // show usage
    if (argc < minArgNum)
    {
        std::cout << "Usage: " << argv[0]
        << " <setting-file> <port>" << std::endl;
        return 1;
    }
    // the first parameter is the QuickFIX cfg
    std::string file = argv[1];
    // the second parameter is the listening port
    const int16_t two = 2;
    int16_t port = 0;
    try
    {
        port = std::stoi(argv[two]);
    }
    // try catch exception for std::stoi conversion
    catch (std::exception& e)
    {
        std::cout << "Error: invalid port=" << argv[two] << std::endl;
        return 1;
    }

    // set message log path
    const std::string msgLogFile = "message.log";

    // Init all settings required to start
    // QuickFIX engine.
    // load session settings from file
    // create application
    // create filestore factory
    // create log factory
    // create initiator
    // start initiator
    // run application
    try
    {
        FIX::SessionSettings settings(file);

        FIXProxy::Application application(msgLogFile, settings);
        FIX::FileStoreFactory storeFactory(settings);
        FIX::ScreenLogFactory logFactory(settings);
        FIX::SocketInitiator initiator(application,
                                       storeFactory,
                                       settings,
                                       logFactory);

        // set the callback function for logging
        // the malformed message in QuickFIX
         FIX::Session::setLogMalformedMsgCB(
            std::bind(&FIXProxy::Application::printMessageLog,
                      &application, std::placeholders::_1));

        initiator.start();
        application.run(port);
        // stop initiator
        initiator.stop();

        return 0;
    }
    catch (std::exception & e)
    {
        std::cout << e.what();
        return 1;
    }
}
