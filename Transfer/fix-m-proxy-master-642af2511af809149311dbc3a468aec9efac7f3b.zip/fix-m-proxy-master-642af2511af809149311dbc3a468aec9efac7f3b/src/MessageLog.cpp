/****************************************************************************
 *     Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : MessageLog.hpp
 *   Project  : Wabi III
 *   Description: Message Log Handler
 *
 *   Created  : 2015/06/02
 *   Author   : Yang Du
 ****************************************************************************/

#include <iostream>
#include <boost/algorithm/string.hpp>
#include <boost/regex.hpp>

#include "MessageLog.h"
#include "Converter.h"

namespace FIXProxy
{
// Class to handle log messages
//  - matching
//  - retrieve
//  - counting
//

// constructor with log path
MessageLog::MessageLog(const std::string& log_path)
  : m_logpath(log_path), m_log(log_path),
  // message log line pattern
  m_message_pattern(".*FIXMsg:.*"),
  // message text log line pattern
  m_messagetext_pattern(".*MsgText:.*"),
  // request log line pattern
  m_request_pattern("Sent .*FIXMsg:.*"),
  // request text log line pattern
  m_requesttext_pattern("Sent .*MsgText:.*"),
  // response log line pattern
  m_response_pattern("Received .*FIXMsg.*"),
  // response text log line pattern
  m_responsetext_pattern("Received .*MsgText.*"),
  //binary fields message log line pattern
  m_bin_fields_pattern(".*BinFields:.*"),
  //binary message log line pattern
  m_bin_pattern(".*BinMsg:.*"),
  // delimiters
  m_delimiters(";")
{
}

// Parse the time string from a log entry
//
// The log line is expected in s specific format
//   or it will be ignored.
//
// return true if parsing succeeds, and time and message
// string will be returned in the referenced arguements.
bool MessageLog::parseLine(const std::string& line,
                           std::string& time,
                           std::string& message) noexcept
{
    std::vector<std::string> items;
    // split log line by '[' or ']'
    boost::algorithm::split(items,
                            line,
                            boost::algorithm::is_any_of("]["),
                            boost::token_compress_on);

    const uint16_t three = 3;
    // resultes should contain at least 3 items
    if (items.size() >= three)
    {
        // the first time is time string
        // return false if time string is empty
        auto regexTime = boost::regex("^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{6}$");
        time = items[1];
        if (time.empty()
          or !boost::regex_match(time, regexTime))
        {
            return false;
        }

        // the second time is message string
        message = line.substr(line.find(']') + 1);
        // erase the first space if message is non-empty
        if (!message.empty())
        {
            message.erase(0, 1);
        }

        return true;
    }

    return false;
}

// Query message with expected FIX tgas
//  The query is expected to have inputs:
//   - expected pattern
//   - start time
//   - line header patterns
//
// The matched message should be after the start time point.
const std::vector<MessageLog::Message>
MessageLog::message(const std::string& expectedText,
                    const std::string& time,
                    const std::string& pattern,
                    const std::string& text_pattern,
                    const bool& isTimedout) noexcept
{
    // vector to store matchedfile lines
    std::vector<MessageLog::Message> messageVector;

    // reset log file stream status and current position
    if (!time.empty())
    {
        resetLogStream(time);
    }

    std::string line;
    // parse each line
    while (std::getline(m_log, line))
    {
        if (isTimedout)
        {
            messageVector.clear();
            break;
        }

        std::string msg_time;
        std::string msg_time_tmp;
        std::string message;
        // parse a time for message time and message content
        // ignore if line invalid
        if (!parseLine(line, msg_time, message))
        {
            continue;
        }

        // ignore messages older than message time
        if (time.compare(msg_time) > 0)
        {
            continue;
        }

        // matching request
        if (!pattern.empty()
          && boost::regex_match(message, boost::regex(pattern)))
        {
            // remove the leading header "Sent FixMsg: "
            std::string msg = boost::regex_replace(message,
              boost::regex("([A-Za-z ]*: )(.*)"),
              "$2");
            std::string msgText;
            // read response text if possible
            if (std::getline(m_log, line)
              // parse line for time and message
              && parseLine(line, msg_time_tmp, message)
              // ensure it non empty pattern
              && !text_pattern.empty()
              // check if it matches response text pattern
              && boost::regex_match(message, boost::regex(text_pattern)))
            {
                // get response text
                msgText = boost::regex_replace(message,
                  boost::regex("([A-Za-z ]*: )(.*)"),
                  "$2");
            }

            // match request message to the expected text
            std::string errorMsg;
            if (match(expectedText,
                      msg + msgText,
                      m_delimiters,
                      errorMsg))
            {
                std::string binFieldsMsg;
                std::string binMsg;
                // save current stream position
                std::streampos pos = m_log.tellg();
                // read response text if possible
                // parse line for time and message
                // ensure it non empty pattern
                if (std::getline(m_log, line)
                  && parseLine(line, msg_time_tmp, message)
                  && !m_bin_fields_pattern.empty()
                  // check if it matches response text pattern
                  && boost::regex_match(message,
                                        boost::regex(m_bin_fields_pattern)))
                {
                    binFieldsMsg = boost::regex_replace(message,
                      boost::regex("([A-Za-z ]*: )(.*)"),
                      "$2");
                }
                // recover to pre position if failed
                else if (pos != m_log.end)
                {
                    m_log.seekg(pos);
                }

                pos = m_log.tellg();
                // read response text if possible
                // parse line for time and message
                // ensure it non empty pattern
                if (std::getline(m_log, line)
                  && parseLine(line, msg_time_tmp, message)
                  && !m_bin_pattern.empty()
                  // check if it matches response text pattern
                  && boost::regex_match(message,
                                        boost::regex(m_bin_pattern)))
                {
                    binMsg = boost::regex_replace(message,
                      boost::regex("([A-Za-z ]*: )(.*)"),
                      "$2");
                }
                // recover to pre position if failed
                else if (pos != m_log.end)
                {
                    m_log.seekg(pos);
                }

                // generate template tags of group field
                std::string grpTags =
                  genGroupTemplateTags(expectedText, msg);

                messageVector.push_back(Message(msg_time,
                                                msg,
                                                msgText,
                                                binFieldsMsg,
                                                binMsg,
                                                grpTags));
            }
        }
    }

    // move the string as it is no longer being used
    return std::move(messageVector);
}

// query message with expected FIX tgas
const std::vector<MessageLog::Message>
MessageLog::message(const std::string& expectedText,
                    const std::string& time,
                    const bool& isTimedout) noexcept
{
    // matching using request patterns
    return message(expectedText,
                   time,
                   m_message_pattern,
                   m_message_pattern,
                   isTimedout);
}

// query request with expected FIX tgas
const std::vector<MessageLog::Message>
MessageLog::request(const std::string& expectedText,
                    const std::string& time,
                    const bool& isTimedout) noexcept
{
    // matching using request patterns
    return message(expectedText,
                   time,
                   m_request_pattern,
                   m_requesttext_pattern,
                   isTimedout);
}

// query response with expected FIX tags, time renge
const std::vector<MessageLog::Message>
MessageLog::response(const std::string& expectedText,
                     const std::string& time,
                     const bool& isTimedout) noexcept
{
    // matching using response patterns
    return message(expectedText,
                   time,
                   m_response_pattern,
                   m_responsetext_pattern,
                   isTimedout);
}

// check if a request matching an expected FIX tags
bool MessageLog::matchRequest(const std::string& expectedText,
                              const std::string& time,
                              const bool& isTimedout,
                              std::string& errorMsg) noexcept
{
    // query the request
    const auto messageVector =
      request(expectedText, time, isTimedout);

    // if matched message more than 0
    if (messageVector.size() > 0)
    {
        return true;
    }

    return false;
}

// Lookup if any Business reject exists
// input:
//   - time: time point to start searching
//   - errorMsg: error message to return
// return true if found at least one reject message,
//  otherwise return false
bool MessageLog::matchBusinessReject(const std::string& time,
                                     const bool& isTimedout,
                                     std::string& errorMsg) noexcept
{
    const auto messageVector = response("35=j", time, isTimedout);
    if (messageVector.size() > 0)
    {
        errorMsg += "Business Reject received. \n";
        errorMsg += getRefMessageText(messageVector);
        return true;
    }
    return false;
}

// Lookup if any session reject(35=3) exists
// input:
//   - expectedText: pattern for message matching
//   - time: time point to start searching
//   - errorMsg: error message to return
// return true if matching succeeded, return false otherwise.
bool MessageLog::matchAdminReject(const std::string& expectedText,
                                  const std::string& time,
                                  const bool& isTimedout,
                                  std::string& errorMsg) noexcept
{
    // query the request
    const auto messageVector =
      response(expectedText, time, isTimedout);

    for (const auto& msg : messageVector)
    {
        if (isTimedout)
        {
            errorMsg = timedoutMsg;
            return false;
        }

        // get message tags
        const std::string& msgTags = msg.tags;
        const std::string& msgText = msg.text;

        std::vector<std::string> messageTextPairs =
          Utils::splitToPairVector(msgTags + msgText, m_delimiters);

        // if msgType 35=3
        if (std::find(messageTextPairs.begin(),
                      messageTextPairs.end(),
                      "35=3") != messageTextPairs.end())
        {
            std::string text;
            std::string refTagID;
            // iterate each pair and get value of tag 58, 371
            for (const auto& pair : messageTextPairs)
            {
                // check if it is tag58
                if (pair.substr(0, pair.find('=')) == "58")
                {
                    // make sure the pair value is non-empty
                    if (pair.size() > pair.find('=') + 1)
                    {
                        // get tag 58 value
                        text = pair.substr(pair.find('=') + 1, pair.size());
                    }
                }
                // make sure the pair value is non-empty
                else if (pair.substr(0, pair.find('=')) == "371"
                  && pair.size() > pair.find('=') + 1)
                {
                    // get the reftagID value
                    refTagID = pair.substr(pair.find('=') + 1, pair.size());
                }
            }


            // if both Text && RefTagID non empty
            if (!text.empty() && !refTagID.empty())
            {
                errorMsg = text + ", ref tag ID: " + refTagID + ". \n";
            }
            // if RefTagID is empty
            else
            {
                errorMsg = text + ". \n";
            }

            // Append all related messages to error
            errorMsg += getRefMessageText(messageVector);
            return true;
        }
    }

    errorMsg += getRefMessageText(messageVector);
    return false;
}

// generate template tags of group field
// loop expected group field and find a match group
// then return group field with the subsript of group
// e.g input: "NoPartyIDs=[PartyID:5482,PartyRole:1]"
//            "NoPartyIDs[1]=[PartyID:5482,PartyIDSource:D,PartyRole:1]"
//    output: "PartyID=[1],PartyRole=[1],"
std::string
MessageLog::genGroupTemplateTags(const std::string& expectedText,
                                 const std::string& messageText) noexcept
{
    std::string result;

    // 1.get field/value pair for expected text and message text
    std::vector<std::string> expectedTextPairs =
      Utils::splitToPairVector(expectedText, ";");
    std::vector<std::string> messageTextPairs  =
      Utils::splitToPairVector(messageText, ";");

    // 2.get all group NoPartyIDs from message text
    std::vector<std::string> groupMaps =
      Utils::findNoPartyIDsFromMsg(messageText);

    // 3.retrieve template tags of group field
    for (const auto& expectedPair : expectedTextPairs)
    {
        // get field name
        std::string expectedField =
          expectedPair.substr(0, expectedPair.find("="));
        if (boost::regex_match(expectedField,
                               boost::regex("^.+\\[.+\\]$")))
        {
            expectedField =
              expectedField.substr(0, expectedField.find("["));
        }

        // ignore if it's not a group field
        if (!Converter::isGroup(expectedField))
        {
            continue;
        }

        // find a matched group from message text
        // and return field name of group with a subscript
        for (const auto& msgTextPair : messageTextPairs)
        {
            // get field name
            std::string msgTextField =
              msgTextPair.substr(0, msgTextPair.find("="));
            if (boost::regex_match(msgTextField,
                                   boost::regex("^.+\\[.+\\]$")))
            {
                msgTextField =
                  msgTextField.substr(0, msgTextField.find("["));
            }

            // get template tags if matched
            std::string errorMsg;
            if (Converter::isGroup(msgTextField)
              and match(expectedPair, msgTextPair, ";", errorMsg, "="))
            {
                std::string msgTextLeft =
                  msgTextPair.substr(0, msgTextPair.find("="));
                result += getGroupTemplateTags(expectedPair,
                                               msgTextLeft,
                                               ";",
                                               "=",
                                               groupMaps);
                break;
            }
        }
    }

    return std::move(result);
}

// get template tags of group
// recursive retrieve group field with a subscript
// special handle group NoPartyIDs which may exist
// in the nest group
// e.g input:
//  "NoPartyIDs=[PartyID:5402,PartyIDSource:D,PartyRole:75]"
//            "NoPartyIDs[1]"
//    output: "PartyID=[1],PartyIDSource=[1],PartyRole=[1],"
std::string
MessageLog::getGroupTemplateTags(const std::string& groupText,
  const std::string& groupName,
  const std::string& delimiter,
  const std::string& connector,
  const std::vector<std::string>& groups) noexcept
{
    std::string result;

    // 1.get name & value of group field
    std::string field = groupText.substr(0, groupText.find(connector));
    std::string value =
      boost::algorithm::replace_first_copy(groupText, field + connector, "");

    // 2.get the subscript
    const std::string noPartyIDs = "NoPartyIDs";
    std::string subscript;
    std::string tagOfNoPartyIDs;
    if (field == noPartyIDs)
    {
        // get the subscript from vector groups for group NoPartyIDs
        uint32_t sub = 1;
        for (const auto& group : groups)
        {
            std::string grpName = group.substr(0, group.find("+"));
            std::string grpText =
              boost::algorithm::replace_first_copy(group, grpName + "+", "");

            // set the loop number as subscript if both of
            // the previous string and group are matched
            std::string errorMsg;
            if (grpName == groupName
              and match(groupText, grpText, delimiter, errorMsg, connector))
            {
                thread_local std::stringstream ss;
                ss.str("");
                ss.clear();
                ss << "[";
                ss << sub;
                ss << "]";

                subscript = ss.str();

                // process subscript of NoPartyIDs
                if (grpName.find(noPartyIDs) == std::string::npos
                  and boost::regex_match(grpName, boost::regex("^.+\\[.+\\]$")))
                {
                    tagOfNoPartyIDs =
                      noPartyIDs + "=" + grpName.substr(groupName.find("["));
                }
                else
                {
                    tagOfNoPartyIDs = noPartyIDs;
                }

                break;
            }

            sub++;
        }
    }
    else if (boost::regex_match(groupName, boost::regex("^.+\\[.+\\]$")))
    {
        // get the subscript from group name
        subscript = groupName.substr(groupName.find("["));
    }

    // 3.get tempalte tags of group field
    if (!value.empty() and !subscript.empty())
    {
        // loop field/value of group and get tempalte tag
        std::vector<std::string> pairs =
          Utils::splitToPairVector(value, ",");
        for (const auto& pair : pairs)
        {
            std::string grpField = pair.substr(0, pair.find(":"));
            if (grpField.empty())
            {
                continue;
            }
            else if (Converter::isGroup(grpField))
            {
                // recursive retrieve the template tags
                // if it's a nest group
                result += getGroupTemplateTags(pair,
                                               groupName,
                                               ",",
                                               ":",
                                               groups);
            }
            else
            {
                result += grpField + "=" + subscript + ",";
            }
        }

        // append template tag of group name
        if (!tagOfNoPartyIDs.empty())
        {
            result += tagOfNoPartyIDs + ",";
        }
        else
        {
            result += field + "=" + subscript + ",";
        }
    }

    return std::move(result);
}

// check if a response matching an expected FIX tags
//  input: - expected message text
//         - time stamp
// return true if expected response message found
bool MessageLog::matchResponse(const std::string& expectedText,
                               const std::string& time,
                               const bool& isTimedout,
                               std::string& errorMsg) noexcept
{
    // query the response
    auto messageVector =
      response(expectedText, time, isTimedout);

    // if matched message more than 0
    if (messageVector.size() == 1)
    {
        return true;
    }
    // if matched multiple messages
    else if (messageVector.size() > 1)
    {
        errorMsg = "multiple responses matched. \n";
        // Append all related messages to error
        errorMsg += getRefMessageText(messageVector);
        return false;
    }

    // try to get order ID
    const std::string requestID =
      parseRequestID(expectedText, m_delimiters);
    const std::string msgType =
      Converter::getMsgType(expectedText);
    
    std::vector<MessageLog::Message> refMessageVector;
    // if get an order id, try to search all response
    // with the same order ID
    if (!requestID.empty() or !msgType.empty())
    {
        // reset log file stream status and current position
        resetLogStream(time);

        std::string idField = Converter::getIDField(msgType);
        std::string pattern;
        if (!idField.empty() and !requestID.empty())
        {
            pattern = idField + "=" + requestID;
        }
        else if (!msgType.empty())
        {
            pattern = "35=" + msgType;
        }

        // matching without time constraint
        if (!pattern.empty())
        {
            messageVector =
              response(pattern, std::string(), isTimedout);
        }

        // check each response if matched
        for (const auto& msg : messageVector)
        {
            if (isTimedout)
            {
                errorMsg = timedoutMsg;
                return false;
            }

            // get msg time, tags, text
            const std::string& msgTime = msg.time;
            const std::string& msgTags = msg.tags;
            const std::string& msgText = msg.text;
            // matching the expectation text to the message
            std::string matchErrorMsg;
            if (match(expectedText,
                      msgTags + msgText,
                      m_delimiters,
                      matchErrorMsg))
            {
                if (time.compare(msgTime) <= 0)
                {
                    return true;
                }
                matchErrorMsg =
                  "response matched but not fulfill the time constraint,"
                  " maybe it is not received in sequence. \n";
            }
            // when request ID is empty, ignore messages doesn't fulfill
            // the time constraint
            else if (requestID.empty() && time.compare(msgTime) > 0)
            {
                continue;
            }
            // record message only when erro msg changed
            if (!matchErrorMsg.empty())
            {
                errorMsg += matchErrorMsg;
                refMessageVector.push_back(msg);
            }
        }

        if (refMessageVector.size() == 0)
        {
            refMessageVector = messageVector;
        }
    }

    // if still no error found,
    // try to find out a administritive rejection
    if (errorMsg.empty())
    {
        const std::string msgSeqNum =
          parseOrderMsgSeqNum(expectedText, m_delimiters);
        // search admin rejections using msgSeqNum
        if (!msgSeqNum.empty())
        {
            matchAdminReject("35=3;34=" + msgSeqNum,
                             time,
                             isTimedout,
                             errorMsg);
        }

        // if the erro msg still empty,
        //  try search admin rejection without constraiant.
        // note this search is inaccurate
        if (errorMsg.empty())
        {
            matchAdminReject("35=3", time, isTimedout, errorMsg);
            // if found a error msg, add a prefix string 'maybe',
            // because this search is inaccurate
            if (!errorMsg.empty())
            {
                errorMsg = "maybe because " + errorMsg + "\n";
            }
        }
    }
    else
    {
        // Append all related messages to error
        errorMsg += getRefMessageText(refMessageVector);
    }

    // check if any business reject message received
    matchBusinessReject(time, isTimedout, errorMsg);

    if (errorMsg.empty())
    {
        errorMsg =
          "Receive NO related response. All responses attached. \n";
        refMessageVector = response("35=([^0]|..)", time, isTimedout);
        errorMsg += getRefMessageText(refMessageVector);
    }

    return false;
}

// process matching
//  input: - expect message text
//         - message log
//         - delimiters
//         - connector
// return true when all field/group matched
bool MessageLog::match(const std::string& expectedText,
                       const std::string& message,
                       const std::string& delimiters,
                       std::string& errorMsg,
                       const std::string& connector) noexcept
{
    // split expected FIX string into a vector
    std::vector<std::string> expectedTextPairs =
      Utils::splitToPairVector(
        Utils::hideSpecChars(expectedText, "space"), delimiters);
    // split FIX message string into a vector
    std::vector<std::string> messageTextPairs =
      Utils::splitToPairVector(
        Utils::hideSpecChars(message, "space"), delimiters);

    // contains the fields which are unexpected in the message
    std::string fieldsUnexpected;
    // contains the fields which are not found in the message
    std::string fieldsNotFound;
    // contains the fields expected value
    std::string fieldsExpectedValue;
    // contains the fields actual value
    std::string fieldsActualValue;
    // group field mismatch
    std::string groupFieldMismatch;

    // check if expected tags are in the message
    for (const auto& pair : expectedTextPairs)
    {
        // get the field name
        std::string tag = pair.substr(0, pair.find(connector));
        // get the field value
        std::string value =
          boost::algorithm::replace_first_copy(pair, tag + connector, "");
        // remove subscript if have
        if (boost::regex_match(tag, boost::regex("^.+\\[.+\\]$")))
        {
             tag = tag.substr(0, tag.find('['));
        }

        // if the expected value is empty, make sure the field doesn't exist
        if (value.empty() && !tag.empty())
        {
            // check if the tag exists in the message or not
            for (const auto& p : messageTextPairs)
            {
                // if tag matched, set it to unexpected
                std::string msgTag = p.substr(0, p.find(connector));
                if (boost::regex_match(msgTag, boost::regex("^.+\\[.+\\]$")))
                {
                     msgTag = msgTag.substr(0, msgTag.find('['));
                }

                if (msgTag == tag)
                {
                    fieldsUnexpected += " " + tag;
                    break;
                }
            }
        }

        // the pair doesn't get a match no matter if it is regex
        // or plain text
        if (!(isRegex(value) && isRegexMatched(messageTextPairs, pair))
            and (!value.empty()
                && std::find(messageTextPairs.begin(),
                  messageTextPairs.end(), pair)
                    == messageTextPairs.end()))
        {
            // ignore empty field
            if (tag.empty())
            {
                continue;
            }

            // check for the novalue tag e.g <tag>=<novalue>
            // convert "<novalue>" to ""
            // treat it as success when <tag>=;(e.g 38=;)
            //  could be found in message text
            if ("<novalue>" == value)
            {
                auto newPair = Utils::showSpecChars(pair, "novalue");
                if (std::find(messageTextPairs.begin(),
                      messageTextPairs.end(), newPair)
                    != messageTextPairs.end())
                {
                    continue;
                }
            }

            // check if group match or not for group field
            // treat it as success when group matched
            if (Converter::isGroup(tag)
              and value.find(':') != std::string::npos
              and matchGroup(messageTextPairs, pair,
                connector, groupFieldMismatch))
            {
                continue;
            }

            // if mismatching tag is one of session attributes
            //  - BeginString(8)
            //  - SendCompID(49)
            //  - TargetCompID(56)
            //  - MsgType(35)
            // return false, and clear error message
            if (tag == "8"
                or tag == "49"
                or tag == "56"
                or tag == "35"
                or tag == "BeginString"
                or tag == "SenderCompID"
                or tag == "TargetCompID"
                or tag == "MsgType")
            {
                return false;
            }

            std::string actualPair;
            // get the actual value for this field
            for (const auto& p : messageTextPairs)
            {
                // if tag matched
                std::string msgTag = p.substr(0, p.find(connector));
                // remove subscript if have
                if (boost::regex_match(msgTag, boost::regex("^.+\\[.+\\]$")))
                {
                     msgTag = msgTag.substr(0, msgTag.find('['));
                }
                if (msgTag == tag)
                {
                    actualPair = p;
                    break;
                }
            }

            // if field not found
            if (actualPair.empty())
            {
                fieldsNotFound += " " + tag;
            }
            // if the fiedl value mismatch
            else
            {
                fieldsExpectedValue += " " + pair;
                fieldsActualValue += " " + actualPair;
            }
        }
    }

    // mismatch found
    if (!fieldsUnexpected.empty()
      or !fieldsNotFound.empty()
      or !fieldsExpectedValue.empty())
    {
        // compose the error message with fields unexpected
        if (!fieldsUnexpected.empty())
        {
            errorMsg += "unexpected fields" + fieldsUnexpected + ". ";
        }

        // compose the error message with fields not found
        if (!fieldsNotFound.empty())
        {
            errorMsg += "fields" + fieldsNotFound + " not found. ";
        }

        // compose the error message with expected / actual value
        if (!fieldsExpectedValue.empty())
        {
            errorMsg += "expect fields" + fieldsExpectedValue
                       + ", but actually received" + fieldsActualValue + ". ";
        }

        if (!errorMsg.empty())
        {
            errorMsg += "\n";
        }

        return false;
    }
    // all matched
    return true;
}

// process group field matching by group
//  input: field/value pair vector
//         expected pair
//         connector of field/value
// return true if all fields of expect group could be matched
bool MessageLog::matchGroup(const std::vector<std::string>& msgPairs,
                            const std::string& expectedPair,
                            const std::string& connector,
                            std::string errorMsg) noexcept
{
    // 1. split expected pair with field/value
    std::string expectedTag   =
      expectedPair.substr(0, expectedPair.find(connector));
    std::string expectedValue =
      boost::algorithm::replace_first_copy(expectedPair,
                                           expectedTag + connector, "");
    // remove subscript if have
    if (boost::regex_match(expectedTag, boost::regex("^.+\\[.+\\]$")))
    {
       expectedTag = expectedTag.substr(0, expectedTag.find('['));
    }

    // 2. treat it as failed if field or value is empty
    if (expectedTag.empty() or expectedValue.empty())
    {
        return false;
    }

    // 3. loop match message pair
    for (const auto& pair : msgPairs)
    {
        // 3.1 split message pair with field/vaue
        std::string actualTag   = pair.substr(0, pair.find(connector));
        std::string actualValue =
          boost::algorithm::replace_first_copy(pair,
                                               actualTag + connector, "");
        // remove subscript if have
        if (boost::regex_match(actualTag, boost::regex("^.+\\[.+\\]$")))
        {
           actualTag = actualTag.substr(0, actualTag.find('['));
        }

        // 3.2 ignore message pair if field/value is empty
        if (actualTag.empty() or actualValue.empty())
        {
            continue;
        }
        
        // 3.3 matching value if field matched
        if (actualTag == expectedTag)
        {
            // remove square brackets for expect/actual field first
            expectedValue = Utils::removeSquareBrackets(expectedValue);
            actualValue   = Utils::removeSquareBrackets(actualValue);
            // check if matched or not
            if (actualValue == expectedValue
              or match(expectedValue, actualValue, ",", errorMsg, ":"))
            {
                // group matched, empty the error message
                errorMsg = "";
                return true;
            }
        }
    }

    return false;
}

// parse a field from message string
//  input: - message text
//         - tag
//         - field
//         - delimiters
// output: field value
const std::string MessageLog::parseOrderField(
  const std::string& messageText,
  const std::string& fieldID,
  const std::string& fieldName,
  const std::string& delimiters) noexcept
{
    // return empty string if no field ID and name input
    if (fieldID.empty() and fieldName.empty())
    {
        return std::string();
    }
    // split the message by token ';' or space
    std::vector<std::string> items =
      Utils::splitToPairVector(messageText, delimiters);

    // lookup items which start with '<tagID>=' or '<tagName>='
    // return the value if found
    for (const auto& item : items)
    {
        // matching tag field ID
        if (boost::starts_with(item, fieldID + "="))
        {
            // get value
            return item.substr(fieldID.size() + 1);
        }

        // matching Order filed name
        if (boost::starts_with(item, fieldName + "="))
        {
            // get value
            return item.substr(fieldName.size() + 1);
        }
    }

    // return empty string if ID not found
    return std::string();
}

// parse order ID from message string
const std::string MessageLog::parseRequestID(const std::string& messageText,
    const std::string& delimiters) noexcept
{
    const std::string msgType = Converter::getMsgType(messageText);
    return parseOrderField(messageText, Converter::getIDField(msgType),
                           Converter::getIDFieldName(msgType), delimiters);
}

// parse order sequence number from message string
const std::string MessageLog::parseOrderMsgSeqNum(
  const std::string& messageText,
    const std::string& delimiters) noexcept
{
    // parse using "34=" && "MsgSeqNum="
    return parseOrderField(messageText, "34", "MsgSeqNum", delimiters);
}

// reset the log file stream to a proper position
// so that the log searching would be more efficient
void MessageLog::resetLogStream(const std::string& time)
{
    // clear error or eof flags
    m_log.clear();
    const int32_t stepSize = 1024 * 1024;

    // set the initial position to end
    m_log.seekg(0, std::ios::end);
    int64_t size = m_log.tellg();

    // if file size smaller than 6000 byte,
    // start from begining
    const uint16_t thousand = 1000;
    if (size < stepSize + thousand)
    {
        m_log.seekg(0, std::ios::beg);
        return;
    }

    // clear error or eof flags
    m_log.clear();
    std::string line;
    int64_t position = -1 * stepSize;
    // set the initial position to (end-5000)
    m_log.seekg(position, std::ios::end);
    // parse each line
    while (std::getline(m_log, line))
    {
        std::string msg_time;
        std::string message;
        // parse a time for message time and message content
        // ignore if line invalid
        if (!parseLine(line, msg_time, message))
        {
            continue;
        }

        // if found any messages older than message time, stop
        if (!msg_time.empty() && time.compare(msg_time) > 0)
        {
            break;
        }
        // msg_time empty, ignore
        else if (msg_time.empty())
        {
            continue;
        }
        // the msg time is still newer than the given time
        // seek back 5000 more
        else
        {
            position -= stepSize;
            // check if the position is out of scope
            // set current-5000 if still in scope
            if (position + size - 1 >= 0)
            {
                m_log.seekg(position, std::ios::end);
                continue;
            }
            // else set it to the begining
            else
            {
                m_log.seekg(0, std::ios::beg);
                break;
            }
        }
    }
}

// count messages matching a pattern in a time range
// input:
//   messageText - pattern to match
//   startTime   - start of a time range
//   endTime     - end of a time range
//   errorMsg    - error message
int32_t MessageLog::count(const std::string& expectedText,
                          const std::string& startTime,
                          const std::string& endTime,
                          const bool& isTimedout,
                          std::string& messages,
                          std::string& errorMsg) noexcept
{
    // vector to store matchedfile lines
    int32_t count = 0;

    // return 0 if startTime > endTime
    if (startTime.empty()
      or endTime.empty()
      or startTime.compare(endTime) > 0)
    {
        return count;
    }

    // reset log file stream status and current position
    resetLogStream(startTime);

    std::string line;
    // parse each line
    while (std::getline(m_log, line))
    {
        if (isTimedout)
        {
            errorMsg = timedoutMsg;
            return 0;
        }

        std::string msg_time;
        std::string message;
        // parse a time for message time and message content
        // ignore if line invalid
        if (!parseLine(line, msg_time, message))
        {
            continue;
        }

        // ignore messages older than the start time
        if (startTime.compare(msg_time) > 0)
        {
            continue;
        }

        // break if the current message is newer than the end time
        if (endTime.compare(msg_time) < 0)
        {
            break;
        }

        // matching message
        if (boost::regex_match(message, boost::regex(m_message_pattern)))
        {
            // remove the leading header like "Sent FixMsg: "
            std::string msg = boost::regex_replace(message,
              boost::regex("([A-Za-z ]*: )(.*)"),
              "$2");
            std::string msgText;
            // read response text if possible
            if (std::getline(m_log, line)
              // parse line for time and message
              && parseLine(line, msg_time, message)
              // check if it matches response text pattern
              && boost::regex_match(message,
                boost::regex(m_messagetext_pattern)))
            {
                // get response text
                msgText = boost::regex_replace(message,
                  boost::regex("([A-Za-z ]*: )(.*)"),
                  "$2");
            }

            std::string errorMsg;
            // match message to the expected text
            if (match(expectedText, msg + msgText, m_delimiters, errorMsg))
            {
                count++;
                messages += msg + " \n";
            }
        }
    }

    return count;
}

// Check if a text string is indicated as a pattern
// If a text is in pattern "regex(<pattern>)", it will be treated
// as a regex pattern.
bool MessageLog::isRegex(const std::string& text) const noexcept
{
    if (!text.empty() && text.front() == '(' && text.back() == ')')
    {
        return true;
    }
    return false;
}

// Check if an entry in a vector matching a regex pattern
// input:
//   - vector of entries in format "<tag>=<value>"
//   - a pattern: regex matching pattern
// return true if found a match.
bool MessageLog::isRegexMatched(
  const std::vector<std::string>& messageTextPairs,
  const std::string& pattern) const noexcept
{
    for (const std::string& entry : messageTextPairs)
    {
        try
        {
            if (boost::regex_match(entry, boost::regex(pattern)))
            {
                return true;
            }
        }
        catch (std::exception& e)
        {
            std::cout << "Error: " << e.what() << std::endl;
        }
    }
    return false;
}

// Return all messages' text in the vector in a string
// input:
//  - messageVector
// return a string with dilimiter '\n'
std::string MessageLog::getRefMessageText(
  const std::vector<Message>& messageVector) noexcept
{
    std::string refMessageText;
    if (messageVector.size() > 0)
    {
        int32_t messageCount = 100;
        refMessageText += "RefMsg: ";
        for (const auto& msg : messageVector)
        {
            const std::string& msgText = msg.text;
            const std::string& binMsg  = msg.binMsg;
            // binary message
            if (!binMsg.empty())
            {
                refMessageText += msgText + "  " + "Binary: " + binMsg + ";  ";
            }
            // fix message
            else
            {
                refMessageText += msgText + "  ";
            }

            // maximum attach message <= 100
            if (messageCount-- <= 0)
            {
                break;
            }
        }
    }

    return std::move(refMessageText);
}

// get malformed message from message log with a period
// and return with a vector
//  input: expected text
//         startTime
//         endTime
// output: malformed message vector
const std::vector<MessageLog::Message>
MessageLog::malformedMessage(const std::string& expectedText,
                             const std::string& startTime,
                             const std::string& endTime,
                             const bool& isTimedout,
                             std::string& errorMsg) noexcept
{
    // vector to store malformed message
    std::vector<MessageLog::Message> messageVector;

    // check the startTime & endTime
    if (startTime.empty()
      or endTime.empty()
      or startTime.compare(endTime) > 0)
    {
        errorMsg = "Invalid start time/end time.";
        return std::move(messageVector);
    }

    // reset log file stream status and current position
    resetLogStream(startTime);

    // define pattern of malformed message
    const std::string malformedMsgPattern = "Info: MalformedMsg:.*";

    std::string line;
    // parse each line
    while (std::getline(m_log, line))
    {
        if (isTimedout)
        {
            errorMsg = timedoutMsg;
            messageVector.clear();
            break;
        }

        std::string msg_time;
        std::string message;
        // parse a time for message time and message content
        // ignore if line invalid
        if (!parseLine(line, msg_time, message))
        {
            continue;
        }

        // ignore the messages which is older than the start time
        if (startTime.compare(msg_time) > 0)
        {
            continue;
        }

        // break if the current message is newer than the end time
        if (endTime.compare(msg_time) < 0)
        {
            break;
        }

        // matching message
        if (boost::regex_match(message,
                               boost::regex(malformedMsgPattern)))
        {
            // remove the leading header "Info: MalformedMsg: "
            // of malformed message
            boost::algorithm::erase_first(message,
                                          "Info: MalformedMsg: ");
            if (match(expectedText, message, m_delimiters, errorMsg))
            {
                // treat it as malformed message if matched
                // and save message into vector for return
                messageVector.push_back(
                  Message(msg_time, message, "", "", "", ""));
            }
        }
    }

    return std::move(messageVector);
}
}
