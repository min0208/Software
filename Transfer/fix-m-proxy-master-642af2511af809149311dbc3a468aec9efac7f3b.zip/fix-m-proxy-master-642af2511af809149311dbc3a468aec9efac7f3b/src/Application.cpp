/****************************************************************************
 *     Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : application.cpp
 *   Project  : Wabi II
 *   Description: application class for fix client initiator
 *
 *   Created  : 2015/03/17
 *   Author   : Yang Du
 ****************************************************************************/

#include <iostream>
#include <string>
#include <chrono>
#include <thread>
#include <mutex>

// quick-fix
#include "quickfix/Session.h"
#include "quickfix/SocketConnection.h"
#include "quickfix/Message.h"
#include "quickfix/BinaryMessage.h"
#include "quickfix/BinaryCCCG.h"
#include "quickfix/BinaryOCG.h"
#include "quickfix/BinaryUtils.h"
#include "quickfix/SessionSettings.h"

// protocol FIX44
#include "lme/fix44/NewOrderSingle.h"
#include "lme/fix44/OrderCancelReplaceRequest.h"
#include "lme/fix44/OrderCancelRequest.h"
#include "lme/fix44/OrderStatusRequest.h"
#include "lme/fix44/TradeCaptureReportRequest.h"
#include "quickfix/fix44/SecurityListRequest.h"


// LMFI, LME Member FIX
#include "lme/fix44/NewTradeList.h"
#include "lme/fix44/TradeCancelRequest.h"
#include "lme/fix44/TradeMassStatusRequest.h"
#include "lme/fix44/DownloadRequest.h"

#include "lme/fix44/TradeExecutionReport.h"
#include "lme/fix44/TradeCancelReject.h"
#include "lme/fix44/RequestResponse.h"

#include "quickfix/fix44/News.h"
#include "lme/fix44/SecurityDefinition.h"
#include "lme/fix44/MemberDefinition.h"

// boost
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>

#include "Application.h"
#include "Converter.h"
#include "Server.h"
#include "Utils.h"
#include "Encryptor.h"

namespace FIXProxy
{
// Constructor
//  - init session settings
Application::Application(const std::string& msgLogFile,
                         FIX::SessionSettings& settings)
  : m_settings(settings),
    m_msgLogFile(msgLogFile)
{
    initCurrentSessionSettings();
}

// start application and waiting for input
// start a socket server on [port]
void Application::run(const int16_t port) noexcept
{
    Server(*this, port);
}

// Callback on session logon
//  - Log message.log for current session information
//  - Log session log for current session information
void Application::onLogon(const FIX::SessionID& sessionID) noexcept
{
    // write session status information to message.log
    std::string sessionInfo =
      getConnectionInfo(sessionID) + "Status=Logon;";
    std::lock_guard<std::mutex> logGuard(m_msgLogFileMutex);
    logMessage(sessionInfo, "Session Info: ");
    logSession(sessionInfo, "Session Info: ", sessionID);
}

// Callback on session logout
//  - Log message.log for current session information
//  - Log session log for current session information
void Application::onLogout(const FIX::SessionID& sessionID) noexcept
{
    // write session status information to message.log
    std::string sessionInfo =
      getConnectionInfo(sessionID) + "Status=Logoff;";
    std::lock_guard<std::mutex> logGuard(m_msgLogFileMutex);
    logMessage(sessionInfo, "Session Info: ");
    logSession(sessionInfo, "Session Info: ", sessionID);
}

// Callback on application message received
//  - log message.log for any message received.
//  - log session log for any message received.
//  - Print the received message to console.
void Application::fromApp(const FIX::Message& message,
                          const FIX::SessionID& sessionID)
  throw (FIX::FieldNotFound,
         FIX::IncorrectDataFormat,
         FIX::IncorrectTagValue,
         FIX::UnsupportedMessageType)
{
    // write message & session log
    logMessage(message, sessionID,
               "Received FIXMsg: ",
               "Received MsgText: ",
               "Received BinFields: ",
               "Received BinMsg: ");
    std::cout << "Received FIXMsg: "
              << Utils::showSpecChars(Utils::toString(message))
              << std::endl;
}

// Callback on application message sent out
//  - check if field PossDupFlag set. ignore message if set the field
//  - set TransactTime if message type is one of
//    * OrderCancelReuqest
//    * OrderCancelReuqest
//    * OrderCancelReplaceReuqest
//    * OrderMassCancelRequest
//  - log outgoing FIX message
void Application::toApp(FIX::Message& message,
                        const FIX::SessionID& sessionID)
  throw (FIX::DoNotSend)
{
    try
    {
        FIX::PossDupFlag possDupFlag;
        message.getHeader().getField(possDupFlag);
        if (possDupFlag.getValue())
        {
            throw FIX::DoNotSend();
        }
    }
    catch (FIX::FieldNotFound&)
    {
    }

    logMessage(message, sessionID,
               "Sent FIXMsg: ", "Sent MsgText: ",
               "Sent BinFields: ", "Sent BinMsg: ");
    std::cout << "Sent FIXMsg: "
              << Utils::showSpecChars(Utils::toString(message))
              << std::endl;
}

// callback on admin message sent out
//  - special handling for Logon message
//  - log Admin FIX outgoing message
//  - enable session if sent logon mesage
//  - disable session if sent logout mesage
void Application::toAdmin(FIX::Message& message,
                          const FIX::SessionID& sessionID) noexcept
{
    FIX::Session* session = FIX::Session::lookupSession(sessionID);
    if (!session)
    {
        return;
    }
    
    auto msgType = FIELD_GET_REF(message.getHeader(), MsgType);
    if (FIX::MsgType_Logon == msgType)
    {
        if (m_workingSessions.find(sessionID) == m_workingSessions.end())
        {
            m_workingSessions.insert(sessionID);
        }
        processLogonMessage(message, sessionID);
    }
    else if (FIX::MsgType_Logout == msgType)
    {
        session->logout();
    }

    logMessage(message, sessionID,
               "Sent AdminFIXMsg: ",
               "Sent AdminMsgText: ",
               "Sent AdminBinFields: ",
               "Sent AdminBinMsg: ");

    std::cout << "Sent AdminFIXMsg: "
              << Utils::showSpecChars(Utils::toString(message)) << std::endl;
}


// Process messages outgoing message
//  before just sent out
//
// It is invoked in Application::toApp.
// In this function it will check
//   messages by types to determine
// whether it needs to add a transaction time.
void Application::processOutgoingAppMessage(const std::string& messageText,
                                            FIX::Message& message,
                                            const FIX::SessionID& sessionID) noexcept
{
    FIX::MsgType msgType;
    if (message.getHeader().isSetField(FIX::FIELD::MsgType))
    {
        message.getHeader().getFieldIfSet(msgType);
    }

    // if message type is one of
    //   NewOrderSingle
    //   OrderCancelReuqest
    //   OrderCancelReplaceReuqest
    //   OrderMassCancelRequest,
    //   Quote
    // append TransactTime automatically
    if (FIX::MsgType_NewOrderSingle == msgType
        or FIX::MsgType_OrderCancelReplaceRequest == msgType
        or FIX::MsgType_OrderCancelRequest == msgType
        or FIX::MsgType_OrderMassCancelRequest == msgType
        or FIX::MsgType_Quote == msgType
        or FIX::MsgType_TradeCaptureReport == msgType)
    {
        // if MillisecondsInTimeStamp set
        // 3 milliseconds digits will be appended
        FIX::Session* session = FIX::Session::lookupSession(sessionID);

        if (session && session->getMillisecondsInTimeStamp())
        {
            const uint16_t three = 3;
            Converter::setTransactTime(message, three, false);
        }
        // 0 milliseconds digits will be appended
        else
        {
            Converter::setTransactTime(message, 0, false);
        }

        // remove tag 60
        auto tvPairs = Converter::toFieldValuePairs(messageText);
        for (auto const& pair : tvPairs)
        {
            if ((pair.first == "60" or pair.first == "TransactTime")
              and pair.second.empty())
            {
                message.removeField(FIX::FIELD::TransactTime);
                break;
            }
        }
    }
}

// Set a session setting
// input:
//   - name: setting name
//   - value: setting value
void Application::setSessionSettingString(const FIX::SessionID& sessionID,
                                          const std::string& name,
                                          const std::string& value) noexcept
{
    FIX::Dictionary& sessionSettings = getCurrentSessionSetting(sessionID);
    sessionSettings.setString(name, value);
}

// Get a session setting
// input:
//   - name: setting name
std::string Application::getSessionSettingString(const FIX::SessionID& sessionID,
                                                 const std::string& name) noexcept
{
    const FIX::Dictionary sessionSettings = getCurrentSessionSetting(sessionID);
    if (sessionSettings.has(name))
    {
        return sessionSettings.getString(name);
    }

    return std::string();
}

// Set one session setting value
//  according the logon message.
//  - set to the tag value of the logon message if exist
//  - set to empty if the message doesn't contain the tag
void Application::setSessionSettingString(const FIX::Message& message,
                                          const int32_t field,
                                          const std::string& settingString,
                                          FIX::Dictionary& sessionSettings) noexcept
{
    // update session settings according to the given message
    // set empty if field can't be found from message
    if (message.isSetField(field))
    {
        sessionSettings.setString(settingString,
                                  message.getField(field));
    }
    else
    {
        sessionSettings.setString(settingString, std::string());
    }
}

// Update session settings by the given logon message
//
// As QuickFIX automatically sending out logon message,
// we need to update the session settings if there is manully logon request
//
// Fields below in the Logon message will be refreshed
//  - EncryptedPasswordMethod
//  - EncryptedPassword
//  - Password
//  - EncryptMethod
//  - EncryptedNewPassword
//  - NewPassword
//  - HeartBtInt
//  - DefaultApplVerID
void Application::updateSessionSettings(const FIX::Message& message,
                                        const FIX::SessionID& sessionID) noexcept
{
    try
    {
        FIX::Dictionary& sessionSettings = getCurrentSessionSetting(sessionID);

        // EncryptMethod(98)
        setSessionSettingString(message,
                                FIX::FIELD::EncryptMethod,
                                "EncryptMethod",
                                sessionSettings);

        // HeartBtInt(108)
        setSessionSettingString(message,
                                FIX::FIELD::HeartBtInt,
                                "HeartBtInt",
                                sessionSettings);

        // Username(553)
        setSessionSettingString(message,
                                FIX::FIELD::Username,
                                "Username",
                                sessionSettings);

        // Password(554)
        setSessionSettingString(message,
                                FIX::FIELD::Password,
                                "Password",
                                sessionSettings);
    }
    catch (std::exception& e)
    {
        std::cout << "Error: failed to get settings for session: "
                  << sessionID.toString()
                  << ", reason=" << e.what() << std::endl;
    }
}

// process Logon Request based on session settings
// priority: 1. set tag value by using message tag value if have
//           2. set tag value by using current session setting if have
//           3. set tag value by using default session setting if have
//  - if setting EnableNextExpectedMsgSeqNum=Y,
//      set the value to getExpectedTargetNum,
//      or set to 1 if nextExpectedMsgSeqNum is not avilable
//  - if set EncryptedPasswordMethod,
//     set FIX tag 1400 to the value
//  - if set Password,
//     encrypt the value
//     and set the encrypted text to FIX tag 1402
//  - if set NewPassword,
//     encrypt the value
//     snd set the encrypted text to FIX tag 1404
//  - if set EncryptedPassword,
//     set FIX tag 1402 to the value
//  - if set EncryptedNewPassword,
//     set FIX tag 1404 to the value
void Application::processLogonMessage(FIX::Message& message,
                                      const FIX::SessionID& sessionID) noexcept
{
    const FIX::Dictionary& currentSessionSetting = getCurrentSessionSetting(sessionID);
    const FIX::Dictionary& defaultSessionSetting = m_settings.get(sessionID);

    // NextExpectedMsgSeqNum(789)
    if (currentSessionSetting.has("EnableNextExpectedMsgSeqNum")
      and currentSessionSetting.getString("EnableNextExpectedMsgSeqNum") == "Y")
    {
        FIX::NextExpectedMsgSeqNum nextExpectedMsgSeqNum = 1;
        FIX::Session* session = FIX::Session::lookupSession(sessionID);
        if (session)
        {
            try
            {
                nextExpectedMsgSeqNum = session->getExpectedTargetNum();
            }
            catch (std::exception& e)
            {
            }
        }

        if (!message.isSetField(FIX::FIELD::NextExpectedMsgSeqNum))
        {
            message.setField(nextExpectedMsgSeqNum);
        }
    }

    // EncryptMethod(98)
    setTagFromSetting(message,
                      currentSessionSetting,
                      defaultSessionSetting,
                      "EncryptMethod",
                      FIX::FIELD::EncryptMethod);
    // HeartBtInt(108)
    setTagFromSetting(message,
                      currentSessionSetting,
                      defaultSessionSetting,
                      "HeartBtInt",
                      FIX::FIELD::HeartBtInt);
    // Username(553)
    setTagFromSetting(message,
                      currentSessionSetting,
                      defaultSessionSetting,
                      "Username",
                      FIX::FIELD::Username);
    // Password(554)
    setEncryptedPassword(message, sessionID);
}

// Set field EncryptedPassword(1402) for Logon message
// input:
//   - message: a message to set
//   - sessionID: current session ID
//
// if message has field Password,
//   get value of the field, encrypt it and set
//   it to field EncryptedPassword.
//   and remove field Password.
//
// if has setting Password,
//   get value of the setting, encrypt it and set
//   it to field EncryptedPassword
// priority: 1. current session setting
//           2. default session setting
//
// if has setting EncryptedPassword,
//   get value of the setting and set
//   it to field EncryptedPassword
//
void Application::setEncryptedPassword(FIX::Message& message,
                                       const FIX::SessionID& sessionID) noexcept
{
    const FIX::Dictionary& currentSessionSetting = getCurrentSessionSetting(sessionID);
    const FIX::Dictionary& defaultSessionSetting = m_settings.get(sessionID);

    std::string password;
    if (message.isSetField(FIX::FIELD::Password))
    {
        // if has field Password
        password = message.getField(FIX::FIELD::Password);
    }
    else
    {
        // get field Password from session settings
        password = getFieldFromSessionSettings(currentSessionSetting,
                                               defaultSessionSetting,
                                               "Password");
    }

    if (!password.empty())
    {
        const std::string& faxKey  =
          getFieldFromSessionSettings(currentSessionSetting,
                                      defaultSessionSetting,
                                      "FaxKey");
        const int64_t timeInMillis =
          std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

        const std::string encryptedPassword =
          Encryptor::generateEncryptedPassword(password, faxKey, timeInMillis);
        const std::string rawData("m:" + std::to_string(timeInMillis));

        // Password(554)
        message.setField(FIX::FIELD::Password, encryptedPassword);
        // RawData(96)
        message.setField(FIX::FIELD::RawData, rawData);
        // RawDataLength(95)
        message.setField(FIX::FIELD::RawDataLength, std::to_string(rawData.length()));
    }
}

//// Set field EncryptedNewPassword(1404) for Logon message
//// input:
////   - message: a message to set
////   - sessionID: current session ID
////
//// if message has field NewPassword,
////   get value of the field, encrypt it and set
////   it to field EncryptedNewPassword.
////   and remove field NewPassword.
////
//// if has setting NewPassword,
////   get value of the setting, encrypt it and set
////   it to field EncryptedNewPassword
//// priority: 1. current session setting
////           2. default session setting
////
//// if has setting EncryptedNewPassword,
////   get value of the setting and set
////   it to field EncryptedNewPassword
////
//void Application::setEncryptedNewPassword(FIX::Message& message,
//  const FIX::SessionID& sessionID) noexcept
//{
//    const FIX::Dictionary& currentSessionSetting =
//                                         getCurrentSessionSetting(sessionID);
//    const FIX::Dictionary& defaultSessionSetting = m_settings.get(sessionID);
//    FIX::Session* session = FIX::Session::lookupSession(sessionID);
//    // if has field Password
//    std::string newPassword;
//    if (message.isSetField(FIX::FIELD::NewPassword))
//    {
//        newPassword = message.getField(FIX::FIELD::NewPassword);
//    }
//    else
//    {
//        // get field NewPassword from session settings
//        newPassword = getFieldFromSessionSettings(currentSessionSetting,
//                                                  defaultSessionSetting,
//                                                  "NewPassword");
//    }
//
//    if (!newPassword.empty())
//    {
//        // add UTC time prefix if binary session
//        if (session && session->getIsBinary())
//        {
//            newPassword = Utils::getUTCTimeStamp() + newPassword;
//        }
//
//        const std::string encryptedNewPassword =
//          Utils::rsaEncrypt(newPassword);
//
//        message.setField(FIX::FIELD::EncryptedNewPassword,
//                         encryptedNewPassword);
//        message.removeField(FIX::FIELD::NewPassword);
//    }
//    // else if has setting EncryptedPassword
//    else
//    {
//        setTagFromSetting(message, currentSessionSetting,
//                          defaultSessionSetting,
//                          "EncryptedNewPassword",
//                          FIX::FIELD::EncryptedNewPassword);
//    }
//}

// Set a Tag from Session Setting
// input:
//   - message: the message
//   - sessionSettings: session settings
//   - sessionSettings: default session settings
//   - settingString: the setting
//   - tag: a tag
//
// If a tag is not set, get value from session setting
// and set the value to the message
// priority: 1. message
//           2. current session setting
//           3. default session setting
//
void Application::setTagFromSetting(FIX::Message& message,
                                    const FIX::Dictionary& currentSessionSetting,
                                    const FIX::Dictionary& defaultSessionSetting,
                                    const std::string& settingString,
                                    uint32_t tag) noexcept
{
    if (!message.isSetField(tag))
    {
        // get field value from session settings
        std::string value = getFieldFromSessionSettings(currentSessionSetting,
                                                        defaultSessionSetting,
                                                        settingString);
        if (!value.empty())
        {
            message.setField(tag, value);
        }
    }
}

// Send out fix message from a string input
// The input string is expected as a space/semcolon sperated string
//
// If it is an Logon message, update session settings accordingly.
// QuickFIX will auto send out logon request using the latest session
// setting from now on.
//
// If BeginString(8) equals to "FIXT.1.1",
//   message will be traited as a FIX50 SP2 protocol one
//   - if 35=D, convert to FIX using FIX50SP2::HKExNewOrderSingle
//   - if 35=G, convert to FIX using FIX50SP2::HKExOrderCancelReplaceRequest
//   - if 35=F, convert to FIX using FIX50SP2::OrderCancelRequest
//   - if 35=q, convert to FIX using FIX50SP2::OrderMassCancelRequest
//   - if 35=CU, convert to FIX using FIX50SP2::PartyEntitlementRequest
//   - if 35=BE, convert to FIX using FIX50SP2::UserRequest
//   - other message type is not supported
//
// If BeginString(8) equals to "FIXT42",
//   message will be traited as a FIX42 protocol one,
//   3 message types are supported
//   - if 35=D, convert to FIX using FIX42::NewOrderSingle
//   - if 35=G, convert to FIX using FIX42::OrderCancelReplaceRequest
//   - if 35=F, convert to FIX using FIX42::OrderCancelRequest
//
// For any other FIX protocol, it is not supported.
bool Application::sendFIXMessage(const std::string& messageText) noexcept
{
    const std::string msgType      = Converter::getMsgType(messageText);
    const std::string beginString  = Converter::getBeginString(messageText);
    const std::string senderCompID = Converter::getSenderCompID(messageText);
    const std::string targetCompID = Converter::getTargetCompID(messageText);

    FIX::SessionID sessionID(beginString, senderCompID, targetCompID);

    FIX::Message message;

    // send out message
    try
    {
        // for logon request, update session parameters accordingly.
        // the settings changes will be in effect later on.
        if (msgType == FIX::MsgType_Logon)
        {
            handleLogonMessage(messageText, message);
            // let QuickFIX auto connect if session not logon
            // send the logon message if session logon already
            // TODO - handle when session can't be found
            FIX::Session* session = FIX::Session::lookupSession(sessionID);
            if (session and !session->isLoggedOn())
            {
                return true;
            }
        }
        // If it is SequenceReset request,
        // update the NewSeqNo(36) to next sender message sequence.
        else if (msgType == FIX::MsgType_SequenceReset)
        {
            handleSequenceResetMessage(messageText, message);
        }
        // FIX protocol FIX44
        else if (beginString == "FIX.4.4")
        {
            FIX::Session* session = FIX::Session::lookupSession(sessionID);
            if (session and session->getSubSystemType() == "MemberFIX")
            {
                handleFIX44MemberFIXMessage(messageText, message);
            }
            else if (session and session->getSubSystemType() == "SelectFIX")
            {
                handleFIX44SelectFIXMessage(messageText, message);
            }

        }
        // other FIX protocol
        else
        {
            message = Converter::toFIXMessage<FIX::Message>(messageText);
        }

        processOutgoingAppMessage(messageText, message, sessionID);

        // send out message
        FIX::Session::sendToTarget(message);

        return true;
    }
    catch (std::exception& e)
    {
        std::cout << e.what() << "\n";
        return false;
    }
}

// Handle Logon message
// It will update the session settings accordingly,
// and enable session logon.
//
// After enabled logon, QuickFIX will manage session logon by itself.
//
void Application::handleLogonMessage(const std::string& messageText,
                                     FIX::Message& message) noexcept
{
    const std::string beginString  = Converter::getBeginString(messageText);
    const std::string senderCompID = Converter::getSenderCompID(messageText);
    const std::string targetCompID = Converter::getTargetCompID(messageText);

    FIX::SessionID sessionID(beginString, senderCompID, targetCompID);
    message = Converter::toFIXMessage<FIX::Message>(messageText);

    updateSessionSettings(message, sessionID);

    FIX::Session* session = FIX::Session::lookupSession(sessionID);
    if (session)
    {
        session->logon();
        // reset AutoReconnectCount
        if (!session->isLoggedOn())
        {
            session->resetFirstLogon();
            FIX::Dictionary sessionSettings = m_settings.get(sessionID);
            if (sessionSettings.has(FIX::AUTO_RECONNECT_COUNT))
            {
                session->setAutoReconnectCount(
                  sessionSettings.getInt(FIX::AUTO_RECONNECT_COUNT));
            }
            session->setStartFromPrimaryHost(true);
        }
    }
    else
    {
        std::cout << "Error: session not found, id="
                  << sessionID.toString()
                  << ", failed to handle Logon message: "
                  << Utils::formatMessageText(messageText) << std::endl;
    }
}

// Generate a Sequence Reset message based on the message string
// input:
//  - message string
//  - FIX message to return
//
// If session information not found the message string,
//  print error and return.
//
// The Sequence Reset will always be set with GapFills=Y and
// it will be set with correct new sequence number(36)
void Application::handleSequenceResetMessage(const std::string& messageText,
                                             FIX::Message& message) noexcept
{
    const std::string beginString  = Converter::getBeginString(messageText);
    const std::string senderCompID = Converter::getSenderCompID(messageText);
    const std::string targetCompID = Converter::getTargetCompID(messageText);

    message = Converter::toFIXMessage<FIX::Message>(messageText);

    FIX::SessionID sessionID(beginString, senderCompID, targetCompID);
    FIX::Session* session = FIX::Session::lookupSession(sessionID);
    if (session)
    {
        FIX::NewSeqNo newSeqNo = session->getExpectedSenderNum();
        message.getHeader().setField(FIX::FIELD::PossDupFlag, "Y");
        message.setField(newSeqNo);
    }
    else
    {
        std::cout << "Error: session not found, id="
                  << sessionID.toString()
                  << ", failed to handle SequenceReset message: "
                  << Utils::formatMessageText(messageText) << std::endl;
    }
}

// Handle message conversion for protocol FIX4.4, MemberFIX
// support message type:
//   New Trade List  E
//   Trade Cancel Request    F
//   Order Mass Status Request   AF
//   Download Request    cm2
//   
//   Trade Execution Report    8
//   Trade Cancel Reject 9
//   Request Response   cm3
//   News    B
//   Security Definition d
//   Member Definition   cm4
//   Business Message Reject j
void Application::handleFIX44MemberFIXMessage(const std::string& messageText,
                                              FIX::Message& message) noexcept
{
    const std::string msgType = Converter::getMsgType(messageText);

    if (msgType == FIX::MsgType_NewTradeList){
        message = Converter::toFIXMessage<FIX44::NewTradeList>(messageText);}
    else if (msgType == FIX::MsgType_TradeCancelRequest){
        message = Converter::toFIXMessage<FIX44::TradeCancelRequest>(messageText);}
    else if (msgType == FIX::MsgType_TradeMassStatusRequest){
        message = Converter::toFIXMessage<FIX44::TradeMassStatusRequest>(messageText);}
    else if (msgType == FIX::MsgType_DownloadRequest){
        message = Converter::toFIXMessage<FIX44::DownloadRequest>(messageText);}
    else if (msgType == FIX::MsgType_TradeExecutionReport){
        message = Converter::toFIXMessage<FIX44::TradeExecutionReport>(messageText);}
    else if (msgType == FIX::MsgType_TradeCancelReject){
        message = Converter::toFIXMessage<FIX44::TradeCancelReject>(messageText);}
    else if (msgType == FIX::MsgType_RequestResponse){
        message = Converter::toFIXMessage<FIX44::RequestResponse>(messageText);}
    else if (msgType == FIX::MsgType_News){
        message = Converter::toFIXMessage<FIX44::News>(messageText);}
    else if (msgType == FIX::MsgType_SecurityDefinition){
        message = Converter::toFIXMessage<FIX44::SecurityDefinition>(messageText);}
    else if (msgType == FIX::MsgType_MemberDefinition){
        message = Converter::toFIXMessage<FIX44::MemberDefinition>(messageText);}
    // others
    else
    {
        message = Converter::toFIXMessage<FIX::Message>(messageText);
    }
}


// Handle message conversion for protocol FIX4.4, SelectFIX
// support message type:
// - NewOrderSingle(35=D)
// - OrderCancelReplaceRequest(35=G)
// - OrderCancelRequest(35=F)
// - OrderStatusRequest(35=H)
// - TradeCaptureReportRequest(35=AD)
void Application::handleFIX44SelectFIXMessage(const std::string& messageText,
                                              FIX::Message& message) noexcept
{
    //TODO
    const std::string msgType = Converter::getMsgType(messageText);
    // NewOrderSingle(35=D)
    if (msgType == FIX::MsgType_NewOrderSingle)
    {
        message = Converter::toFIXMessage<FIX44::NewOrderSingle>(messageText);
    }
    // OrderCancelReplaceRequest(35=G)
    else if (msgType == FIX::MsgType_OrderCancelReplaceRequest)
    {
        message = Converter::toFIXMessage<FIX44::OrderCancelReplaceRequest>(messageText);
    }
    // OrderCancelRequest(35=F)
    else if (msgType == FIX::MsgType_OrderCancelRequest)
    {
        message = Converter::toFIXMessage<FIX44::OrderCancelRequest>(messageText);
    }
    // OrderStatusRequest(35=H)
    else if (msgType == FIX::MsgType_OrderStatusRequest)
    {
        message = Converter::toFIXMessage<FIX44::OrderStatusRequest>(messageText);
    }
    // TradeCaptureReportRequest(35=AD)
    else if (msgType == FIX::MsgType_TradeCaptureReportRequest)
    {
        message = Converter::toFIXMessage<FIX44::TradeCaptureReportRequest>(messageText);
    }
    // SecurityListRequest(35=x)
    else if (msgType == FIX::MsgType_SecurityListRequest)
    {
        message = Converter::toFIXMessage<FIX44::SecurityListRequest>(messageText);
    }
    // others
    else
    {
        message = Converter::toFIXMessage<FIX::Message>(messageText);
    }
}

// lookup FIX request from FIX message log file using
//  - a pattern
//  - time as constraint
// as input
// return the matched messages in a vector
std::vector<MessageLog::Message>
Application::lookupFIXRequest(const std::string& messageText,
                              const std::string& time,
                              const bool& isTimedout) noexcept
{
    Utils::printSysLog("Lookup request matching: "
      + Utils::formatMessageText(messageText)
      + " sent after " + time);
    return MessageLog(m_msgLogFile).request(messageText,
                                            time,
                                            isTimedout);
}

// lookup FIX response from FIX message log file using
//  - a pattern
//  - time as constraint
// as input
// return the matched messages in a vector
std::vector<MessageLog::Message>
Application::lookupFIXResponse(const std::string& messageText,
                               const std::string& time,
                               const bool& isTimedout) noexcept
{
    Utils::printSysLog("Lookup response matching: "
      + Utils::formatMessageText(messageText)
      + " received after " + time);
    return MessageLog(m_msgLogFile).response(messageText,
                                             time,
                                             isTimedout);
}

// lookup FIX message from FIX message log file using
//  - a pattern
//  - time as constraint
// as input
// return the matched messages in a vector
std::vector<MessageLog::Message>
Application::lookupFIXMessage(const std::string& messageText,
                              const std::string& time,
                              const bool& isTimedout) noexcept
{
    Utils::printSysLog("Lookup message matching: "
      + Utils::formatMessageText(messageText)
      + " logged after " + time);
    return MessageLog(m_msgLogFile).message(messageText,
                                            time,
                                            isTimedout);
}

// match FIX response from log file using
//  - a pattern
//  - time as constraint
// as input
// and expect
// return true if found a matching or
// return false and set errorMsg properly
bool
Application::matchFIXResponse(const std::string& messageText,
                              const std::string& time,
                              const bool& isTimedout,
                              std::string& errorMsg) noexcept
{
    Utils::printSysLog("Match response using: "
      + Utils::formatMessageText(messageText)
      + " received after " + time);
    return MessageLog(m_msgLogFile).matchResponse(messageText,
                                                  time,
                                                  isTimedout,
                                                  errorMsg);
}

// Count FIX messages from log file using
//  - a pattern (with start/end time range)
// as input
// and expect
// return matching count
//
// The counting time range is parsed from the message test.
// Start time is required to record in a customed field '_StartTime'
// End time is required to record in a customed field '_EndTime'
int32_t Application::countFIXMessages(const std::string& messageText,
                                      const bool& isTimedout,
                                      std::string& messages,
                                      std::string& errorMsg) noexcept
{
    // As start time and end time and encoded as
    // special tags inside the message text,
    //  we get the the values out first.
    const std::string startTimeFieldName = "_StartTime";
    const std::string endTimeFieldName   = "_EndTime";
    std::string startTime =
      Converter::getFieldValue(messageText, startTimeFieldName);
    std::string endTime   =
      Converter::getFieldValue(messageText, endTimeFieldName);

    // remove the fields which on longer needs
    std::string messageTextNew =
      Converter::removeField(messageText, startTimeFieldName);
    messageTextNew =
      Converter::removeField(messageTextNew, endTimeFieldName);

    Utils::printSysLog("Count messages using: "
      + Utils::formatMessageText(messageTextNew)
      + " from " + startTime + " to " + endTime);
    return MessageLog(m_msgLogFile).count(messageTextNew,
                                          startTime,
                                          endTime,
                                          isTimedout,
                                          messages,
                                          errorMsg);
}

// Log FIX message
//  - message: the FIX message + group string
//  - sessionID: the current sessionID for
//      getting data dictionary information
//  - prefix: prefix for FIX log message string
//  - textPrefix: prefix for FIX text string
//
// The FIX message will be write to
// a session log as well as a message log
//
// A mutex lock is used for
// ensuring the 2 message and text
// entries are logging consucutively
void Application::logMessage(const FIX::Message& message,
                             const FIX::SessionID& sessionID,
                             const std::string& prefix,
                             const std::string& textPrefix,
                             const std::string& binFieldsPrefix,
                             const std::string& binPrefix)
{
    FIX::DataDictionary dataDictionary;
    FIX::DataDictionary appDataDictionary;
    Utils::getSessionDataDictionaries(sessionID,
                                      dataDictionary,
                                      appDataDictionary);

    // write log to both session log and message log
    std::lock_guard<std::mutex> logGuard(m_msgLogFileMutex);
    logMessage(Utils::toString(message,
                               dataDictionary,
                               appDataDictionary), prefix);
    logMessage(Utils::toTextString(message,
                                   dataDictionary,
                                   appDataDictionary), textPrefix);
    logSession(Utils::toString(message), prefix, sessionID);
    logSession(Utils::toTextString(message,
                                   dataDictionary,
                                   appDataDictionary), textPrefix, sessionID);
}

// handle administrive messages from counterparty
//
// if get logon response,
//  set next taget sequence number accordingly
// if get logout response,
//  parse and set next taget sequence number accordingly
void Application::handleFromAdmin(const FIX::Message& message,
                                  const FIX::SessionID& sessionID) noexcept
{
    FIX::Session* session = FIX::Session::lookupSession(sessionID);

    FIX::MsgType msgType;
    message.getHeader().getFieldIfSet(msgType);

    // if get logon response
    // set the next taget sequence number according
    // to the received tag sequence number(34)
    if (session && std::string(msgType) == FIX::MsgType_Logon)
    {
        FIX::MsgSeqNum msgSeqNum;
        message.getHeader().getFieldIfSet(msgSeqNum);
        session->setNextTargetMsgSeqNum(msgSeqNum);
    }

    // if get logout response,
    //  check if it rejected by "MsgSeqNum too low"
    // reset next sender sequence number accordingly
    // As there is no special tag to contains
    //  the expected sequence number,
    // the expected sequence number is parsed from
    // the Text(58) from logout response
    if (session && std::string(msgType) == FIX::MsgType_Logout)
    {
        FIX::Text text;
        message.getFieldIfSet(text);
        std::string expectedSeqNumStr;

        const std::string patternLessThan = "Sequence number is less than";
        const std::string msgSeqNumTooLow = "MsgSeqNum too low";
        std::size_t found = text.getString().find(msgSeqNumTooLow);
        if (!text.getString().empty() && found != std::string::npos)
        {
            const boost::regex expression(".*expecting ([0-9]*) but received.*");
            boost::cmatch what;
            if (boost::regex_match(text.getString().c_str(), what, expression))
            {
                expectedSeqNumStr = what[1];
            }
        }
        else if (!text.getString().empty()
            && patternLessThan == text.getString().substr(0, patternLessThan.size()))
        {
            const boost::regex expression(".*than expected : Expected=([0-9]*).*");
            boost::cmatch what;
            if (boost::regex_match(text.getString().c_str(), what, expression))
            {
                expectedSeqNumStr = what[1];
            }
        }

        if (!expectedSeqNumStr.empty())
        {
            // try/catch here as boost::lexical_cast
            //  may throw exceptions
            try
            {
                int32_t expectedSeqNum =
                  boost::lexical_cast<int32_t>(expectedSeqNumStr);
                session->setNextSenderMsgSeqNum(expectedSeqNum);
            }
            // do nothing if get exception
            catch (std::exception& e)
            {
            }
        }
    }
}

// Return session status string from a enum value
// possible status:
//   - Logon
//   - Logoff
//   - Not Logon
//   - Unknown
std::string Application::sessionStatus(
    const FIXSessionStatus& status) const noexcept
{
    if (FIXSessionStatus::LOGON == status)
    {
        return "Logon";
    }
    else if (FIXSessionStatus::LOGOFF == status)
    {
        return "Logoff";
    }
    else if (FIXSessionStatus::NOT_LOGON == status)
    {
        return "NotLogon";
    }
    else
    {
        return "Unknown";
    }
}

// Get session status by a session ID
// input:
//  - session ID
//
// return a session status string
std::string Application::getSessionStatus(
    const FIX::SessionID& sessionID) const noexcept
{
    FIX::Session* session = FIX::Session::lookupSession(sessionID);
    if (session && session->isLoggedOn())
    {
        return sessionStatus(FIXSessionStatus::LOGON);
    }
    // Check if session closed by peer side without logoff explicitly
    // If connection closed by peer side, the session status would be
    // logoff as QUICKFIX heartbeat is checking it automatically
    else if (session && !session->isLoggedOn())
    {
        if (m_workingSessions.find(sessionID) == m_workingSessions.end())
        {
            return sessionStatus(FIXSessionStatus::NOT_LOGON);
        }
        return sessionStatus(FIXSessionStatus::LOGOFF);
    }
    return sessionStatus(FIXSessionStatus::UNKNOWN);
}

// Get session status by a BeginString, SenderCompID, TargetCompID
// input:
//  - BeginString
//  - SenderCompID
//  - TargetCompID
//
// return a session status string
std::string Application::getSessionStatus(
    const std::string& beginString,
    const std::string& senderCompID,
    const std::string& targetCompID) const noexcept
{
    FIX::SessionID sessionID(beginString, senderCompID, targetCompID);
    return getSessionStatus(sessionID);
}

// Get session status by a message string
// input:
//  - message string with session information
//
// return a session status string if
//   session information exists in the message
// return UNKNOWN session status if session information not found
std::string Application::getSessionStatus(
    const std::string& messageText) const noexcept
{
    Utils::printSysLog("Get session status using: "
      + Utils::formatMessageText(messageText));
    const std::string beginString = Converter::getBeginString(messageText);
    const std::string senderCompID = Converter::getSenderCompID(messageText);
    const std::string targetCompID = Converter::getTargetCompID(messageText);

    if (beginString.empty() or senderCompID.empty() or targetCompID.empty())
    {
        return sessionStatus(FIXSessionStatus::UNKNOWN);
    }

    return getSessionStatus(beginString, senderCompID, targetCompID);
}

// Reformat a message string
// input:
//   - startIndex: start index
//   - endIndex: end index
//   - field: field to contain contents
//      between startIndex and endIndex
// The text between start index and end index will be reformated
// All semicolon characters inside will be replaced to comma.
// All equal sign characters inside will be replaced to comma.
// The result string will be set to field Text.
std::string Application::reformatMessage(const std::string& messageText,
                                         size_t startIndex,
                                         size_t endIndex,
                                         const std::string& field) noexcept
{
    std::string newMessage = messageText;
    std::string blockString =
      messageText.substr(startIndex, endIndex-startIndex);
    std::replace(blockString.begin(), blockString.end(), ';', ',');
    std::replace(blockString.begin(), blockString.end(), '=', ',');
    newMessage += field + "=" + std::move(blockString) + ";";
    return std::move(newMessage);
}

// Process a message before logging to message log
//
// This function will process message
//  types below to different format
//  - Party Entitlement Report (CV)
//  - User Response (BF)
//
// For 35=CV, the string between "1772=" and "10=" will be
//   treated as the repeating group values.
// For MsgType=CV, the string between
//  "NoPartyEntitlements=" and "CheckSum=" will be
//   treated as the repeating group values.
// For 35=BF, the string between "1610=" and "10=" will be
//   treated as the repeating group values.
// For MsgType=BF, the string between
//  "NoThrottles=" and "CheckSum=" will be
//   treated as the repeating group values.
//
// The repeating group values will be treated as
// a block in tag Text(58) in a comma seperated format.

std::string Application::processMessageLogging(
  const std::string& messageText) noexcept
{
    const size_t index1 = messageText.find(";35=CV;");
    const size_t index2 = messageText.find(";MsgType=CV;");
    const size_t index3 = messageText.find(";35=BF;");
    const size_t index4 = messageText.find(";MsgType=BF;");

    // if match none of the message tpyes
    if (index1 == std::string::npos
        && index2 == std::string::npos
        && index3 == std::string::npos
        && index4 == std::string::npos)
    {
        return messageText;
    }

    const size_t pattern1 = messageText.find(";1772=");
    const size_t pattern2 = messageText.find(";NoPartyEntitlements=");
    const size_t pattern3 = messageText.find(";1610=");
    const size_t pattern4 = messageText.find(";NoThrottles=");

    // if match none of the message tpyes
    if (pattern1 == std::string::npos
        && pattern2 == std::string::npos
        && pattern3 == std::string::npos
        && pattern4 == std::string::npos)
    {
        return messageText;
    }

    const size_t checkSumIndex1 = messageText.find(";10=");
    const size_t checkSumIndex2 = messageText.find(";CheckSum=");

    // if match 35=CV
    if (index1 != std::string::npos
       && pattern1 != std::string::npos
       && checkSumIndex1 != std::string::npos)
    {
        return reformatMessage(messageText, pattern1+1, checkSumIndex1, "58");
    }

    // if match MsgType=CV
    if (index2 != std::string::npos
       && pattern2 != std::string::npos
       && checkSumIndex2 != std::string::npos)
    {
        return reformatMessage(messageText, pattern2+1, checkSumIndex2, "Text");
    }

    // if match 35=BF
    if (index3 != std::string::npos
       && pattern3 != std::string::npos
       && checkSumIndex1 != std::string::npos)
    {
        return reformatMessage(messageText, pattern3+1, checkSumIndex1, "58");
    }

    // if match MsgType=BF
    if (index4 != std::string::npos
       && pattern4 != std::string::npos
       && checkSumIndex2 != std::string::npos)
    {
        return reformatMessage(messageText, pattern4+1, checkSumIndex2, "Text");
    }

    // normally shouldn't reach here
    return messageText;
}

// Get FIX Fields
// input:
//   - a message string containing FIX tags
//
// This function should convert all FIX tags to
// both FIX text fields
// return a message string containing FIX text fields
std::string Application::getFIXFields(
  const std::string& messageText) const noexcept
{
    const std::string beginString = Converter::getBeginString(messageText);
    const std::string senderCompID = Converter::getSenderCompID(messageText);
    const std::string targetCompID = Converter::getTargetCompID(messageText);

    FIX::SessionID sessionID(beginString, senderCompID, targetCompID);

    FIX::DataDictionary dataDictionary;
    FIX::DataDictionary appDataDictionary;
    Utils::getSessionDataDictionaries(
      sessionID, dataDictionary, appDataDictionary);

    const auto tvPairs = Converter::toFieldValuePairs(messageText);
    std::string messageTextNew;
    for (auto const& pair : tvPairs)
    {
        std::string fieldName;
        int32_t tag = 0;
        if (Utils::tag2field(dataDictionary, appDataDictionary,
          pair.first, tag, fieldName))
        {
            messageTextNew += std::to_string(tag) + "=" + fieldName + ";";
        }
        else
        {
            messageTextNew += pair.first + "=" + pair.first + ";";
        }

    }

    return std::move(messageTextNew);
}

// Get Session Connection Information
// as a semicolon-seperated string.
//
// eg. "Sender Comp ID=CO0000101;Target Comp ID=HKEXCCCO
// Local IP Address=10.193.40.4;..."
//
// input:
//  - SessionID
//
// The output string will contain all
//  or part of information below:
//  - Sender Comp ID
//  - Target Comp ID
//  - Local IP Address
//  - Local Port
//  - Remote IP Address
//  - Remote Port
//  - Config SocketConnectHost
//  - Config SocketConnectPort
//  - Config SocketConnectHost<N>
//  - Config SocketConnectPort<N>
//
std::string Application::getConnectionInfo(
  const FIX::SessionID& sessionID) const noexcept
{
    std::string connectionInfo = std::string("SenderCompID=")
      + sessionID.getSenderCompID().getValue()
      + ";TargetCompID=" + sessionID.getTargetCompID().getValue() + ";";
    FIX::Session* session = FIX::Session::lookupSession(sessionID);
    if (session)
    {
        int32_t socket = 0;
        FIX::Responder* responder = session->getResponder();
        if (responder)
        {
            socket = responder->getSocket();
        }

        struct sockaddr_in sin;
        socklen_t len = sizeof(sin);
        if (socket && getsockname(socket, (struct sockaddr*)&sin, &len) != -1)
        {
            connectionInfo += "SourceIPAddress="
              + std::string(inet_ntoa(sin.sin_addr)) + ";";
            connectionInfo += "SourcePort="
              + std::to_string(ntohs(sin.sin_port)) + ";";
        }

        if (socket && getpeername(socket, (struct sockaddr*)&sin, &len) != -1)
        {
            connectionInfo += "RemoteIPAddress="
              + std::string(inet_ntoa(sin.sin_addr)) + ";";
            connectionInfo += "RemotePort="
              + std::to_string(ntohs(sin.sin_port)) + ";";
        }
    }

    connectionInfo += getConfigConnectionInfo(sessionID);

    return std::move(connectionInfo);
}

// Get Configured Session Connection Information
// as a semicolon-seperated string.
//
// eg. "Config SocketConnectHost=10.193.40.4
//  Config SocketConnectPort=12345;..."
//
// input:
//  - SessionID
//
// The output string will contain all
//  configured information below:
//  - Config SocketConnectHost
//  - Config SocketConnectPort
//  - Config SocketConnectHost<N>
//  - Config SocketConnectPort<N>
//
std::string Application::getConfigConnectionInfo(
  const FIX::SessionID& sessionID) const noexcept
{
    std::string connectionInfo;
    FIX::Session* session = FIX::Session::lookupSession(sessionID);
    if (!session)
    {
        return std::string();
    }

    FIX::Dictionary sessionSettings = m_settings.get(sessionID);
    // add config of remote ip address/port information
    for (uint32_t i = 0; ; ++i)
    {
        std::string socketHostString = FIX::SOCKET_CONNECT_HOST;
        std::string socketPortString = FIX::SOCKET_CONNECT_PORT;
        if (i)
        {
            socketHostString += std::to_string(i);
            socketPortString += std::to_string(i);
        }
        if (sessionSettings.has(socketHostString)
          && sessionSettings.has(socketPortString))
        {
            connectionInfo += "Config " + socketHostString + "="
              + sessionSettings.getString(socketHostString) + ";";
            connectionInfo += "Config " + socketPortString + "="
              + sessionSettings.getString(socketPortString) + ";";
        }
        else
        {
            break;
        }
    }

    // add config of local ip address information
    if (sessionSettings.has(FIX::LOCAL_IP_ADDRESS))
    {
        connectionInfo += std::string("Config ")
          + FIX::LOCAL_IP_ADDRESS + "="
          + sessionSettings.getString(FIX::LOCAL_IP_ADDRESS) + ";";
    }
    return std::move(connectionInfo);
}


// Get Session Connection Information
// input:
//  - messageText, which should contain
//      - BeginString
//      - SenderCompID
//      - TargetCompID
// to determine session ID.
//
// output:
//   session connection information
//    as a semicolon-seperated string
//
std::string Application::getConnectionInfo(
    const std::string& messageText) const noexcept
{
    Utils::printSysLog("Get session status using: "
      + Utils::formatMessageText(messageText));
    const std::string beginString = Converter::getBeginString(messageText);
    const std::string senderCompID = Converter::getSenderCompID(messageText);
    const std::string targetCompID = Converter::getTargetCompID(messageText);

    if (beginString.empty() or senderCompID.empty() or targetCompID.empty())
    {
        return std::string();
    }

    FIX::SessionID sessionID(beginString, senderCompID, targetCompID);
    std::string status = getSessionStatus(sessionID);
    return getConnectionInfo(sessionID) + "Status=" + status + ";";
}

// Print a log line to message log
// input:
//   - log string
//
// The log line will be printed as string like,
// "Info: abcdefg.."
void Application::printMessageLog(const std::string& messageText) noexcept
{
    Utils::printSysLog("Print info log: " + messageText);
    // 1. get field "Log"
    std::string msgLog = Converter::getFieldValue(messageText, "info");

    // 2. write message log
    std::lock_guard<std::mutex> logGuard(m_msgLogFileMutex);
    logMessage(Utils::showSpecChars(msgLog), "Info: ");
}

// get session setting from current session settings
//  input: - a session ID
// output: - a dictinary which saving session settings
FIX::Dictionary& Application::getCurrentSessionSetting(
  const FIX::SessionID& sessionID)
{
    SessionDictionaries::iterator it = m_currentSessionSettings.find(sessionID);
    if (it == m_currentSessionSettings.end())
    {
       throw FIX::ConfigError( "Session not exist");
    }

    return it->second;
}

// initiate session dictionaries base on default session settings
// called at constructor
void Application::initCurrentSessionSettings() noexcept
{
    std::set<FIX::SessionID> sessionIDs = m_settings.getSessions();
    std::set<FIX::SessionID>::iterator it = sessionIDs.begin();
    for ( ; it != sessionIDs.end(); it++)
    {
        FIX::SessionID sessionID = *it;
        if (m_settings.has(sessionID))
        {
            FIX::Dictionary sessionDictionary(m_settings.get(sessionID));
            m_currentSessionSettings[sessionID] = sessionDictionary;
        }
    }
}

// get field from session settings
// priority: 1. current session settings
//           2. default session settings
// return a empty string if no found
std::string Application::getFieldFromSessionSettings(
  const FIX::Dictionary& currentSessionSetting,
  const FIX::Dictionary& defaultSessionSetting,
  const std::string& field) noexcept
{
    std::string value;
    if (currentSessionSetting.has(field)
      and !currentSessionSetting.getString(field).empty())
    {
        value = currentSessionSetting.getString(field);
    }
    else if (defaultSessionSetting.has(field)
      and !defaultSessionSetting.getString(field).empty())
    {
        value = defaultSessionSetting.getString(field);
    }
    return std::move(value);
}

// lookup malformed message from message log
std::vector<MessageLog::Message>
Application::lookupMalformedMessage(const std::string& messageText,
                                    const bool& isTimedout) noexcept
{
    // As start time and end time and encoded as
    // special tags inside the message text,
    //  we get the the values out first.
    const std::string startTimeFieldName = "_StartTime";
    const std::string endTimeFieldName   = "_EndTime";
    std::string startTime =
      Converter::getFieldValue(messageText, startTimeFieldName);
    std::string endTime   =
      Converter::getFieldValue(messageText, endTimeFieldName);
    std::string errorMsg;

    // remove the fields which on longer needs
    std::string messageTextNew =
      Converter::removeField(messageText, startTimeFieldName);
    messageTextNew =
      Converter::removeField(messageTextNew, endTimeFieldName);

    Utils::printSysLog("Lookup malformed message using: "
      + Utils::formatMessageText(messageTextNew)
      + " from " + startTime + " to " + endTime);

    return MessageLog(m_msgLogFile).malformedMessage(messageTextNew,
                                                     startTime,
                                                     endTime,
                                                     isTimedout,
                                                     errorMsg);
}
}
