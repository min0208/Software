/****************************************************************************
 *     Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : utils.cpp
 *   Project  : Wabi II
 *   Description: utility implementation file
 *
 *   Created  : 2015/03/19
 *   Author   : Yang Du
 ****************************************************************************/

#include "Utils.h"

#include <iostream>
#include <fstream>
#include <streambuf>
#include <string>
#include <chrono>
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <atomic>
#include <thread>

#include <openssl/pem.h>
#include <openssl/rsa.h>
#include <openssl/err.h>

#include <boost/archive/iterators/base64_from_binary.hpp>
#include <boost/archive/iterators/insert_linebreaks.hpp>
#include <boost/archive/iterators/transform_width.hpp>
#include <boost/archive/iterators/ostream_iterator.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>

#include "Converter.h"

namespace FIXProxy
{
const std::string Utils::m_publicKey = "rsa_public_key.pem";
const std::string Utils::m_faxKey    = "omd_fax_key.pem";

// print system log
void Utils::printSysLog(const std::string& logStr) noexcept
{
    std::cout << "[" << getTimeString() << "]["
              << std::this_thread::get_id() << "] "
              << logStr << std::endl;
}

// Convert a string of digits to a integer tag
// This is actually a string to integer convertion founction
//  input: field -- field in text
// output: field -- field in numeric
int32_t Utils::strToField(const std::string& fieldStr) noexcept
{
    int32_t field = 0;
    try
    {
        // convert string to integer field
        field = std::stoi(fieldStr);
    }
    // catch exception if invalid
    catch (std::exception& e)
    {
        std::cout << "Invalid tag: " << fieldStr << "\n" << std::flush;
    }

    return field;
}

// Return fix message as a dilimiter seperated string
// The convertion is simply done by replace the special char '\001'
// to a delimiter in the raw FIX message,
// then it is very effecient.
//  input: - FIX message
//         - delimiter
// output: - message text
// e.g. "8=FIXT.1.1;9=215;35=D;34=73;49=CO01224101;"
std::string Utils::toString(const FIX::Message& message,
                            const std::string delimiter) noexcept
{
    // convert message to \001 seperated string by QuickFIX function
    std::string messageText = message.toString();
    messageText = Utils::hideSpecChars(messageText, "semicolon");
    // replace all \001 char to comma
    std::replace(messageText.begin(), messageText.end(), '\001', ';');
    messageText += getBrokerIDs(message);
    messageText += getTCRBrokerIDs(message);

    return std::move(messageText);
}

// Return fix message as a dilimiter seperated string
// The convertion is simply done by replace the special char '\001'
// to a delimiter in the raw FIX message,
// then it is very effecient.
// Appending the group string
//  input: - FIX message
//         - session data dictionary
//         - business data dictionary
//         - delimiter
// output: - message text
// e.g. "8=FIXT.1.1;9=215;35=D;34=73;49=CO01224101;"
//      "NoDisclosureInstructions=[DisclosureType:100,DisclosureInstruction:1];"
std::string Utils::toString(const FIX::Message& message,
                            const FIX::DataDictionary& dataDictionary,
                            const FIX::DataDictionary& appDataDictionary,
                            const std::string delimiter) noexcept
{
    // convert message to \001 seperated string by QuickFIX function
    std::string messageText = message.toString();
    messageText = Utils::hideSpecChars(messageText, "semicolon");
    // replace all \001 char to comma
    std::replace(messageText.begin(), messageText.end(), '\001', ';');
    // get group string with text format
    // and append it to message tags
    messageText += getGroupString(message,
                                  dataDictionary,
                                  appDataDictionary);
    messageText += getBrokerIDs(message);
    messageText += getTCRBrokerIDs(message);

    return std::move(messageText);
}

// Return fix message as a dilimiter seperated text string
//
// The field names of the given FIX message are coverting
// to text field names defined in FIX spec using the given data
// dictionaries.
//
// For FIX50*, there are 2 data dictionaries. One is transport data
// dictionary and one is application data dictionary.
//
// For FIX4*, there are only one application data dictionary.
//
// Only the fileds has values to be handled,
// and empty value tags will be ingnored.
//
// The conversion is a bit ineffecient,
// as the FIX message is handled tag by tag.
// but looks there is no better way?.
//  input: - message -- FIX::Message
//         - dataDictionary -- Transport data dictionary
//         - appDataDictionary -- Application data dictionary
//         - delimiter -- default = ";"
// output: - message text
// e.g. "BeginString=FIX.4.2;BodyLength=153;MsgType=D;MsgSeqNum=76;"
std::string Utils::toTextString(const FIX::Message& message,
                                const FIX::DataDictionary& dataDictionary,
                                const FIX::DataDictionary& appDataDictionary,
                                const std::string delimiter) noexcept
{
    std::string messageTextNew;
    std::string messageText = message.toString();
    messageText = hideSpecChars(messageText, "semicolon");
    // replace all \001 char to comma
    std::replace(messageText.begin(), messageText.end(), '\001', ';');

    // split to tag=value pairs and save to a vector
    std::vector<std::string> messageAttrsVector;
    // split the FIX string by comma
    boost::algorithm::split(messageAttrsVector,
                            messageText,
                            boost::algorithm::is_any_of(";"),
                            boost::token_compress_on);

    const int16_t pairSize = 2;

    for (auto const& entry : messageAttrsVector)
    {
        std::vector<std::string> tagValuePair;
        // split FIX tag pair by equal sign
        boost::algorithm::split(tagValuePair,
                                entry,
                                boost::algorithm::is_any_of("="));
        // show fields with value
        if (tagValuePair.size() >= pairSize)
        {
            // get tag
            std::string firstValue =
              boost::algorithm::trim_copy(tagValuePair[0]);
            // get value
            std::string secondValue = entry.substr(firstValue.size() + 1);

            std::string fieldName = firstValue;

            // check quickfix data dictionary
            //   for string tag to integer tag convertion
            assert(!firstValue.empty());
            // get field text name from session data dictionary
            // convert the integer tag field to text field using transport and
            // application data dictionaries
            // try catch the exception for std::stoi
            uint32_t tag = 0;
            try
            {
                tag = boost::lexical_cast<int32_t>(firstValue);
            }
            catch (std::exception& e)
            {
                std::cout << "Error: invalid integer tag "
                  << firstValue << std::endl;
                continue;
            }

            if (dataDictionary.getFieldName(tag, fieldName)
              || appDataDictionary.getFieldName(tag, fieldName))
            {
                messageTextNew += fieldName + "=" + secondValue + delimiter;
            }
        }
    }

    return std::move(messageTextNew);
}

// Return fix message from a dilimiter seperated string
// The convertion is simply done by replace the special char '\001'
// to a delimiter in the raw FIX message,
// then it is very effecient.
//  input: message text -- e.g. "8=FIXT.1.1;9=215;35=D;34=73;49=CO01224101;"
//         delimiter
// output: message -- FIX::Message
FIX::Message Utils::toFIX(const std::string& msgStr,
                          const std::string delimiter) noexcept
{
    // convert message to \001 seperated string by QuickFIX function
    std::string messageText = msgStr;

    // replace all \001 char to comma
    std::replace(messageText.begin(), messageText.end(), ';', '\001');

    FIX::Message message;
    try
    {
        message = FIX::Message(Utils::showSpecChars(messageText));
    }
    catch (FIX::InvalidMessage& e)
    {
        // Do nothing
    }

    return std::move(message);
}

// get group string with text format from message
//  input: - FIX message
//         - sessino data dictionary
//         - business data dictionary
// output: - group string
// e.g "NoDisclosureInstructions[1]=
//[DisclosureType:100,DisclosureInstruction:1];"
std::string
Utils::getGroupString(const FIX::Message& message,
                      const FIX::DataDictionary& dataDictionary,
                      const FIX::DataDictionary& appDataDictionary) noexcept
{
   // format group string by a stringstream
   thread_local std::stringstream groupStr;
   groupStr.str("");
   groupStr.clear();

   // loop message and parse group field if found
   FIX::FieldMap::const_iterator it = message.begin();
   for (; it != message.end(); ++it)
   {
       uint32_t tag = it->first;
       std::string field;
       if (dataDictionary.getFieldName(tag, field)
         or appDataDictionary.getFieldName(tag, field))
       {
           if (!Converter::isGroup(field))
           {
               continue;
           }

           // parse all groups for group field found
           size_t count = message.groupCount(tag);
           for (uint32_t j = 1; j <= count; ++j)
           {
               const FIX::FieldMap& group = message.getGroupRef(j, tag);
               std::string temp = parseGroupField(group,
                                                  dataDictionary,
                                                  appDataDictionary);
               // append formatted group string
               // and group name with a subscript
               groupStr << field;
               groupStr << "[";
               groupStr << j;
               groupStr << "]=[";
               groupStr << temp;
               groupStr << "];";
           }
       }
   }

   return std::move(groupStr.str());
}

// Parse group field from a group
// and parse with a recursion for nest group
// get text field from data dictionary
//  input: - FIX group
//         - session data dictionary
//         - business data dictionary
// output: - group string
// e.g "Side:2,NoPartyIDs:[PartyID:5401,PartyIDSource:D,PartyRole:1],ExecInst:c"
std::string
Utils::parseGroupField(const FIX::FieldMap& group,
                       const FIX::DataDictionary& dataDictionary,
                       const FIX::DataDictionary& appDataDictionary) noexcept
{
    std::string res;

    // 1. construct group string
    // loop each field of group
    // and append it to group string
    FIX::FieldMap::iterator it = group.begin();
    for (; it != group.end(); ++it)
    {
        uint32_t tag = it->first;
        std::string field;
        // get text field name from data dictionary
        if (dataDictionary.getFieldName(tag, field)
          or appDataDictionary.getFieldName(tag, field))
        {
            // 1.1 handle normal field
            size_t count = group.groupCount(tag);
            if (!count)
            {
                std::string strTag;
                try
                {
                    strTag = boost::lexical_cast<std::string>(tag);
                }
                catch (std::exception& e)
                {
                    std::cout << "Error: " << e.what() << std::endl;
                    continue;
                }
                std::string fixStr = it->second.getFixString();
                boost::algorithm::replace_first(fixStr, strTag, field);
                res += fixStr;

                continue;
            }
            // 1.2 handle nest group field
            // by recursive calling function self
            for (uint32_t j = 1; j <= count; ++j)
            {
                try
                {
                    const FIX::FieldMap& subGroup = group.getGroupRef(j, tag);
                    std::string temp = parseGroupField(subGroup,
                                                       dataDictionary,
                                                       appDataDictionary);
                    res +=  field + ":[" + temp + "],";
                }
                catch (FIX::FieldNotFound& e)
                {
                    std::cout << "Error: " << e.what() << std::endl;
                    continue;
                }
            }
        }
    }

    // 2. special handle group string
    std::replace(res.begin(), res.end(), '=', ':');
    std::replace(res.begin(), res.end(), '\001', ',');
    if (!res.empty() and res[res.size()-1] == ',')
    {
        res.pop_back();
    }

    return std::move(res);
}

// find group NoPartyIDs from message text
// return a vector which saving NoPartyIDs
// with format group name + group text
//  input: - message text
// output: - vector of group NoPartyIDs
// e.g "NoSides[1]+NoPartyIDs:[PartyID:5402,PartyIDSource:D,PartyRole:75]"
std::vector<std::string>
Utils::findNoPartyIDsFromMsg(const std::string& messageText) noexcept
{
    std::vector<std::string> groups;
    
    // loop search field/value pair of message text
    // and save it into vecter if found
    std::vector<std::string> messageTextPairs =
      splitToPairVector(messageText, ";");
    for (const auto& pair : messageTextPairs)
    {
        // 1. split message pair with field/value
        std::string fieldLeft = pair.substr(0, pair.find("="));
        std::string field     = fieldLeft;
        std::string value     =
          boost::algorithm::replace_first_copy(pair, field + "=", "");
        if (boost::regex_match(field, boost::regex("^.+\\[.+\\]$")))
        {
            field = field.substr(0, field.find("["));
        }

        // 2. save the group NoPartyIDs into vector
        if (field == "NoPartyIDs")
        {
            groups.push_back(fieldLeft + "+" + pair);
        }
        // 3. handle nest group in group NoSides
        else if (field == "NoSides")
        {
            std::vector<std::string> grpPairs = splitToPairVector(value, ",");
            for (const auto& grpPair : grpPairs)
            {
                std::string grpField = grpPair.substr(0, grpPair.find(":"));
                if (boost::regex_match(grpField, boost::regex("^.+\\[.+\\]$")))
                {
                    grpField = grpField.substr(0, field.find("["));
                }

                if (grpField == "NoPartyIDs")
                {
                    groups.push_back(fieldLeft + "+" + grpPair);
                }
            }
        }
    }
    
    return std::move(groups);
}

// Get time string in "%Y-%m-%d %H:%M:%S.%f" format
// The memory new'ed for time_facet which would be managed by itself,
// and which is no need to delete it in caller side.
std::string
Utils::getTimeString( const boost::posix_time::ptime time) noexcept
{
    // get time string
    boost::posix_time::time_facet *facet =
      new boost::posix_time::time_facet("%Y-%m-%d %H:%M:%S.%f");
    // output time with facet format
    // use stringstream for string convertion
    std::ostringstream oss;
    // set locale
    oss.imbue(std::locale(oss.getloc(), facet));
    oss << time;
    return oss.str();
}

// Get Milliseconds
// get a 8 digits number by current timstamp
uint32_t Utils::getMilliseconds() noexcept
{
    auto nowSinceEpoch =
      std::chrono::steady_clock::now().time_since_epoch().count();
    const uint32_t MAX = 100000000;
    return static_cast<uint32_t>(nowSinceEpoch % static_cast<uint32_t>(MAX));
}

// Get a unique ID with max 8 digits
// this ID is assumed to be unique during the day
uint32_t Utils::getOrderID() noexcept
{
    static std::atomic<uint32_t> id(getMilliseconds());
    return id++;
}

// Encypt a string using RSA
// input:
//   - text: input text
//
// return a base64 encoded string
//
// To use this feature, a RSA public key named "rsa_public_key.pem"
// is required to existing in the working directory.
// The resuluting encrypted string will always be 344 bytes.
std::string Utils::rsaEncrypt(const std::string& text) noexcept
{
    const uint16_t SIZE = 4098;
    unsigned char encrytedText[SIZE];
    const unsigned char* ucharText =
      reinterpret_cast<const unsigned char*>(text.c_str());
    FILE* fp = fopen(m_publicKey.c_str(), "r");
    // check if public key open succeeded or not
    if (!fp)
    {
        std::cout << "Error: failed to open public key file: "
                  << m_publicKey << std::endl;
        return std::string();
    }

    RSA* rsa = PEM_read_RSA_PUBKEY(fp, NULL, NULL, NULL);
    // check if public key loading succeeded or not
    if (!rsa)
    {
        std::cout << "Error: failed to read public key file: "
                  << m_publicKey << std::endl;
        fclose(fp);
        return std::string();
    }

    int32_t encryptedTextLength = RSA_public_encrypt(text.length(),
                                                     ucharText,
                                                     encrytedText,
                                                     rsa,
                                                     RSA_PKCS1_PADDING);

    // check if encryption succeeded or not
    if (encryptedTextLength == -1)
    {
        std::cout << "Error: failed to encypt text" << std::endl;
        fclose(fp);
        return std::string();
    }

    fclose(fp);

    // convert encrypted string to standard base64 string
    std::string encryptedString =
      base64Encode(std::string(reinterpret_cast<char*>(encrytedText),
                               encryptedTextLength));
    return std::move(encryptedString);
}

// Encode a binary string in base64
// This is standard BASE64 encoding function which accepts a string
// and generates the base64 string.
//  input: text -- string
// output: text -- base64 string
std::string Utils::base64Encode(const std::string& text) noexcept
{
    using namespace boost::archive::iterators;

    thread_local std::stringstream os;
    os.clear();
    os.str("");

    // convert binary values to base64 characters
    // retrieve 6 bit integers from a sequence of 8 bit bytes
    const uint16_t SIX = 6;
    const uint16_t EIGHT = 8;
    const uint16_t THREE = 3;
    typedef
        base64_from_binary<
            transform_width<
                const char *,
                SIX, EIGHT >> base64_text;

    std::copy(base64_text(text.data()),
        base64_text(text.data() + text.size()),
        ostream_iterator<char>(os)
    );

    std::string encryptedText = os.str();
    encryptedText.append((THREE - text.size() % THREE) % THREE, '=');

    return std::move(encryptedText);
}

// Get a UTC timestamp string in format "%Y%m%d%H%M%S"
std::string Utils::getUTCTimeStamp() noexcept
{
    const uint16_t SIZE = 32;
    std::time_t now = std::time(NULL);
    std::tm * ptm = std::gmtime(&now);
    char buffer[SIZE];
    std::strftime(buffer, SIZE, "%Y%m%d%H%M%S", ptm);

    return std::string(buffer);
}

// Hide the special characters for a plain text
// Currently support semicolon, space and empty
//  input: - message text
//         - specialChars -- specify character to hide, default hide all
// output: - new message text
//
// e.g --
//  input: "52=20150709-06;25;14.863;56=HKEXCO;98=0;108=;789= ;"
//         "all"
// output: "52=20150709-06<sc>25<sc>14.863;"
//   "56=HKEXCO;98=0;108=<novalue>;789=<space>;"
std::string Utils::hideSpecChars(const std::string& msgStr,
                                 const std::string specialChars) noexcept
{
    std::string msgStrNew(msgStr);

    std::vector<std::string> vecSpecChar;
    boost::algorithm::split(vecSpecChar,
                            specialChars,
                            boost::algorithm::is_any_of("|"));
    for (const auto& iter : vecSpecChar)
    {
        if ("semicolon" == iter)
        {
            boost::algorithm::replace_all(msgStrNew, ";", "<sc>");
        }
        else if ("space" == iter)
        {
            boost::algorithm::replace_all(msgStrNew, " ", "<space>");
        }
        else if ("novalue" == iter)
        {
            boost::algorithm::replace_all(msgStrNew, "", "<novalue>");
        }
        else if ("all" == iter)
        {
            boost::algorithm::replace_all(msgStrNew, ";", "<sc>");
            boost::algorithm::replace_all(msgStrNew, " ", "<space>");
            boost::algorithm::replace_all(msgStrNew, "", "<novalue>");
            break;
        }
    }

    return std::move(msgStrNew);
}

// Show the special characters for a plain text
// Currently support semicolon, space and empty
//  input: - message text
//         - specialChars -- specify character to show, default hide all
// output: - new message text
//
// e.g --
//  input: "52=20150709-06<sc>25<sc>14.863;"
//    "56=HKEXCO;98=0;108=<novalue>;789=<space>;"
//         "space|novalue"
// output: "52=20150709-06<sc>25<sc>14.863;56=HKEXCO;98=0;108=;789= ;"
std::string Utils::showSpecChars(const std::string& msgStr,
                                 const std::string specialChars) noexcept
{
    // return directly if no spec chars
    if (std::string::npos == msgStr.find('<'))
    {
        return msgStr;
    }

    std::string msgStrNew(msgStr);

    std::vector<std::string> vecSpecChar;
    boost::algorithm::split(vecSpecChar,
                            specialChars,
                            boost::algorithm::is_any_of("|"));
    for (const auto& iter : vecSpecChar)
    {
        if ("semicolon" == iter)
        {
            boost::algorithm::replace_all(msgStrNew, "<sc>", ";");
        }
        else if ("space" == iter)
        {
            boost::algorithm::replace_all(msgStrNew, "<space>", " ");
            boost::algorithm::replace_all(msgStrNew, "<s>", " ");
        }
        else if ("novalue" == iter)
        {
            boost::algorithm::replace_all(msgStrNew, "<novalue>", "");
        }
        else if ("eq" == iter)
        {
            boost::algorithm::replace_all(msgStrNew, "<eq>", "=");
        }
        else if ("all" == iter)
        {
            boost::algorithm::replace_all(msgStrNew, "<s>", " ");
            boost::algorithm::replace_all(msgStrNew, "<sc>", ";");
            boost::algorithm::replace_all(msgStrNew, "<space>", " ");
            boost::algorithm::replace_all(msgStrNew, "<novalue>", "");
            break;
        }
    }
    
    return std::move(msgStrNew);
}

// Format a message text
// 1. Show the special characters like space(" "),semicolon(";")
// 2. Re-format the print chars for the tag with empty value.
//  input: - message text
// output: - new message text
// e.g --
//  input: message text e.g. "52=20150709-06<sc>25<sc>14.863;108=;789=<space>;"
// output: message text e.g. "52=20150709-06;25;14.863;108=<nosuchtag>;789= ;"
std::string Utils::formatMessageText(const std::string& messageText) noexcept
{
    std::string messageTextNew;

    messageTextNew =  showSpecChars(messageText, "space|semicolon");
    boost::algorithm::replace_all(messageTextNew, "=;", "=<nosuchtag>;");

    return std::move(messageTextNew);
}

// Get SessionID
// input:
//   - BeginString
//   - SenderCompID
//   - TargetCompID
FIX::SessionID Utils::getSessionID(const std::string& beginString,
  const std::string& senderCompID,
  const std::string& targetCompID) noexcept
{
    return FIX::SessionID(beginString, senderCompID, targetCompID);
}

// Get Session
// input:
//   - SessionID
// return the posible incoming or outgoing sessions
FIX::Session* Utils::getSession(const FIX::SessionID& sessionID) noexcept
{
    return getSession(sessionID.getBeginString().getValue(),
                      sessionID.getSenderCompID().getValue(),
                      sessionID.getTargetCompID().getValue());
}

// Get Session
// input:
//   - BeginString
//   - SenderCompID
//   - TargetCompID
// return the posible incoming or outgoing sessions
FIX::Session* Utils::getSession(const std::string& beginString,
  const std::string& senderCompID,
  const std::string& targetCompID) noexcept
{
    const FIX::SessionID sessionID1(beginString, senderCompID, targetCompID);
    const FIX::SessionID sessionID2(beginString, targetCompID, senderCompID);
    if (FIX::Session::lookupSession(sessionID1))
    {
        return FIX::Session::lookupSession(sessionID1);
    }
    return FIX::Session::lookupSession(sessionID2);
}

// Get data dictionaries for a session
// data dictionaries
// For FIXT.1.1, there are 2 data dictionaries
//  - admin data dictionary
//  - application  data dictionary
//
// For other FIX protocol, there is only 1 data dictionary
//  - data dictionary
bool Utils::getSessionDataDictionaries(const FIX::SessionID& sessionID,
    FIX::DataDictionary& dataDictionary,
    FIX::DataDictionary& appDataDictionary) noexcept
{
    FIX::Session* session = getSession(sessionID);
    if (session)
    {
        dataDictionary =
          session->getDataDictionaryProvider()
            .getSessionDataDictionary(sessionID.getBeginString());
        if ("FIXT.1.1" == sessionID.getBeginString())
        {
            appDataDictionary =
              session->getDataDictionaryProvider()
              .getApplicationDataDictionary(
                session->getSenderDefaultApplVerID());
        }
        return true;
    }
    std::cout << "Session Not Found: " << sessionID.toString() << std::endl;
    return false;
}

// Convert a FIX tag to a FIX fieldname  or
// Convert a FXI fieldname to a FIX tag
// input: - session data dictionary
//        - business data dictionary
//        - name -- tag/text
//        - tag -- for saving tag convert from name
//        - field -- for saving field name in text convert from name
bool Utils::tag2field(const FIX::DataDictionary& dataDictionary,
                      const FIX::DataDictionary& appDataDictionary,
                      const std::string& name,
                      int32_t& tag, std::string& field) noexcept
{
    try
    {
        tag = boost::lexical_cast<int32_t>(name);
    }
    catch (std::exception& e)
    {
        tag = 0;
    }

    if (dataDictionary.getFieldName(tag, field)
      || appDataDictionary.getFieldName(tag, field))
    {
        return true;
    }
    else if (dataDictionary.getFieldTag(name, tag)
      || appDataDictionary.getFieldTag(name, tag))
    {
        field = name;
        return true;
    }

    return false;
}

// Check if the log file should be erased or not
// Return true when the last modify date of file is not current day
//  input: - path -- path of log file
// output: - result -- indicate if erase the file or not
bool Utils::isEraseFile(const std::string& path) noexcept
{
    // 1. get last modify day of file
    const uint32_t SIZE = 256;
    char timeStr[SIZE];
    struct stat fileStat;
    if (stat(path.c_str(), &fileStat) < 0)
    {
        // treat it as file not exist
        return false;
    }

    time_t tm = fileStat.st_mtime;
    std::strftime(timeStr, sizeof(timeStr), "%F", std::localtime(&tm));
    std::string fileLastModifyDay(timeStr);

    // 2. get current day
    tm = time(NULL);
    std::strftime(timeStr, sizeof(timeStr), "%F", std::localtime(&tm));
    std::string currentDay(timeStr);

    // 3. return true, means erase file if the date is difference
    if (fileLastModifyDay == currentDay)
    {
        return false;
    }

    return true;
}

// Split a string to 2 parts using a seperator
// input:
//   - text, the original text for splitting
//   - dilimiter, a char
//   - first, 1st part of result
//   - second, 2nd part of result
void Utils::splitTo2Parts(const std::string& text,
                          const char dilimiter,
                          std::string& first,
                          std::string& second) noexcept
{
    std::size_t pos = text.find_first_of(dilimiter);
    first  = text.substr(0, pos);
    second = std::string();
    if (std::string::npos != pos)
    {
        second = text.substr(pos+1);
    }
}

// Remove the outter square brackets if exists
//
// eg. convert "[abcde]" to "abcde"
std::string Utils::removeSquareBrackets(const std::string& text) noexcept
{
    const uint16_t two = 2;
    if (!text.empty() and text.front() == '[' and text.back() == ']')
    {
        return text.substr(1, text.size() - two);
    }

    return text;
}

// split all FIX tag/value pair
// or text field/value pair into a vactor
//  input: - message text
//         - delimiter
// output: - vector of message pair
std::vector<std::string>
Utils::splitToPairVector(const std::string& messageText,
                         const std::string& delimiters) noexcept
{
    std::vector<std::string> items;

    // handling message with group
    if (delimiters == ","
      and messageText.find('[') != std::string::npos
      and messageText.find(']') != std::string::npos)
    {
        items = Converter::tokenizeGroupText(messageText);
    }
    // split the message by token delimiters or newline
    // save the FIX tag pair to a vector
    // set "\n" as a dilimiter also
    // use "\n" as token to handle multiple line messages
    else
    {
        boost::algorithm::split(items,
          messageText,
          boost::algorithm::is_any_of(delimiters + "\n"),
          boost::token_compress_on);
    }

    return std::move(items);
}

}
