/****************************************************************************
 *     Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : Server.cpp
 *   Project  : Wabi III
 *   Description: Socket Server Handler
 *
 *   Created  : 2015/05/27
 *   Author   : Yang Du
 ****************************************************************************/

#include <iostream>
#include <thread>
#include <memory>
#include <functional>
#include <boost/asio/io_service.hpp>
#include <boost/asio/ip/tcp.hpp>
#include <boost/asio/spawn.hpp>

#include "Session.h"
#include "Server.h"

using boost::asio::ip::tcp;

namespace FIXProxy
{
// Constructor for a server
// It starts a listener for client sessions.
Server::Server(Application& app, const int16_t port)
  : m_app(app), m_port(port)
{
    if (!start())
    {
        // throw exception if starting failed
        throw "failed to handle client session";
    }
}

// start socket listening
// It uses boost coroutine to handle sessions
// to user level concurrency in a thread.
// which means there is no need to starting multiple thread
// to get excution concurrecy.
// It saves time and resource to start/manage threads
// and interactive with system kernel.
//
// For more details, please check boost coroutine library.
bool Server::start() noexcept
{
    try
    {
        // spawn server handler as a coroutine
        boost::asio::spawn(m_io_service,
          [&](boost::asio::yield_context yield)
          {
            // tcp acceptor on port m_port
            tcp::acceptor acceptor(m_io_service,
              tcp::endpoint(tcp::v4(), m_port));

            // loop handling incoming session
            for (;;)
            {
                // error code
                boost::system::error_code ec;
                // start socket
                tcp::socket socket(m_io_service);
                // listen on socket
                acceptor.async_accept(socket, yield[ec]);
                if (!ec)
                {
                    // create a session for handling client connection
                    // and run its public function 'go'
                    std::shared_ptr<Session>(
                      new Session(std::move(socket), m_app))->go();
                }
            }
          }
        );

        // run io_service
        runIOService();
    }
    catch (std::exception& e)
    {
        // encountered an exception
        std::cout << "Error: failed to handle incoming tcp session\n";
        return false;
    }

    // normally code can't reach here
    return true;
}

// Run IO Service in a thread pool
void Server::runIOService() noexcept
{
    // create a vector to contains the shared ptr to the threads
    std::vector<std::shared_ptr<std::thread>> thread_pool;
    // start No. of threads equal to the CPU cores
    // in this case the IO server could use the full cpu power
    for (std::size_t i = 0; i < std::thread::hardware_concurrency(); ++i)
    {
        // recording new started thread to the vector
        thread_pool.push_back(
          std::shared_ptr<std::thread>(
            new std::thread(
              std::bind(static_cast<std::size_t (boost::asio::io_service::*)()>(
                &boost::asio::io_service::run), &m_io_service))));
    }

    // join the threads
    for (const auto& thread : thread_pool)
    {
        thread->join();
    }
}
}
