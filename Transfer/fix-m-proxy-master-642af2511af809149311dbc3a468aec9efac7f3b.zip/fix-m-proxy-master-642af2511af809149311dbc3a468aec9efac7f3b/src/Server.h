/****************************************************************************
 *     Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : Server.h
 *   Project  : Wabi III
 *   Description: Socket Server Handler
 *
 *   Created  : 2015/05/19
 *   Author   : Yang Du
 ****************************************************************************/

#include <boost/asio/io_service.hpp>

#ifndef SERVER_H
#define SERVER_H

namespace FIXProxy
{
class Server
{
    public:
    Server(Application&, const int16_t);
    // start server
    bool start() noexcept;
    // Run IO Service in a thread pool
    void runIOService() noexcept;

    private:
    // QuickFIX application
    Application& m_app;
    // io service
    boost::asio::io_service m_io_service;
    // port
    int16_t m_port;
};
}
#endif // SERVER_H
