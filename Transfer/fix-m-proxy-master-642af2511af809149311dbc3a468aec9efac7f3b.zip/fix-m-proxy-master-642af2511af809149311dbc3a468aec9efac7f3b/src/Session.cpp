/****************************************************************************
 *     Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : Session.cpp
 *   Project  : Wabi III
 *   Description: Socket Client Session Handler
 *
 *   Created  : 2015/05/19
 *   Author   : Yang Du
 ****************************************************************************/

#include <chrono>
#include <memory>

// boost
#include <boost/asio/io_service.hpp>
#include <boost/asio/ip/tcp.hpp>
#include <boost/asio/spawn.hpp>
#include <boost/asio/read.hpp>
#include <boost/asio/read_until.hpp>
#include <boost/asio/write.hpp>
#include <boost/asio/streambuf.hpp>

#include "Session.h"
#include "Converter.h"
#include "Application.h"

using boost::asio::ip::tcp;

namespace FIXProxy
{
// Session entrance
// it uses a coroutine to handle incoming requests,
// and handle timeout in another coroutine.
void Session::go() noexcept
{
    // a shared ptr refer to self to make sure
    // this shared_ptr object doesn't destruct itself
    auto self(shared_from_this());
    // spawn a coroutine handing icoming request
    boost::asio::spawn(m_strand,
        [this, self](boost::asio::yield_context yield)
    {
        handleRequest(yield);
    });
    // spawn a coroutine handing timeout
    boost::asio::spawn(m_strand,
        [this, self](boost::asio::yield_context yield)
    {
        handleTimeout(yield);
    });
}

// JSON request handler
// it parses info of request action, message, timefrom JSON message
//  - action: request type
//  - message: full message for FIX sending or matching pattern for response
//  - time: mandatory for response matching, used for searching time range
//
// if action equels
//  - send: it is to send out a FIX message
//  - retrieverequest: it is to retrieve an FIX request from message.log
//  - retrieveresponse: it is to retrieve an FIX response from message.log
//  - matchresponse: it is to match an FIX response from message.log
//  - getid: get a number limited to 8 digits
//  - status: return status for a FIX session
//  - exit/quit: quit this application
//
// if request succeed, success response
//  or corresponding message will be sent back.
// if failed, an error message will be sent back.
//
// Every request has a timeout in 30s.
//  - if a request is processing more than 30s, it will be cancelled
//  - or timer will be cancelld if request processed within 30s.
void Session::handleRequest(boost::asio::yield_context& yield) noexcept
{
    std::string requestsStr;
    std::string action;
    std::string time;
    std::string messageText;

    try
    {
        // start a timer expires in 30s
        // close this socket if a session hangs up for 30 seconds
        const int16_t timeout = 30;
        m_timer.expires_from_now(std::chrono::seconds(timeout));

        requestsStr = readRequest(yield);
        if (!Converter::parseJSONRequest(requestsStr,
                                         action,
                                         messageText,
                                         time))
        {
            const std::string err = "failed to parse JSON request";
            std::cout << "Error: " << err
                      << ":" << requestsStr << std::endl;
            writeResponse(yield, generateFailedResponse(err));
            cancelTimer();
            return;
        }

        Utils::printSysLog("Received request: <" + action + "> " + messageText);

        // Send FIX message if the action=send
        // The FIX message is generated from the JSON content
        //
        // Return an error message if any exception occurs
        // during the sending.
        if ("send" == action)
        {
            const std::string timestamp = Utils::getTimeString();
            if (handleSendMessage(messageText))
            {
                writeResponse(yield, generateSendingResponse(timestamp));
            }
            else
            {
                Utils::printSysLog("Error: failed to handle sending message");
                writeResponse(yield,
                  generateFailedResponse("failed to handle sending message"));
            }
        }
        // Retrieve FIX request from message.log
        // the request must contain the message string
        //   and fulfill the time restrict
        // A session "not logon" error will be returned if
        //  a matching not found and session is not logon
        //
        // Return an failed message if nothing found.
        else if ("retrieverequest" == action)
        {
            const std::string jsonResponseStr =
              handleRetrieveRequest(messageText, time, m_isTimedout);

            std::string responseMsg(jsonResponseStr);
            if (responseMsg.empty())
            {
                // failed to retrieve request
                if (m_app.getSessionStatus(messageText) != "Logon")
                {
                    responseMsg = generateFailedResponse("Session is not logon");
                }
                else if (m_isTimedout)
                {
                    responseMsg = generateFailedResponse(timedoutMsg);
                }
                else
                {
                    responseMsg = m_failedResponse;
                }
            }
            writeResponse(yield, responseMsg);
        }
        // retrieve FIX response from message.log
        // return a response message matching based on the message pattern
        //   and time restriction
        //
        // Return an failed message if nothing found.
        else if ("retrieveresponse" == action)
        {
            const std::string jsonResponseStr =
              handleRetrieveResponse(messageText, time, m_isTimedout);
            
            std::string responseMsg(jsonResponseStr);
            if (responseMsg.empty())
            {
                if (m_isTimedout)
                {
                    responseMsg = generateFailedResponse(timedoutMsg);
                }
                else
                {
                    responseMsg =
                      generateFailedResponse("failed to retrieve response");
                }
            }
            writeResponse(yield, responseMsg);
        }
        // matching FIX response
        // return if a response message matching based on the message pattern
        //   and time restriction
        //
        // Return an failed message if nothing found.
        else if ("matchresponse" == action)
        {
            std::string errorMsg;
            if (handleMatchResponse(messageText,
                                    time,
                                    m_isTimedout,
                                    errorMsg))
            {
                writeResponse(yield, m_successResponse);
            }
            else
            {
                writeResponse(yield, generateFailedResponse(errorMsg));
            }
        }
        // count FIX messages
        // return the count of messages
        // matching a pattern with time restriction
        else if ("count" == action)
        {
            std::string messages;
            std::string errorMsg;
            const int32_t count =
              handleCountMessages(messageText, m_isTimedout, messages, errorMsg);
            if (!errorMsg.empty())
            {
                writeResponse(yield, generateFailedResponse(errorMsg));
            }
            else
            {
                writeResponse(yield, generateCountingResponse(count, messages));
            }
        }
        // change quickfix settings
        // nothing has implemented right now here.
        else if ("set" == action)
        {
            writeResponse(yield, m_successResponse);
        }
        // get session status
        // return a session status in
        //  JSON response
        else if ("status" == action)
        {
            writeResponse(yield,
              generateStatusResponse(
                m_app.getSessionStatus(messageText)));
        }
        // get order id
        // return an unique order id in JSON response.
        //
        // It is an operation to ensure all clients
        // have proxy-wide unique order ids.
        else if ("getid" == action)
        {
            writeResponse(yield,
              generateOrderIDResponse(Utils::getOrderID()));
        }
        // convert a list integer WABI tags to
        // a list of FIX fields
        else if ("getfixfields" == action)
        {
            writeResponse(yield,
              handleTagsToFIXFieldsConversion(messageText));
        }
        // convert a list integer WABI tags to
        // a list of binary fields
        else if ("getbinaryfields" == action)
        {
            writeResponse(yield,
              handleTagsToBinaryFieldsConversion(messageText));
        }
        // convert a list integer WABI tags to
        // a list of FIX fields
        else if ("getconnectioninfo" == action)
        {
            writeResponse(yield, handleSessionInfo(messageText));
        }
        // quit application
        else if ("exit" == action || "quit" == action)
        {
            writeResponse(yield, m_successResponse);
            exit(0);
        }
        // Print message log if the action=print
        // The message is generated from the JSON content
        //
        // Return error response if any error found.
        else if ("print" == action)
        {
            try
            {
                handlePrintMessageLog(messageText);
                writeResponse(yield, m_receivedResponse);
            }
            catch (std::exception& e)
            {
                writeResponse(yield,
                  generateFailedResponse("failed to write log"));
            }
        }
        // retrieve malformed message
        //
        // Query message.log for any malformed messages
        // Return failed response if the operation failed.
        // Return the malformed message in JSON if succeeded.
        else if ("retrievemalformedmsg" == action)
        {
            const std::string jsonResponseStr =
              handleRetrieveMalformedMsg(messageText, m_isTimedout);

            std::string responseMsg(jsonResponseStr);
            if (responseMsg.empty())
            {
                if (m_isTimedout)
                {
                    responseMsg = generateFailedResponse(timedoutMsg);
                }
                else
                {
                    responseMsg =
                      generateFailedResponse("failed to retrieve malformed message");
                }
            }
            writeResponse(yield, responseMsg);
        }
        // Unknown action type received
        // Return an error if it is an
        // unknown action
        else
        {
            std::cout << "Warning: Unknown request action: "
                      << action << '\n';
            writeResponse(yield,
                          generateFailedResponse(
                            "Unknown request action: " + action));
        }

        Utils::printSysLog("Finished request: <" + action + "> " + messageText);
    }
    catch (std::exception& e)
    {
        // write failed status response
        writeResponse(yield,
          generateFailedResponse(
            "exception in FIX proxy: " + std::string(e.what())));
    }

    // cancel timer
    cancelTimer();
}

// read JSON request from client asynchrously
// it read a request till reached a line end '\n'
// return request JSON text if success,
// else return an empty string
std::string Session::readRequest(boost::asio::yield_context& yield) noexcept
{
    boost::asio::streambuf buf;
    boost::system::error_code ec;
    boost::asio::async_read_until(m_socket, buf, '\n', yield[ec]);

    if (ec)
    {
        std::cout << "Error: failed to read request" << "\n";
        return std::string();
    }

    // use a thread local object for buffer to
    // convert boost::asio::streambuf to string
    thread_local std::ostringstream ss;
    ss.str("");
    ss.clear();
    ss << &buf;

    return ss.str();
}

// write JSON resposne back to user asynchrously
// it convert JSON string response to boost::asio::streambuf,
// then send out the response.
// print an error message if sending failure
void Session::writeResponse(boost::asio::yield_context& yield,
                            const std::string& jsonResponseStr) noexcept
{
    boost::system::error_code ec;
    boost::asio::streambuf jsonResponse;

    std::ostream rs(&jsonResponse);
    rs << jsonResponseStr;
    boost::asio::async_write(m_socket, jsonResponse, yield[ec]);

    if (ec)
    {
        std::cout << "Error: failed to write response" << '\n';
    }

    m_socket.close();
}

// user request handler,
// send one user FIX request to FIX gateway
// using quickfix Application class
bool Session::handleSendMessage(const std::string& message) noexcept
{
    return m_app.sendFIXMessage(message);
}

// request handler to
// handle "retrieverequest" request.
// it use the message as input passttern to search FIX request in message.log,
// the request message found will be converted to JSON.
//  - return the JSON string if found
//  - return empty string if not found
std::string Session::handleRetrieveRequest(const std::string& message,
                                           const std::string& time,
                                           const bool& isTimedout) const noexcept
{
    auto msgVector = m_app.lookupFIXRequest(message, time, isTimedout);
    for (const auto& msg : msgVector)
    {
        std::string jsonResponse = Converter::encodeJSONResponse(msg);
        return std::move(jsonResponse);
    }

    return std::string();
}

// handler for retrieving response
// to handle "retrieveresponse" JSON request for searching
// FIX response received in message.log.
// The response message found will be converted to JSON.
//  - return the JSON string if found
//  - return empty string if not found
std::string Session::handleRetrieveResponse(const std::string& message,
                                            const std::string& time,
                                            const bool& isTimedout) const noexcept
{
    auto msgVector = m_app.lookupFIXResponse(message, time, isTimedout);
    for (const auto& msg : msgVector)
    {
        std::string jsonResponse = Converter::encodeJSONResponse(msg);
        return std::move(jsonResponse);
    }

    return std::string();
}

// handle session connection information request
// input:
//    - message, which contains
//        - BeginString,
//        - SenderCompID,
//        - TargetCompID
// output:
//  session connection information as a string
std::string Session::handleSessionInfo(const std::string& message
                                       ) const noexcept
{
    const std::string sessionInfo = m_app.getConnectionInfo(message);
    FIXProxy::MessageLog::Message msg("", sessionInfo, "", "", "", "");
    std::string jsonResponse = Converter::encodeJSONResponse(msg);
    return std::move(jsonResponse);
}

// Lookup matched response with a pattern and time constraint
// and set error message properly if don't find a match
bool Session::handleMatchResponse(const std::string& messageText,
                                  const std::string& time,
                                  const bool& isTimedout,
                                  std::string& errorMsg) noexcept
{
    return m_app.matchFIXResponse(messageText,
                                  time,
                                  isTimedout,
                                  errorMsg);
}

// Count messages with a pattern with start time and end time
// the start time and end time values are inside parameter messageText.
// And set error message properly if count failed
int32_t Session::handleCountMessages(const std::string& messageText,
                                     const bool& isTimedout,
                                     std::string& messages,
                                     std::string& errorMsg) noexcept
{
    return m_app.countFIXMessages(messageText,
                                  isTimedout,
                                  messages,
                                  errorMsg);
}

// Timeout Handler
// loop to check if timeout while socket is open.
//  - close socket on timeout if still open
//  - yield to scheduler if not timed out
void Session::handleTimeout(boost::asio::yield_context& yield) noexcept
{
    m_timer.async_wait(std::bind(&Session::processTimedout,
                                 shared_from_this(),
                                 std::placeholders::_1));
}

// process timed out
// m_isTimedout is as a shared variable to
// indicate if it's timed out or not
// update the indicator if it's timed out
void Session::processTimedout(const boost::system::error_code& ec) noexcept
{
    if (m_timer.expires_from_now() <= std::chrono::seconds(0))
    {
        m_isTimedout = true;
        Utils::printSysLog("Error: Process timed out");
    }
}

// Handle conversion of WABI integer tags
//  to FIX fields
//
// convert a list of interger tags
// to a list FIX field names and return them
// in a JSON response.
std::string Session::handleTagsToFIXFieldsConversion(
  const std::string& message) noexcept
{
    const std::string fixFields = m_app.getFIXFields(message);
    FIXProxy::MessageLog::Message msg("", fixFields, "", "", "", "");
    std::string jsonResponse = Converter::encodeJSONResponse(msg);
    return std::move(jsonResponse);
}

// Handle conversion of WABI integer tags
//  to Binary fields
//
// convert a list of interger tags
// to a list Binary field names and return them
// in a JSON response.
std::string Session::handleTagsToBinaryFieldsConversion(
  const std::string& message) noexcept
{
    FIXProxy::MessageLog::Message msg("", "", "", "", "", "");
    std::string jsonResponse = Converter::encodeJSONResponse(msg);
    return std::move(jsonResponse);
}

// Handle print log request
//
// Write a log entry to message.log
void Session::handlePrintMessageLog(const std::string& messageText) noexcept
{
    m_app.printMessageLog(messageText);
}

// Handle retrieve malformed message
//
// Query message.log for if there is any
// malformed FIX messages and
// return it as JSON response if found.
std::string
Session::handleRetrieveMalformedMsg(const std::string& messageText,
                                    const bool& isTimedout) const noexcept
{
    auto msgVector =
      m_app.lookupMalformedMessage(messageText, isTimedout);
    for (const auto& msg : msgVector)
    {
        std::string jsonResponse =
          Converter::encodeJSONResponse(msg);
        return std::move(jsonResponse);
    }

    return std::string();
}
}
