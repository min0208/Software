/****************************************************************************
 *   Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : converter.cpp
 *   Project  : Wabi II
 *   Description: encoder header file
 *
 *   Created  : 2015/03/17
 *   Author   : Yang Du
 ****************************************************************************/

#include "Converter.h"
#include "Utils.h"

#include <boost/algorithm/string.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>
#include <boost/regex.hpp>
#include <boost/fusion/tuple.hpp>

#include <vector>
#include <functional>

namespace FIXProxy
{

// init private static members
std::mutex Converter::readJsonMutex;

// All Header tags
// as the list is not accurate for all FIX protocols,
// this list is only used for printing
// The accurate check of header tag is to use QuickFIX function
std::vector<std::string> const Converter::headerTags_ =
  {
    "8", "9", "34", "35", "43", "49", "50", "52", "56"
  };

// Split message text to FieldValuePairs
// The input message text is expected a delimiter
//  sperated string, default is ";".
// All tag=value pairs will be stored to a
//  std::vector using std::pair
// Using vector instead of hash here is to
//  allow support storing duplication tags.
//  input: message text
//         delimiter
// output: vector of pair of field, value
//
// e.g.  input: "8=FIXT.1.1;9=216;35=CV;",
//              ";"
//      output: {{first = "8", second = "FIXT.1.1"},
//               {first = "9", second = "216"},
//               {first = "35", second = "CV"}},
Converter::FieldValuePairs Converter::toFieldValuePairs(
  const std::string& messageText,
  const std::string delimiter) noexcept
{
    // vector of std::pair<string,string>
    FieldValuePairs fvPairs;

    std::vector<std::string> entries;
    boost::algorithm::split(entries,
                            messageText,
                            boost::algorithm::is_any_of(delimiter),
                            boost::token_compress_on);

    auto parseFunc = [&](const std::string& messageText)
    {
        setMessageAttrs(fvPairs, messageText);
    };

    std::for_each(entries.begin(),
                  entries.end(), parseFunc);

    return std::move(fvPairs);
}

// Set TransactTime - field: 60
//  - set tag 60 only if overwrite=true or it already unset
//    the TransactTime should be set to FIX message header
//  input: message -- Fix::Message
//         millisecondsBits -- the bits of millisecond
//         overwrite -- indicate overwrite or not
// output: message with TransactTime
//
// e.g.  input:
//      output:
void Converter::setTransactTime(FIX::Message& message,
                                int32_t millisecondsBits,
                                bool overwrite) noexcept
{
    if (overwrite == true || !message.isSetField(trasactTimeField))
    {
        message.setField(FIX::TransactTime(millisecondsBits));
    }
}

// Get MsgType from plain message text
//   - return value of field 35 if set
//   - return value of MsgType if MsgType defined
//  input: message text
// output: value of field MsgType|35
//
// e.g.  input: "8=FIXT.1.1;9=215;35=D;34=73;49=CO01224101;56=HKEXCCCO;"
//      output: "D"
std::string Converter::getMsgType(const std::string& messageText) noexcept
{
    std::string msgType = getFieldValue(messageText, "35");
    if (msgType.empty())
    {
        msgType = getFieldValue(messageText, "MsgType");
    }

    return std::move(msgType);
}

// Get BeginString from plain message text
//   - return value of field 8 if set
//   - return value of BeginString if BeginString defined
//  input: message text
// output: value of field BeginString|8
//
// e.g.  input: "8=FIXT.1.1;9=215;35=D;34=73;49=CO01224101;56=HKEXCCCO;"
//      output: "FIXT.1.1"
std::string Converter::getBeginString(const std::string& messageText) noexcept
{
    std::string beginString = getFieldValue(messageText, "8");
    if (beginString.empty())
    {
        beginString = getFieldValue(messageText, "BeginString");
    }

    return std::move(beginString);
}

// Get SenderCompID from plain message text
//   - return value of field 49 if set
//   - return value of SenderCompID if set
//  input: message text
// output: value of field SenderCompID|49
//
// e.g.  input: "8=FIXT.1.1;9=215;35=D;34=73;49=CO01224101;56=HKEXCCCO;"
//      output: "CO01224101"
std::string Converter::getSenderCompID(const std::string& messageText) noexcept
{
    std::string senderCompID = getFieldValue(messageText, "49");
    if (senderCompID.empty())
    {
        senderCompID = getFieldValue(messageText, "SenderCompID");
    }

    return std::move(senderCompID);
}

// Get TargetCompID from plain message text
//   - return value of field 56 if set
//   - return value of TargetCompID if set
//  input: message text
// output: value of field TargetCompID|56
//
// e.g.  input: "8=FIXT.1.1;9=215;35=D;34=73;49=CO01224101;56=HKEXCCCO;"
//      output: "HKEXCCCO"
std::string Converter::getTargetCompID(const std::string& messageText) noexcept
{
    std::string targetCompID = getFieldValue(messageText, "56");
    if (targetCompID.empty())
    {
        targetCompID = getFieldValue(messageText, "TargetCompID");
    }

    return std::move(targetCompID);
}

// Get value of tag/field from plain message text
//  - messageText: the message to lookup
//  - field: get value of the field in the given message
// Assume the message is seperated by space/semicolon/vetical bar
//  input: message text
//         target field
// output: value of target field
//
// e.g.  input: "8=FIXT.1.1;9=215;35=D;34=73;49=CO01224101;56=HKEXCCCO;",
//              "56"
//      output: "HKEXCCCO"
std::string Converter::getFieldValue(const std::string& messageText,
                                     const std::string& field) noexcept
{
    std::vector<std::string> entries;
    boost::algorithm::split(entries,
                            messageText,
                            boost::algorithm::is_any_of(";"),
                            boost::token_compress_on);

    // iterate the vector, and return if field matches
    for (auto const& entryStr : entries)
    {
        std::string firstValue, secondValue;
        Utils::splitTo2Parts(entryStr, '=', firstValue, secondValue);

        if (firstValue == field)
        {
            return Utils::showSpecChars(secondValue);
        }
    }

    return std::string();
}

// Remove an entry from plain message text
//  - messageText: the message to lookup
//  - field: a field to remove
// Assume the message is seperated by space/semicolon/vetical bar
//  input: message text
//         target field
// output: message text
//
// e.g.  input: "8=FIXT.1.1;9=215;35=D;34=73;49=CO01224101;56=HKEXCCCO;",
//              "56"
//      output: "8=FIXT.1.1;9=215;35=D;34=73;49=CO01224101;"
std::string Converter::removeField(const std::string& messageText,
                                   const std::string& field) noexcept
{
    std::vector<std::string> entries;
    boost::algorithm::split(entries,
                            messageText,
                            boost::algorithm::is_any_of(";"),
                            boost::token_compress_on);

    std::string newMessageText;

    // iterate the vector, and ignore if field matches
    for (auto const& entryStr : entries)
    {
        std::string firstValue, secondValue;
        Utils::splitTo2Parts(entryStr, '=', firstValue, secondValue);
        if (!firstValue.empty())
        {
            if (firstValue == field)
            {
                continue;
            }
            newMessageText += entryStr + ";";
        }
    }

    return std::move(newMessageText);
}

// Set message integer tag by a string like "Account=A00001"
//   - fvPairs: a vector to store std::pair<string, string>
//   - messageText: a string expected to in format "<tag>=<value>"
//
// add the "tag=value" string as a std::pair to the give vector
//  input: vector of pair of field, value
//         message text
// output: vector of pair of field, value
//
// e.g.  input: {{first = "8", second = "FIXT.1.1"}},
//              "9=216"
//      output: {{first = "8", second = "FIXT.1.1"},
//               {first = "9", second = "216"}},
void Converter::setMessageAttrs(FieldValuePairs& fvPairs,
                                const std::string& messageText) noexcept
{
    // split by equal sign
    std::string firstValue, secondValue;
    Utils::splitTo2Parts(messageText, '=', firstValue, secondValue);

    if (!firstValue.empty())
    {
        fvPairs.push_back(FieldValuePair(firstValue, secondValue));
    }
}

// Set message integer tag by a string like "Account=A00001"
// using data dictionaries.
//
// The data dictionaries is for conversion of text fields to integer.
// Repeating group data will be handled specifically.
//  input: vector of pair of field, value
//         message text
//         transport data dictonary
//         application data dictonary
// output: vector of pair of field, value
// e.g.  input:
//      output:
void Converter::setMessageAttrs(FieldValuePairs& fvPairs,
                                const std::string& messageText,
                                const FIX::DataDictionary& dataDictionary,
                                const FIX::DataDictionary& appDataDictionary) noexcept
{
    std::string firstValue, secondValue;
    Utils::splitTo2Parts(messageText, '=', firstValue, secondValue);

    if (!firstValue.empty())
    {
        // When the second value matching a group pattern,
        // the last trailing number is a special indicator
        // for repeating group managing in WABI FIX.
        // Remove the last trailing number for first value
        if (boost::regex_match(firstValue, boost::regex("^.+\\[.+\\]$")))
        {
            firstValue = firstValue.substr(0, firstValue.find('['));
        }

        int32_t tag = 0;
        // check transport data dictionary
        if (dataDictionary.getFieldTag(firstValue, tag))
        {
            firstValue = std::to_string(tag);
        }
        // else check application dictionary
        else if (appDataDictionary.getFieldTag(firstValue, tag))
        {
            firstValue = std::to_string(tag);
        }

        // if matches a group pattern,
        // process the entry and substitute the text tag to interger tag
        if (isGroup(firstValue))
        {
            secondValue = processGroupText(secondValue,
                                           dataDictionary,
                                           appDataDictionary);
        }

        fvPairs.push_back(FieldValuePair(firstValue, secondValue));
    }
}

// Template specialization for FIX::Message
// It is for handling general message conversion from string.
//
// It only converts general FIX tags, no group tag support.
//  input: vector of pair of field, value
//         transport data dictonary
// output: message -- FIX::Message
// e.g.  input:
//      output:
template<>
FIX::Message Converter::toFIXMessage(const FieldValuePairs& fvPairs,
    const FIX::DataDictionary& dataDictionary) noexcept
{
    FIX::Message message;
    // get message header
    FIX::Header& header = message.getHeader();
    for (auto const& pair : fvPairs)
    {
        int32_t field = Utils::strToField(pair.first);
        if (!field)
        {
            continue;
        }

        // check if it's header tag
        if (dataDictionary.isHeaderField(field) ||
          std::find(headerTags_.begin(), headerTags_.end(), pair.first)
            != headerTags_.end())
        {
            try
            {
                header.setField(field, Utils::showSpecChars(pair.second));
            }
            catch (std::exception& e)
            {
                std::cout << "Error: failed to set header field, "
                          << field << "=" << pair.second << std::endl;
            }

            if (pair.second.empty())
            {
                header.removeField(field);
            }
        }
        // set it to message body if not header tag
        else
        {
            try
            {
                message.setField(field, Utils::showSpecChars(pair.second));
            }
            catch (std::exception& e)
            {
                std::cout << "Error: failed to set field, "
                          << field << "=" << pair.second << std::endl;
            }
            if (pair.second.empty())
            {
                message.removeField(field);
            }
        }
    }

    return std::move(message);
}

// Convert a map of fix message <tag,value> to a string
//  - fvPairs: given message vector
//  - delimiter: dilimiter output FIX string, default = ';'
//
// It loops the vector and constructs the message tag by tag,
// Header tags are insterted first
//  input: vector of pair of field, value
//         delimiter
// output: message text
// e.g.  input: {{first = "8", second = "FIXT.1.1"},
//        {first = "9", second = "216"}},
//      output: "8=FIXT.1.1;9=216;"
std::string Converter::toString(const FieldValuePairs& fvPairs,
                                const char delimiter) noexcept
{
    std::string fixMessageStr;
    std::string tmpTagValuePairStr;

    for (auto const& v : headerTags_)
    {
        for (const auto& pair : fvPairs)
        {
            if (pair.first.compare(v) == 0)
            {
                tmpTagValuePairStr = v + "=" + pair.second + delimiter;
                fixMessageStr += tmpTagValuePairStr;
            }
        }
    }

    // read message body fields
    for (auto const& pair : fvPairs)
    {
        int32_t field = Utils::strToField(pair.first);
        if (!field)
        {
            continue;
        }

        if (!FIX::Message::isHeaderField(field))
        {
            tmpTagValuePairStr = pair.first + "=" + pair.second + delimiter;
            fixMessageStr += tmpTagValuePairStr;
        }
    }

    return std::move(fixMessageStr);
}

// Convert a json string to FIX message
// The JSON string is spected for have those attributes
//   - action: request type
//   - message: FIX message request with sub attributes 'tags' and 'text'
//   - time: request time
//
// The JSON string is parsed by boost::property_tree::ptree.
// return true if parsed successfully
//  input: json text
// output: action
//         message text
//         time
// e.g.  input: "{ \"action\" : \"send\", \"message\": { \"tags\":
//               [ { \"8\": \"FIX.4.2\" }, { \"9\": \"187\" } ] },
//               \"time\" : \"2015-05-22 19:28:19.972954\" }"
//      output: "send",
//              "8=FIX.4.2;9=187;",
//              "2015-05-22 19:28:19.972954"
bool Converter::parseJSONRequest(const std::string& jsonStr,
    std::string& action,
    std::string& message,
    std::string& time) noexcept
{
    // use a thread local std::stringstream to avoid
    // multiple constructions
    thread_local std::stringstream ss;
    ss.str("");
    ss.clear();
    ss << jsonStr;

    boost::property_tree::ptree pt;
    try
    {
        // boost::property_tree::read_json has a bug and isn't
        // thread-safe in this boost version, so a lock is used here
        std::lock_guard<std::mutex> readJsonLock(readJsonMutex);
        boost::property_tree::read_json(ss, pt);
    }
    catch (std::exception& e)
    {
        return false;
    }

    action = pt.get<std::string>("action", std::string());
    time = pt.get<std::string>("time", std::string());
    std::string messageText;

    // if messages child not exist
    if (pt.count("message") == 0)
    {
        return true;
    }

    auto tags_pt = pt.get_child_optional("message.tags");
    if (!tags_pt)
    {
        return true;
    }

    // loop getting each tag & value
    for (auto const& child : pt.get_child("message.tags"))
    {
        for (auto const& entry : child.second)
        {
            std::string tag = entry.first;
            std::string value = entry.second.data();
            if (tag.empty())
            {
                std::cout << "Waning: empty tag ingored" << '\n';
                continue;
            }

            // construct the FIX message string
            messageText += tag + "="
              + Utils::hideSpecChars(value, "space|semicolon") + ";";
        }
    }

    // move the message as it is no longer being used
    message = std::move(messageText);

    return true;
}

// Convert string FIX Message to JSON response
// it use boost property tree for JSON construction,
// the JSON response will contain those attributes
//  input: MesageLog::Message(time,message,messageText,
// binaryFields,binaryMessage,groupTags)
// output: json text
std::string Converter::encodeJSONResponse(
  const FIXProxy::MessageLog::Message& msg) noexcept
{
    const std::string message       = msg.tags;
    const std::string messageText   = msg.text;
    const std::string binaryFields  = msg.binText;
    const std::string binaryMessage = msg.binMsg;
    const std::string time          = msg.time;
    const std::string grpTags       = msg.grpTags;

    boost::property_tree::ptree pt, tags_pt,
      text_pt, binaryFields_pt, message_pt;
    FieldValuePairs fvPairs = toFieldValuePairs(message);

    // construct message tags JSON array
    for (auto const& pair : fvPairs)
    {
        boost::property_tree::ptree entry_pt;
        entry_pt.put(pair.first, pair.second);
        tags_pt.push_back(std::make_pair("", entry_pt));
    }
    
    // construct message text JSON array
    FieldValuePairs tvPairs = toFieldValuePairs(messageText);
    for (auto const& pair : tvPairs)
    {
        boost::property_tree::ptree entry_pt;
        entry_pt.put(pair.first, pair.second);
        text_pt.push_back(std::make_pair("", entry_pt));
    }

    // construct binary fields text JSON array
    FieldValuePairs bfvPairs = toFieldValuePairs(binaryFields);
    for (auto const& pair : bfvPairs)
    {
        boost::property_tree::ptree entry_pt;
        entry_pt.put(pair.first, pair.second);
        binaryFields_pt.push_back(std::make_pair("", entry_pt));
    }

    // put tags property tree under "message.tags"
    // put text property tree under "message.text"
    message_pt.put_child("message.tags", tags_pt);
    message_pt.put_child("message.text", text_pt);
    // put binary string under "message.binary"
    message_pt.put_child("message.binary_fields", binaryFields_pt);
    // put binary string under "message.binary"
    message_pt.put<std::string>("message.binary", binaryMessage);
    // put time string under "message.time"
    message_pt.put<std::string>("message.time", time);
    // put group template tags
    message_pt.put<std::string>("message.group_tags", grpTags);

    thread_local std::stringstream ss;
    ss.str("");
    ss.clear();
    write_json(ss, message_pt);

    std::string jsonResponseStr(ss.str());

    return jsonResponseStr;
}

// Parser for repeating group value
// convert the text fields to integer fields using
// transport and application data dictionaries.
//  input: groupText
//         transport data dictionary
//         application data dictionary
// output: groupText
//
// e.g.  input: "NoPartyIDs=PartyID:5001,PartyIDSource:D,PartyRole:1"
//              [dataDictionary]
//              [appDataDictionary]
//      output: "453=448:5001,447:D,452:1"
std::string Converter::processGroupText(const std::string& groupText,
  const FIX::DataDictionary& dataDictionary,
  const FIX::DataDictionary& appDataDictionary) noexcept
{
    std::string groupTextNew;

    // parse each string entry and convert the tag to integer tag accordingly
    // each entry should be in a ':' seperated string
    for (const auto& messageText : tokenizeGroupText(groupText))
    {
        std::size_t pos = messageText.find(':');
        if (std::string::npos != pos)
        {
            std::string firstValue =
              boost::algorithm::trim_copy(messageText.substr(0, pos));
            std::string secondValue =
              boost::algorithm::trim_copy(messageText.substr(pos+1));

            int32_t tag = 0;
            if (dataDictionary.getFieldTag(firstValue, tag) && 0 != tag)
            {
                firstValue = std::to_string(tag);
            }
            else if (appDataDictionary.getFieldTag(firstValue, tag) && 0 != tag)
            {
                firstValue = std::to_string(tag);
            }
            // Recurse if the tag is a repeating group
            if (isGroup(firstValue) && !secondValue.empty())
            {
                secondValue = processGroupText(
                  secondValue, dataDictionary, appDataDictionary);
                secondValue = '[' + secondValue + ']';
            }

            groupTextNew += firstValue + ':' + secondValue + ',';
        }
        else
        {
            std::cout << "Error: failed to parse group entry: "
                      << groupText << std::endl;
        }
    }

    if (!groupTextNew.empty() && groupTextNew[groupTextNew.size() - 1] == ',')
    {
        groupTextNew.pop_back();
    }
    return std::move(groupTextNew);
}


// Tokenize a FIX group text in WABI format
//
// It should handle 1 lelvel group text as well
// as recursive group text.
// eg.
// [PartyID:1234,PartyIdSource:D,PartyRole:1]
// [Side:1,NoPartyIDs[1]:[PartyID:1234,PartyIdSource:D,
// PartyRole:1],NoClearingInstructions[1]:[ClearingInstruction:0]]

std::vector<std::string> Converter::tokenizeGroupText(
  const std::string& groupText) noexcept
{
    std::vector<std::string> groupAttrVector;
    std::size_t pos = 0;
    int32_t level = 0;

    std::string groupTextNew = Utils::removeSquareBrackets(groupText);
    for (uint32_t i = 0; i < groupTextNew.size(); ++i)
    {
        if (groupTextNew[i] == '[')
        {
            ++level;
        }
        else if (groupTextNew[i] == ']')
        {
            --level;
        }
        else if (level <= 0 && groupTextNew[i] == ',' )
        {
            if (i > pos)
            {
                groupAttrVector.push_back(groupTextNew.substr(pos, i-pos));
            }
            level = 0;
            pos = i + 1;
        }

        if (i == groupTextNew.size() - 1)
        {
            if (i >= pos)
            {
                groupAttrVector.push_back(groupTextNew.substr(pos));
            }
        }
    }

    return std::move(groupAttrVector);
}

// Check if a FIX tag is supported repeating group or not
//
// Supported repeating groups:
//   - NoPartyIDs
//   - NoDisclosureInstructions
//   - NoQuoteEntries
//   - NoSides
//   - NoClearingInstructions
bool Converter::isGroup(const std::string& field) noexcept
{
    static const std::vector<std::string> grpFields = {"453"  , "NoPartyIDs",
                                                       "552"  , "NoSides",
                                                       "555"  , "NoLegs",
                                                       "580"  , "NoDates",
                                                       "10010", "NoOfInstrumentLegs",
                                                       "897"  , "NoTrades"};
    if (std::find(grpFields.begin(), grpFields.end(), field) != grpFields.end())
    {
      return true;
    }

    return false;
}

// Get ID field based on message type
//
// - tag 11 if 35=[DFGq8rE]
// - tag 1770 if 35=CV or 35=CU
// - tag 923 if 35=BE or 35=BF
// - tag 390 if 35=S
// - tag 1166 if 35=Z or 35=AI
// - tag 571 if 35=AE or 35=AR
std::string Converter::getIDField(const std::string& msgType) noexcept
{
    if (boost::regex_match(msgType, boost::regex("^[DFGq8rE]$")))
    {
        return "11";
    }
    else if (boost::regex_match(msgType, boost::regex("^(CU|CV)$")))
    {
        return "1770";
    }
    else if (boost::regex_match(msgType, boost::regex("^(BE|BF)$")))
    {
        return "923";
    }
    else if (boost::regex_match(msgType, boost::regex("^S$")))
    {
        return "390";
    }
    else if (boost::regex_match(msgType, boost::regex("^(Z|AI)$")))
    {
        return "1166";
    }
    else if (boost::regex_match(msgType, boost::regex("^(AE|AR)$")))
    {
        return "571";
    }

    return std::string();
}

// Get ID field name based on message type
//
// - tag 11 if 35=[DFGq8rE]
// - tag 1770 if 35=CV or 35=CU
// - tag 923 if 35=BE or 35=BF
// - tag 390 if 35=S
// - tag 1166 if 35=Z or 35=AI
// - tag 571 if 35=AE or 35=AR
std::string Converter::getIDFieldName(const std::string& msgType) noexcept
{
    if (boost::regex_match(msgType, boost::regex("^[DFGq8E]$")))
    {
        return "ClOrdID";
    }
    else if (boost::regex_match(msgType, boost::regex("^(CU|CV)$")))
    {
        return "EntitlementsRequestID";
    }
    else if (boost::regex_match(msgType, boost::regex("^(BE|BF)$")))
    {
        return "UserRequestID";
    }
    else if (boost::regex_match(msgType, boost::regex("^S$")))
    {
        return "BidID";
    }
    else if (boost::regex_match(msgType, boost::regex("^(Z|AI)$")))
    {
        return "QuoteMsgID";
    }
    else if (boost::regex_match(msgType, boost::regex("^(AE|AR)$")))
    {
        return "TradeReportID";
    }

    return std::string();
}
}
