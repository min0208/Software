/****************************************************************************
 *   Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : Encryptor.h
 *   Project  : FIX Proxy for LME
 *   Description: encryptor header file
 *
 *   Created  : 2017/07/17
 *   Author   : Daniel Liang
 ****************************************************************************/

#ifndef FIXPROXY_ENCRYPTOR_H
#define FIXPROXY_ENCRYPTOR_H

#include <string>
#include <vector>
#include <memory>

// Crypto++
#include <cryptopp/secblock.h>
#include <cryptopp/sha.h>
#include <cryptopp/hmac.h>
#include <cryptopp/hex.h>

namespace FIXProxy
{
class Encryptor
{
    public:
    // encrypt password
    static std::string generateEncryptedPassword(const std::string&,
                                                 const std::string&,
                                                 int64_t) noexcept;
    private:
    // assist encrypt methods
    static CryptoPP::SecByteBlock convertLongToBytes(int64_t) noexcept;
    static CryptoPP::SecByteBlock convertStringToBytes(const std::string&) noexcept;
    static void sha1EncryptPassword(const std::string&,
                                    CryptoPP::SecByteBlock&) noexcept;
    // HmacSHA1 encryptor
    static std::string hmacSHA1Encrypt(const std::string&,
                                       const std::string&,
                                       int64_t) noexcept;

}; // class Encryptor

}
#endif // FIXPROXY_ENCRYPTOR_H
