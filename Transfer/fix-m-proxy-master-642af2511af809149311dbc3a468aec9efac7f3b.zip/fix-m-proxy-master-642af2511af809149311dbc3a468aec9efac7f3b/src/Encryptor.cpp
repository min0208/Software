/****************************************************************************
 *   Copyright (c) HongKong Stock Exchange and Clearing, Ltd.
 *   All rights reserved.
 *
 *   Filename : Encryptor.hpp
 *   Project  : FIX Proxy for LME
 *   Description: encryptor source file
 *
 *   Created  : 2017/07/17
 *   Author   : Daniel Liang
 ****************************************************************************/

#include <iostream>
#include <fstream>
#include "Encryptor.h"

namespace FIXProxy
{
// HmacSHA1 encrypt password
// - An 8-bytes increasing number
// - fax key
// - source password
std::string Encryptor::generateEncryptedPassword(const std::string& password,
                                                 const std::string& faxKey,
                                                 int64_t timeInMillis) noexcept
{
    return hmacSHA1Encrypt(password, faxKey, timeInMillis);
}

// convert Long to byte[]
CryptoPP::SecByteBlock Encryptor::convertLongToBytes(int64_t value) noexcept
{
    if (value <= 0)
    {
        return std::move(CryptoPP::SecByteBlock{});
    }

    std::vector<byte> bytes(8, 0);
    bytes[0] = (byte) ((value & 0x00000000ff000000L) >> 24);
    bytes[1] = (byte) ((value & 0x0000000000ff0000L) >> 16);
    bytes[2] = (byte) ((value & 0x000000000000ff00L) >> 8);
    bytes[3] = (byte)  (value & 0x00000000000000ffL);

    bytes[4] = bytes[0];
    bytes[5] = bytes[1];
    bytes[6] = bytes[2];
    bytes[7] = bytes[3];

    return std::move(CryptoPP::SecByteBlock{bytes.data(), bytes.size()});
}

// convert string to byte[]
CryptoPP::SecByteBlock Encryptor::convertStringToBytes(const std::string& data) noexcept
{
    if (data.empty() or data.length() % 2 != 0)
    {
        return std::move(CryptoPP::SecByteBlock{});
    }

    auto valueOf = [](char pChar)
    {
        int tChar = (pChar >='A' && pChar <='F') ? pChar + 'a' - 'A' : pChar;
        if (tChar >= '0' && tChar <= '9')
        {
            return tChar - '0';
        }
        else if (tChar >= 'a' && tChar <= 'f')
        {
            return tChar - 'a' + 10;
        }
        else
        {
            std::cout << "Invalid hexadecimal digit: " << pChar << std::endl;
            return 0;
        }
    };

    int size = data.length() / 2;
    std::vector<byte> bytes(size, 0);
    for (int p = 0; p < size; ++p)
    {
        int tHiNibble = valueOf(data[p * 2]);
        int tLoNibble = valueOf(data[p * 2 + 1]);
        int tValue    = tHiNibble * 16 + tLoNibble;
        bytes[p]      = (char)(tValue > 127 ? tValue - 256 : tValue);
    }

    return std::move(CryptoPP::SecByteBlock{bytes.data(), bytes.size()});
}

// SHA1 encrypt 
// - source password
void Encryptor::sha1EncryptPassword(const std::string& password,
                                    CryptoPP::SecByteBlock& encrypted) noexcept
{
    const byte salt[] =
    {
        (byte) 0x5C, (byte) 0x8D, (byte) 0x0E, (byte) 0x8A,
        (byte) 0x38, (byte) 0x8A, (byte) 0x10, (byte) 0x76
    };

    CryptoPP::SecByteBlock pwBytes{
      reinterpret_cast<const byte*>(password.data()), password.length()};

    CryptoPP::SHA sha;
    sha.Update(salt, sizeof(salt));
    sha.Update(pwBytes, pwBytes.size());
    sha.Final(encrypted);
}

// HmacSHA1 encrypt
// - An 8-bytes number
// - key
// - source password
std::string Encryptor::hmacSHA1Encrypt(const std::string& data,
                                       const std::string& key,
                                       int64_t timeInMillis) noexcept
{
    if (timeInMillis <= 0 or key.empty() or data.empty())
    {
        return std::string{};
    }

    // HmacSHA1 encrypted
    std::string encoded;
    try
    {
        using namespace CryptoPP;
        // 1.Fax key
        SecByteBlock keySBB = convertStringToBytes(key);
        CryptoPP::HMAC<CryptoPP::SHA1> hmac{keySBB, keySBB.size()};

        // 2.Millis time
        SecByteBlock timSBB = convertLongToBytes(timeInMillis);
        hmac.Update(timSBB, timSBB.size());

        // 3.SHA encrypted password
        SecByteBlock pwdSBB{hmac.DigestSize()};
        sha1EncryptPassword(data, pwdSBB);
        hmac.Update(pwdSBB, pwdSBB.size());

        // 4.Final
        SecByteBlock macSBB{hmac.DigestSize()};
        hmac.Final(macSBB);

        // 5.Hex encode
        ArraySource as{macSBB, macSBB.size(), true,
                       new HexEncoder{new StringSink{encoded}, false}};
    }
    catch (const CryptoPP::Exception& e)
    {
        std::cout << e.what() << std::endl;
    }

    return std::move(encoded);
}

}
