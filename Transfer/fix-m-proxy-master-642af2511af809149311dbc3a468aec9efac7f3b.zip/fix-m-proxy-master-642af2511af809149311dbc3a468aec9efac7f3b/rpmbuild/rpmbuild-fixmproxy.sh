#!/bin/sh

#     Copyright (c) HongKong Stock Exchange and Clearing, Ltd. All rights reserved.
#
#     Filename : rpmbuild-fixmproxy.sh
#     Project  : Wabi
#     Description: fixmproxy rpm build script
#
#     Created  : 2015/03/25
#     Author   : Yang Du

VERSION=1.1.0
SCRIPT_PATH=$(dirname $0)
FIXPROXY_PATH="$SCRIPT_PATH/../"
OS_RELEASE=$(uname -r | sed -e 's/\.[^\.]*$//' -e 's/^.*\.//')

elog ()
{
  timestamp=`date '+%Y-%m-%d %H:%M:%S'`
  echo "[$timestamp] Error: $1" | tee -a $LOG_FILE
  exit 1
}

log ()
{
  timestamp=`date '+%Y-%m-%d %H:%M:%S'`
  echo "[$timestamp] Info: $1" | tee -a $LOG_FILE
}

execute ()
{
  log "$*"
  $*
  if [ $? -ne 0 ]; then
    elog "failed to execute"
  fi
}

clean()
{
  log "clean old files"
  execute rm -rf ${HOME}/rpmbuild/BUILD/

  which rpmdev-setuptree > /dev/null 2>&1
  if [ $? -ne 0 ]; then
    echo "Error: Package rpmdevtools hasn't installed"
    exit 1
  fi
  execute rpmdev-setuptree
}

build_source()
{
  log "prepare lisa tool source to build rpm"
  TMP_SOURCE_DIR=/tmp/fixmproxy-$VERSION
  execute mkdir -p $TMP_SOURCE_DIR
  execute cp -rf $FIXPROXY_PATH/src/ $TMP_SOURCE_DIR/
  execute cp -rf $FIXPROXY_PATH/include/ $TMP_SOURCE_DIR/
  execute cp -rf $FIXPROXY_PATH/nexus/ $TMP_SOURCE_DIR/
  execute cp -rf $FIXPROXY_PATH/src/Makefile.rpmbuild $TMP_SOURCE_DIR/src/Makefile

  log "zip fixmproxy source files"
  cd /tmp
  execute tar zcvf fixmproxy-$VERSION.tar.gz ./fixmproxy-$VERSION
  execute mv fixmproxy-$VERSION.tar.gz ${HOME}/rpmbuild/SOURCES
  execute rm -rf $TMP_SOURCE_DIR
  cd -
}

generate_sepc()
{
  log "generate fixmproxy spec from template"
  sed -e "s/^Version.*$/Version: $VERSION/" -e "s/^Source0:.*$/Source0: fixmproxy-$VERSION.tar.gz/" $FIXPROXY_PATH/rpmbuild/fixmproxy.${OS_RELEASE}.spec.template > /tmp/fixmproxy.spec.$$
  mv /tmp/fixmproxy.spec.$$ ${HOME}/rpmbuild/SPECS/fixmproxy.spec
}

clean
build_source
generate_sepc

log "building lisa tool RPM"
export QA_SKIP_RPATHS=$[ 0x0001|0x0010 ]
execute rpmbuild --quiet --clean -bb ${HOME}/rpmbuild/SPECS/fixmproxy.spec

log "Success."
execute find ${HOME}/rpmbuild/RPMS/ | grep fixmproxy
