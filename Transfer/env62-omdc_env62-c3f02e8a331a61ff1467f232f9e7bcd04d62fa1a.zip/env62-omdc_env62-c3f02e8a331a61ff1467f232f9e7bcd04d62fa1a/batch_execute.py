#!/usr/bin/python

from logger import logger
import re
import os
import sys
import datetime
import collections
import json
import time
import traceback
import subprocess
import copy
import multiprocessing

__version__ = "v0.7"

logger.info(""" batch execution %s """ % __version__)

def had_sufficient_ram(required_ram):
    total_ram, used_ram, _,_,_,free_ram = map(int, os.popen('free -t -m').readlines()[1].split()[1:])
    # logger.info("total_ram: %s used_ram %s free_ram %s" % (total_ram, used_ram, free_ram))
    if free_ram < required_ram:
        logger.info("total_ram: %s used_ram %s free_ram %s, on hold" % (total_ram, used_ram, free_ram))
        return False
        # time.sleep(2)
        # logger.warn("ram limit, avaliable %s < required %s, hold on" % (free_ram, required_ram))
    else:
        return True

def load_config(file_name, plan_name):

    """
        parse json format configuration file, for such specific environment
    """

    if not os.path.isfile(file_name):
        logger.warn("configuraton file given %s do not exist, please check" % file_name)
        exit(1)


    try:
        config = json.loads(open(file_name).read(), object_pairs_hook=collections.OrderedDict)
        logger.debug("config loaded: %s" % json.dumps(config, indent=4))

        config["general"]["output_folder"] = "%s_no.%s" % (plan_name, os.environ["BUILD_NUMBER"] if os.environ.has_key("BUILD_NUMBER") else 0)
        os.mkdir(config["general"]["output_folder"])
        logger.info("output at %s" % config["general"]["output_folder"])
        logger.info("abs path %s" % os.path.abspath(config["general"]["output_folder"]))

        if config["pdf_related"]["environment_info"].strip()[-1] != ";":
            config["pdf_related"]["environment_info"] += ";"

        if "TEST_SCRIPT_VERSION" in os.environ.keys() and 'Test Script Version' not in config["pdf_related"]["environment_info"]:
            config["pdf_related"]["environment_info"] += "Test Script Version=%s;" % os.environ["TEST_SCRIPT_VERSION"]

        logger.info("rc config pdf_related environment_info is '%s'" % config["pdf_related"]["environment_info"])

        return config
    except:
        logger.warn(traceback.format_exc())
        logger.warn("seems %s is not a valid json, please check" % file_name)
        exit(1)

def load_csv(file_name):

    """
        parse / load the csv batch file, read into [{},{}] format,
        do some scan on predceding case id, or some grouping stuff
    """

    # load csv as list of dictionarys

    fh = open(file_name)
    header = fh.readline().strip().split(",")

    records = []
    groups = collections.OrderedDict()

    # basic load
    for l in fh:
        # allow empty line
        if l.strip() == "" or re.match("^ *#.*", l) or re.match("^,*$", l.strip()):
            logger.debug("line %s invalid, ignore" % l.strip())
            continue
        else:
            logger.debug("line %s valid, continue the parsing" % l.strip())
        record = collections.OrderedDict()
        try:
            for i, v in enumerate(l.strip().split(",")):
                record[header[i]] = v
            records.append(record)
        except:
            logger.warn("line not aligned, %s" % l)
            exit(1)

        logger.debug("raw csv scan get %s" % json.dumps(record, indent=4))

    # handle the "Previous" tag
    previous = None

    for record in records:
        if record["preceding_case_id"] == "Previous" and previous != None:
            record["preceding_case_id"] = previous["case_id"]
        previous = record


    # handle the "group" tag
    for i, record in enumerate(records):
        logger.debug("parsing on No.#%s record, which is %s" % (i, str(record)))
        record["seq"] = i

        if record.has_key("group") and record["group"] != "":
            try:
                groups[record["group"]].append("%s:%s" % (record["seq"], record["case_id"]))
            except:
                groups[record["group"]] = []
                groups[record["group"]].append("%s:%s" % (record["seq"], record["case_id"]))

            logger.debug("at case %s, now group is %s" % (record["case_id"], json.dumps(groups[record["group"]], indent=4)))
        if record["preceding_case_id"] != "Nil":
            if re.match("Group:(.*)", record["preceding_case_id"]):
                parsed_deps = []
                group_name = re.match("Group:(.*)", record["preceding_case_id"]).groups()[0]
                try:
                    record["preceding_case_id"] = "|".join(groups[group_name])
                    logger.debug("preceding_case_id of %s is group %s, which is %s" % (record["case_id"], group_name, json.dumps(groups[group_name], indent=4)))
                except:
                    logger.warn(traceback.format_exc())
                    logger.warn("group seems not exist %s" % group_name)
                    exit(1)
            else:
                parsed_deps = []
                for each_dep in record["preceding_case_id"].split("|"):
                    logger.debug("looking on deps %s" % each_dep)
                    current_dep = None
                    for x, another_record in enumerate(records):
                        if another_record["case_id"] == each_dep:
                            logger.debug("found deps, should be No.%s record, which is %s" % (x, str(another_record)))
                            if x < i:
                                current_dep = another_record
                    # tagged = filter(lambda x: records[x]["case_id"] == each_dep and x <= i, range(len(records)))[-1]
                    parsed_deps.append("%s:%s" % (current_dep["seq"], current_dep["case_id"]))

                record["preceding_case_id"] = "|".join(parsed_deps)

        # TODO, add another tag

    # logger.info("read csv %s, got step(s) %s" % (file_name, records))
    logger.info("read csv %s, got %s step(s)" % (file_name, len(records)))
    logger.debug("read csv %s, got %s" % (file_name, json.dumps(records, indent=4)))

    return records

def already_satisfied(status, step):
    """
        check if such step ready to run
        to check start_time and preceding_case_id
    """
    # check if time good
    if step["start_time"] != "Nil":
        if datetime.datetime.now().time() < datetime.datetime.strptime(step["start_time"], "%H:%M:%S").time():
            logger.debug("start_time %s not satisfied for %s" % (step["start_time"], step["case_id"]))
            return False

    # check if preceeding good
    if step["preceding_case_id"] != "Nil":
        if not all(map(lambda x:  (x in status["passed"]) or (x in status["failed"]), step["preceding_case_id"].split("|"))):
            logger.debug("preceding_case_id %s not satisfied for %s" % (step["preceding_case_id"], step["case_id"]))
            return False

    if not had_sufficient_ram(1000):
        return False
    return True

def all_step_passed(json_path):

    """
        the additional checking, on output json of cucumber / fix_cli
        suppose no failed / skipped / undefied steps
    """
    if not open(json_path).readlines():
        logger.warn("json fie %s seems empty, case not triggerd" % json_path)
        return False

    if not json.loads(open(json_path).read()):
        logger.warn("json fie %s seems empty, case not triggerd" % json_path)
        return False

    if any(filter(lambda x: re.match("^ *\"status\": \"(failed|skipped|undefied)\".*", x), open(json_path).readlines())):
        return False
    else:
        return True

def mark_status(rc, status, step, flag, seq):

    """
        give proper tag / status mark , and logging
    """

    if flag == "passed":
        # logger.info("executtion of case %s success" % rc["tag"])
        logger.info("testcase %s pass" % rc["tag"])
        status["passed"].append("%s:%s" % (seq, rc["tag"]))

        step["status"] = "passed"
        step["json"] = rc["output_json"]
        step["pdf"] = rc["output_pdf"]

        status["report"].append(step)
    elif flag == "failed":
        logger.warn("testcase %s failed" % rc["tag"])
        # logger.warn("executtion of case %s failed" % rc["tag"])
        status["failed"].append("%s:%s" % (seq, rc["tag"]))

        step["status"] = "failed"
        step["json"] = rc["output_json"]
        step["pdf"] = rc["output_pdf"]

        status["report"].append(step)
    else:
        logger.warn("invalid flag %s of step %s" % (flag, step))

def input_order(rc, status, step, i):

    """
        fire up subprocess for actual case execution
        compose the "rc" and templates given from configuraiotn file
    """

    if rc["use_native_cucumber"] == "true":
        composed_command = ["cucumber", "-f", "json",
            "-o", "%s/%s" % (rc["output_folder"], rc["output_json"]),
            "--tags", rc["tag"],
            ]
    else:
        composed_command = ["fix_cli",  "execute",
            "--logonoff=%s" % rc["logonoff"],
            "--parallel=%s" % rc["parallel"],
            "--serial=%s" % rc["serial"],
            "--misc=%s" % rc["misc"],
            "--runprofile=%s" % rc["run_profile"],
            "--maximum", "50",
            "--memory", "100",
            "--output", "%s/%s" % (rc["output_folder"], rc["output_json"]),
            "--loglevel=%s" % rc["log_level"],
            "--tags", rc["tag"],
            ]

    logger.info("testcase %s started" % rc["tag"])
    logger.debug("execute case %s:\n  %s" % (rc["tag"], " ".join(composed_command)))
    # logger.info("execute %s" % composed_command)
    try:
        # wait_if_ram_lower_than(1000)
        p = subprocess.Popen(composed_command, env=os.environ, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = p.communicate()
        logger.debug("stdout: %s" % stdout)
        logger.debug("stderr: %s" % stderr)
        if p.returncode == 0:
            if all_step_passed("%s/%s" % (rc["output_folder"], rc["output_json"])):
                mark_status(rc, status, step, "passed", i)
            else:
                mark_status(rc, status, step, "failed", i)
                if rc["stop_execution_if_fail"] == "Y":
                    status["direct_quit"].append(True)
                    logger.warn("critical step %s failed, batch would stop" % rc["tag"])

        else:
            mark_status(rc, status, step, "failed", i)
            if rc["stop_execution_if_fail"] == "Y":
                status["direct_quit"].append(True)
                logger.warn("critical step %s failed, batch would stop" % rc["tag"])
                # logger.info("status is %s" % ["%s: %s" % (x, str(status[x])) for x in status])
                # raise Exception("critical step failed, batch terminate")
                # sys.exit(1)
    except:
        logger.warn(traceback.format_exc())
        mark_status(rc, status, step, "failed", i)
        if rc["stop_execution_if_fail"] == "Y":
            status["direct_quit"].append(True)
            logger.warn("critical step %s failed, batch would stop" % rc["tag"])
            # logger.info("status is %s" % ["%s: %s" % (x, str(status[x])) for x in status])
            # raise Exception("critical step failed, batch terminate")
            # sys.exit(1)


def generate_report(rc, status, step):

    """
        fire up subprocess for post execution report hanlding
        compose the "rc" and templates given from configuraiotn file
    """

    composed_command = ["wabi-pdf-generator", "-f", rc["using_template"],
        "-e", '%s' % rc["environment_info"],
        "-d", rc["one_pdf_per_feature_file"],
        "-c", rc["full_length_feature_title"],
        "-t", '%s' % rc["cover_page_title1"],
        "-s", '%s' % rc["cover_page_subtitle1"],
        "-i", '%s/%s' % (rc["output_folder"], rc["output_json"]),
        "-o", '%s/%s' % (rc["output_folder"], rc["output_pdf"])
    ]

    if rc["one_pdf_per_feature_file"] == "true":
        if not os.path.isdir(rc["output_pdf"]) and not os.path.isfile(rc["output_pdf"]):
            os.mkdir(rc["output_pdf"])

    # logger.info("execute %s" % composed_command)
    logger.info("generate pdf to %s/%s" % (rc["output_folder"], rc["output_pdf"]))
    logger.debug("gen report %s:\n  %s" % (rc["tag"], " ".join(composed_command)))
    try:
        # wait_if_ram_lower_than(1000)
        p = subprocess.Popen(composed_command, env=os.environ, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = p.communicate()

        logger.debug("stdout: %s" % stdout)
        logger.debug("stderr: %s" % stderr)
        if p.returncode == 0:
            logger.debug("gen report success")
        #     status["passed"].append(rc["tag"])
        else:
            logger.debug("gen report failed")
        #     status["failed"].append(rc["tag"])
    except:
        logger.debug("gen report failed")
        pass
        # status["failed"].append(rc["tag"])


def get_parm(config, group, detail, default=None):

    """
        load / retreive the 2-layer configuraiton json, and leaves a default value
    """

    if config.has_key(group):
        if config[group].has_key(detail):
            return config[group][detail]
    return default

def run_case(config, status, step, i):

    """
        wrap function for one line of the batch file
        that mostly do case execution and report generation
    """

    # template and wrapping parameters for input
    rc = collections.OrderedDict()

    rc["log_level"] = get_parm(config, "general", "log_level",   default = "INFO")

    rc["serial"]    = get_parm(config, "general", "serial",      default = "true")
    rc["logonoff"]  = get_parm(config, "general", "logonoff",    default = "false")
    rc["parallel"]  = get_parm(config, "general", "parallel",    default = "false")
    rc["misc"]      = get_parm(config, "general", "misc",        default = "false")

    rc["use_native_cucumber"]       = get_parm(config, "general", "use_native_cucumber", default = "false")

    rc["tag"]                       = step["case_id"]

    # case_id,start_time,preceding_case_id,stop_execution_if_fail,group_in_report,protocol,remark
    # @CASE=CheckCurrentTradingState_NASD_is_CTS_CT,Nil,Nil,Y,=ALL=,FIX,
    # @FEATURE=CT_Q47,Nil,Previous,N,FIX_CT_Q47,FIX,LoginAdmin
    # @FEATURE=CT_Q48,Nil,Previous,N,FIX_CT_Q48,FIX,LoginAdmin
    # @FEATURE=CT_Q47,Nil,Previous,N,BIN_CT_Q47,BIN,LoginAdmin
    # @FEATURE=CT_Q48,Nil,Previous,N,BIN_CT_Q48,BIN,LoginAdmin
    # @FEATURE=CT_Q53,Nil,Previous,N,FIX_CT_Q53_Q54,FIX,LoginAdmin
    # @FEATURE=CT_Q53,Nil,Previous,N,BIN_CT_Q53_Q54,BIN,LoginAdmin
    # @FEATURE=CT_Q54,Nil,Previous,N,FIX_CT_Q53_Q54,FIX,LoginAdmin
    # @FEATURE=CT_Q54,Nil,Previous,N,BIN_CT_Q53_Q54,BIN,LoginAdmin

    rc["output_json"]               = step["case_id"] + ".json"
    rc["output_pdf"]                = step["case_id"] + ".pdf"
    if step.has_key("protocol"):
        if step["protocol"] == "FIX":
            rc["output_json"] = "FIX_" + step["case_id"] + ".json"
            rc["output_pdf"]  = "FIX_" + step["case_id"] + ".pdf"
        elif step["protocol"] == "BIN":
            rc["output_json"] = "BIN_" + step["case_id"] + ".json"
            rc["output_pdf"]  = "BIN_" + step["case_id"] + ".pdf"


    rc["output_folder"]             = get_parm(config, "general", "output_folder", default = "batch_reports")
    rc["stop_execution_if_fail"]    = step["stop_execution_if_fail"]

    # logger.info("step case_id is %s" % step["case_id"])
    # logger.info("rc tag is %s" % rc["tag"])

    rc["using_template"]            = get_parm(config, "pdf_related", "using_template",             default = "test-execution-full-report")
    rc["cover_page_title1"]         = get_parm(config, "pdf_related", "cover_page_title1",          default = "WABI report")
    rc["cover_page_subtitle1"]      = get_parm(config, "pdf_related", "cover_page_subtitle1",       default = "WABI report")
    rc["environment_info"]          = get_parm(config, "pdf_related", "environment_info",           default = "version=1")
    rc["one_pdf_per_feature_file"]  = get_parm(config, "pdf_related", "one_pdf_per_feature_file",   default = "false")
    rc["full_length_feature_title"] = get_parm(config, "pdf_related", "full_length_feature_title",  default = "false")

    if step.has_key("protocol"):
        if step["protocol"] == "FIX":
            rc["run_profile"] = "features/fixprofile.csv"
        elif step["protocol"] == "BIN":
            rc["run_profile"] = "features/binaryprofile.csv"
    else:
        rc["run_profile"] = None

    # logger.info("rc environment_info is '%s'" % rc["environment_info"])
    if rc["environment_info"].strip()[-1] != ";":
        rc["environment_info"] += ";"

    # logger.info("rc environment_info is '%s'" % rc["environment_info"])
    if "TEST_SCRIPT_VERSION" in os.environ.keys() and 'Test Script Version' not in rc["environment_info"]:
        rc["environment_info"] += "Test Script Version=%s;" % os.environ["TEST_SCRIPT_VERSION"]
    if rc["run_profile"]:
        rc["environment_info"] += "Profile=%s;" % rc["run_profile"]
    # logger.info("rc environment_info is '%s'" % rc["environment_info"])


    # pick profile based on protocol

    # the atom transaction
    # would track status, and stop if stop_execution_if_fail is N

    logger.debug("run %s" % json.dumps(step, indent=4))
    logger.debug("rc prepared is %s" % json.dumps(rc, indent=4))
    # logger.info("run %s" % json.dumps(step, indent=4))

    input_order(rc, status, step, i)
    generate_report(rc, status, step)

    # status["passed"] |= set([step["case_id"],])
    # logger.warn("status is now %s" % status)


def wait_till_all_ends(status):
    """
        at the end of batch, holds on to collect all subprocess finish
    """

    for x in status["pool"]:
        if x.is_alive():
            logger.info("wait for %s to end" % x)
            x.join()
    # while any(map(lambda p: p.is_alive(), pool)):
    #     time.sleep(1)

def set_env(config):
    """
        many parameters for fixproxy / omdproxy / fix_cli / wabi / selenium
        are just environment variables

        so collect them and "EXPORT" at start, to simplify the cli parameters at each step
    """

    env_wrapper = {
        # General
        "MULTIPLEPROJECT" : get_parm(config, "general", "multipleproject"),
        "IIMA"            : get_parm(config, "general", "iima"),

        # Browser
        "MODE"            : get_parm(config, "web_related", "mode"),
        "BROWSER"         : get_parm(config, "web_related", "browser"),
        "HIGHLIGHT"       : get_parm(config, "web_related", "highlight"),

        # FIX
        "FIXPROXYPORT"    : get_parm(config, "fix_related", "fixproxyport"),

        # OMD
        "OMD_CMP"         : get_parm(config, "omd_related", "check_missing_package"),
        "PRE_RUN_CASE"    : get_parm(config, "omd_related", "continue_case_if_omd_varification_fail"),

        # OMD-C
        "OMDC_IP"         : get_parm(config, "omd_related", "omdc_ip"),
        "OMDC_PORT"       : get_parm(config, "omd_related", "omdc_port"),

        # OMD-D
        "OMD_IP"          : get_parm(config, "omd_related", "omdd_ip"),
        "OMD_PORT"        : get_parm(config, "omd_related", "omdd_port")
    }

    for x in env_wrapper.keys():
        if env_wrapper[x]:
            os.environ[x] = env_wrapper[x]
            logger.debug("environment variable %s set to %s" % (x, env_wrapper[x]))

    # # minic source /opt/rh/rh-ruby22/enable
    if config.has_key("environment_variable"):
        for env_variable in filter(lambda x: x != "comments", config["environment_variable"].keys()):
            try:
                os.environ[env_variable] = config["environment_variable"][env_variable] + ":" + os.environ[env_variable]
                logger.debug("environment variable %s append %s" % (env_variable, config["environment_variable"][env_variable]))
            except:
                os.environ[env_variable] = config["environment_variable"][env_variable]
                logger.debug("environment variable %s set to %s" % (env_variable, config["environment_variable"][env_variable]))

def combine_json(target_filename, file_list):
    list_of_features = []

    # sort json file in mtime order, so combined PDF were sorted in time on scenario / cases
    for x in sorted(file_list, cmp=lambda x, y: os.stat(x).st_mtime > os.stat(y).st_mtime):
        if not os.path.isfile(x):
            logger.warn("json file %s not exist" % x)
            continue

        if not open(x).readlines():
            logger.warn("json file %s empty" % x)
            continue

        d = json.loads(open(x).read(), object_pairs_hook =collections.OrderedDict)

        if not d:
            logger.warn("json file %s empty" % x)
            continue

        list_of_features += d

    fh = open(target_filename, "w")
    fh.write(json.dumps(list_of_features, indent=2))
    fh.close()


def combine_and_generate_report(report_group_name, json_needs_combine, config):

    """
        fire up subprocess for post execution report hanlding, to generate additional "combined" reports
        based on user input on column "group_in_repor"

        the =ALL= tag still works as before, that would appeared in every report generated

    """

    combined_json = "%s/%s" % (config["general"]["output_folder"], report_group_name + ".json")
    combined_pdf = "%s/%s" % (config["general"]["output_folder"], report_group_name + ".pdf")
    json_list = map(lambda x: "%s/%s" % (config["general"]["output_folder"], x), json_needs_combine)

    combine_json(combined_json, json_list)

    composed_command = ["wabi-pdf-generator", "-f", config["pdf_related"]["using_template"],
        "-e", '%s' % config["pdf_related"]["environment_info"],
        "-d",        config["pdf_related"]["one_pdf_per_feature_file"],
        "-c",        config["pdf_related"]["full_length_feature_title"],
        "-t", '%s' % config["pdf_related"]["cover_page_title1"],
        "-s", '%s' % config["pdf_related"]["cover_page_subtitle1"],
        "-i", '%s' % combined_json,
        "-o", '%s' % combined_pdf
    ]

    if config["pdf_related"]["one_pdf_per_feature_file"] == "true":
        if not os.path.isdir(combined_pdf) and not os.path.isfile(combined_pdf):
            os.mkdir(combined_pdf)

    # logger.info("execute %s" % composed_command)
    logger.debug("combine report %s:\n  %s" % (report_group_name, " ".join(composed_command)))
    logger.info("generate pdf to %s" % combined_pdf)
    try:
        # wait_if_ram_lower_than(1000)
        p = subprocess.Popen(composed_command, env=os.environ, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = p.communicate()

        logger.debug("stdout: %s" % stdout)
        logger.debug("stderr: %s" % stderr)
        if p.returncode == 0:
            logger.debug("combine report success")
        #     status["passed"].append(rc["tag"])
        else:
            logger.debug("combine report failed")
        #     status["failed"].append(rc["tag"])
    except:
        logger.debug("combine report failed")
        pass
        # status["failed"].append(rc["tag"])


def combine_pdf_if_required(steps, config):
    """
        loop through the group_in_report column
    """
    report_groups = list(set(filter(lambda group_name: group_name != None and group_name != "",
        map(lambda record: record["group_in_report"] if record.has_key("group_in_report") else None, steps))))

    for report_group_name in filter(lambda x: x and x != "=ALL=", report_groups):
        logger.debug("prepare report group: %s" % report_group_name)

        json_needs_combine = []

        for step in steps:
            if step.has_key("group_in_report") and (step["group_in_report"] == report_group_name or step["group_in_report"] == "=ALL="):
                if step.has_key("protocol"):
                    if step["protocol"] == "BIN":
                        json_needs_combine.append("BIN_%s.json" % step["case_id"])
                    elif step["protocol"] == "FIX":
                        json_needs_combine.append("FIX_%s.json" % step["case_id"])

        # json_needs_combine = map(lambda x: x["case_id"] + ".json" ,
        #     filter(lambda x: x.has_key("group_in_report") and (x["group_in_report"] == report_group_name or  x["group_in_report"] == "=ALL="), steps))
        logger.debug("which contains following json: %s" % json_needs_combine)

        combine_and_generate_report(report_group_name, json_needs_combine, config)


def dump_reports(status):
    logger.info("execution status:")

    print ""
    required_column = ["case_id", "status"]
    print ",".join(required_column)

    for r in status["report"]:
        print ",".join(map(lambda x: r[x], required_column))

    print ""
    # logger.info(status)
    print "passed: %s\n%s" % (len(status["passed"]), "\n".join(status["passed"]))
    print "failed: %s\n%s" % (len(status["failed"]), "\n".join(status["failed"]))
    print ""


def explain_plan(config_name, plan_name):
    """
        overall process / scheduling controller
        create some slots for status collecting and signal routing
    """

    if not os.path.exists(plan_name):
        logger.warn("plan %s not exist, quite" % plan_name)
        sys.exit(1)

    # logger.info("loading %s" % plan_name)
    config = load_config(config_name, plan_name)

    steps = load_csv(plan_name)

    set_env(config)

    manager = multiprocessing.Manager()
    status  = collections.OrderedDict()

    status["passed"]      = manager.list()
    status["failed"]      = manager.list()
    status["started"]     = manager.list()
    status["direct_quit"] = manager.list()
    status["report"]      = manager.list()

    status["pool"] = []

    # main loop at here
    # keep scan / trying to start all process, at every 1 second
    while len(status["pool"]) != len(steps):
        for idx, step in enumerate(steps):
            # status["queued"].append("%s:%s" % (idx, step["case_id"]))
            if already_satisfied(status, step) and "%s:%s" % (step["seq"], step["case_id"]) not in status["started"]:
                # status["queued"].remove("%s:%s" % (idx, step["case_id"]) )
                # wait_if_ram_lower_than(1000)
                status["started"].append("%s:%s" % (step["seq"], step["case_id"]))
                p = multiprocessing.Process(target=run_case, args=(config, status, step, step["seq"]), name=step["case_id"])
                p.start()
                status["pool"].append(p)
            if status["direct_quit"]:
                break
        time.sleep(5)

        logger.debug("passed: %s"      % status["passed"])
        logger.debug("failed: %s"      % status["failed"])
        logger.debug("started: %s"     % status["started"])
        logger.debug("pool: %s"        % status["pool"])
        logger.debug("direct_quit: %s" % status["direct_quit"])
        logger.debug("report: %s"      % status["report"])

        logger.debug("%s/%s done" % (len(status["pool"]), len(steps)))
        if status["direct_quit"]:
            break

    wait_till_all_ends(status)

    combine_pdf_if_required(steps, config)

    dump_reports(status)

if __name__ == "__main__":
    logger.info("%s called with %s" % (__name__, sys.argv))
    explain_plan(sys.argv[1], sys.argv[2])
