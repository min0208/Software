#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging
import logging.handlers
import os
import traceback
import json
import sys

# define format
general_formatter = logging.Formatter( "%(asctime)s | PID:%(process)d -> %(funcName)s at %(filename)s:%(lineno)d | %(levelname)s: %(message)s" )
cli_formatter     = logging.Formatter( "%(asctime)s | %(levelname)s: %(message)s" )

def init_logger_to_file():
    handler_to_file = logging.handlers.TimedRotatingFileHandler(
        'batch_execute_%s.log' % os.environ["BUILD_NUMBER"] if os.environ.has_key("BUILD_NUMBER") else "", 
        when='D', backupCount=7
    )
    handler_to_file.setLevel(logging.INFO)
    handler_to_file.setFormatter(general_formatter)

    return handler_to_file

def init_logger_to_terminal():
    handler_to_terminal = logging.StreamHandler()
    handler_to_terminal.setLevel(logging.INFO)
    handler_to_terminal.setFormatter(cli_formatter)
    return handler_to_terminal


logger = logging.getLogger()
logger.addHandler(init_logger_to_file())
logger.addHandler(init_logger_to_terminal())
logger.setLevel(logging.INFO)

