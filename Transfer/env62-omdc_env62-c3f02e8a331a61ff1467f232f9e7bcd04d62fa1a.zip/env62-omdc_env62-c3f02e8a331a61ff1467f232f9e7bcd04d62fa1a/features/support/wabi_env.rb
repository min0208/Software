require 'wabi-core'
# require 'wabi'
require 'wabi-fix'
require 'wabi-omd'
require 'wabi-web'

Before('~@=RandomPort')do
  #@fixproxy = "fixproxy"
  #@wfpPort = 8671
  @wfpPort = ENV["FIXPROXYPORT"]
  @cleanUpTemplate = "CancelOrder"
  @waittimeForSessionLogon = 10
  @waittimeForResponse = 5
  @waittimeForSendingRequest = 1
  @waittimeForStartingFIXProxy = 20
  @waittimeForQueryRequest = 5
  @timeout = 300
  @useAccurateSentTime = 'Y'
  
  #OMD-Retransmission
  @retrans_server_host = '10.163.236.28'
  @retrans_server_port = '55455'
  @retrans_timedout    = 300
  @retrans_interval    = 15
  @retrans_latency     = 0.5

  #MMDH
  @mmdh_timeout  = 3600  # waiting time for processing
  
  end

Before('@=RandomPort') do 
  @cleanUpTemplate = "CancelOrder"
  @waittimeForSessionLogon = 10
  @waittimeForResponse = 5 
  @waittimeForSendingRequest = 1
  @waittimeForStartingFIXProxy = 5
  @waittimeForQueryRequest = 5
end

Given(/^([a-zA-Z0-9 ]*) invalid retransmitted repeat (\d+) times:$/) do |subject, num, table|
  error = table.hashes[0]['Error_Message']
  num.to_i.times do
	  step "Next line has error \"#{error}\""
	  step "[error-table] #{subject} retransmitted:", table
  end
end

#WABI-OMD
ENV['OMD_PROJECT'] = 'omdc'
ENV['OMD_IP'] = '127.0.0.1'
ENV['OMD_PORT'] = '6666'
ENV['OMD_VERSION'] = '1.23'
