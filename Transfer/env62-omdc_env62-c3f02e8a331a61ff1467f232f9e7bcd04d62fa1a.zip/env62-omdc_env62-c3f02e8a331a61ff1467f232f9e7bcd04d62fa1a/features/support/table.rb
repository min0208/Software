# Consolidate all search results into a table
Given /^Combine (\d+) rows in table (.*?) which has (\d+) rows and (\d+) columns each in (\d+) pages$/ do |recordnum,table,rowOpt,colnum,pagenum|	
	(0..pagenum.to_i-1).each do |page|
	
	    # save the table
		step "Copy table #{table} to tb_#{page+1}"		
		
		# verify header
		(0..colnum.to_i-1).each do |num|
		  step "Verify (tb_#{page+1}_header[#{num}] == header_#{num+1})"
		end
								
		# if it is last page, then check the no. of rows
		# if not, check the no. of rows according to row option
		  if (page == pagenum.to_i-1)
			if (recordnum.to_i%rowOpt.to_i == 0)
				steps %{
				   * Verify (tb_#{page+1}.size == #{rowOpt.to_i})
				   * Verify (tb_#{page+1}_header.size == #{colnum})
				}
			else
				@row_lastpage = recordnum.to_i%rowOpt.to_i
				steps %{
				   * Verify (tb_#{page+1}.size == #{@row_lastpage})
				   * Verify (tb_#{page+1}_header.size == #{colnum})
				}
			end
		 else
			steps %{
				* Verify (tb_#{page+1}.size == #{rowOpt.to_i})
				* Verify (tb_#{page+1}_header.size == #{colnum})
				* Click the NavBar_PageNext
				* Wait 1 second
			}
		 end
	end
	
	# Combine all tables into one big table
	step "Assign tb_1 to FullResultTable"
	(1..pagenum.to_i-1).each do |tbnum|
		steps %{
		  * Assign (FullResultTable + tb_#{tbnum+1}) to FullResultTable
		}
	end
	step "Verify (FullResultTable.size == #{recordnum.to_i})"
end

#Sort in descending order
Given /^Sort table column (\d+) (.*?) in descending order$/ do |colnum,colname|
  content = []
  @bigmap['FullResultTable'].each do | line |
    content << line[colnum.to_i-1]
  end
  unless content.sort.reverse  == content
    raise "the order of #{content} is not descending"
  end
  puts "#{colname} is in descending order"
  puts content
end

#Sort in ascending order
Given /^Sort table column (\d+) (.*?) in ascending order$/ do |colnum,colname|
  content = []
  @bigmap['FullResultTable'].each do | line |
    content << line[colnum.to_i-1]
  end
  unless content.sort  == content
    raise "the order of #{content} is not ascending"
  end
  puts "#{colname} is in ascending order"
  puts content
end

#Check if the result matches with one search criterion
Given /^The result table column (\d+) "(.*?)" contains (.*?)$/ do |colno,colname,value|
	#keyword = @bigmap['keyword'].to_s
	#@bigmap['FullResultTable'].each do |row|
	#  unless row[colno.to_i-1].include? keyword
#		raise "#{keyword} is not found in #{colname}"
#	  end	  
#	end
#	puts "Result match"
	
	keyword = @bigmap[value]
	steps %{
	  * [loop from 2 to FullResultTable.size] Verify (FullResultTable[<LOOP>][#{colno}] == "#{keyword}"
	} 
end

#Check if the result matches with two search criteria
Given /^The result table column (\d+) contains (.*?), column (\d+) contains (.*?)$/ do |col1,value1,col2,value2|
	keyword1 = @bigmap['value1'].to_s
	keyword2 = @bigmap['value2'].to_s
	
	# Search the first value
	@bigmap['FullResultTable'].each do |row|
	  unless row[col1.to_i-1].include? keyword1
		raise "#{keyword1} is not found in #{row.index}"
	  end	  
	end
	
	# Search the second value
	@bigmap['FullResultTable'].each do |row|
	  unless row[col2.to_i-1].include? keyword2
		raise "#{keyword2} is not found in #{row.index}"
	  end	  
	end
	puts "Result match"
end

#Check if the result matches with three search criteria
Given /^Column (\d+) contains (.*?), column (\d+) contains (.*?) and column (\d+) contains (.*?)$/ do |col1,value1,col2,value2,col3,value3|
	keyword1 = @bigmap['value1'].to_s
	keyword2 = @bigmap['value2'].to_s
	keyword3 = @bigmap['value3'].to_s
	
	# Search the first value
	@bigmap['FullResultTable'].each do |row|
	  unless row[col1.to_i-1].include? keyword1
		raise "#{keyword1} is not found in #{row.index}"
	  end	  
	end
	
	# Search the second value
	@bigmap['FullResultTable'].each do |row|
	  unless row[col2.to_i-1].include? keyword2
		raise "#{keyword2} is not found in #{row.index}"
	  end	  
	end
	
	# Search the third value
	@bigmap['FullResultTable'].each do |row|
	  unless row[col3.to_i-1].include? keyword3
		raise "#{keyword3} is not found in #{row.index}"
	  end	  
	end
	puts "Result match"
end


# Check the no. of textfields in a page
Given /^(.*?) contains (\d+) textfields$/ do |var, num|
  var_html = Nokogiri::HTML(@bigmap[var])
  raise "it doesn't contain #{num} textfields" unless var_html.xpath("//input").size == num
end

# Assign the column name into variable one by one
# variable name = header_[no.]
Given /^Column name (.*?)$/ do |colnam|
  header = colnam.split(",")
  @count = 1
  header.each do |head|
    if (head == '""')
	   head = ""
	end 
    step "Assign \"#{head}\" to header_#{@count}"
	@count +=1
  end   
end

# Verify header name
Given /^Verify table header name with (\d+) column$/ do |colnum|
  colno = colnum.to_i
  (0..colno-1).each do |num|
	step "Verify (FullResultTable_header[#{num}] == header_#{num+1})"
  end
end

# Verify wildcard search
Given /^Verify wildcard search result column (\d+) "(.*?)" with (.*?)$/ do |colnum,colname,value|
  keyword = @bigmap[value].gsub('%','')
  steps %{
    * Assign "#{keyword}" to #{value}
    * The result table column #{colnum} "#{colname}" contains #{value}
  }
end

# Verify empty table
Given /^Verify empty table$/ do
  step "Verify (FullResultTable.size == 0)"
  #steps %{
   # * Verify (FullResultTable.size == 0)
  #}
end

# Verify the table is not empty
Given /^Verify not empty table$/ do
  tablesize = @bigmap['FullResultTable'].size
  if tablesize.zero?
    raise "The table is not empty."
  end
end

Given /^Table should have (\d+) row$/ do |row|
  step "Verify (FullResultTable.size == #{row})"

  #steps %{
   # * Verify (FullResultTable.size == #{row})
  #}
end


# verify the content in one column in one row
Given /^Verify table (.*?) column (\d+) row (\d+) with (.*?)$/ do |obj,rownum,colnum,keyword|
  keyword = @bigmap['keyword']
  steps %{
    * Copy table #{obj} to tb
	* Verify (tb[#{rownum.to_i-1}][#{colnum.to_i-1}] == "#{keyword}")
  }
end

# verify the content in two columns in one row
Given /^Verify table (.*?) row (\d+) column (\d+) with (.*?) and column (\d+) with (.*?)$/ do |table,rownum,colnum1,keyword1,colnum2,keyword2|
  value1 = @bigmap[keyword1]
  value2 = @bigmap[keyword2]

  steps %{
    * Copy table #{table} to tb
	* Print tb
	* Verify (tb[#{rownum.to_i-1}][#{colnum1.to_i-1}] == "#{value1}" and tb[#{rownum.to_i-1}][#{colnum2.to_i-1}] == "#{value2}")
  }
    
end


# verify the content in three columns in one row
Given /^Verify row (\d+) in table (.*?) under column (\d+) with (.*?),column (\d+) with (.*?) and column (\d+) with (.*?)$/ do |rownum,table,colnum1,keyword1,colnum2,keyword2,colnum3,keyword3|
  
  value1 = @bigmap[keyword1]
  value2 = @bigmap[keyword2]
  value3 = @bigmap[keyword3]

  steps %{
    * Copy table #{table} to tb
	* Print tb
	* Verify (tb[#{rownum.to_i-1}][#{colnum1.to_i-1}] == "#{value1}" and tb[#{rownum.to_i-1}][#{colnum2.to_i-1}] == "#{value2}" and tb[#{rownum.to_i-1}][#{colnum3.to_i-1}] == "#{value3}")
  }
    
end





