Given /^Verify the RealTime menu button$/ do 
  steps %{
   * Verify the ActSusBroker_MenuButton with "Activate / Suspend Broker"
   * Verify the ActSusMemFirm_MenuButton with "Activate / Suspend Member Firm"
   * Verify the ActSusBrokerSPOrderSub_MenuButton with "Activate / Suspend SP Order Submission"
   * Verify the CxlAllBrokerOrders_MenuButton with "Cancel All Broker Orders"
   * Verify the CxlBrokerOrders_MenuButton with "Cancel Broker Orders"
   * Verify the CxlBrokerTrades_MenuButton with "Cancel Broker Trades"
   * Verify the CxlMemFirmOrders_MenuButton with "Cancel Member Firm Orders"
   * Verify the CxlPostMCETrades_MenuButton with "Cancel Post-MCE Trades"
   * Verify the EnquireCxlActionsUpdateART_MenuButton with "Enquire / Cancel Actions / Update ART"
   * Verify the EnquireUpdateScheduleTradStates_MenuButton with "Enquire / Update Scheduled Trading States"
   * Verify the InitiateAction_MenuButton with "Initiate Action"
   * Verify the MaintainUpdateActionList_MenuButton with "Maintain / Update Action List"
   * Verify the MtnUpdExRate_MenuButton with "Maintain / Update Exchange Rate"
   * Verify the MaintainUpdateSecFreeText with "Maintain / Update Security Free Text"
   * Verify the ScheduleExchangeIntervention_MenuButton with "Schedule Exchange Intervention"
   * Verify the UpdateCGClient_MenuButton with "Update CG Client"
   * Verify the UpdateMemFirm_MenuButton with "Update Member Firm"
   * Verify the UpdateSecurity_MenuButton with "Update Security"
   * Verify the UpdateTradingSupportFacility_MenuButton with "Update Trade Support Facility"
   * Verify the UpdPreTradingState_MenuButton with "Update / Preset Trading State"
  }
end

Given /^Verify the UserAdmin menu button$/ do 
  steps %{
   * Verify the MaintainUsers_MenuButton with "Maintain Users"
   * Verify the MaintainDepartment_MenuButton with "Maintain Departments"
   * Verify the MaintainRole_MenuButton with "Maintain Roles"
  }
end

Given /^Verify the Deferred menu button$/ do 
  steps %{
   * Verify the MaintainBroker_MenuButton with "Maintain Broker"
   * Verify the MaintainCalendar_MenuButton with "Maintain Calendar"
   * Verify the MaintainCGClient_MenuButton with "Maintain CG Client"
   * Verify the MaintainDesignatedDealers_MenuButton with "Maintain Designated Dealers"
   * Verify the MaintainExchangeParameter_MenuButton with "Maintain Exchange Parameters"
   * Verify the MaintainIndexCodes_MenuButton with "Maintain Index Codes"
   * Verify the MaintainLinkedSecurities_MenuButton with "Maintain Linked Securities"
   * Verify the MaintainLPSMMBrokerSecAssign_MenuButton with "Maintain LP/SMM Broker-Security Assignment"
   * Verify the MaintainMarket_MenuButton with "Maintain Market"
   * Verify the MaintainMarketSegment_MenuButton with "Maintain Market Segment"
   * Verify the MaintainFirm_MenuButton with "Maintain Member Firm"
   * Verify the MaintainSecurity_MenuButton with "Maintain Security"
   * Verify the MaintainSecurityAccessGroup_MenuButton with "Maintain Security Access Group"
   * Verify the MaintainTASSPRINTSChange_MenuButton with "Maintain TAS/SPRINTS Changes"
   * Verify the MaintainThrottle_MenuButton with "Maintain Throttle"
   * Verify the MaintainTradingSupportFacility_MenuButton with "Maintain Trading Support Facility"
   * Verify the RequestActivityLog_MenuButton with "Request Activity Log"
   * Verify the UpdSecAndBrokerData_MenuButton with "Upload Securities and Broker Data"
   * Verify the UpdTradingTimetable_MenuButton with "Upload Trading Timetable"
   * Verify the ViewPasswordPolicy_MenuButton with "View Password Policy"
   * Verify the ViewProductType_MenuButton with "View Product Type"
   * Verify the ReportGeneration_MenuButton with "Report Generation"
  }
end

Given /^Verify the MaintainTASSPRINTSChange menu button$/ do 
  steps %{
   * Verify the MaintainScheduledSecChange_MenuButton with "Maintain Scheduled Security Changes"
   * Verify the TASCPRINTSScheduledChangeBulkApproval_MenuButton with "TAS/SPRINTS & Scheduled Changes Bulk Approval"
   * Verify the MaintainTASSPRINTSChangeInTASSPRINT_MenuButton with "Maintain TAS/SPRINTS Changes"
  }
end

Given /^Verify the MaintainExchangeParameter menu button$/ do 
  steps %{
   * Verify the MaintainBusinessFunctionGroup_MenuButton with "Maintain Business Function Group"
   * Verify the MaintainCASParaGp_MenuButton with "Maintain CAS Parameter Group"
   * Verify the MaintainCurrency_MenuButton with "Maintain Currency".
   * Verify the MaintainFeeGroup_MenuButton with "Maintain Fee Group"
   * Verify the MaintainGlobalParameters_MenuButton with "Global Parameters"
   * Verify the MaintainPriceLimitGroup_MenuButton with "Price Limit Group"
   * Verify the MaintainProductGroup_MenuButton with "Maintain Product Group"
   * Verify the MaintainReportingGroup_MenuButton with "Maintain Reporting Group"
   * Verify the MaintainSecurityIDRange_MenuButton with "Maintain Security ID Range"
   * Verify the MaintainSSAllowedPerOrdType_MenuButton with "Maintain Short Sell Allowed Per Order Type"
   * Verify the MaintainShortSellRulesGroup_MenuButton with "Maintain Short Sell Rules Group"
   * Verify the MaintainSpreadTable_MenuButton with "Maintain Spread Table"
   * Verify the MaintainTradingRulesGroup_MenuButton with "Maintain Trading Rules Group"
   * Verify the MaintainVCMParametergroup_MenuButton with "Maintain VCM Parameter Group'
  }
end

Given /^Verify the RealTime menu button$/ do 
  steps %{
   * Verify the ActSusBroker_MenuButton with "Activate / Suspend Broker"
   * Verify the ActSusMemFirm_MenuButton with "Activate / Suspend Member Firm"
   * Verify the ActSusBrokerSPOrderSub_MenuButton with "Activate / Suspend SP Order Submission"
   * Verify the CxlAllBrokerOrders_MenuButton with "Cancel All Broker Orders"
   * Verify the CxlBrokerOrders_MenuButton with "Cancel Broker Orders"
   * Verify the CxlBrokerTrades_MenuButton with "Cancel Broker Trades"
   * Verify the CxlMemFirmOrders_MenuButton with "Cancel Member Firm Orders"
   * Verify the CxlPostMCETrades_MenuButton with "Cancel Post-MCE Trades"
   * Verify the EnquireCxlActionsUpdateART_MenuButton with "Enquire / Cancel Actions / Update ART"
   * Verify the EnquireUpdateScheduleTradStates_MenuButton with "Enquire / Update Scheduled Trading States"
   * Verify the InitiateAction_MenuButton with "Initiate Action"
   * Verify the MaintainUpdateActionList_MenuButton with "Maintain / Update Action List"
   * Verify the MtnUpdExRate_MenuButton with "Maintain / Update Exchange Rate"
   * Verify the MaintainUpdateSecFreeText with "Maintain / Update Security Free Text"
   * Verify the ScheduleExchangeIntervention_MenuButton with "Schedule Exchange Intervention"
   * Verify the UpdateCGClient_MenuButton with "Update CG Client"
   * Verify the UpdateMemFirm_MenuButton with "Update Member Firm"
   * Verify the UpdateSecurity_MenuButton with "Update Security"
   * Verify the UpdateTradingSupportFacility_MenuButton with "Update Trade Support Facility"
   * Verify the UpdPreTradingState_MenuButton with "Update / Preset Trading State"
  }
end

Given /^Verify the existence of header button (.*?) in (.*?)$/ do |button,modulename|
  steps %{
   * Verify the #{button} existing
   * Verify the #{button} with "#{modulename}"
   * Verify the PageAdmin_HomeButton existing
   * Verify the PageAdmin_SignOut existing
   * Verify the PageAdmin_UserId existing
   
   * Click the PageAdmin_UserId
   * Verify the PageAdmin_ChangePW existing
   
  }
  #* Verify the PageAdmin_HeaderTitle with "OTP-C Admin (Env M3)-MTC"
end


Given /^Click the (.*?) and Verify the page name with (.*?) in (.*?)$/ do |button,msg,msg2|
   if (msg2 == "Deferred") 
        obj = PageAdmin_DF
   elsif (msg2 == "Real Time")
        obj = PageAdmin_RT
   elsif (msg2 == "User Admin")
        obj = PageAdmin_UA
   end
  steps %{
   * Click the #{button}
   * Verify the #{obj} existing
   * Verify the #{obj} with "#{msg2}"
   * Verify the PageAdmin_HomeButton existing
   * Verify the PageAdmin_SignOut existing
   * Verify the PageAdmin_UserId existing
   
   * Verify the PageAdmin_Row_2_title with "#{msg}"
  }
  #* Verify the PageAdmin_HeaderTitle with "OTP-C Admin (Env M3)-MTC"
end


