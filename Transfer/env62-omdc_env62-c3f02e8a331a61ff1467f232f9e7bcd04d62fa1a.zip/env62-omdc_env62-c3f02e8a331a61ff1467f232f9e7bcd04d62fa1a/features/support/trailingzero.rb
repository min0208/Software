Given /^The (.*?) of (.*?) should be (.*?) with trailing zero$/ do |type,obj,value|

   if type == "percentage"
     decimal = '%.4f' % (@bigmap[value].to_f)
   elsif type == "price"
     decimal = '%.5f' % (@bigmap[value].to_f)
   elsif type == "rate"
     decimal = '%.2f' % (@bigmap[value].to_f)
   else 
     raise "Wrong data type"
   end
   
   step "Attribute value of #{obj} is #{decimal}"
   
end

Given /^Add a trailing zero for (.*?) in (.*?) and assign to (.*?)$/ do |value,type,variable|
   
   if type == "percentage"
     decimal = '%.4f' % (@bigmap[value].to_f)
   elsif type == "price"
     decimal = '%.5f' % (@bigmap[value].to_f)
   elsif type == "rate"
     decimal = '%.2f' % (@bigmap[value].to_f)
   else 
     raise "Wrong data type"
   end

   step "Assign #{decimal} to #{variable}"

end