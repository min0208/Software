Given(/^Exclude the security (.*?) in the action list (.*?)$/) do |variable,obj|
  element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
  html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
  prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
  i = 1
  k = -1
  keyword = @bigmap[variable]
  
  html_doc.xpath('//tr').each do |row|
	  row.xpath('./td[3]').each do |data|
		if data.content.strip == keyword
			if (i == 1)
				step("Load object InitiateAction_OptList_Exclude from xpath //select") 
			else
				step("Load object InitiateAction_OptList_Exclude from xpath //tr[#{i}]/td[7]/select") 
			end
			step("Select the InitiateAction_OptList_Exclude with Y")
			k = 0
			break
		end
	  i+=1
	  end	
  end
  
 while (prop != 'not-allowed' && k != 0)
	step("Click the NavBar_PageNext")
	i = 1
	element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
	html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
	prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
	  html_doc.xpath('//tr').each do |row|
		  row.xpath('./td[3]').each do |data|
			if data.content.strip == keyword
				if (i == 1)
					step("Load object InitiateAction_OptList_Exclude from xpath //select") 
				else
					step("Load object InitiateAction_OptList_Exclude from xpath //tr[#{i}]/td[7]/select") 
				end
			step("Select the InitiateAction_OptList_Exclude with Y")
				k = 0
				break
			end
		  i+=1
		  end	
	  end	  
 end
	
  if k == 0 
     puts "#{keyword} is excluded"
  else
     raise "#{keyword} is not found" 
  end
  
end

Given(/^Include the security (.*?) in the action list (.*?)$/) do |variable,obj|
  element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
  html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
  prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
  i = 1
  k = -1
  keyword = @bigmap[variable]
  
  html_doc.xpath('//tr').each do |row|
	  row.xpath('./td[3]').each do |data|
		if data.content.strip == keyword
			if (i == 1)
				step("Load object InitiateAction_OptList_Exclude from xpath //select") 
			else
				step("Load object InitiateAction_OptList_Exclude from xpath //tr[#{i}]/td[7]/select") 
			end
			step("Select the InitiateAction_OptList_Exclude with N")
			k = 0
			break
		end
	  i+=1
	  end	
  end

 while (prop != 'not-allowed' && k != 0)
	step("Click the NavBar_PageNext")
	i = 1
	element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
	html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
	prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
	  html_doc.xpath('//tr').each do |row|
		  row.xpath('./td[3]').each do |data|
			if data.content.strip == keyword
				if (i == 1)
					step("Load object InitiateAction_OptList_Exclude from xpath //select") 
				else
					step("Load object InitiateAction_OptList_Exclude from xpath //tr[#{i}]/td[7]/select") 
				end
			step("Select the InitiateAction_OptList_Exclude with N")
				k = 0
				break
			end
		  i+=1
		  end	
	  end	  
 end
	
  if k == 0 
     puts "#{keyword} is excluded"
  else
     raise "#{keyword} is not found" 
  end
  
end
  
Given(/^Verify the security (.*?) exist in the action list (.*?)$/) do |variable,obj|
  element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
  html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
  prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
  i = 1
  k = -1
  keyword = @bigmap[variable]
  html_doc.xpath('//tr').each do |row|
	  row.xpath('./td[2]').each do |data|
		if data.content.strip == keyword
			k = 0
		end
	  i+=1
	  end	
  end
  
 while (prop != 'not-allowed' && k != 0)
	step("Click the NavBar_PageNext")
	i = 1
	element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
	html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
	prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
	  html_doc.xpath('//tr').each do |row|
		  row.xpath('./td[2]').each do |data|
			if data.content.strip == keyword				
				k = 0
			end
		  i+=1
		  end	
	  end	  
 end
	
  if k == 0 
     puts "#{keyword} exist"
  else
     raise "#{keyword} does not found" 
  end
  
end


Given(/^Remove the security (.*?) in the action list (.*?)$/) do |variable,obj|
  element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
  html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
  prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
  i = 1
  k = -1
  keyword = @bigmap[variable]
  html_doc.xpath('//tr').each do |row|
	  row.xpath('./td[2]').each do |data|
		if data.content.strip == keyword
			if (i == 1)
				step("Load object InitiateAction_OptList_Remove from xpath //td[4]/select") 
			else
				step("Load object InitiateAction_OptList_Remove from xpath //tr[#{i}]/td[4]/select") 
			end
			step("Select the InitiateAction_OptList_Remove with Y")
			k = 0
			break
		end
	  i+=1
	  end	
  end
  
 while (prop != 'not-allowed' && k != 0)
	step("Click the NavBar_PageNext")
	i = 1
	element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
	html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
	prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
	  html_doc.xpath('//tr').each do |row|
		  row.xpath('./td[2]').each do |data|
			if data.content.strip == keyword
				if (i == 1)
					step("Load object InitiateAction_OptList_Remove from xpath //td[4]/select") 
				else
				   step("Load object InitiateAction_OptList_Remove from xpath //tr[#{i}]/td[4]/select") 
				end
			    step("Select the InitiateAction_OptList_Remove with Y")
				k = 0
				break
			end
		  i+=1
		  end	
	  end	  
 end
	
  if k == 0 
     puts "#{keyword} is removed"
  else
     raise "#{keyword} is not found" 
  end
  
end



Given(/^Verify the security (.*?) removed from the action list (.*?)$/) do |variable,obj|
  element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
  html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
  prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
  i = 1
  k = -1
  keyword = @bigmap[variable]
  puts keyword

  html_doc.xpath('//tr').each do |row|
	  row.xpath('./td[2]').each do |data|
	  puts data
		if data.content.strip == keyword			
			k = 0
			break
		end
	  i+=1
	  end	
  end
  
 while (prop != 'not-allowed' && k != 0)
	step("Click the NavBar_PageNext")
	i = 1
	element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
	html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
	prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
	  html_doc.xpath('//tr').each do |row|
		  row.xpath('./td[2]').each do |data|
		   puts data
			if data.content.strip == keyword				
				k = 0
				break
			end
		  i+=1
		  end	
	  end	  
 end
	
  if k == 0 
     raise "#{keyword} is not removed" 
  else
     puts "#{keyword} is removed"
  end
  
end




Given(/^Verify the security (.*?) knock out in the MCE (.*?)$/) do |variable,obj|
  element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
  html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
  prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
  i = 1
  k = -1
  keyword = @bigmap[variable]
  html_doc.xpath('//tr').each do |row|
	  row.xpath('./td[2]').each do |data|
		if data.content.strip == keyword
			k = 0
		end
	  i+=1
	  end	
  end
  
 while (prop != 'not-allowed' && k != 0)
	step("Click the NavBar_PageNext")
	i = 1
	element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
	html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
	prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
	  html_doc.xpath('//tr').each do |row|
		  row.xpath('./td[2]').each do |data|
			if data.content.strip == keyword				
				k = 0
			end
		  i+=1
		  end	
	  end	  
 end
	
  if k == 0 
     puts "CBBC #{keyword} knocked out"
  else
     raise "CBBC #{keyword} does not found" 
  end
  
end