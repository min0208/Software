Given (/^Verify drop down object (\w+) with (.*?)$/)  do |object,label|
  var = @bigmap[object].nil? ? object : @bigmap[object]
  str = #{label}
  expect_value = WabiUtil.get_value(@bigmap, label)
  puts var
  puts str
  puts expect_value
  if var =~ /<option selected="selected" label="#{label}" value="(.*)">#{label}<\/option>/
    #puts true
	puts "#{label} is selected"
  else 
	if var =~ /<option selected="selected" label="#{expect_value}" value="(.*)">#{expect_value}<\/option>/
		puts "#{expect_value} is selected"
    #puts false
	else
		raise "#{label} is not selected"
	end
  end
end

Given (/^Verify the drop down list (\w+) is (.*?)$/) do |object,label|
steps %{
   * Copy HTML #{object} to Variable_Temp
   * Print Variable_Temp
   * Verify drop down object Variable_Temp with #{label}
   }
end

Given (/^Verify IE drop down object (\w+) with (.*?)$/)  do |object,label|
  var = @bigmap[object].nil? ? object : @bigmap[object]
  str = #{label}
  expect_value = WabiUtil.get_value(@bigmap, label)
  puts var
  puts str
  puts expect_value
  if var =~ /<option selected="selected" value="(.*)" label="#{label}">#{label}<\/option>/
    #puts true
	puts "#{label} is selected"
  else 
	if var =~ /<option selected="selected" value="(.*)" label="#{expect_value}">#{expect_value}<\/option>/
		puts "#{expect_value} is selected"
    #puts false
	else
		raise "#{label} is not selected"
	end
  end
end

Given (/^Verify the IE drop down list (\w+) is (.*?)$/) do |object,label|
steps %{
   * Copy HTML #{object} to Variable_Temp
   * Print Variable_Temp
   * Verify IE drop down object Variable_Temp with #{label}
   }
end

Given (/^Save the original option of drop down list (.*?) to (.*?)$/)  do |obj,var|
   ele = @bigmap[obj].nil? ? obj : @bigmap[obj]
   if ele =~ /<option selected="selected" label="(.*)" value="(.*)">(.*)<\/option>/
     @bigmap[var] = ele.attribute value
   else
     raise "Nothing is selected"
   end 
   
   puts @bigmap[var]

end

Given (/^Verify calendar drop down object (\w+) with (.*?)$/)  do |object,label|
  var = @bigmap[object].nil? ? object : @bigmap[object]
  str = #{label}
  expect_value = WabiUtil.get_value(@bigmap, label)
  #puts var
  #puts str
  if var =~ /<option value="(.*)" label="#{label}" selected="selected">#{label}<\/option>/
    #puts true
	puts "#{label} is selected"
  else 
	if var =~ /<option value="(.*)" label="#{label}" selected="selected">#{expect_value}<\/option>/
		puts "#{expect_value} is selected"
    #puts false
	else
		raise "#{label} is not selected"
	end
  end
end

Given (/^Verify the calendar drop down list (\w+) is (.*?)$/) do |object,label|
steps %{
   * Copy HTML #{object} to Variable_Temp
   * Print Variable_Temp
   * Verify drop down object Variable_Temp with #{label}
   }
end