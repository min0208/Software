After('@auto-logout') do
  begin
     steps %{
	        * Load object from OTPCAdmin_Common_object
			* Already login to OTP-C Admin
			* Click the PageAdmin_SignOut
	}
	 puts "Successfully logout"
  rescue
  end
end

Given /^Login to OTP-C Admin$/ do
  puts "Open the browser"
  steps %{
        * Open the browser
        * Visit the page with website_OTPC_admin
		}
  i=1
  for i in 1 .. 10
    begin
      steps %{
        * Input the otpcAdmin_username_P#{i} to PageAdmin_UserName
        * Wait 2 seconds
        * Input the otpcAdmin_password_P#{i} to PageAdmin_UserPW
        * Wait 2 seconds
        * Click the PageAdmin_SignIn
        * Wait 2 seconds
        }
	  element_close_btn = @driver.find_element(:id, "homeIcon")
	  step "Click the PageAdmin_HomeButton"
	  break
    rescue
	  i = i + 1
	end

  end

end

Given /^Check login to OTP-C Admin$/ do
begin
     element_close_btn = @driver.find_element(:id, "homeIcon")
	 step "Click the PageAdmin_HomeButton"
  rescue
     step "Click the SuccessMsg_CloseButton"
          i=1
          for i in 1 .. 10
            begin
              steps %{
                * Input the otpcAdmin_username_P#{i} to PageAdmin_UserName
                * Wait 2 seconds
                * Input the otpcAdmin_password_P#{i} to PageAdmin_UserPW
                * Wait 2 seconds
                * Click the PageAdmin_SignIn
                * Wait 2 seconds
                }
        	  element_close_btn = @driver.find_element(:id, "homeIcon")
        	  step "Click the PageAdmin_HomeButton"
        	  break
            rescue
        	  i = i + 1
			end
          end
  end
end


Given /^Close OTP-C Admin$/ do
   begin
     steps %{
	        * Load object from OTPCAdmin_Common_object
			* Already login to OTP-C Admin
			* Click the PageAdmin_SignOut
			* Close the browser
	}
	 puts "Successfully close"
  rescue
  end
end

Given(/^Already login to OTP-C Admin$/) do
 
  begin
     element_close_btn = @driver.find_element(:id, "homeIcon")
	 step "Click the PageAdmin_HomeButton"
  rescue
     step "Click the SuccessMsg_CloseButton"
  end
  
end

Given /^Approve the submit request and the request is accepted$/ do
  steps %{
   * Input the otpcAdmin_approver_username to Approval_ApprovalID
   * Input the otpcAdmin_approver_password to Approval_ApprovalPW
   * Click the PageAdmin_SubmitButton
   * Goto the popup
   * Verify the Approval_MsgDesc with "Your request has been submitted successfully!"
   * Click the Approval_OKButton
  }
end

Given /^Approve the deferred submit request and the request is accepted$/ do
  steps %{
   * Input the df_otpcAdmin_approver_username to Approval_ApprovalID
   * Input the df_otpcAdmin_approver_password to Approval_ApprovalPW
   * Click the PageAdmin_SubmitButton
   * Goto the popup
   * Verify the DF_Approval_MsgDesc with "Your request has been submitted successfully!"
   * Click the DF_Approval_OKButton
  }
end

Given /^Approve the submit request but error message "(.*?)" is prompted$/ do |msg|
  steps %{
   * Goto the popup
   * Copy HTML Approval_ErrorMsgDesc_1 to Variable_Temp
   * Print Variable_Temp
   * Verify error message Variable_Temp is #{msg}
  }
end

Given /^Approve the deferred submit request but error message "(.*?)" is prompted$/ do |msg|
  steps %{
   * Goto the popup
   * Copy HTML Approval_ErrorMsgDesc_1 to Variable_Temp
   * Print Variable_Temp
   * Verify error message Variable_Temp is #{msg}
  }
end

Given /^Two error messages are prompted "(.*?)" and "(.*?)"$/ do |msg1,msg2|
  steps %{
   * Goto the popup
   * Copy HTML Approval_ErrorMsgDesc_1 to Variable_Temp_1
   * Print Variable_Temp_1
   * Verify error message Variable_Temp_1 is #{msg1}
   * Copy HTML Approval_ErrorMsgDesc_2 to Variable_Temp_2
   * Print Variable_Temp_2
   * Verify error message Variable_Temp_2 is #{msg2}
  }
end

Given /^Three error messages are prompted "(.*?)", "(.*?)" and "(.*?)"$/ do |msg1,msg2,msg3|
  steps %{
   * Goto the popup
   * Copy HTML Approval_ErrorMsgDesc_1 to Variable_Temp_1
   * Print Variable_Temp_1
   * Verify error message Variable_Temp_1 is #{msg1}
   * Copy HTML Approval_ErrorMsgDesc_2 to Variable_Temp_2
   * Print Variable_Temp_2
   * Verify error message Variable_Temp_2 is #{msg2}
   * Copy HTML Approval_ErrorMsgDesc_3 to Variable_Temp_3
   * Print Variable_Temp_3
   * Verify error message Variable_Temp_3 is #{msg3}
  }
end


Given /^Submit a request but error message "(.*?)" is prompted$/ do |msg|
  steps %{
   * Wait 2 seconds
   * Click the PageAdmin_SubmitButton
   * Wait 2 seconds
   * Goto the popup
   * Copy HTML Approval_ErrorMsgDesc_1 to Variable_Temp
   * Print Variable_Temp
   * Verify error message Variable_Temp is #{msg}
  }  
end



Given (/^Verify error message (.*?) is (.*?)$/) do |obj,msg|
   puts msg
   var = @bigmap[obj].nil? ? obj : @bigmap[obj]
   puts var
  if var ==  msg			
     puts "#{msg} is found"
   else
     raise "#{msg} does not found" 	 
  end 
end



# In Cancel Broker Trade/Orders, the message will pop up as success:XX, failed:XX, timeout:XX.
Given /^Approve the submit request and request is proceed successfully$/ do
  steps %{
   * Wait 2 seconds
   * Input the otpcAdmin_approver_username to Approval_ApprovalID
   * Input the otpcAdmin_approver_password to Approval_ApprovalPW
   * Wait 1 seconds
   * Click the PageAdmin_SubmitButton
   * Wait 1 seconds
   * Goto the popup
   * Wait 1 seconds
   * Verify the Approval_MsgDesc with "Success: .*, Failed: 0, Timeout: 0."
   * Wait 1 seconds
   * Click the Approval_OKButton
  }
end


# In Cancel Broker Trade/Orders, the message will pop up as success:XX, failed:XX, timeout:XX.
Given /^Approve the submit request and request is proceed failed$/ do
  steps %{
   * Input the otpcAdmin_approver_username to Approval_ApprovalID
   * Input the otpcAdmin_approver_password to Approval_ApprovalPW
   * Wait 1 seconds
   * Click the PageAdmin_SubmitButton
   * Goto the popup
   * Verify the Approval_MsgDesc with "Success: 0, Failed: .*, Timeout: 0."
   * Click the Approval_OKButton
  }
end


#  Verify text 
Given /^Verify the (.*?) includes text (.*?)$/ do |obj,msg|
  keyword = WabiUtil.get_value(@bigmap, msg)
  var = @bigmap[obj].nil? ? obj : @bigmap[obj]
  
  puts keyword
  puts var
  
  element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
  html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
  puts html_doc
  puts "#{html_doc}"
  isIn = html_doc.to_s.include? keyword
  puts isIn
  if (html_doc.to_s.include? keyword)
      puts "#{keyword} is found"
  else
      raise "#{keyword} does not found" 
  end 
end
