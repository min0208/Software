require 'wabi-core'
# require 'wabi'
require 'wabi-fix'

# verify session status
Given(/^(\w+) status isnot (\S+)$/) do |sender, status|
  session_string = @sender_session_map[sender]
  if session_string.nil? or session_string == "" then
    raise "#{sender} has an invalid session: #{@sender_session_map[sender]}"
  end
  actual_session_status = get_session_status(session_string);
  puts "#{sender} status is #{actual_session_status} at #{Time.now}"
  if status == actual_session_status 
    raise "#{sender} status is match."\
      + "Non-ExpectedStatus=#{status}, ActualStatus=#{actual_session_status}"
  else 
     puts "#{sender} status is mismatch. "\
      + "Non-ExpectedStatus=#{status}, ActualStatus=#{actual_session_status}"
  end
end

Given(/^(\S.*, *\S+)status isnot (\S+)$/) do |senders, status|
  senders.split(%r{,\s*}).each do |sender|
     step "#{sender} status isnot #{status}"
  end
end

Given(/^(\w+) single Logon$/) do |broker|
 steps %{
    * Set timestamp as T0
  }
     step "#{broker} send:", table(%{
      | MyRef | Template          |
      | L0001 | Logon             | 
        })
     step "#{broker} expect after T0:", table(%{
      | MyRef | Template          |
      | L0001 | LogonResponse     |
        })
     step "#{broker} send:", table(%{
      | MyRef | Template          |
      | L0002 | SequenceReset     |
        })
end


Given(/^(\w+)\s{1,2}single Logon with password (\w+)$/) do |broker, logonpassword|
 steps %{
    * Set timestamp as T0
  }
     step "#{broker} send:", table(%{
      | MyRef | Template          | Password                  |
      | L0001 | Logon             | #{logonpassword}          |
        })
     step "#{broker} expect after T0:", table(%{
      | MyRef | Template          |
      | L0001 | LogonResponse     |
        })
     step "#{broker} send:", table(%{
      | MyRef | Template          |
      | L0002 | SequenceReset     |
        })
end


Given(/^(\w+) single Logon send with reference (\w+)$/) do |broker, ref|

     step "#{broker} send:", table(%{
      | MyRef | Template          |
      | #{ref}| Logon             | 
        })
end

Given(/^(\w+) single Logon fail with reference (\w+)$/) do |broker, ref|
     step "#{broker} expect:", table(%{
      | MyRef | Template          |
      | #{ref}| LogoutResponse    |
        })
end
#* Firm1BinaryBackOffice1 Logon for 3 times
Given(/^(\w+) Logon for ([0-9]+) times$/) do |broker, timenum|
    num = timenum.to_i
    myref_num = 1
    num.times do 
    m_num = myref_num.to_s.rjust(4,'0')
    myref = "L" + m_num
    step "#{broker} single Logon send with reference #{myref.to_s}"
    # puts myref
    myref_num += 1
    end
end


# * Firm1957BinaryBro6060 change password from Cc123456 to Dd123456
Given(/^(\w+)\s{1,2}change password from (\w+) to (\w+)$/) do |broker, prepassword,newpassword|
 steps %{
    * #{broker} status isnot Logon
  }
     step "#{broker} send:", table(%{
      | MyRef | Template          | Password         | NewPassword        | 
      | L0001 | ChangePassword    | #{prepassword}   | #{newpassword}     | 
        })
 steps %{
    * #{broker} print response
  }        
     step "#{broker} expect:", table(%{
      | MyRef | Template               |  SessionStatus |
      | L0001 | ChangePasswordResponse |       1        |
        })
 steps %{
    * #{broker} status is Logon
  }
end

Given(/^(\w+) single Logoff$/) do |broker|
 steps %{
    * Set timestamp as T0
  }
     step "#{broker} send:", table(%{
      | MyRef | Template          |
      | L0001 | Logout            |
        })
     step "#{broker} expect after T0:", table(%{
      | MyRef | Template          |
      | L0001 | LogoutResponse    |
        })
end
# CCG.rb:124: syntax error, unexpected keyword_end, expecting $end (SyntaxError)
Given(/^(\S.*, *\S+) mutiple Logoff$/) do |senders|
   myref_num = 1
   senders.split(%r{,\s*}).each do |sender|
         m_num = myref_num.to_s.rjust(4,'0')
         ref = "L" + m_num
         puts "This is MyRef #{ref} with #{sender}"
         step "#{sender} send:", table(%{
          | MyRef  | Template          |
          | #{ref} | Logout            |
            })
         step "#{sender} expect:", table(%{
          | MyRef  | Template          |
          | #{ref} | LogoutResponse    |
            })
        myref_num += 1
    end
 end


Given(/^(\w+) single Logoff send with reference (\w+)$/) do |broker, ref|

     step "#{broker} send:", table(%{
      | MyRef   | Template          |
      | #{ref}  | Logout            |
        })
     step "#{broker} expect:", table(%{
      | MyRef  | Template          |
      | #{ref} | LogoutResponse    |
        })
end


