Given (/^Check input object (\w+) with (.*?)$/)  do |object,label|
  var = @bigmap[object].nil? ? object : @bigmap[object]
  str = "#{label}"
  puts var
  puts str
  if var =~ /chkstate="#{str}"/   
	puts "#{label} is selected"
  else
	str = WabiUtil.get_value(@bigmap, label)
	 #puts str
	 if var =~ /chkstate="#{str}"/ 
		puts "#{str} is selected"
	 else	
		raise "#{str} is not selected"
	 end
  end
end


Given (/^Verify input object (\w+) with (.*?)$/) do |object,label|
steps %{
   * Copy HTML #{object} to Variable_Temp
   * Print Variable_Temp
   * Check input object Variable_Temp with #{label}
   }
end



Given (/^Verify checkbox object (\w+) with (.*?)$/)  do |object,label|
  element = Browser.find_element(@driver, @object_hash, @object_acc, object)
  html_doc = Nokogiri::HTML(element.attribute('outerHTML'))
  str = "#{label}"
  puts html_doc
  puts str
  #if html_doc =~ /chkstate="#{str}"/
  if html_doc.include? "chkstate=\"#{str}\""
	puts "#{label} is selected"
  else
	str = WabiUtil.get_value(@bigmap, label)
	 #puts str
	 #if html_doc =~ /chkstate="#{str}"/ 
	 if html_doc.include? "chkstate=\"#{str}\""
		puts "#{str} is selected"
	 else	
		raise "#{str} is not selected"
	 end
  end
end
