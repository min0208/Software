Given /^Input new trading state schedule at (\d+)\:(\d+)\:(\d+) during (\d+)\:(\d+)$/ do |hou,min,sec,duringMin,duringSec|
   steps %{
   * Input the #{hou} to UpdPreTradingState_ScheduleAtHour_EditForm
   * Input the #{min} to UpdPreTradingState_ScheduleAtMinute_EditForm
   * Input the #{sec} to UpdPreTradingState_ScheduleAtSecond_EditForm
   * Input the #{duringMin} to UpdPreTradingState_ScheduleDuringMinute_EditForm
   * Input the #{duringSec} to UpdPreTradingState_ScheduleDuringSecond_EditForm
   }
end


Given /^Input VCM start time from (\d+)\:(\d+)\:(\d+) to (\d+)\:(\d+)\:(\d+)$/ do |startHou,startMin,startSec,endHou,endMin,endSec|
steps %{
   * Input the #{startHou} to UpdPreTradingState_VCMStartHour_EditForm
   * Input the #{startMin} to UpdPreTradingState_VCMStartMinute_EditForm
   * Input the #{startSec} to UpdPreTradingState_VCMStartSecond_EditForm
   * Input the #{endHou} to UpdPreTradingState_VCMEndHour_EditForm
   * Input the #{endMin} to UpdPreTradingState_VCMEndMinute_EditForm
   * Input the #{endSec} to UpdPreTradingState_VCMEndSecond_EditForm
   }
end