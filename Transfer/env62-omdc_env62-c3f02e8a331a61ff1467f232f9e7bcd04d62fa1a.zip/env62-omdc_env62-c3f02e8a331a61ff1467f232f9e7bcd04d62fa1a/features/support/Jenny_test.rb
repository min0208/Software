# Demo step by Chris
Given (/^Get (\d+) minutes later time to (\w+) with hh:mm:ss format$/) do |num,var|
   ts = Time.now + (num.to_i*60)
   @bigmap[var] = ts.strftime("%H:%M:%S")
end


Given (/^Get (\d+) minutes later time to (\w+)$/) do |num,var|
   ts = Time.now + (num.to_i*60)
   @bigmap[var] = ts.strftime("%H:%M")
end

#Given /^Input schedule exchange intervention time at (\w+)$/ do |time|
#  ts = @bigmap[time]
#  hou = ts.split(':')[0]
#  min = ts.split(':')[1]
#steps %{
#   * Input the #{hou} to ScheduleEI_Hour_EditForm
#   * Input the #{min} to ScheduleEI_Minute_EditForm
#   }
#end
#
#
#Given /^Input new trading state schedule from (\w+) during (\d+):(\d+)$/ do |time,duringMin,duringSec|
#  ts = @bigmap[time]
#  hou = ts.split(':')[0]
#  min = ts.split(':')[1]
#  sec = ts.split(':')[2]
#steps %{
#   * Input the #{hou} to UpdPreTradingState_ScheduleAtHour_EditForm
#   * Input the #{min} to UpdPreTradingState_ScheduleAtMinute_EditForm
#   * Input the #{sec} to UpdPreTradingState_ScheduleAtSecond_EditForm
#   * Input the #{duringMin} to UpdPreTradingState_ScheduleDuringMinute_EditForm
#   * Input the #{duringSec} to UpdPreTradingState_ScheduleDuringSecond_EditForm
#   }
#end
#
Given /^Input VCM start time at (\w+)$/ do |time|
  ts = @bigmap[time]
  hou = ts.split(':')[0]
  min = ts.split(':')[1]
  sec = ts.split(':')[2]
steps %{
   * Input the #{hou} to UpdPreTradingState_VCMStartHour_EditForm
   * Input the #{min} to UpdPreTradingState_VCMStartMinute_EditForm
   * Input the #{sec} to UpdPreTradingState_VCMStartSecond_EditForm
   }
end


Given /^Input VCM end time at (\w+)$/ do |time|
  ts = @bigmap[time]
  hou = ts.split(':')[0]
  min = ts.split(':')[1]
  sec = ts.split(':')[2]
steps %{
   * Input the #{endHou} to UpdPreTradingState_VCMEndHour_EditForm
   * Input the #{endMin} to UpdPreTradingState_VCMEndMinute_EditForm
   * Input the #{endSec} to UpdPreTradingState_VCMEndSecond_EditForm
   }
end

