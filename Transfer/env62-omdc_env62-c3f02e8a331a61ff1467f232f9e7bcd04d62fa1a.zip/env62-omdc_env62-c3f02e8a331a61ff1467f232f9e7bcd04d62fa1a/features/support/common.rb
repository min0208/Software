#select an item in search result
Given(/^Select record from search table (.*?) with (.*?) and (.*?)$/) do |obj,variable,navBarNextPage|
  element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
  html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
  prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
  i = 1
  k = -1
  keyword = WabiUtil.get_value(@bigmap, variable)
  puts "trying to locate #{variable}, which is #{keyword} after extract from bigmap, within table"
  
  html_doc.xpath('//tr').each do |row|
	  row.xpath('./td[1]').each do |data|
		if data.content.strip == keyword
			if (i == 1)
				step("Load object edit_icon from xpath //td") 
			else
				step("Load object edit_icon from xpath //tr[#{i}]") 
			end
			step("Click the edit_icon")
			k = 0
			break
		end
	  i+=1
	  end	
  end
  
 while (prop != 'not-allowed' && k != 0)
	step("Click the NavBar_PageNext")
	i = 1
	element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
	html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
	prop = Browser.get_property(@driver,@object_hash, @object_acc, navBarNextPage,'cursor')
	  html_doc.xpath('//tr').each do |row|
		  row.xpath('./td[1]').each do |data|
			if data.content.strip == keyword
				if (i == 1)
					step("Load object edit_icon from xpath //td") 
				else
					step("Load object edit_icon from xpath //tr[#{i}]") 
				end
			step("Click the edit_icon")
				k = 0
				break
			end
		  i+=1
		  end	
	  end	  
 end
	
  if k == 0 
     puts "#{keyword} is selected"
  else
     raise "#{keyword} is not found" 
  end
  
end

# Verify the search parameter whether exist in search result
# index : the column index in search result table
# obj   : search result table 
# variable : the parameter input in search inputbox
Given(/^Verify column (\d) from search table (.*?) with (.*?)$/) do |index,obj,variable|
  element = Browser.find_element(@driver, @object_hash, @object_acc, obj)  
  html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
  prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
  expect_value = WabiUtil.get_value(@bigmap, variable)
  i = 1
  k = -1
  j = index.to_i
  html_doc.xpath('//tr').each do |row|
	  row.xpath("./td[#{j}]").each do |data|
		if data.content.strip ==expect_value
			#step("Load object edit_icon from xpath //tr[#{i}]/td") 
			#step("Click the edit_icon")
			k = 0
			break
		end
	  i+=1
	  end	
  end
  
 while (prop != 'not-allowed' && k != 0)
	step("Click the NavBar_PageNext")
	i = 1
	element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
	html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
	prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
	  html_doc.xpath('//tr').each do |row|
		  row.xpath("./td[#{j}]").each do |data|
			if data.content.strip ==expect_value
				#step("Load object edit_icon from xpath //tr[#{i}]/td") 
				#step("Click the edit_icon")
				k = 0
				break
			end
		  i+=1
		  end	
	  end	  
 end
	
  if k == 0 
     puts expect_value+" is selected"
  else
     raise expect_value+" is not found" 
  end
  
end


# Remove the action code from action list
# variable : action code to remove
# obj   : action list table 
Given(/^Remove action code (.*?) from table (.*?)$/) do |variable,obj|
  element = Browser.find_element(@driver, @object_hash, @object_acc, obj)  
  html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
  prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
  expect_value = WabiUtil.get_value(@bigmap, variable)
  i = 1
  k = -1
  j = 1
  puts expect_value
  html_doc.xpath('//tr').each do |row|
	  row.xpath("./td[#{j}]").each do |data|
		puts data.content.strip
		if data.content.strip ==expect_value
			if (i == 1)
				step("Load object remove_icon from xpath //td[5]/span") 
			else
				step("Load object remove_icon from xpath //tr[#{i}]/td[5]/span") 
			end
			step("Click the remove_icon")
			k = 0
			break
		end
	  i+=1
	  end	
  end
  
 while (prop != 'not-allowed' && k != 0)
	step("Click the NavBar_PageNext")
	i = 1
	element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
	html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
	prop = Browser.get_property(@driver,@object_hash, @object_acc, "navbtnNext",'cursor')
	  html_doc.xpath('//tr').each do |row|
		  row.xpath("./td[#{j}]").each do |data|
		  puts data.content.strip
			if data.content.strip ==expect_value
				if (i == 1)
				step("Load object remove_icon from xpath //td[5]/span") 
				else
					step("Load object remove_icon from xpath //tr[#{i}]/td[5]/span") 
				end
				step("Click the remove_icon")
				k = 0
				break
			end
		  i+=1
		  end	
	  end	  
 end
	
  if k == 0 
     puts expect_value+" is removed"
  else
     raise expect_value+" is not found" 
  end
  
end


# Remove the security access group from table
# variable : security access group name to remove
# obj   : result table 
Given(/^Remove security access group (.*?) from table (.*?)$/) do |variable,obj|
  element = Browser.find_element(@driver, @object_hash, @object_acc, obj)  
  html_doc = Nokogiri::HTML(element.attribute('innerHTML'))
  expect_value = WabiUtil.get_value(@bigmap, variable)
  i = 1
  k = -1
  j = 1
  puts expect_value
  html_doc.xpath('//tr').each do |row|
	  row.xpath("./td[#{j}]").each do |data|
		puts data.content.strip
		 if data.content.strip =~ /<option selected="selected" label="#{expect_value}" value="(.*)">#{expect_value}<\/option>/
			if (i == 1)
				step("Load object remove_icon from xpath //td[3]/button") 
			else
				step("Load object remove_icon from xpath //tr[#{i}]/td[3]/button") 
			end
			step("Click the remove_icon")
			k = 0
			break
		end
	  i+=1
	  end	
  end

  if k == 0 
     puts expect_value+" is removed"
  else
     raise expect_value+" is not found" 
  end
  
end

