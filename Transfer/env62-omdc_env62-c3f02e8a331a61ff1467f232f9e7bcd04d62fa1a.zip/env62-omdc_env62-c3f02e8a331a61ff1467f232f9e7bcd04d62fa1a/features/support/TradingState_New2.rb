# Change trading state for one market segment in Enquire Update Scheduled Trading States.
Given /^Change trading state of (\w+) from (\w+) (\w+) to (\w+) (\w+)$/ do |marketsegment,curtradingseeiontype,curtradestate,tradingsessiontype, tradingstate|
    #* Login to OTP-C Admin
steps %{
    * Load object from OTPCAdmin_Common_object
    * Load value from OTPCAdmin_Common_value
    * Load object from OTPCAdmin_RT_UpdPreTradingState_object
    * Click the PageAdmin_RT
    * Click the EnquireUpdateScheduleTradStates_MenuButton
    * Tick Trading State checkboxs whose column 3 is #{marketsegment} and column 6 is #{curtradingseeiontype} and colum 7 is #{curtradestate} at table EnqUpdScheduleTradStates_Display_Table
    * Select the EnqUpdScheduleTradStates_OptList_NewAutoControl with "M - Manual"
    * Select the EnqUpdScheduleTradStates_OptList_NewTradingSessionID with Day
    * Select the EnqUpdScheduleTradStates_OptList_NewTSType with #{tradingsessiontype}
    * Select the EnqUpdScheduleTradStates_OptList_NewTS with #{tradingstate}
    }
    if (tradingstate == "RC")
      steps %{
        * Input Random Close time (\w+) in Enquire Update Scheduled Trading State
        }
    end

    steps %{
        * Click the PageAdmin_NextButton
        }

    if (marketsegment == "ETS" || marketsegment == "NASD")
     steps %{
          * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_VCMApplicable1
          * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_ReserVCMPx1
          }
      else if (tradingstate == "CT" && curtradestate == "BL")
        steps %{
            * Get 10 minutes laster time and input VCM start time in Enquire Update Scheduled Trading State
            * Get 120 minutes laster time and input VCM end time in Enquire Update Scheduled Trading State
            * Verify and tick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_VCMApplicable1
            * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_ReserVCMPx1
            }
      else if (tradingstate == "CT" && curtradestate == "OC")
           steps %{
               * Get 10 minutes laster time and input VCM start time in Enquire Update Scheduled Trading State
               * Get 120 minutes laster time and input VCM end time in Enquire Update Scheduled Trading State
               * Verify and tick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_VCMApplicable1
               * Verify and tick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_ReserVCMPx1
               }
         end
      end
   end
end

# to loop "change market status" operation on all markets
Given /^Change trading state of all from (\w+) (\w+) to (\w+) (\w+) and schedule a time$/ do |curtradingseeiontype,curtradestate,tradingsessiontype, tradingstate|
	["MAIN", "GEM", "ETS", "NASD"].each do | marketsegment |g
		steps %{
			* Change trading state of #{marketsegment} from #{curtradingseeiontype} #{curtradestate} to #{tradingsessiontype} #{tradingstate} and schedule a time
		}
	end
end


# Change trading state for one market segment and schedule a few minutes in Enquire Update Scheduled Trading States.
# It ensure if changing multiple market segment and schedule in a same time.
# Get 2 minuts later time 
# * Get 2 minutes time as Later_time
Given /^Change trading state of (\w+) from (\w+) (\w+) to (\w+) (\w+) and schedule a time$/ do |marketsegment,curtradingseeiontype,curtradestate,tradingsessiontype, tradingstate|

puts "now change market #{marketsegment} from #{curtradingseeiontype} #{curtradestate} to #{tradingsessiontype} #{tradingstate}"
    #* Login to OTP-C Admin
steps %{
    * Load object from OTPCAdmin_Common_object
    * Load value from OTPCAdmin_Common_value
    * Load object from OTPCAdmin_RT_UpdPreTradingState_object
    * Click the PageAdmin_RT
    * Click the EnquireUpdateScheduleTradStates_MenuButton
    * Tick Trading State checkboxs whose column 3 is #{marketsegment} and column 6 is #{curtradingseeiontype} and column 7 is #{curtradestate} at table EnqUpdScheduleTradStates_Display_Table
    * Select the EnqUpdScheduleTradStates_OptList_NewAutoControl with "M - Manual"
    * Select the EnqUpdScheduleTradStates_OptList_NewTradingSessionID with Day
    * Select the EnqUpdScheduleTradStates_OptList_NewTSType with #{tradingsessiontype}
    * Select the EnqUpdScheduleTradStates_OptList_NewTS with #{tradingstate}
    * Click the EnqUpdScheduleTradStates_RadioButton_ScheduleAt
    * Input schedule time Later_time in Enquire Update Scheduled Trading State
    * Click the PageAdmin_NextButton
    }

    if (marketsegment == "ETS" || marketsegment == "NASD")
     steps %{
          * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_VCMApplicable1
          * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_ReserVCMPx1
          }
      else if (tradingstate == "CT" && curtradestate == "BL")
        steps %{
            * Get 10 minutes laster time and input VCM start time in Enquire Update Scheduled Trading State
            * Get 120 minutes laster time and input VCM end time in Enquire Update Scheduled Trading State
            * Verify and tick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_VCMApplicable1
            * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_ReserVCMPx1
            }
      else if (tradingstate == "CT" && curtradestate == "OC")
           steps %{
               * Get 10 minutes laster time and input VCM start time in Enquire Update Scheduled Trading State
               * Get 120 minutes laster time and input VCM end time in Enquire Update Scheduled Trading State
               * Verify and tick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_VCMApplicable1
               * Verify and tick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_ReserVCMPx1
               }
         end
      end
   end
end




# Change trading state for one market segment and schedule a few minutes in Enquire Update Scheduled Trading States.
# It ensure if changing multiple market segment and schedule in a same time.
# Get 2 minuts later time 
# * Get 2 minutes time as Later_time
Given /^Change trading state of (\w+) from (\w+) (\w+) to (\w+) (\w+) and schedule a same time$/ do |marketsegment,curtradingseeiontype,curtradestate,tradingsessiontype, tradingstate|
    #* Login to OTP-C Admin
    steps %{
    * Load object from OTPCAdmin_Common_object
    * Load value from OTPCAdmin_Common_value
    * Load object from OTPCAdmin_RT_UpdPreTradingState_object
    * Click the PageAdmin_RT
    * Click the EnquireUpdateScheduleTradStates_MenuButton
	* Wait 2 seconds
    * Tick Trading State checkboxs whose column 3 is #{marketsegment} and column 6 is #{curtradingseeiontype} and colum 7 is #{curtradestate} at table EnqUpdScheduleTradStates_Display_Table
    * Select the EnqUpdScheduleTradStates_OptList_NewAutoControl with "M - Manual"
    * Select the EnqUpdScheduleTradStates_OptList_NewTradingSessionID with Day
    * Select the EnqUpdScheduleTradStates_OptList_NewTSType with #{tradingsessiontype}
    * Select the EnqUpdScheduleTradStates_OptList_NewTS with #{tradingstate}
    * Click the EnqUpdScheduleTradStates_RadioButton_ScheduleAt
    * Input schedule time Later_time in Enquire Update Scheduled Trading State
    * Click the PageAdmin_NextButton
    }
    if (tradingstate == "RC")
      steps %{
        * Input the 02 to EnqUpdScheduleTradStates_Input_DurationMM
        * Input the 00 to EnqUpdScheduleTradStates_Input_DurationSS
        * Click the PageAdmin_NextButton
        }
    end
    if (marketsegment == "ETS" || marketsegment == "NASD")
     steps %{
          * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_VCMApplicable1
          * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_ReserVCMPx1
            }
      else if (tradingstate == "CT" && curtradestate == "BL")
        steps %{
            * Get 4 minutes laster time and input VCM start time in Enquire Update Scheduled Trading State
            * Get 240 minutes laster time and input VCM end time in Enquire Update Scheduled Trading State
            * Verify and tick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_VCMApplicable1
            * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_ReserVCMPx1
            }
       else if (tradingstate == "CT" && curtradestate == "OC")
           steps %{
               * Get 4 minutes laster time and input VCM start time in Enquire Update Scheduled Trading State
               * Get 240 minutes laster time and input VCM end time in Enquire Update Scheduled Trading State
               * Verify and tick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_VCMApplicable1
               * Verify and tick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_ReserVCMPx1
               }
          end 
       end
   end
	steps %{
	* Click the PageAdmin_SubmitButton
	}
end


Given /^Change trading state of (\w+) to (\w+) (\w+) at scheduled start time (\w+)$/ do |marketsegment,tradingsessiontype, tradingstate, starttime|
    #* Login to OTP-C Admin
    tmp_time = $timestamps[starttime]
    @bigmap[starttime] = tmp_time.strftime("%H:%M:%S")
    if(marketsegment == "all_markets")
      steps %{
      * Click the PageAdmin_RT
      * Click the EnquireUpdateScheduleTradStates_MenuButton
      * Wait 2 seconds
      * Click the EnqUpdScheduleTradStates_CheckBox_All
      * Select the EnqUpdScheduleTradStates_OptList_NewAutoControl with "M - Manual"
      * Select the EnqUpdScheduleTradStates_OptList_NewTradingSessionID with Day
      * Select the EnqUpdScheduleTradStates_OptList_NewTSType with #{tradingsessiontype}
      * Select the EnqUpdScheduleTradStates_OptList_NewTS with #{tradingstate}
      * Click the EnqUpdScheduleTradStates_RadioButton_ScheduleAt
      * Input schedule time #{starttime} in Enquire Update Scheduled Trading State
      }
    else
      steps %{
      * Click the PageAdmin_RT
      * Click the EnquireUpdateScheduleTradStates_MenuButton
      * Wait 2 seconds
      * Tick Trading State checkboxs whose column 3 is #{marketsegment} at table EnqUpdScheduleTradStates_Display_Table
      * Select the EnqUpdScheduleTradStates_OptList_NewAutoControl with "M - Manual"
      * Select the EnqUpdScheduleTradStates_OptList_NewTradingSessionID with Day
      * Select the EnqUpdScheduleTradStates_OptList_NewTSType with #{tradingsessiontype}
      * Select the EnqUpdScheduleTradStates_OptList_NewTS with #{tradingstate}
      * Click the EnqUpdScheduleTradStates_RadioButton_ScheduleAt
      * Input schedule time #{starttime} in Enquire Update Scheduled Trading State
      }
    end
    if (tradingstate == "RC")
      steps %{
        * Input the 02 to EnqUpdScheduleTradStates_Input_DurationMM
        * Input the 00 to EnqUpdScheduleTradStates_Input_DurationSS
        * Click the PageAdmin_NextButton
        }
    else
      steps %{
        * Click the PageAdmin_NextButton
      }  
    end
    if (tradingstate == "CT")
      if (marketsegment == "all_markets")
      steps %{
        * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_VCMApplicable1
        * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_ReserVCMPx1
        * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_VCMApplicable2
        * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_ReserVCMPx2
        * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_VCMApplicable3
        * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_ReserVCMPx3
        * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_VCMApplicable4
        * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_ReserVCMPx4
        }
      else
      steps %{
        * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_VCMApplicable1
        * Verify and untick checkbox of EnqUpdScheduleTradStates_CheckBox_SecPage_ReserVCMPx1
        }
      end
    end
  steps %{
  * Click the PageAdmin_SubmitButton
  }
end



##### Below custom steps are necessary to support the above change trading state step #####

#Given /^Login to OTP-C Admin$/ do
#  puts "Open the browser"
#  steps %{
#   * Open the browser
#   * Visit the page with website_OTPC_admin
#   * Input the otpcAdmin_username to PageAdmin_UserName
#   * Wait 2 seconds
#   * Input the otpcAdmin_password to PageAdmin_UserPW
#   * Wait 2 seconds
#   * Click the PageAdmin_SignIn
#   * Wait 2 seconds
#  }
#end

Given (/^Timestamp: wait till (\w+)$/) do | timest |
  ts = $timestamps[timest]
  actual_time = ts.strftime("%H:%M:%S")
  steps %{
    * Wait till #{actual_time}
  }
end


# Get current time
Given (/^Get current time as (\w+)$/) do |var|
   ts = Time.now
   @bigmap[var] = ts.strftime("%H:%M:%S")
end



# Get a few minutes later time time
Given (/^Get (\d+) minutes time as (\w+)$/) do |num,var|
   ts = Time.now + (num.to_i*60)
   @bigmap[var] = ts.strftime("%H:%M:%S")
end



# Input Random Close time in Enquire Update Scheduled Trading State
# Schedule in 2 minuts and 
Given /^Input Random Close time in Enquire Update Scheduled Trading State$/ do
  ts = Time.now + (2*60)
  ts = ts.strftime("%H:%M:%S")
  hou = ts.split(':')[0]
  min = ts.split(':')[1]
  sec = ts.split(':')[2]
steps %{
   * Input the #{hou} to EnqUpdScheduleTradStates_Input_ScheduleAtHH
   * Input the #{min} to EnqUpdScheduleTradStates_Input_ScheduleAtMM
   * Input the #{sec} to EnqUpdScheduleTradStates_Input_ScheduleAtSS
   * Input the 59 to EnqUpdScheduleTradStates_Input_DurationMM
   * Input the 00 to EnqUpdScheduleTradStates_Input_DurationSS
   }
end



# Input schedule time in Enquire Update Scheduled Trading State
# Schedule in 2 minuts and 
Given /^Input schedule time (\w+) in Enquire Update Scheduled Trading State$/ do |time|
  ts = @bigmap[time]
  hou = ts.split(':')[0]
  min = ts.split(':')[1]
  sec = ts.split(':')[2]
steps %{
   * Input the #{hou} to EnqUpdScheduleTradStates_Input_ScheduleAtHH
   * Input the #{min} to EnqUpdScheduleTradStates_Input_ScheduleAtMM
   * Input the #{sec} to EnqUpdScheduleTradStates_Input_ScheduleAtSS
   }
end



# Input VCM start time in Enquire Update Scheduled Trading State
Given /^Get (\d+) minutes laster time and input VCM start time in Enquire Update Scheduled Trading State$/ do |num|
  ts = Time.now + (num.to_i*60)
  ts = ts.strftime("%H:%M:%S")
  hou = ts.split(':')[0]
  min = ts.split(':')[1]
steps %{
   * Input the #{hou} to EnqUpdScheduleTradStates_CheckBox_SecPage_VCMStartHH
   * Input the #{min} to EnqUpdScheduleTradStates_CheckBox_SecPage_VCMStartMM
   * Input the 00 to EnqUpdScheduleTradStates_CheckBox_SecPage_VCMStartSS
   }
end



# Input VCM end time in Enquire Update Scheduled Trading State
Given /^Get (\d+) minutes laster time and input VCM end time in Enquire Update Scheduled Trading State$/ do |num|
  ts = Time.now + (num.to_i*60)
  ts = ts.strftime("%H:%M:%S")
  endHou = ts.split(':')[0]
  endMin = ts.split(':')[1]
steps %{
   * Input the #{endHou} to EnqUpdScheduleTradStates_CheckBox_SecPage_VCMEndHH
   * Input the #{endMin} to EnqUpdScheduleTradStates_CheckBox_SecPage_VCMEndMM
   * Input the 00 to EnqUpdScheduleTradStates_CheckBox_SecPage_VCMEndSS
   }
end



# Tick or untick a checkbox
# "exp" uses 2 value, tick or untick.
Given(/^Verify and (.*?) checkbox of (.*?)$/) do |exp,obj|
  element = Browser.find_element(@driver, @object_hash, @object_acc, obj)
   if (element.attribute('checked') == "true")
     if (exp == "untick")
      steps %{
      * Click the #{obj}
      }
      puts "Untick checkbox #{obj}"
     end
    else if (exp == "tick")
    steps %{
      * Click the #{obj}
      }
      puts "Tick checkbox #{obj}"
    end
   end
end



# web, checkbox, multi pattern
# This is used for Enquire/Update Scheduled Trading State page.

Given(/^Tick Trading State checkboxs whose ([\S :|,]+) at table (.*?)$/) do |all_pattern, target_table|
# Given(/^Tick Trading State checkboxs whose ((column (.*?) is (.*?) ?(?:and|,)? ?)+) at table (.*?)$/) do |all_pattern, _, _, _, target_table|
  html_doc = Nokogiri::HTML(Browser.find_element(@driver, @object_hash, @object_acc, target_table).attribute('innerHTML'))
  i = 1

  html_doc.xpath('//tbody/tr').each do | table_row |
    # puts "table_row: #{table_row}"
    row_match = true
    
    # split multiple pattern
    all_pattern.scan(/column (\S+) is (\S+)/).each do | at_column, expected_value |
      # puts "checking at column: #{at_column}"
      table_row.xpath("./td[#{at_column}]").each do | cell_data |
        puts "cell_data: #{cell_data.content.strip}, expected_value: #{expected_value}"
        row_match &= cell_data.content.strip == process_WABI_expression(expected_value)
      end

    end
    puts "i is #{i}, row_match: #{row_match}"

    if row_match
      puts "checking //table[@id='tblQueryResult']/tbody/tr#{if i == 1 then "" else "[#{i}]" end}/td/label/input"
      step("Load object checkbox_icon from xpath (//input[@type='checkbox'])[#{i+1}]") 
      step("Click the checkbox_icon")
    end

    i += 1  
  end

end


