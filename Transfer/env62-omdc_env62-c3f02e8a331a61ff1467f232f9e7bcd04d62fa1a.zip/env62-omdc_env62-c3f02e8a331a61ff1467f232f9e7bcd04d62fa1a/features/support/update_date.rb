#Update effective date to next trading day in upload data file
Given /^Update effective date to next trading day in upload data file: (.*?)$/ do |value|
  keyword = @bigmap[value]
  puts keyword
  cmd1 = "file="
  cmd2 = "
    oldTime=$(cat ${file}|tail -n +2|head -n 1|awk -F, '{print $2}')
    echo ${oldTime}
    curWeek=$(date '+%a')
    echo ${curWeek}
    if [ ${curWeek} == 'Fri' ] 
    then
        newTime=$(date -d 'next monday' '+%Y%m%d')
    else
        newTime=$(date -d next-day +%Y%m%d)
    fi
    echo ${newTime}
    sed -i 's/'${oldTime}'/'${newTime}'/g' ${file}
    resetTime=$(cat ${file}|tail -n +2|head -n 1|awk -F, '{print $2}')
    echo ${resetTime}"
  cmd = cmd1 + keyword + cmd2
  system(cmd)
  cmd3 = "
    cat ${file}|tail -n +2|head -n 1|awk -F, '{print $2}'"
  cmdputs = cmd1 + keyword + cmd3
  getvalue = `#{cmdputs}`
  puts getvalue
end

#Update effective date to next day include weekend in upload data file
Given /^Update effective date to next day in upload data file: (.*?)$/ do |value|
  keyword = @bigmap[value]
  puts keyword
  cmd1 = "file="
  cmd2 = "
    oldTime=$(cat ${file}|tail -n +2|head -n 1|awk -F, '{print $2}')
    echo ${oldTime}
    curWeek=$(date '+%a')
    echo ${curWeek}
    newTime=$(date -d next-day +%Y%m%d)
    echo ${newTime}
    sed -i 's/'${oldTime}'/'${newTime}'/g' ${file}
    resetTime=$(cat ${file}|tail -n +2|head -n 1|awk -F, '{print $2}')
    echo ${resetTime}"
  cmd = cmd1 + keyword + cmd2
  system(cmd)
  cmd3 = "
    cat ${file}|tail -n +2|head -n 1|awk -F, '{print $2}'"
  cmdputs = cmd1 + keyword + cmd3
  getvalue = `#{cmdputs}`
  puts getvalue
end

#the submit click for upload file scenario , these scenario need more waiting time to verify the upload data
Given /^Approve the uploadFile submit request and the request is accepted$/ do
  steps %{
   * Input the df_otpcAdmin_approver_username to Approval_ApprovalID
   * Input the df_otpcAdmin_approver_password to Approval_ApprovalPW
   * Click the PageAdmin_SubmitButton
   * Wait 60 seconds
   * Goto the popup
   * Wait 5 seconds
   * Verify the DF_Approval_MsgDesc with "Your request has been submitted successfully!"
   * Wait 5 seconds
   * Click the DF_Approval_OKButton   
  }
end