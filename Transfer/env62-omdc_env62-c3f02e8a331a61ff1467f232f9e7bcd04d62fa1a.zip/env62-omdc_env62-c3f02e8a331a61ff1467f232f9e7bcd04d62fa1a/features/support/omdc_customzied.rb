# customzied step for WABI-OMDC
# add by jack 2017-04-18

# web, checkbox, multi pattern
# Given(/^Tick checkboxs whose ((column (.*?) is (.*?) ?(?:and|,)? ?)+) at table (.*?)$/) do |all_pattern, _, _, _, target_table|
Given(/^Tick checkboxs whose ([\S :|,]+) at table (.*?)$/) do |all_pattern, target_table|
  html_doc = Nokogiri::HTML(Browser.find_element(@driver, @object_hash, @object_acc, target_table).attribute('innerHTML'))
  i = 1

  html_doc.xpath('//tbody/tr').each do | table_row |
    # puts "table_row: #{table_row}"
    row_match = true
    
    # split multiple pattern
    all_pattern.scan(/column (\S+) is (\S+)/).each do | at_column, expected_value |
      # puts "checking at column: #{at_column}"
      table_row.xpath("./td[#{at_column}]").each do | cell_data |
        puts "cell_data: #{cell_data.content.strip}, expected_value: #{expected_value}"
        row_match &= cell_data.content.strip == process_WABI_expression(expected_value)
      end

    end
    puts "i is #{i}, row_match: #{row_match}"

    if row_match
      puts "checking //table[@id='tblQueryResult']/tbody/tr#{if i == 1 then "" else "[#{i}]" end}/td/input"
      # step("Load object checkbox_icon from xpath //table[@id='tblQueryResult']/tbody/tr#{if i == 1 then "" else "[#{i}]" end}/td/input") 
      step("Load object checkbox_icon from xpath //table[@id='tblQueryResult']/tbody/tr[#{i}]/td/input") 
      step("Click the checkbox_icon")
    end

    i += 1  
  end

end

# wabi, omdc, timestamp
Given(/^Verify that OMD timestamp (\S+) is within (\S+) (minutes|seconds) with WABI timestamp (\S+)$/) do |ts_omd, delta, unit, ts_wabi|
  # retrive variable, and timestamp format convert
  ts_omd = @bigmap[ts_omd] if @bigmap.has_key?(ts_omd)
  ts_wabi = @bigmap[ts_wabi] if @bigmap.has_key?(ts_wabi)
  
  if not $timestamps[ts_omd]
    ts_omd = DateTime.strptime(ts_omd, '%Y-%m-%d %H:%M:%S').to_time.getlocal("+08:00")
  #   puts "ts_omd been striped #{ts_omd}"
  else
    ts_omd = $timestamps[ts_omd]
  #   puts "ts_omd been fetched #{ts_omd}"
  end
  if not $timestamps[ts_wabi]
    ts_wabi = DateTime.strptime(ts_wabi, '%Y-%m-%d %H:%M:%S').to_time.getlocal("+08:00")
  #   puts "ts_wabi been stripped #{ts_omd}"
  else
    ts_wabi = $timestamps[ts_wabi]
  #   puts "ts_wabi been fetched #{ts_wabi}"
  end

  # puts "debug: ts_omd, #{p ts_omd}, ts_wabi, #{p ts_wabi}"
  # puts "debug: ts #{ts_wabi.strftime("%s")}, #{ts_omd.strftime("%s")}"
  # puts "debug: ts.to_i #{ts_wabi.strftime("%s").to_i}, #{ts_omd.strftime("%s").to_i}"
  if ts_wabi.strftime("%s").to_i < ts_omd.strftime("%s").to_i
    puts "ts_wabi #{ts_wabi} is earlier than ts_omd #{ts_omd}"
  else
    if unit == "minutes"
      if ts_wabi.strftime("%s").to_i - ts_omd.strftime("%s").to_i < 60 * delta.to_i
        puts "ts_wabi #{ts_wabi} - ts_omd #{ts_omd} is #{ts_wabi.strftime("%s").to_i - ts_omd.strftime("%s").to_i} seconds, less than #{delta} minutes"
      else
        raise "ts_wabi #{ts_wabi} - ts_omd #{ts_omd} is #{ts_wabi.strftime("%s").to_i - ts_omd.strftime("%s").to_i} seconds, exceed #{delta} minutes"
      end
    elsif unit == "seconds"
      if ts_wabi.strftime("%s").to_i - ts_omd.strftime("%s").to_i < delta.to_i
        puts "ts_wabi #{ts_wabi} - ts_omd #{ts_omd} is #{ts_wabi.strftime("%s").to_i - ts_omd.strftime("%s").to_i} seconds, less than #{delta} seconds"
      else
        raise "ts_wabi #{ts_wabi} - ts_omd #{ts_omd} is #{ts_wabi.strftime("%s").to_i - ts_omd.strftime("%s").to_i} seconds, exceed #{delta} seconds"
      end
    else
      raise "unknown time unit #{unit}, accept 'minutes' and 'seconds' only"
    end
  end
end

# # wabi, omdc, timestamp, tinezone
Given(/^Assign OMD-C timestamp (\S+) as real timestamp (\S+)/) do | ts_omd, ts_wabi |

  # WABIStep.add_timestamp(WabiUtil.get_timestamp(hour,min,sec),name)
  ts_omd = DateTime.strptime(process_WABI_expression(ts_omd), '%Y-%m-%d %H:%M:%S').to_time.getlocal("+08:00").to_datetime
  WABIStep.add_timestamp(WabiUtil.get_timestamp(ts_omd.hour, ts_omd.minute, ts_omd.second), ts_wabi)
  
  # $timestamps[ts_wabi] = ts_omd
end

# timestamp
Given(/^Set (\S+) as (\S+) ([\+-]) (\d+)$/) do |name, ts, op, sec|
  raise "invalid timestamp #{ts}" unless $timestamps[ts]
  ts = if op == '+'
         WabiUtil.get_timestamp_from_delta($timestamps[ts], '0', '0', sec, :inc)
       else
         WabiUtil.get_timestamp_from_delta($timestamps[ts], '0', '0', sec, :dec)
       end
  WABIStep.add_timestamp(ts, name)
end

Given(/^Set (\S+) as (\S+) ([\+-]) (\d+):(\d+)$/) do |name, ts, op, min, sec|
  raise "invalid timestamp #{ts}" unless $timestamps[ts]
  ts = if op == '+'
         WabiUtil.get_timestamp_from_delta($timestamps[ts], '0', min, sec, :inc)
       else
         WabiUtil.get_timestamp_from_delta($timestamps[ts], '0', min, sec, :dec)
       end
  WABIStep.add_timestamp(ts, name)
end

# 2015-01-01 01:01:01.000000
Given(/^Assign timestamp \[CURRENT_DATE \+ (\d+):(\d+):(\d+)\] as (\S+)$/) do |hour, min, sec, name|
  date_string = Time.now.strftime("%Y-%m-%d")
  ts   = WabiUtil.get_timestamp_from_delta(Time.parse("#{date_string}"), hour, min, sec, :inc)
  v1 = ts.strftime("%Y-%m-%d %H:%M:%S.%6N")
  v2 = name
  @bigmap["#{v2}"] = "#{v1}"
  puts "#{v2}=#{@bigmap[v2.to_s]}"
end

# 15-01-01T01:01:01
Given(/^Assign timestamp \[CURRENT_DATE \+ T \+ (\d+):(\d+):(\d+)\] as (\S+)$/) do |hour, min, sec, name|
  date_string = Time.now.strftime("%Y-%m-%d")
  ts   = WabiUtil.get_timestamp_from_delta(Time.parse("#{date_string}"), hour, min, sec, :inc)
  v1 = ts.strftime("%y-%m-%dT%H:%M:%S")
  v2 = name
  @bigmap["#{v2}"] = "#{v1}"
  puts "#{v2}=#{@bigmap[v2.to_s]}"
end



# compare MMDH SeqNum and InternalSeqNum
Given(/^OMD check (any|each) value of (\w+) ([<>=]) (\w+):$/) do |any_or_each, left, operator, right, table|
  # puts "@bigmap is #{@bigmap}"

  for row in table.hashes
    for column_name in row.keys()
      if @bigmap.has_key?(row[column_name])
        row[column_name] = @bigmap[row[column_name]]
      end
      # row[column_name] = row[column_name].to_i
    end
  end

# puts "
#parameter passed in:
# any_or_each: #{any_or_each}
# left: #{left}
# operator: #{operator}
# right: #{right}
# table: #{table.hashes}
# "

  pass = true
  if any_or_each == "any"
    # pass = true

    left_column = table.hashes.map{|row| row[left]}.select{|x| not /^ *$/.match(x) and x != nil }
    if left_column.select{|x| not /^[0-9]+$/.match(x)}.any?
      raise "invalid value found in compare, could only compare digits, #{table.hashes}"
    end
    left_column = left_column.map{|x| x.to_i}

    right_column = table.hashes.map{|row| row[right]}.select{|x| not /^ *$/.match(x) and x != nil }
    if right_column.select{|x| not /^[0-9]+$/.match(x)}.any?
      raise "invalid value found in compare, could only compare digits, #{table.hashes}"
    end
    right_column = right_column.map{|x| x.to_i}

    if operator == "<"
      if not left_column.max < right_column.min
        #puts "Verify failed, #{left}.max #{left_column.max} if not smaller than #{right}.min #{right_column.min}"
        pass = pass & false
        raise "Verify failed, #{left}.max #{left_column.max} if not smaller than #{right}.min #{right_column.min}"
      end
    elsif operator == ">"
      if not left_column.min > right_column.max
        #puts "Verify failed, #{left}.min #{left_column.min} if not greater than #{right}.max #{right_column.max}"
        pass = pass & false
        raise "Verify failed, #{left}.min #{left_column.min} if not greater than #{right}.max #{right_column.max}"
      end
    else
      #puts "Verify failed, operator #{operator} not allowed, use < or > only"
      pass = pass & false
      raise "Verify failed, operator #{operator} not allowed, use < or > only"
    end
  elsif any_or_each == "each"
    # pass = true
    for row in table.hashes
      if operator == "<"
        if not row[left] < row[right]
          #puts "Verify failed, at row #{row}, #{left} #{row[left]} is not smaller than #{right} #{row[right]}"
          pass = pass & false
          raise "Verify failed, at row #{row}, #{left} #{row[left]} is not smaller than #{right} #{row[right]}"
        end
      elsif operator == "="
        if not row[left] == row[right]
          #puts "Verify failed, at row #{row}, #{left} #{row[left]} is not equal to #{right} #{row[right]}"
          pass = pass & false
          raise "Verify failed, at row #{row}, #{left} #{row[left]} is not equal to #{right} #{row[right]}"
        end
      elsif operator == ">"
        if not row[left] > row[right]
          #puts "Verify failed, at row #{row}, #{left} #{row[left]} is not greater than #{right} #{row[right]}"
          pass = pass & false
          raise "Verify failed, at row #{row}, #{left} #{row[left]} is not greater than #{right} #{row[right]}"
        end
      end
    end
  end

  if pass
    puts "Verify sucessfully, all value in #{left} #{operator} all value in #{right}"
  # else
    # puts "Verify failed"
    # raise "fail"
  end
end
Given(/^Check timestamp (\S+)/) do |ts1|

#puts "@bigmap is #{@bigmap}"
#puts "$timestamp is #{$timestamps}"

puts "@bigmap.has_key?(ts1) #{@bigmap.has_key?(ts1)}"
puts "$timestamps.has_key?(ts1) #{$timestamps.has_key?(ts1)}"

puts "The timestamp in bigmap required is #{@bigmap[ts1]}"
puts "The timestamp in timestamps required is #{$timestamps[ts1]}"

end




Given(/^Check if the trade time (\S+) match with real transaction time (\S+)/) do |ts_omd, ts_fix|

ts_omd = @bigmap[ts_omd] if @bigmap.has_key?(ts_omd)
ts_fix = @bigmap[ts_fix] if @bigmap.has_key?(ts_fix)

ts_omd_t = DateTime.strptime(ts_omd, '%Y-%m-%d %H:%M:%S.%N').to_time
ts_fix_t = DateTime.strptime(ts_fix, '%Y%m%d-%H:%M:%S.%N').to_time

	if ts_omd_t - ts_fix_t == 0
		puts "The trade time #{ts_omd} is fully matched with real transaction time #{ts_fix}"
	else
		raise "The trade time #{ts_omd} is different from real transaction time #{ts_fix}"
	end
end


Given(/^Change trading status of Security (.*?) to (.*?)$/) do |security, status|
security = WabiUtil.get_value(@bigmap, security)
puts "Security Code: #{security}"
puts "Target status: #{status}"
	if status =~ /.*Halt.*/
    #* Login to OTP-C Admin
		steps %{
			* Wait 1 seconds
			* Click the PageAdmin_RT
			* Wait 2 seconds
			* Click the InitiateAction_MenuButton
			* Wait 1 seconds
			* Verify the PageAdmin_PageName with "Initiate Action"
			* Wait 2 seconds
			* Input the #{security} to InitiateAction_Input_ActListCode
			* Wait 1 seconds
			* Click the InitiateAction_Add_Button
			* Copy table SearchField_ResultTable to FullResultTable
			* Wait 1 seconds
			* The result table column 1 "Action List Code" contains #{security}
			* Wait 1 seconds
			* Select the InitiateAction_OptList_Action with #{status}
			* Wait 1 seconds
			* Click the PageAdmin_SubmitButton
			* Wait 1 seconds
			* Click the PageAdmin_SubmitButton
			}
	else
    # * Login to OTP-C Admin
		steps %{
			* Wait 1 seconds
			* Click the PageAdmin_RT
			* Wait 2 seconds
			* Click the InitiateAction_MenuButton
			* Wait 1 seconds
			* Verify the PageAdmin_PageName with "Initiate Action"
			* Wait 2 seconds
			* Input the #{security} to InitiateAction_Input_ActListCode
			* Wait 1 seconds
			* Click the InitiateAction_Add_Button
			* Copy table SearchField_ResultTable to FullResultTable
			* Wait 1 seconds
			* The result table column 1 "Action List Code" contains #{security}
			* Wait 1 seconds
			* Select the InitiateAction_OptList_Action with #{status}
			* Wait 1 seconds
			* Select the InitiateAction_OptList_TradeResume_ApplyImmediately with Yes
			* Wait 1 seconds
			* Click the PageAdmin_SubmitButton
			* Wait 1 seconds
			* Click the PageAdmin_SubmitButton
			}
	end
end

Given(/^Search trade with BrokerNo (.*?), SecCode (.*?), CPBrokerNo (.*?), OrderSide (.*?)$/) do | broker_number, security_code, counterparty_brokder_number, side |
  
  # fetch WABI defined templates

	broker_number = WabiUtil.get_value(@bigmap, broker_number)
	security_code = WabiUtil.get_value(@bigmap, security_code)
	counterparty_brokder_number = WabiUtil.get_value(@bigmap, counterparty_brokder_number)
    side = WabiUtil.get_value(@bigmap, side)

    puts "broker_number: #{broker_number}"
    puts "security_code: #{security_code}"
    puts "counterparty_brokder_number: #{counterparty_brokder_number}"
    puts "side: #{side}"

	broker_number = ("00000" + broker_number.to_s).to_s
	broker_number = broker_number[(broker_number.length() -5), 5]
    puts "broker_number: #{broker_number}"
  #* Login to OTP-C Admin
  steps %{
   
   * Wait 1 seconds
   * Click the PageAdmin_HomeButton
   * Wait 1 seconds
   * Click the PageAdmin_RT
   * Wait 1 seconds
   * Click the CxlBrokerTrades_MenuButton
   * Wait 2 seconds
   * Input the #{broker_number} to SearchField_BrokerID
   * Wait 1 seconds
   * Click the SearchField_SearchButton
   * Wait 1 second
   * Select record from search table SearchField_ResultTable with #{broker_number} and NavBar_PageNext
   * Wait 1 second   
   * Verify the CxlBrokerTrades_Display_BrokerNo with #{broker_number}
   * Wait 2 seconds
   * Input the #{security_code} to CxlBrokerTrades_Input_SecCode
   * Wait 1 seconds
   * Input the #{counterparty_brokder_number} to CxlBrokerTrades_Input_CPBrokerNo
   * Wait 1 second   
   * Select the CxlBrokerTrades_OptList_OrderSide with #{side}
   * Wait 1 second   

   * Click the SearchField_SearchButton
   * Wait 1 second   
   }
   
end

Given(/^Cancel trade with Price (.*?) and Qty (.*?)$/) do | expected_price, expected_qty |

   # * Approve the submit request and the request is accepted   
  expected_price = WabiUtil.get_value(@bigmap, expected_price)
  expected_qty = WabiUtil.get_value(@bigmap, expected_qty)
  steps %{
   * Wait 1 seconds
   * Tick trade checkboxs whose column 6 is #{expected_price} and column 7 is #{expected_qty} and column 10 is  at table CxlBrokerTrades_TradeTable 	
   * Wait 1 seconds
   * Click the PageAdmin_SubmitButton
  }

end


#Given(/^Tick trade checkboxs whose ((column (.*?) is (.*?) ?(?:and|,)? ?)+) at table (.*?)$/) do |all_pattern, _, _, _, target_table|
Given(/^Tick trade checkboxs whose ([\S :|,]+) at table (.*?)$/) do |all_pattern, target_table|
  html_doc = Nokogiri::HTML(Browser.find_element(@driver, @object_hash, @object_acc, target_table).attribute('innerHTML'))
  i = 1

  html_doc.xpath('//tbody/tr').each do | table_row |
    # puts "table_row: #{table_row}"
    row_match = true
    
    # split multiple pattern
   # all_pattern.scan(/column (\S+) is (\S+)/).each do | at_column, expected_value |
     all_pattern.split("and").each do | pair |
		at_column = /column (\d+)/.match(pair.split("is")[0].strip)[1]
        expected_value = pair.split("is")[1].strip
      puts "checking at column: #{at_column}"
      table_row.xpath("./td[#{at_column}]").each do | cell_data |
        puts "checking at row #{i}, column #{at_column}, cell_data: #{cell_data.content.strip}, expected_value: #{expected_value}"
        row_match &= cell_data.content.strip == process_WABI_expression(expected_value)
      end

    end
    puts "at row #{i}, row_match: #{row_match}"

    if row_match
      puts "checking //table[@id='tblQueryResult']/tbody/tr#{if i == 1 then "" else "[#{i}]" end}/td/label/input"
      # step("Load object checkbox_icon from xpath //table[@id='tblQueryResult']/tbody/tr#{if i == 1 then "" else "[#{i}]" end}/td/label/input") 
      step("Load object checkbox_icon from xpath //table[@id='tblQueryResult']/tbody/tr[#{i}]/td/label/input") 
      step("Click the checkbox_icon")
    end

    i += 1  
  end

end


#Real Time Update Preset Trading State functions
Given (/^Check (\S+?) trading state is (\S+?) (\S+?)$/) do |marketsegment,curtradingseeiontype,curtradestate|
  steps %{
   * Wait 5 second
   * Click the PageAdmin_HomeButton  
   * Click the PageAdmin_RT
   * Click the UpdPreTradingState_MenuButton
   * Select the UpdPreTradingState_OptList_MarketSegment with #{marketsegment}
   * Verify the UpdPreTradingState_Display_Current_TradSessionType with #{curtradingseeiontype}
   * Verify the UpdPreTradingState_Display_Current_TradState with #{curtradestate}

  }
end


# Wait for trading state CAS MA
Given /^Wait for (\w+) trading state change to CAS MA$/ do |marketsegment|

  30.times do
	  steps %{
        * Click the PageAdmin_HomeButton  
        * Click the PageAdmin_RT
        * Click the UpdPreTradingState_MenuButton
        * Select the UpdPreTradingState_OptList_MarketSegment with #{marketsegment}
		* Copy the UpdPreTradingState_Display_Current_TradSessionType to tradtype
	    * Copy the UpdPreTradingState_Display_Current_TradState to tradstate
	  }
	  
	  if (@bigmap["tradtype"] == "CAS" && @bigmap["tradstate"] == "MA")
	     puts "trading state changed to CAS MA already"
	     break
	  elsif (@bigmap["tradtype"] == "CAS" && @bigmap["tradstate"] == "RC")
	     steps %{
	     * Wait 120 seconds for response with note ("check trading state each 2 mins")
	     }
	  else
	     raise "trading state is not CAS RC"
	  end
  end
  
end


# Split a value with header characters
Given(/^Split off first (\d+) characters of string value (\S+) to (\S+)$/) do |times, v1, v2|
  v1_string = @bigmap[v1] if @bigmap.has_key?(v1)
  puts "#{v1}=\"#{v1_string}\""
  v2_string = v1_string.gsub(/^.{#{times}}/,'')
  puts "#{v2}=\"#{v2_string}\""
  @bigmap[v2] = v2_string
end
