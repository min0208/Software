Given /^Get the enquiry time (.*?) and should be current time$/ do |obj|
  ts = Time.now
  current = ts.strftime("%H:%M:%S")
  step "Verify the #{obj} with #{current}"
end

Given /^Capture screenshot (.*?) to (.*?)$/ do |filename,folder|
  ts = Time.now
  date = ts.strftime("%y%m%d")
  step "Screenshot to #{filename}_#{date} in #{folder}/#{date}"
end


Given /^The date (.*?) has been lapsed$/ do |var|
  date = @bigmap[var]
  unless Date.parse(date) < Date.today
    raise "#{date} is future date"
  end
  puts "#{date} has been lapsed"
end


Given /^Dates (.*?) and (.*?) are equal$/ do |var1,var2|
  date1 = @bigmap[var1]
  date2 = @bigmap[var2]
  
  unless Date.parse(date1) == Date.parse(date2)
    raise "#{date1} and #{date2} are not equal"
  end
  
  puts "#{date1} and #{date2} are equal"
end


Given /^The date (.*?) is earlier than (.*?)$/ do |var1,var2|
  date1 = @bigmap[var1]
  date2 = @bigmap[var2]
  
  unless Date.parse(date1) < Date.parse(date2)
    raise "#{date1} is not earlier than #{date2}"
  end
  puts "#{date1} is earlier than #{date2}"
end


# Get some days later time, e.g. can be used when need to input Security Delisting Date.
Given (/^Get (\d+) days later time to (\w+)$/) do |num,var|
   ts = Time.now + (num.to_i*86400)
   @bigmap[var] = ts.strftime("%F")
end


# For waiting scenarios that needs to wait till next day
Given (/^Wait till next day (.*?)$/) do |var|
   steps %{
   * Wait till 23:59:00
   * Wait 1000 seconds
   * Wait till time
   }
end
