# Verify OTPCAdmin_OTPCSYSTST-157 - when invalid username and password, the approve not be blocked.
Given /^OTPCAdmin_OTPCSYSTST_Edit-157 (\S+) (\S+) (\S+)$/ do |obj1,obj2,var|
 Description1=DateTime.parse(Time.now.to_s).strftime('%Y-%m-%d %H:%M:%S').to_s
  steps %{
   * Login to OTP-C Admin
   * Click the PageAdmin_DF
   }
   if (var.to_i == 0)
	steps %{
    * Click the #{obj1}
	}
   else
	steps %{
		* Click the MaintainExchangeParameter_MenuButton
		* Click the #{obj1}
	}
   end
   steps %{
	   * Click the SearchField_SearchButton
	   * Click the Search_ResultRow1
	   * Click the PageAdmin_EditButton
	   * Input the #{Description1} to #{obj2}
	   * Click the PageAdmin_SubmitButton
	   * Input the "!@#$D%^&*()_+32rfesf{}|":><?Jhbgssa51851w541f" to Approval_ApprovalID
	   * Input the "!@#$D%^&*()_+{}|":><?Jhbgssa51851w541f" to Approval_ApprovalPW
	   * Click the PageAdmin_ApproveSubmit
	   * Wait 1 second
	   * Click the ErrorMsg_OKButton  
	   * Approve the submit request and the request is accepted
   }
end
# Verify OTPCAdmin_OTPCFUAT_661 - Cancel Button Function on Edit/Approve page
Given /^Goto edit page of the (\S+) which on the (\S+)$/ do |obj,var|
   steps %{
   * Login to OTP-C Admin
   * Click the PageAdmin_DF
   }
	case var
		when "FirstLevelMenu"
		steps %{
			* Click the #{obj}
			}
		when "MaintainExchangeParameter_MenuButton"
		steps %{
			* Click the MaintainExchangeParameter_MenuButton
			* Click the #{obj}
			}
		when "MaintainTASSPRINTSChange_MenuButton"
		steps %{
			* Click the MaintainTASSPRINTSChange_MenuButton
			* Click the #{obj}
			}
	end
	case obj
		when "MaintainGlobalParameters_MenuButton","MaintainSecurityIDRange_MenuButton","MaintainTradingSupportFacility_MenuButton","MaintainSSAllowedPerOrdType_MenuButton"
			steps %{
			* Click the PageAdmin_EditButton
			}
		when "ReportGeneration_MenuButton"
			puts "This Function have not Edit Button"
		else 
			steps %{
			* Click the SearchField_SearchButton
			* Wait 1 second
			* Click the Search_ResultRow1
			* Wait 1 second
			* Click the PageAdmin_EditButton
			}
	end

end
Given /^Re-goto edit page of the (\S+)$/ do |obj|
	case obj
		when "MaintainGlobalParameters_MenuButton","MaintainSecurityIDRange_MenuButton","MaintainTradingSupportFacility_MenuButton","MaintainSSAllowedPerOrdType_MenuButton"
			steps %{
			* Click the PageAdmin_EditButton
			}
		when "ReportGeneration_MenuButton"
			steps %{
			* Click the ReportGeneration_MenuButton
			}
		else 
			steps %{
			* Click the SearchField_SearchButton
			* Wait 1 second
			* Click the Search_ResultRow1
			* Click the PageAdmin_EditButton
			}
	end
end
Given /^Update the (\S+) on the (\S+)$/ do |obj1,obj2|
Description1=DateTime.parse(Time.now.to_s).strftime('%Y-%m-%d %H:%M:%S').to_s
	case obj2
			when "MaintainCGClient_MenuButton"
				steps %{
					* Input the Xx123456 to #{obj1}
				}
			when "MaintainGlobalParameters_MenuButton","MaintainTradingSupportFacility_MenuButton"
				steps %{
					* Input the 99999 to #{obj1}
				}
			when "MaintainThrottle_MenuButton"
				steps %{
					* Input the 9 to #{obj1}
				}
			when "ReportGeneration_MenuButton","MaintainSecurityIDRange_MenuButton"		
				steps %{
					* Click the #{obj1}
				}
			when "MaintainCalendar_MenuButton"
				steps %{
					* Select the #{obj1} with "D - Deleted"
				}
			when "MaintainSSAllowedPerOrdType_MenuButton"
				steps %{
					* Select the MaintainSSAllowPerOrdType_OptList_ELO with "N - No"
					* Select the MaintainSSAllowPerOrdType_OptList_LO with "N - No"
					* Select the MaintainSSAllowPerOrdType_OptList_SLO with "N - No"
					* Select the MaintainSSAllowPerOrdType_OptList_AO with "N - No"
					* Select the MaintainSSAllowPerOrdType_OptList_ALO with "N - No"
					* Select the MaintainSSAllowPerOrdType_OptList_ALO with "N - No"
					* Select the MaintainSSAllowPerOrdType_OptList_Quote with "N - No"
				}
				
			else
				steps %{
				* Input the #{Description1} to #{obj1}
				}
	end
end
# Check whether "CancelButton" of Edit or create page can work normally.
Given /^Verify CancelButton Function of edit or create page on the (\S+)$/ do |obj|
steps %{
		* Click the PageAdmin_CancelButton
		* Click the PageAdmin_Warning_No
		* Wait 1 second
		* Verify the PageAdmin_SubmitButton existing
		* Click the PageAdmin_CancelButton
		* Goto the popup
		* Verify the Approval_Warning with "Pressing Cancel will abort the request and all previous input will be LOST!"
		* Click the ErrorMsg_OKButton
		}
		case obj
	   		when "MaintainGlobalParameters_MenuButton","MaintainSecurityIDRange_MenuButton","MaintainTradingSupportFacility_MenuButton","MaintainSSAllowedPerOrdType_MenuButton"
				steps %{
					* Verify the PageAdmin_EditButton existing
					}
			when "ReportGeneration_MenuButton"
				steps %{
					* Verify the ReportGeneration_MenuButton existing
					}
			else
				steps %{
				* Verify the SearchField_SearchButton existing
				}
			end	
end
# Check whether "CancelButton" of approve page can work normally.
Given /^Verify CancelButton Function of approve page on the (\S+)$/ do |obj|
steps %{
		* Click the PageAdmin_SubmitButton
		* Input the otpcAdmin_approver_username to Approval_ApprovalID
		* Input the otpcAdmin_approver_password to Approval_ApprovalPW
		* Click the PageAdmin_ApproveCancel
		* Click the PageAdmin_Warning_No
		* Wait 1 second
		* Verify the PageAdmin_ApproveSubmit existing
		* Click the PageAdmin_ApproveCancel
		* Goto the popup
		* Verify the Approval_Warning with "Pressing Cancel will abort the request and all previous input will be LOST!"
		* Click the ErrorMsg_OKButton
		* Wait 2 second
		}
		case obj
	   		when "MaintainGlobalParameters_MenuButton","MaintainSecurityIDRange_MenuButton","MaintainTradingSupportFacility_MenuButton"
				steps %{
					* Verify the PageAdmin_EditButton existing
					}
			when "MaintainSSAllowedPerOrdType_MenuButton"
				steps %{
					* Verify the PageAdmin_SubmitButton existing
					}
			when "ReportGeneration_MenuButton"
				steps %{
					* Verify the ReportGeneration_Item1 existing
					}
			else
				steps %{
				* Verify the SearchField_SearchButton existing
				}
		end		
end

##Choose a option on Table when value matched
#Given /^Choose the (\S+) on row (\S+) of Table$/ do |obj,var|
#  i = 1
#  puts var.to_i / 10
#	while i <= var.to_i / 10
#		Browser.click_element(@driver, @object_hash, @object_acc, "navbtnNext")
#		i+=1
#	end
#	Browser.click_element(@driver, @object_hash, @object_acc, obj)
#end
# Approve the request and into similar page
Given /^Approve the request and into similar page$/ do
  steps %{
   * Input the df_otpcAdmin_approver_username to Approval_ApprovalID
   * Input the df_otpcAdmin_approver_password to Approval_ApprovalPW
   * Click the PageAdmin_SubmitButton
   * Wait 1 second
   * Click the Approval_SimilarButton   
  }
end
# Generated all Report which listed in Function "Report Generation" of OTP-C Admin
Given /^Generate All Trading Report which list in table when (\S+) pages$/ do |var|
	EffectiveDate1=DateTime.parse(Time.now.to_s).strftime('%d/%m/%Y').to_s
	ReportDes=Array.new
	reportcount = 0
	a=Array.new
	b=Array.new
	x=["reportIdRadio_0","reportIdRadio_1","reportIdRadio_2","reportIdRadio_3","reportIdRadio_4","reportIdRadio_5","reportIdRadio_6","reportIdRadio_7","reportIdRadio_8","reportIdRadio_9"]
	i = 1
	for i in 1..var.to_i
		if i>1 then
			k=1
			while k<i 
				Browser.click_element(@driver, @object_hash, @object_acc, "navbtnNext")
				count_click=1
				k+=1
				sleep 1
			end
		end
		steps %{
			* Wait 1 second
			* Copy table SearchField_ResultTable to FullResultTable
			* Wait 1 second
			}
			count=0
			ReportDes.clear # => []
			@bigmap['FullResultTable'].each do |row|
				ReportDes.push(row[1])
				count += 1
			end
		j=0
		for j in 0..count-1 do
			if i>1 and count_click!=1 then
				k=1
				while k<i 
					Browser.click_element(@driver, @object_hash, @object_acc, "navbtnNext")
					k+=1
					sleep 1
				end
			end
			Browser.click_element(@driver, @object_hash, @object_acc, x[j])
			steps %{
				* Wait 1 second
				* Click the PageAdmin_SubmitButton
				* Wait 1 second
				}
				element = Browser.find_element(@driver, @object_hash, @object_acc, "PageAdmin_SubmitButton")
				boolvalue = element.attribute('data-ng-click')
				if boolvalue != "approvalCtrl.onSubmit()" then
					puts "This Report need to input Effective Date information when generated on OTP-C Admin"
					steps %{
						* Wait 1 second
						* Input the #{EffectiveDate1} to EffectiveDate
						* Wait 1 second
						* Click the PageAdmin_SubmitButton
					}
				end
				a=ReportDes[j].split("(R")
				b=a[1].split(")")
				steps %{	
					* Wait 1 second
					* Input the df_otpcAdmin_approver_username to Approval_ApprovalID
					* Input the df_otpcAdmin_approver_password to Approval_ApprovalPW
					* Click the PageAdmin_SubmitButton
				}
				nowtime=(Time.now).to_s
				reportname="R"+b[0]+"-"+DateTime.parse(nowtime).strftime('%Y%m%d').to_s+"-"+DateTime.parse(nowtime).strftime('%H%M').to_s
				steps %{
					* Wait 1 second
					* Click the Approval_SimilarButton   
		
				}		
				puts "#{ReportDes[j]} - Generate Report Successfully on UI! "
				steps %{
					* Wait 2 second
					* Generated report #{reportname} to itopsm3
				}
				reportcount+=1
				j+=1
				count_click=0
				$logger.info "#{ReportDes[j]} - Generate Report Successfully! "
		end	
		i+=1
	end
	puts "Function 'Generate Report' total generated #{reportcount} reports successfully."
	$logger.info "Function 'Report Generation' total generated #{reportcount} reports successfully." # this information will be printed when run script on debug
end
# Removed attribute of object.
Given(/^Remove Attribute style of the (\S+)$/) do |obj|
		@driver.execute_script("#{@object_hash[obj]}.removeAttribute('style')")

end
# upload file.
Given(/^upload file$/) do 
	adFileUpload = Browser.find_element(@driver, @object_hash, @object_acc, "uploadDataFile")
	filePath = "/home/jenkins/Desktop/workspace/WEB Test Execution Independence II/features/serial/TestData/uploadBroker_Modify_normal_logic_linux_20170905.csv"
	adFileUpload.send_Keys(filePath)
end
# Change two fields value on a page of OTP-C Admin
Given (/^SetValue (.*?) for the (.*?) and SetValue (.*?) for the (.*?)$/)  do |label1,object1,label2,object2|
  element1 = Browser.find_element(@driver, @object_hash, @object_acc, object1)
  element2 = Browser.find_element(@driver, @object_hash, @object_acc, object2)
  var1 = element1.attribute('innerHTML')
  var2 = element2.attribute('innerHTML')
  expect_value1 = WabiUtil.get_value(@bigmap, label1)
  expect_value2 = WabiUtil.get_value(@bigmap, label2)
  if var1 =~ /<option value="(.*)" label="#{label1}" selected="selected">#{label1}<\/option>/ and var2 =~ /<option value="(.*)" label="#{label2}" selected="selected">#{label2}<\/option>/ then
	puts "#{label1} is selected"
	puts "#{label2} is selected"
  else 
	if var1 =~ /<option selected="selected" label="#{expect_value1}" value="(.*)">#{expect_value1}<\/option>/ and var2 =~ /<option selected="selected" label="#{expect_value2}" value="(.*)">#{expect_value2}<\/option>/ then
	puts "Buy Orders Allowed? and Sell Orders Allowed? needn't to be updated!"
	steps %{
			* Click the PageAdmin_CancelButton
			* Click the ErrorMsg_OKButton
			}
	else
	steps %{
		* Select the #{object1} with #{label1}
		* Select the #{object2} with #{label2}
		* Click the PageAdmin_SubmitButton
		* Approve the submit request and the request is accepted
			}
	end
  end
end
# Change one field value on a page of OTP-C Admin
Given (/^Updated (.*?) for the (.*?)$/)  do |label,object|
  element = Browser.find_element(@driver, @object_hash, @object_acc, object)
  var = element.attribute('innerHTML')
  expect_value = WabiUtil.get_value(@bigmap, label)
  if var =~ /<option value="(.*)" label="#{label}" selected="selected">#{label}<\/option>/ then
	puts "#{label} is selected"
  else 
	if var =~ /<option selected="selected" label="#{expect_value}" value="(.*)">#{expect_value}<\/option>/ then
	puts "#{object} value has been #{label}"
	steps %{
			* Click the PageAdmin_CancelButton
			* Click the ErrorMsg_OKButton
			}
	else
	steps %{
		* Select the #{object} with #{label}
		* Click the PageAdmin_SubmitButton
		* Approve the request and into similar page
			}
	end
  end
end
# verify the content in two columns in one row
Given /^Verify_New row (\d+) column (\d+) with (.*?) and column (\d+) with (.*?)$/ do |rownum,colnum1,keyword1,colnum2,keyword2|
	#value1 = @bigmap[keyword1]
	#value2 = @bigmap[keyword2]
	value1 = WabiUtil.get_value(@bigmap, keyword1)  
	value2 = WabiUtil.get_value(@bigmap, keyword2) 
	count = 0
		steps %{
		* Copy table SearchField_ResultTable to FullResultTable
		}
	RecordValue=Array.new
	@bigmap['FullResultTable'].each do |row|
	RecordValue.push(row[1])
	count += 1
	end
if RecordValue[colnum1.to_i-1]==value1 and RecordValue[colnum2.to_i-1]==value2 then
	puts "Remain outstanding order information is correct!"
else
	puts "Remain outstanding order information is incorrect!"
end  
end
