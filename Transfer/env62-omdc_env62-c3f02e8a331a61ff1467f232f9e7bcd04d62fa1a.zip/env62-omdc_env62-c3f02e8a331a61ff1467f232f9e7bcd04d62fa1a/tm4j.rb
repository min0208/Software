require 'find'
require 'json'
require 'csv'

class TM4J
	@user = ""
	@password = ""
	@ip = ""
	@port = ""
	@search_path  = ""

	def readConf()
		confPath = ""
		if File.file?('./paraConfigTM4J.json')
			@search_path = "./"
			confPath = @search_path + 'paraConfigTM4J.json'			
		elsif File.file?('./TM4J_Ruby/paraConfigTM4J.json')
			@search_path = "./TM4J_Ruby/"
			confPath = @search_path + 'paraConfigTM4J.json'
		else
			raise "Can't find configuration file"
		end

		content   = JSON.parse(File.read(confPath))

		@user = content['USER']
		@password = content['PASSWORD']
		@ip = content['IP']
		@port = content['PORT']
		
		return [content['action'], content['cycle_id'], content['cycle_name'], content['cycle_folder'], content['project_key']]
	end

	def getCommand(type, *args)
		if type == "getCycleInfo"
			return "curl -s --basic --user %s:%s -X GET http://%s:%s/rest/atm/latest/testrun/%s" % [@user, @password, @ip, @port, args[0]]
		elsif type == "updateCase"			
			return "curl -s --basic --user %s:%s -H Content-Type:application/json --data @#{@search_path}tempFolder/updateCase.json -X PUT http://%s:%s/rest/atm/latest/testrun/%s/testcase/%s/testresult" % [@user, @password, @ip, @port, args[0], args[1]]
		elsif type == "createCase"    		
			return "curl -s --basic --user %s:%s -H Content-Type:application/json --data @#{@search_path}tempFolder/updateCase.json -X POST http://%s:%s/rest/atm/latest/testrun/%s/testcase/%s/testresult" % [@user, @password, @ip, @port, args[0], args[1]]
		elsif type == "createCycle" 		
			return "curl -s --basic --user %s:%s -H Content-Type:application/json --data @#{@search_path}tempFolder/createCycle.json -X POST http://%s:%s/rest/atm/latest/testrun" % [@user, @password, @ip, @port]
		else
			raise "Wrong command type: [#{type}]"
		end
	end

	def runCommand(str)
		return IO.popen(str).gets().to_s.strip
	end

	def getAllResultJsonFiles(path)
		arr = Array.new()

		# Find.find(path).each do |item|
		# 	if File.file?(item) and item.downcase.end_with?('.json')
		# 		arr.push(item)
		# 	end
		# end
		Find.find(path).each do |item|
			if File.file?(item) and item.downcase.end_with?('.json')
				if not /.*Nil\.json.*/.match(item)
					arr.push(item)
				end
			end
		end
		return arr
	end

	def readAllScenarioInfo(list)
		sceInfoArr = Array.new()
		for file in list
			content = JSON.parse(File.read(file))
			next if content[0].nil?
			next if content[0]['elements'].nil?

			content[0]['elements'].select{|x| x['keyword'] == 'Scenario'}.each do |scenario|
				next if scenario['tags'].nil?				

				# scenario without @CASE will be ingored
				tempArr = scenario['tags'].select{|x| x['name'].split('=')[0].strip == '@CASE'}
				if tempArr.empty?
					next
				elsif tempArr.length > 1
					raise "file:[#{file}] scenario name:[#{scenario['name']}], this case has more than 1 tag named @CASE"
				end
				case_id = tempArr[0]['name'].split('=')[1].to_s.strip

				# support 1 @CASE mapping to multiple @testCaseKey
				tempArr = scenario['tags'].select{|x| x['name'].split('=')[0].strip == '@testCaseKey'}
				if tempArr.empty?
					testCaseKeyArr = []
				else		
					testCaseKeyArr = tempArr.map{|x| x['name'].split('=')[1].to_s.strip}
				end	

				startTime = ""
				if scenario['after']
					scenario['after'].each do |tempHash|
						if tempHash['output']
							tempHash['output'].each do |output|
								if output.match(/^\[start\] \d{4}-\d{2}-\d{2}/)
									startTime = output.match(/^\[start\] (\d{4}-\d{2}-\d{2})/)[1]
									break
								end
							end
						end
						break if startTime != ""
					end
				end

				allPass = true
				tempInfo = {'case_id' => case_id, 'testCaseKey' => testCaseKeyArr, 'execute_date' => startTime, 'comment' => ""}
				scenario['steps'].each do |step|
					if step['result']['status'] != 'passed'
						tempInfo['status']  = 'Fail'
						tempInfo['comment'] = step['result']['error_message'].to_s
						allPass = false
						break
					end
				end
				if allPass
					tempInfo['status']  = 'Pass'
				end

				sceInfoArr.push(tempInfo)
			end
		end
		return sceInfoArr
	end

	def getAllCaseInfoInCycle(str)
		content = JSON.parse(str)
		return content['items'].map{|x| x['testCaseKey']}
	end

	def generateNewCycleJsonFile(cycleName, cycleFolder, projectKey, sceInfoList)	
		itemArr = Array.new()
		for sceInfo in sceInfoList
			keyValueArr = sceInfo['testCaseKey']
			caseStatus  = sceInfo['status']
			caseComment = sceInfo['comment']

			for keyValue in keyValueArr
				itemArr << {'testCaseKey' => keyValue, 'status' => caseStatus, 'comment' => caseComment}
			end
		end

		jsonDict = Hash.new()
		jsonDict["projectKey"] = projectKey
		jsonDict["name"]       = cycleName
		jsonDict["items"]      = itemArr		
		jsonDict["folder"]     = cycleFolder if cycleFolder != ""

		f = File.open(@search_path + "tempFolder/createCycle.json", "w")
		f.write(JSON.pretty_generate(jsonDict))
		f.close
	end

	def generateCaseJsonFile(caseStatus, caseComment)
		updateJson = Hash.new()

		updateJson["status"]  = caseStatus
		updateJson["comment"] = caseComment

		fp = File.open(@search_path + "tempFolder/updateCase.json", "w")
		fp.write(JSON.pretty_generate(updateJson))
		fp.close
	end

	def createTempFolder()
		path = @search_path + 'tempFolder'

		if not File.directory?(path)
			Dir.mkdir(path)
		end
	end

	def newCycle(cycleName, cycleFolder, projectKey, sceInfoList)
		jiraKeyCountInFile = 0
		sceInfoList.map{|x| x['testCaseKey']}.each{|x| x.each{jiraKeyCountInFile += 1}}

		puts "ACTION:      [New cycle]"
		puts "@CASE        count in all json file: #{sceInfoList.length}"
		puts "@testCaseKey count in all json file: #{jiraKeyCountInFile}"
		generateNewCycleJsonFile(cycleName, cycleFolder, projectKey, sceInfoList)
		
		resultStr = runCommand(getCommand("createCycle"))
		puts resultStr

		if resultStr.match(/^\{"key":".*"\}$/)
			cycle_id = resultStr.match(/^\{"key":"(.*)"\}$/)[1]
			puts "\nRESULT: Create cycle PASS, new cycle id is: [#{cycle_id}]"
		else
			puts "\nRESULT: Create new cycle FAIL"
		end
	end

	def updateCycle(str, cycle_id, sceInfoList)
		caseInfoList = getAllCaseInfoInCycle(str)

		jiraKeyCountInFile = 0
		sceInfoList.map{|x| x['testCaseKey']}.each{|x| x.each{jiraKeyCountInFile += 1}}

		puts "ACTION:      [Update cycle only]"
		puts "@CASE        count in all json file: #{sceInfoList.length}"
		puts "@testCaseKey count in all json file: #{jiraKeyCountInFile}"
		puts "JIRA keys    count in cycle #{cycle_id}: #{caseInfoList.length}"
		puts ""

		passCount = 0
		failCount = 0
		notExistCount = 0

		for sceInfo in sceInfoList
			keyValueArr = sceInfo['testCaseKey']
			caseStatus  = sceInfo['status']
			caseComment = sceInfo['comment']

			for keyValue in keyValueArr
				if caseInfoList.include?(keyValue)
					generateCaseJsonFile(caseStatus, caseComment)
					resultStr = runCommand(getCommand("updateCase", cycle_id, keyValue))
					if resultStr.match(/^\{"id":\d+\}$/)
						puts "testCaseKey:[#{keyValue}  #{caseStatus}] updated SUCCESSFULLY"
						passCount += 1
					else
						puts "testCaseKey:[#{keyValue}  #{caseStatus}] updated UNSUCCESSFULLY"
						puts resultStr
						failCount += 1
					end
				else
					puts "testCaseKey:[#{keyValue}  #{caseStatus}] not exist in JIRA cycle:[#{cycle_id}], SKIP"
					notExistCount += 1
				end
			end
		end
		puts "\nRESULT: #{passCount} updated PASS, #{failCount} updated FAIL, #{notExistCount} not exist in JIRA"
	end

	def updateCycleAndAddNewCase(str, cycle_id, sceInfoList)
		caseInfoList = getAllCaseInfoInCycle(str)		

		jiraKeyCountInFile = 0
		sceInfoList.map{|x| x['testCaseKey']}.each{|x| x.each{jiraKeyCountInFile += 1}}

		puts "ACTION:      [Update cycle and Add new case]"
		puts "@CASE        count in all json file: #{sceInfoList.length}"
		puts "@testCaseKey count in all json file: #{jiraKeyCountInFile}"
		puts "JIRA keys    count in cycle #{cycle_id}: #{caseInfoList.length}"
		puts ""

		passCountUpdate = 0
		failCountUpdate = 0
		passCountAdd = 0
		failCountAdd = 0

		for sceInfo in sceInfoList
			keyValueArr = sceInfo['testCaseKey']
			caseStatus  = sceInfo['status']
			caseComment = sceInfo['comment']

			generateCaseJsonFile(caseStatus, caseComment)

			for keyValue in keyValueArr
				if caseInfoList.include?(keyValue)					
					resultStr = runCommand(getCommand("updateCase", cycle_id, keyValue))
					if resultStr.match(/^\{"id":\d+\}$/)
						puts "testCaseKey:[#{keyValue}  #{caseStatus}] updated SUCCESSFULLY"
						passCountUpdate += 1
					else
						puts "testCaseKey:[#{keyValue}  #{caseStatus}] updated UNSUCCESSFULLY"
						puts resultStr
						failCountUpdate += 1
					end
				else
					resultStr = runCommand(getCommand("createCase", cycle_id, keyValue))
					if resultStr.match(/^\{"id":\d+\}$/)
						puts "testCaseKey:[#{keyValue}  #{caseStatus}] added SUCCESSFULLY"
						passCountAdd += 1
					else
						puts "testCaseKey:[#{keyValue}  #{caseStatus}] added UNSUCCESSFULLY"
						puts resultStr
						failCountAdd += 1
					end
				end
			end
		end
		puts "\nRESULT: #{passCountUpdate} updated PASS, #{failCountUpdate} updated FAIL, #{passCountAdd} added PASS, #{failCountAdd} added FAIL"
	end

	def countResult(plan_csv, json_result_folder, isWriteResult=true)
		fileList    = getAllResultJsonFiles(json_result_folder)
		sceInfoList = readAllScenarioInfo(fileList)

		allJiraKeyInFile = Array.new()
		sceInfoList.map{|x| x['testCaseKey']}.each do |tempArr|
			tempArr.each{|x| allJiraKeyInFile << x}
		end
		dupJiraKeys = allJiraKeyInFile.select{|x| allJiraKeyInFile.count(x) > 1}.uniq
		unless dupJiraKeys.empty?
			puts "For plan csv: [#{plan_csv}]"
			puts "For json folder: [#{json_result_folder}]"
			raise "testCaseKey #{dupJiraKeys} in json file are duplicated"
		end

		allCaseInFile = sceInfoList.map{|x| x['case_id']}
		dupCases = allCaseInFile.select{|x| allCaseInFile.count(x) > 1}.uniq
		unless dupCases.empty?
			puts "For plan csv: [#{plan_csv}]"
			puts "For json folder: [#{json_result_folder}]"
			raise "case id #{dupCases} in json file are duplicated"
		end	

		if isWriteResult
			resultHash = Hash.new()
			sceInfoList.each do |h|
				resultHash[h['case_id']] = [h['testCaseKey'], h['status'], h['execute_date']]
			end

			f_all_name = json_result_folder + '/' + File.basename(plan_csv)[0...-4] + '_result_all.csv'
			f_pass_name = json_result_folder + '/' + File.basename(plan_csv)[0...-4] + '_result_pass.csv'
			f_fail_name = json_result_folder + '/' + File.basename(plan_csv)[0...-4] + '_result_fail.csv'

			f_all = CSV.open(f_all_name, 'w')
			f_pass = CSV.open(f_pass_name, 'w')
			f_fail = CSV.open(f_fail_name, 'w')

			f_all << ["Scenario", "JIRA_Case_Key", "Status", "Execute_Date", "Env_No", "Env_Version"]
			f_pass << ['case_id', 'start_time', 'preceding_case_id', 'stop_execution_if_fail', 'env_no', 'env_version']
			f_fail << ['case_id', 'start_time', 'preceding_case_id', 'stop_execution_if_fail', 'env_no', 'env_version']

			total_count = 0
			pass_count = 0
			fail_count = 0
			File.readlines(plan_csv)[1..-1].reject{|x| x.strip[0] == '#'}.map{|x| x.strip.split(',').map{|y| y.strip}}.each do |row|
				case_id = row[0]

				tempRow = nil
				if resultHash.has_key?(case_id)
					caseHash = resultHash[case_id]
					if caseHash[1] == "Pass"
						if pass_count == 0
							f_pass << [row[0], row[1], 'Nil', row[3], row[4], row[5]]
						else
							f_pass << row
						end
						pass_count += 1					
					else
						if fail_count == 0
							f_fail << [row[0], row[1], 'Nil', row[3], row[4], row[5]]
						else
							f_fail << row
						end
						fail_count += 1
					end
					tempRow = [case_id, caseHash[0].join(', '), caseHash[1], caseHash[2], row[-2], row[-1]]
				else
					if fail_count == 0
						f_fail << [row[0], row[1], 'Nil', row[3], row[4], row[5]]
					else
						f_fail << row
					end
					fail_count += 1
					tempRow = [case_id, "Unknown", "Unknown", "Unknown", row[-2], row[-1]]
				end
				f_all << tempRow
				total_count += 1
			end

			f_all << ['', '', '', '', '', '', 'Total', 'Pass', 'Fail']
			f_all << ['', '', '', '', '', '', total_count, pass_count, fail_count]
			f_all.close()
			f_pass.close()
			f_fail.close()

			puts "Generate all result:[#{f_all_name}]"
			puts "Generate pass result:[#{f_pass_name}]"
			puts "Generate fail result:[#{f_fail_name}]"
			puts ""
		end

		return sceInfoList
	end

	def refreshCycle(sceInfoList, action, cycle_id, cycle_name, cycle_folder, project_key)
		createTempFolder()

		puts "----- JIRA start -----"
		if action == 'UpdateCaseOnly'	
			resp_cycle = runCommand(getCommand("getCycleInfo", cycle_id))	
			
			if resp_cycle.include?('projectKey') and resp_cycle.include?('testCaseCount')
				updateCycle(resp_cycle, cycle_id, sceInfoList)
			else
				puts "Failed to curl cycle id:[#{cycle_id}] info in JIRA, wrong url? wrong authrization? cycle_id not exist?"
			end
		elsif action == 'UpdateAndAddNewCase'
			resp_cycle = runCommand(getCommand("getCycleInfo", cycle_id))

			if resp_cycle.include?('projectKey') and resp_cycle.include?('testCaseCount')
				updateCycleAndAddNewCase(resp_cycle, cycle_id, sceInfoList)
			else
				puts "Failed to curl cycle id:[#{cycle_id}] info in JIRA, wrong url? wrong authrization? cycle_id not exist?"
			end
		elsif action == 'CreateNewCycle'
			newCycle(cycle_name, cycle_folder, project_key, sceInfoList)
		else
			raise "Not supported action: #{action}"
		end
		puts "----- JIRA end -----"
		puts ""
	end

	def run()
		if (ARGV.length != 3) or (ARGV[0] != 'count' and ARGV[0] != 'refresh' and ARGV[0] != 'autoJenkins')
			puts "usage:"
			puts "tm4j.rb autoJenkins BATCH_test.csv build_no_folder"
			puts "tm4j.rb autoJenkins single_test.csv build_no_folder [modify paraConfigTM4J.json first]"
			puts "tm4j.rb count BATCH_test.csv build_no_folder"
			puts "tm4j.rb count single_test.csv json_folder_path"
			puts "tm4j.rb refresh BATCH_test.csv build_no_folder"
			puts "tm4j.rb refresh null json_folder_path [modify paraConfigTM4J.json first]"
			puts "tm4j.rb refresh OMDC-C89 json_folder_path [modify paraConfigTM4J.json first]"
			exit()
		end		

		action, cycle_id, cycle_name, cycle_folder, project_key = readConf()
		method = ARGV[0]
		csvPath = ARGV[1]
		jsonFolder = ARGV[2]
		if csvPath != 'null'			
			if csvPath.match(/^OMDC-C\d+$/) # must use with 'tm4j.rb refresh' to set cycle_id
				cycle_id = csvPath
			else
				raise "csv file:[#{csvPath}] not exist" unless File.file?(csvPath)
			end
		end
		raise "json folder:[#{jsonFolder}] not exist" unless File.directory?(jsonFolder)
		jsonFolder = jsonFolder.end_with?('/') ? jsonFolder : jsonFolder + '/'		

		csvBaseFolder = File.dirname(csvPath)
		csvName = File.basename(csvPath)
		configArr = Array.new()
		if csvName.start_with?('BATCH_')
			tempArr = File.readlines(csvPath).map{|x| x.strip.split(',').map{|y| y.to_s.strip}}
			header = tempArr[0]
			tempArr[1..-1].each do |row|
				tempHash = Hash.new()
				row.each_index do |i|
					tempHash[header[i]] = row[i]
				end
				tempHash['plan_file_path'] = csvBaseFolder + '/' + tempHash['plan_file']
				tempHash['json_folder_path'] = jsonFolder + tempHash['plan_file']
				configArr.push(tempHash)
			end
		else
			tempHash = Hash.new()
			tempHash['plan_file_path'] = csvPath
			if method == 'autoJenkins'
				# tempHash['json_folder_path'] = jsonFolder + csvName
				tempHash['json_folder_path'] = jsonFolder
			else
				tempHash['json_folder_path'] = jsonFolder
			end

			tempHash['action'] = action
			tempHash['cycle_id'] = cycle_id
			tempHash['cycle_name'] = cycle_name
			tempHash['cycle_folder'] = cycle_folder
			tempHash['project_key'] = project_key
			configArr.push(tempHash)
		end

		configArr.each do |config|
			if (csvPath != 'null') and (not csvPath.match(/^OMDC-C\d+$/))
				raise "csv plan file:[#{config['plan_file_path']}] not exist" unless File.file?(config['plan_file_path'])
			end
			config['json_folder_path'] = config['json_folder_path'][0...-1] if config['json_folder_path'].end_with?('/')
			raise "json folder:[#{config['json_folder_path']}] not exist" unless File.directory?(config['json_folder_path'])
		end

		if method == 'autoJenkins'
			configArr.each do |config|
				sceInfoList = countResult(config['plan_file_path'], config['json_folder_path'])
				refreshCycle(sceInfoList, config['action'], config['cycle_id'], config['cycle_name'], config['cycle_folder'], config['project_key'])
			end
		elsif method == 'count'
			configArr.each do |config|
				countResult(config['plan_file_path'], config['json_folder_path'])
			end
		elsif method == 'refresh'
			configArr.each do |config|
				sceInfoList = countResult("none", config['json_folder_path'], false)
				refreshCycle(sceInfoList, config['action'], config['cycle_id'], config['cycle_name'], config['cycle_folder'], config['project_key'])
			end
		end
	end
end

TM4J.new().run()
